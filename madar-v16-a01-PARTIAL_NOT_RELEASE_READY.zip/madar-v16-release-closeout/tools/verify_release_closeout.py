#!/usr/bin/env python3
"""Run baseline checks, but never report an unfinished A01 contract as release-ready."""
from pathlib import Path
import contextlib
import io
import sys
ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "docs/execution/a01/baseline/verify_release_closeout.py.txt"
output = io.StringIO()
status = 0
try:
    with contextlib.redirect_stdout(output):
        exec(compile(source.read_text(), __file__, "exec"), {"__name__": "__main__", "__file__": __file__})
except SystemExit as exc:
    status = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
except Exception as exc:
    print("FAIL: baseline verifier raised " + type(exc).__name__, file=sys.stderr)
    status = 1
print(output.getvalue(), end="")
print("BLOCKED: A01 contract is IN_PROGRESS; F02-F12 are not integrated or accepted.")
print("BLOCKED: No Android/SQLCipher/device/server acceptance is certified by this package.")
raise SystemExit(1 if status not in (0, 2) else 2)

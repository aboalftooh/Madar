#!/usr/bin/env python3
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    ':core:model': ROOT / 'core/model',
    ':core:sync': ROOT / 'core/sync',
    ':feature:ledger': ROOT / 'feature/ledger',
    ':feature:auth': ROOT / 'feature/auth',
    ':feature:assets': ROOT / 'feature/assets',
    ':feature:debts': ROOT / 'feature/debts',
    ':feature:goals': ROOT / 'feature/goals',
    ':feature:reports': ROOT / 'feature/reports',
}
BANNED_IMPORTS = (
    'android.', 'androidx.', 'com.shift.app.data.', 'com.shift.app.ui.',
    'com.shift.app.viewmodel.', 'io.github.jan.', 'io.ktor.', 'net.zetetic.',
)
ALLOWED = {
    ':core:model': set(),
    ':core:sync': set(),
    ':feature:ledger': {':core:model'},
    ':feature:auth': set(),
    ':feature:assets': {':core:model'},
    ':feature:debts': {':core:model'},
    ':feature:goals': {':core:model'},
    ':feature:reports': {':core:model'},
}
errors: list[str] = []
settings = (ROOT / 'settings.gradle.kts').read_text()
for name, path in EXPECTED.items():
    if f'include("{name}")' not in settings:
        errors.append(f'missing settings include: {name}')
    if not (path / 'build.gradle.kts').is_file():
        errors.append(f'missing build file: {name}')

fqcn_owner: dict[str, str] = {}
source_roots = {':app': ROOT / 'app/src/main/java'} | {k: v / 'src/main/java' for k, v in EXPECTED.items()}
for owner, src_root in source_roots.items():
    if not src_root.exists():
        continue
    for file in src_root.rglob('*.kt'):
        text = file.read_text()
        pkg = re.search(r'^package\s+([\w.]+)', text, re.M)
        if not pkg:
            continue
        # top-level declarations are enough to catch duplicated moved classes
        for kind, name in re.findall(r'^(?:public\s+|internal\s+|private\s+)?(class|interface|object|enum\s+class|data\s+class|sealed\s+(?:class|interface))\s+(\w+)', text, re.M):
            fqcn = f'{pkg.group(1)}.{name}'
            previous = fqcn_owner.get(fqcn)
            if previous and previous != owner:
                errors.append(f'duplicate {fqcn}: {previous}, {owner}')
            fqcn_owner[fqcn] = owner
        if owner != ':app':
            for imp in re.findall(r'^import\s+([^\s]+)', text, re.M):
                if imp.startswith(BANNED_IMPORTS):
                    errors.append(f'{owner} forbidden import {imp} in {file.relative_to(ROOT)}')
                feature_match = re.match(r'com\.shift\.app\.feature\.([^.]+)\.', imp)
                if feature_match:
                    own_feature = owner.split(':')[-1] if owner.startswith(':feature:') else None
                    if own_feature != feature_match.group(1):
                        errors.append(f'{owner} cross-feature import {imp} in {file.relative_to(ROOT)}')

edges: dict[str, set[str]] = defaultdict(set)
for name, path in EXPECTED.items():
    text = (path / 'build.gradle.kts').read_text()
    for dep in re.findall(r'project\("(:[^"\)]+)"\)', text):
        edges[name].add(dep)
    illegal = edges[name] - ALLOWED[name]
    if illegal:
        errors.append(f'{name} illegal project dependencies: {sorted(illegal)}')

app_build = (ROOT / 'app/build.gradle.kts').read_text()
app_deps = set(re.findall(r'project\("(:[^"\)]+)"\)', app_build))
missing_app_deps = set(EXPECTED) - app_deps
if missing_app_deps:
    errors.append(f'app missing module dependencies: {sorted(missing_app_deps)}')
edges[':app'] = app_deps

visiting, visited = set(), set()
def visit(node: str, trail: list[str]) -> None:
    if node in visiting:
        errors.append('dependency cycle: ' + ' -> '.join(trail + [node]))
        return
    if node in visited:
        return
    visiting.add(node)
    for nxt in edges[node]:
        visit(nxt, trail + [node])
    visiting.remove(node); visited.add(node)
for node in [':app', *EXPECTED]:
    visit(node, [])

# moved packages must no longer exist in app
for rel in (
    'com/shift/app/feature/auth/domain', 'com/shift/app/feature/assets/domain',
    'com/shift/app/feature/debts/domain', 'com/shift/app/feature/goals/domain',
    'com/shift/app/feature/reports/domain', 'com/shift/app/domain/goals',
):
    if (ROOT / 'app/src/main/java' / rel).exists():
        errors.append(f'moved package still exists in app: {rel}')

checks = 0
checks += len(EXPECTED) * 2
checks += len(fqcn_owner)
checks += sum(len(list((p/'src/main/java').rglob('*.kt'))) for p in EXPECTED.values())
checks += len(EXPECTED)
if errors:
    print('\n'.join(f'FAIL: {e}' for e in errors))
    print(f'FAILED with {len(errors)} errors')
    sys.exit(1)
print(f'PASS: {checks} module-boundary checks')
print('PASS: dependency graph is acyclic')
print('PASS: no duplicate Kotlin declarations across modules')

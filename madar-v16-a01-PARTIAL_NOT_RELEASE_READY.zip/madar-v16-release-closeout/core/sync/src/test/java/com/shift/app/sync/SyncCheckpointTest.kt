package com.shift.app.sync

import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.sync.completedSyncCheckpoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncCheckpointTest {
    @Test
    fun fullSyncUsesRunStartAsCheckpoint() {
        assertEquals(100L, completedSyncCheckpoint(syncStartedAt = 100L))
    }

    @Test
    fun participantKeysAreStableAndUnique() {
        val keys = SyncCheckpointKey.entries.map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        assertTrue("Global last_sync must not be a participant", "last_sync" !in keys)
    }
}

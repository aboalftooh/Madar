package com.shift.app.sync

/** One independently owned synchronization feature. */
interface SyncParticipant {
    val key: String
    val order: Int

    suspend fun pullOperations(): List<SyncOperation>
    suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation>
    suspend fun finalizeOperations(): List<SyncOperation> = emptyList()
}

data class SyncOperation(
    val step: String,
    val checkpointKey: SyncCheckpointKey? = null,
    val execute: suspend () -> Unit,
)

package com.shift.app.sync

import kotlinx.coroutines.flow.Flow

/** Presentation-facing contract for durable synchronization requests and diagnostics. */
interface SyncQueueGateway {
    val pendingCount: Flow<Int>
    val failedCount: Flow<Int>

    suspend fun requestSync(
        reason: String,
        operationId: String = reason,
        now: Long = System.currentTimeMillis(),
    )

    fun enqueueRecovery()
}

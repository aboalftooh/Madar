package com.shift.app.sync

interface SyncCheckpointStore {
    suspend fun lastSuccessfulSync(): Long
    suspend fun setLastSuccessfulSync(value: Long)
    suspend fun setParticipantCheckpoint(key: String, value: Long)
}

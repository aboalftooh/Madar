package com.shift.app.sync

import java.util.concurrent.CancellationException

/**
 * Stable synchronization ownership keys. Each participant advances independently,
 * so one successful pull cannot hide a failed participant behind a global cursor.
 */
enum class SyncCheckpointKey(val key: String) {
    IncomeSources("income_sources"),
    ExpenseBeneficiaries("expense_beneficiaries"),
    Transactions("transactions"),
    BalanceTransactions("balance_transactions"),
    Payments("payments"),
    LedgerHistoryMigrations("ledger_history_migrations"),
    Assets("assets"),
    AssetTransactions("asset_transactions"),
    AssetValuations("asset_valuations"),
    CurrencyAssetLots("currency_asset_lots"),
    CurrencyAssetSaleAllocations("currency_asset_sale_allocations"),
    DebtLedger("debt_ledger"),
    LegacyDebts("debts"),
    FinancialGoals("financial_goals"),
    Settings("user_settings"),
}

/** Public outcome used by callers instead of relying on a broad exception. */
sealed interface SyncRunResult {
    /** Checkpoint is the run start, not the completion time, to avoid skipping writes made during sync. */
    data class Success(val checkpoint: Long) : SyncRunResult

    /** No full-sync checkpoint is advanced when any required step fails. */
    data class PartialFailure(val failedSteps: List<String>) : SyncRunResult

    data object AuthenticationRequired : SyncRunResult
}


data class SyncStepFailure(
    val step: String,
    val causeType: String,
    val error: Throwable,
)

suspend fun runIsolatedSyncStep(
    step: String,
    failures: MutableList<SyncStepFailure>,
    onFailure: (SyncStepFailure) -> Unit = {},
    block: suspend () -> Unit,
) {
    runCatching { block() }
        .onFailure { error ->
            if (error is CancellationException) throw error
            val failure = SyncStepFailure(step, error::class.java.name, error)
            failures += failure
            onFailure(failure)
        }
}

fun completedSyncCheckpoint(syncStartedAt: Long): Long = syncStartedAt


class SyncRunFailedException(val result: SyncRunResult) : IllegalStateException(
    when (result) {
        is SyncRunResult.Success -> "Synchronization succeeded"
        is SyncRunResult.PartialFailure ->
            "Synchronization failed in: ${result.failedSteps.joinToString()}"
        SyncRunResult.AuthenticationRequired -> "Authentication is required"
    },
)

fun SyncRunResult.requireSuccess(): SyncRunResult.Success = when (this) {
    is SyncRunResult.Success -> this
    else -> throw SyncRunFailedException(this)
}

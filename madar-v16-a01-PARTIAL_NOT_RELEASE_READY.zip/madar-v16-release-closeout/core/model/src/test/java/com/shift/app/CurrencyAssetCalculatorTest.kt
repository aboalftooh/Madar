package com.shift.app

import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CurrencyAssetCalculatorTest {
    private val lots = listOf(
        lot("lot-1", "500", "175000", "2026-01-01", 1L),
        lot("lot-2", "300", "126000", "2026-02-01", 2L)
    )

    @Test
    fun firstPartialSale_usesOldestLotOnly() {
        val plan = CurrencyAssetCalculator.allocateFifo(lots, emptyList(), "200")

        assertEquals("800.00000000", plan.availableBeforeDecimal)
        assertEquals("600.00000000", plan.availableAfterDecimal)
        assertEquals("70000.00", plan.allocatedLocalCostDecimal)
        assertEquals(listOf("lot-1"), plan.allocations.map { it.lotId })
        assertEquals("200.00000000", plan.allocations.single().quantitySoldDecimal)
    }

    @Test
    fun laterSale_consumesRemainderThenNextLot() {
        val previous = listOf(allocation("lot-1", "200", "70000"))
        val plan = CurrencyAssetCalculator.allocateFifo(lots, previous, "400")

        assertEquals(listOf("lot-1", "lot-2"), plan.allocations.map { it.lotId })
        assertEquals(listOf("300.00000000", "100.00000000"), plan.allocations.map { it.quantitySoldDecimal })
        assertEquals(listOf("105000.00", "42000.00"), plan.allocations.map { it.allocatedLocalCostDecimal })
        assertEquals("147000.00", plan.allocatedLocalCostDecimal)
        assertEquals("200.00000000", plan.availableAfterDecimal)
    }

    @Test
    fun exactFullSale_isAllowedAndLeavesZero() {
        val plan = CurrencyAssetCalculator.allocateFifo(lots, emptyList(), "800")

        assertEquals("0.00000000", plan.availableAfterDecimal)
        assertEquals("301000.00", plan.allocatedLocalCostDecimal)
    }

    @Test
    fun oversell_isRejectedBeforeDraftsAreReturned() {
        assertThrows(IllegalArgumentException::class.java) {
            CurrencyAssetCalculator.allocateFifo(lots, emptyList(), "800.00000001")
        }
    }

    @Test
    fun softDeletedAllocation_doesNotReduceAvailableQuantity() {
        val deleted = allocation("lot-1", "500", "175000", deletedAt = 10L)
        assertEquals("800.00000000", CurrencyAssetCalculator.availableQuantity(lots, listOf(deleted)))
    }

    @Test
    fun finalFractionReceivesRoundingRemainder() {
        val smallLot = listOf(lot("lot", "3", "10", "2026-01-01", 1L))
        val previous = listOf(
            allocation("lot", "1", "3.33"),
            allocation("lot", "1", "3.33")
        )
        val plan = CurrencyAssetCalculator.allocateFifo(smallLot, previous, "1")

        assertEquals("3.34", plan.allocations.single().allocatedLocalCostDecimal)
    }

    @Test
    fun sameDateOrdering_isDeterministicByCreatedAtThenId() {
        val sameDate = listOf(
            lot("b", "1", "20", "2026-01-01", 2L),
            lot("c", "1", "30", "2026-01-01", 1L),
            lot("a", "1", "10", "2026-01-01", 1L)
        )
        val plan = CurrencyAssetCalculator.allocateFifo(sameDate, emptyList(), "2")

        assertEquals(listOf("a", "c"), plan.allocations.map { it.lotId })
    }

    private fun lot(id: String, quantity: String, cost: String, date: String, createdAt: Long) =
        CurrencyLotSnapshot(id, quantity, cost, date, createdAt)

    private fun allocation(
        lotId: String,
        quantity: String,
        cost: String,
        deletedAt: Long? = null
    ) = CurrencyAllocationSnapshot(lotId, quantity, cost, deletedAt)
}

package com.shift.app

import com.shift.app.domain.finance.FinancialOperationKind
import com.shift.app.domain.finance.FinancialRules
import com.shift.app.domain.finance.PaymentKind
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialRulesTest {
    @Test
    fun expenseReports_areDerivedOnlyFromPaymentKind() {
        assertTrue(FinancialRules.entersExpenseReports(PaymentKind.OrdinaryExpense))
        assertTrue(FinancialRules.entersExpenseReports(PaymentKind.AssetMaintenance))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetPurchase))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetImprovement))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.BalanceWithdrawal))
    }

    @Test
    fun operationImpact_incomeAffectsBalanceAndIncomeOnly() {
        val impact = FinancialRules.impact(FinancialOperationKind.Income)

        assertTrue(impact.affectsBalance)
        assertTrue(impact.entersIncome)
        assertFalse(impact.appearsInPayments)
        assertFalse(impact.entersExpenses)
        assertFalse(impact.affectsAsset)
        assertTrue(impact.requiresAtomicOperation)
    }

    @Test
    fun operationImpact_assetPurchaseAffectsBalancePaymentsAndAssetButNotExpenses() {
        val impact = FinancialRules.impact(FinancialOperationKind.AssetPurchase)

        assertTrue(impact.affectsBalance)
        assertTrue(impact.appearsInPayments)
        assertTrue(impact.affectsAsset)
        assertFalse(impact.entersExpenses)
        assertFalse(impact.entersIncome)
        assertTrue(impact.requiresAtomicOperation)
    }

    @Test
    fun operationImpact_assetMaintenanceEntersExpensesAndAffectsAsset() {
        val impact = FinancialRules.impact(FinancialOperationKind.AssetMaintenance)

        assertTrue(impact.affectsBalance)
        assertTrue(impact.appearsInPayments)
        assertTrue(impact.entersExpenses)
        assertTrue(impact.affectsAsset)
        assertFalse(impact.entersIncome)
        assertTrue(impact.requiresAtomicOperation)
    }

    @Test
    fun operationImpact_assetValuationDoesNotAffectBalanceOrPayments() {
        val impact = FinancialRules.impact(FinancialOperationKind.AssetValuation)

        assertFalse(impact.affectsBalance)
        assertFalse(impact.appearsInPayments)
        assertFalse(impact.entersExpenses)
        assertTrue(impact.affectsAsset)
        assertFalse(impact.entersIncome)
        assertTrue(impact.requiresAtomicOperation)
    }

    @Test
    fun operationImpact_manualWithdrawalAffectsBalanceAndPaymentsButNotExpenses() {
        val impact = FinancialRules.impact(FinancialOperationKind.ManualBalanceWithdrawal)

        assertTrue(impact.affectsBalance)
        assertTrue(impact.appearsInPayments)
        assertFalse(impact.entersExpenses)
        assertFalse(impact.affectsAsset)
        assertFalse(impact.entersIncome)
        assertTrue(impact.requiresAtomicOperation)
    }
}

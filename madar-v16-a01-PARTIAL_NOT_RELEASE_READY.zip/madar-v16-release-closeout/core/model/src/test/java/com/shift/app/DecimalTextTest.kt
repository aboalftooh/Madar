package com.shift.app

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.math.BigDecimal

class DecimalTextTest {
    @Test
    fun canonical_roundsMoneyToTwoPlaces() {
        assertEquals("10.24", DecimalText.canonical("10.235", DecimalTextScale.Money))
        assertEquals("10.23", DecimalText.canonical("10.234", DecimalTextScale.Money))
    }

    @Test
    fun canonical_roundsExchangeRateAndQuantityToEightPlaces() {
        assertEquals("350.12345679", DecimalText.canonical("350.123456789", DecimalTextScale.ExchangeRate))
        assertEquals("2.00000001", DecimalText.canonical("2.000000005", DecimalTextScale.Quantity))
    }

    @Test
    fun canonicalPositive_rejectsZeroAndNegativeValues() {
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonicalPositive("0", DecimalTextScale.Money)
        }
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonicalPositive("-1", DecimalTextScale.Money)
        }
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonicalPositive("0.000000001", DecimalTextScale.Quantity)
        }
    }

    @Test
    fun canonicalNonNegative_acceptsZeroAndRejectsNegativeValues() {
        assertEquals("0.00", DecimalText.canonicalNonNegative("0", DecimalTextScale.Money))
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonicalNonNegative("-0.01", DecimalTextScale.Money)
        }
    }

    @Test
    fun invalidDecimalTextThrows() {
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonical("", DecimalTextScale.Money)
        }
        assertThrows(IllegalArgumentException::class.java) {
            DecimalText.canonical("not-number", DecimalTextScale.Money)
        }
    }

    @Test
    fun legacyDoubleConversionUsesMoneyScale() {
        assertEquals("12.35", DecimalText.moneyFromLegacyDouble(12.345))
    }

    @Test
    fun toBigDecimalParsesCanonicalText() {
        assertEquals(BigDecimal("12.30"), DecimalText.toBigDecimal("12.30"))
    }
}

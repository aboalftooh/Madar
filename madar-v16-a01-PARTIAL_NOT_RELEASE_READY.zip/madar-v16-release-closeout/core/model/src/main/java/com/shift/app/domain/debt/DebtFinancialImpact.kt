package com.shift.app.domain.debt

data class DebtFinancialImpact(
    val balanceDeltaDecimal: String = "0.00",
    val assetDeltaDecimal: String = "0.00",
    val receivableDeltaDecimal: String = "0.00",
    val payableDeltaDecimal: String = "0.00",
    val earnedIncomeDecimal: String = "0.00",
    val collectedIncomeDecimal: String = "0.00",
    val expenseDecimal: String = "0.00",
    val wealthAdjustmentDecimal: String = "0.00",
    val entersOrdinaryIncome: Boolean = false,
    val entersOrdinaryExpense: Boolean = false,
    val requiresBalanceEnabled: Boolean = false,
    val externalCashWarning: Boolean = false,
    val family: DebtFamily,
    val flow: DebtUserFlow
) {
    val affectsCash: Boolean get() = balanceDeltaDecimal != "0.00"
    val affectsWealth: Boolean
        get() = balanceDeltaDecimal != "0.00" ||
            assetDeltaDecimal != "0.00" ||
            receivableDeltaDecimal != "0.00" ||
            payableDeltaDecimal != "0.00" ||
            wealthAdjustmentDecimal != "0.00"
}

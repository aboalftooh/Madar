package com.shift.app.domain.debt

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal
import java.math.RoundingMode

data class DebtCalculationResult(
    val remainingDecimal: String,
    val status: DebtAccountStatus,
    val confirmedReceivableDecimal: String,
    val confirmedPayableDecimal: String
)

object DebtCalculator {
    fun remaining(transactions: List<DebtTransactionInput>): String {
        val total = transactions
            .filterNot { it.isVoided }
            .fold(BigDecimal.ZERO) { acc, tx ->
                val signed = when (tx.type) {
                    DebtTransactionType.Reversal -> reversalDelta(tx, transactions)
                    DebtTransactionType.Correction -> BigDecimal.ZERO
                    else -> tx.amount.value.multiply(BigDecimal(tx.type.remainingSign))
                }
                acc + signed
            }
            .setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP)
        return total.max(BigDecimal.ZERO).toPlainString()
    }

    fun calculate(account: DebtAccountSnapshot): DebtCalculationResult {
        val remaining = DecimalText.toBigDecimal(remaining(account.transactions))
        val status = when {
            !account.confirmed -> DebtAccountStatus.NeedsReview
            account.archived -> DebtAccountStatus.Archived
            remaining.compareTo(BigDecimal.ZERO) == 0 -> DebtAccountStatus.Settled
            else -> DebtAccountStatus.Open
        }
        val remainingText = remaining.setScale(2).toPlainString()
        return DebtCalculationResult(
            remainingDecimal = remainingText,
            status = status,
            confirmedReceivableDecimal = if (account.confirmed && account.direction == DebtDirection.Receivable) remainingText else "0.00",
            confirmedPayableDecimal = if (account.confirmed && account.direction == DebtDirection.Payable) remainingText else "0.00"
        )
    }

    fun assertCanReduce(account: DebtAccountSnapshot, amount: DebtMoney) {
        val remaining = DecimalText.toBigDecimal(remaining(account.transactions))
        require(amount.value > BigDecimal.ZERO) { "Reduction amount must be positive" }
        require(amount.value <= remaining) { "Amount must not exceed remaining debt" }
    }

    fun assertSameDirection(accounts: List<DebtAccountSnapshot>) {
        require(accounts.isNotEmpty()) { "At least one account is required" }
        val direction = accounts.first().direction
        require(accounts.all { it.direction == direction }) { "Debt organization requires matching directions" }
    }

    fun assertSingleCurrency(accounts: List<DebtAccountSnapshot>) {
        require(accounts.isNotEmpty()) { "At least one account is required" }
        val currencyCode = accounts.first().currencyCode
        require(accounts.all { it.currencyCode == currencyCode }) { "Debt operations require a single local currency" }
    }

    private fun reversalDelta(
        reversal: DebtTransactionInput,
        allTransactions: List<DebtTransactionInput>
    ): BigDecimal {
        val originalId = reversal.originalTransactionId ?: return BigDecimal.ZERO
        val original = allTransactions.firstOrNull { it.id == originalId } ?: return BigDecimal.ZERO
        return original.amount.value
            .multiply(BigDecimal(original.type.remainingSign))
            .negate()
    }
}

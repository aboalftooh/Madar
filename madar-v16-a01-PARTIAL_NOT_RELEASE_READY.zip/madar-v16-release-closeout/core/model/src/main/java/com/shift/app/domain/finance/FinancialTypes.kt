package com.shift.app.domain.finance

enum class BalanceDirection(val dbValue: String) {
    Inflow("inflow"),
    Outflow("outflow")
}

enum class BalanceTransactionKind(val dbValue: String, val direction: BalanceDirection) {
    Income("income", BalanceDirection.Inflow),
    ManualAdd("manual_add", BalanceDirection.Inflow),
    AssetSale("asset_sale", BalanceDirection.Inflow),
    OpeningBalance("opening_balance", BalanceDirection.Inflow),
    OpeningBalanceAdjustment("opening_balance_adjustment", BalanceDirection.Inflow),
    ExpensePayment("expense_payment", BalanceDirection.Outflow),
    AssetPurchase("asset_purchase", BalanceDirection.Outflow),
    AssetImprovement("asset_improvement", BalanceDirection.Outflow),
    AssetMaintenance("asset_maintenance", BalanceDirection.Outflow),
    ManualWithdrawal("manual_withdrawal", BalanceDirection.Outflow)
}

enum class PaymentKind(val dbValue: String) {
    OrdinaryExpense("ordinary_expense"),
    AssetPurchase("asset_purchase"),
    AssetImprovement("asset_improvement"),
    AssetMaintenance("asset_maintenance"),
    BalanceWithdrawal("balance_withdrawal"),
    DebtGift("debt_gift")
}

enum class AssetStatus(val dbValue: String) {
    Active("active"),
    Sold("sold"),
    Lost("lost"),
    Damaged("damaged"),
    Disposed("disposed"),
    Transferred("transferred"),
    Archived("archived")
}

enum class AssetTransactionKind(val dbValue: String) {
    Purchase("purchase"),
    PreexistingAdd("preexisting_add"),
    Improvement("improvement"),
    Maintenance("maintenance"),
    SaleFull("sale_full"),
    SalePartial("sale_partial"),
    Lost("lost"),
    Damaged("damaged"),
    Disposed("disposed"),
    Transferred("transferred"),
    Archived("archived"),
    Reversal("reversal")
}

enum class SyncState(val dbValue: String) {
    Pending("pending"),
    Synced("synced"),
    Failed("failed"),
    Conflict("conflict"),
    IncompleteRemote("incomplete_remote")
}

enum class FinancialOperationKind {
    Income,
    ManualBalanceAdd,
    OrdinaryExpense,
    AssetPurchase,
    PreexistingAssetAdd,
    AssetImprovement,
    AssetMaintenance,
    AssetValuation,
    AssetSale,
    CurrencyPartialSale,
    ManualBalanceWithdrawal,
    AssetLost,
    AssetTransfer,
    Reversal
}

package com.shift.app.domain.debt

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal

enum class DebtDirection(val dbValue: String) {
    Payable("payable"),
    Receivable("receivable");

    companion object {
        fun fromDb(value: String): DebtDirection =
            entries.firstOrNull { it.dbValue == value }
                ?: throw IllegalArgumentException("Unknown debt direction: $value")
    }
}

enum class DebtAccountStatus {
    Draft,
    Open,
    Settled,
    Archived,
    NeedsReview
}

enum class DebtReviewStatus(val dbValue: String) {
    Pending("pending"),
    Approved("approved"),
    Rejected("rejected"),
    Resolved("resolved")
}

enum class DebtCashSource(val dbValue: String) {
    MadarBalance("madar_balance"),
    External("external"),
    None("none")
}

enum class DebtFamily {
    F01Opening,
    F02CashBorrowLend,
    F03DeferredExpense,
    F04AccruedIncome,
    F05FinancedAsset,
    F06AssetSettlement,
    F07PaymentCollection,
    F08Adjustment,
    F09ReversalCorrection,
    F10Organization
}

enum class DebtUserFlow {
    UF1Create,
    UF2Increase,
    UF3CompositeCreate,
    UF4Pay,
    UF5Collect,
    UF6Settle,
    UF7Organize,
    UF8Migrate
}

enum class DebtTransactionType(val dbValue: String, val remainingSign: Int) {
    Opening("opening", 1),
    Increase("increase", 1),
    Payment("payment", -1),
    Collection("collection", -1),
    Waiver("waiver", -1),
    WriteOff("write_off", -1),
    GiftConversion("gift_conversion", -1),
    Offset("offset", -1),
    AssetSettlement("asset_settlement", -1),
    SplitOut("split_out", -1),
    SplitIn("split_in", 1),
    MergeOut("merge_out", -1),
    MergeIn("merge_in", 1),
    TransferOut("transfer_out", -1),
    TransferIn("transfer_in", 1),
    Reversal("reversal", 0),
    Correction("correction", 0);

    companion object {
        fun fromDb(value: String): DebtTransactionType =
            entries.firstOrNull { it.dbValue == value }
                ?: throw IllegalArgumentException("Unknown debt transaction type: $value")
    }
}

data class DebtMoney(val decimalText: String) {
    val value: BigDecimal = DecimalText.toBigDecimal(decimalText)

    init {
        require(value >= BigDecimal.ZERO) { "Debt amount must not be negative" }
        require(value.scale() <= DecimalTextScale.Money.places) { "Debt amount must be money-scale canonical text" }
    }

    operator fun plus(other: DebtMoney): DebtMoney = of(value + other.value)
    operator fun minus(other: DebtMoney): DebtMoney = of(value - other.value)

    companion object {
        val Zero = DebtMoney("0.00")

        fun of(raw: String): DebtMoney =
            DebtMoney(DecimalText.canonicalNonNegative(raw, DecimalTextScale.Money))

        fun of(value: BigDecimal): DebtMoney =
            DebtMoney(value.setScale(DecimalTextScale.Money.places).toPlainString())
    }
}

data class DebtTransactionInput(
    val id: String,
    val accountId: String,
    val operationId: String,
    val type: DebtTransactionType,
    val amount: DebtMoney,
    val occurredAtEpochMillis: Long,
    val reason: String? = null,
    val originalTransactionId: String? = null,
    val isVoided: Boolean = false
)

data class DebtAccountSnapshot(
    val accountId: String,
    val direction: DebtDirection,
    val partyName: String,
    val currencyCode: String,
    val confirmed: Boolean,
    val archived: Boolean,
    val transactions: List<DebtTransactionInput>
)

package com.shift.app.domain.finance

data class OperationImpact(
    val affectsBalance: Boolean,
    val appearsInPayments: Boolean,
    val entersExpenses: Boolean,
    val affectsAsset: Boolean,
    val entersIncome: Boolean,
    val requiresAtomicOperation: Boolean,
    val mirrorsOriginalOperation: Boolean = false
)

object FinancialRules {
    fun entersExpenseReports(kind: PaymentKind): Boolean =
        kind == PaymentKind.OrdinaryExpense || kind == PaymentKind.AssetMaintenance || kind == PaymentKind.DebtGift

    fun impact(kind: FinancialOperationKind): OperationImpact =
        when (kind) {
            FinancialOperationKind.Income -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = false,
                entersIncome = true,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.ManualBalanceAdd -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = false,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.OrdinaryExpense -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = true,
                entersExpenses = true,
                affectsAsset = false,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetPurchase -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = true,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.PreexistingAssetAdd -> OperationImpact(
                affectsBalance = false,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetImprovement -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = true,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetMaintenance -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = true,
                entersExpenses = true,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetValuation -> OperationImpact(
                affectsBalance = false,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetSale,
            FinancialOperationKind.CurrencyPartialSale -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.ManualBalanceWithdrawal -> OperationImpact(
                affectsBalance = true,
                appearsInPayments = true,
                entersExpenses = false,
                affectsAsset = false,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetLost -> OperationImpact(
                affectsBalance = false,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.AssetTransfer -> OperationImpact(
                affectsBalance = false,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = true,
                entersIncome = false,
                requiresAtomicOperation = true
            )

            FinancialOperationKind.Reversal -> OperationImpact(
                affectsBalance = false,
                appearsInPayments = false,
                entersExpenses = false,
                affectsAsset = false,
                entersIncome = false,
                requiresAtomicOperation = true,
                mirrorsOriginalOperation = true
            )
        }
}

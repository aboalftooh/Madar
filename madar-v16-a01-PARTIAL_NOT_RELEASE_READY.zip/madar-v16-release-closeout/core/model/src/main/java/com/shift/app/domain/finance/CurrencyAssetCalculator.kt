package com.shift.app.domain.finance

import java.math.BigDecimal
import java.math.RoundingMode

data class CurrencyLotSnapshot(
    val id: String,
    val quantityPurchasedDecimal: String,
    val localCostDecimal: String,
    val purchaseDate: String,
    val createdAt: Long,
    val deletedAt: Long? = null
)

data class CurrencyAllocationSnapshot(
    val lotId: String,
    val quantitySoldDecimal: String,
    val allocatedLocalCostDecimal: String,
    val deletedAt: Long? = null
)

data class CurrencyLotBalance(
    val lotId: String,
    val quantityPurchasedDecimal: String,
    val quantitySoldDecimal: String,
    val quantityRemainingDecimal: String,
    val localCostRemainingDecimal: String
)

data class FifoAllocationDraft(
    val lotId: String,
    val quantitySoldDecimal: String,
    val allocatedLocalCostDecimal: String
)

data class CurrencySalePlan(
    val requestedQuantityDecimal: String,
    val availableBeforeDecimal: String,
    val availableAfterDecimal: String,
    val allocatedLocalCostDecimal: String,
    val allocations: List<FifoAllocationDraft>
)

object CurrencyAssetCalculator {
    fun lotBalances(
        lots: List<CurrencyLotSnapshot>,
        allocations: List<CurrencyAllocationSnapshot>
    ): List<CurrencyLotBalance> {
        val activeAllocations = allocations.filter { it.deletedAt == null }.groupBy { it.lotId }
        return lots
            .filter { it.deletedAt == null }
            .sortedWith(compareBy<CurrencyLotSnapshot> { it.purchaseDate }.thenBy { it.createdAt }.thenBy { it.id })
            .map { lot ->
                val purchased = positiveQuantity(lot.quantityPurchasedDecimal)
                val localCost = nonNegativeMoney(lot.localCostDecimal)
                val lotAllocations = activeAllocations[lot.id].orEmpty()
                val sold = lotAllocations.fold(BigDecimal.ZERO) { total, item ->
                    total + positiveQuantity(item.quantitySoldDecimal)
                }
                val allocatedCost = lotAllocations.fold(BigDecimal.ZERO) { total, item ->
                    total + nonNegativeMoney(item.allocatedLocalCostDecimal)
                }
                val remaining = purchased - sold
                val remainingCost = localCost - allocatedCost
                require(remaining >= BigDecimal.ZERO) { "Allocated quantity exceeds purchased quantity for lot ${lot.id}" }
                require(remainingCost >= BigDecimal.ZERO) { "Allocated cost exceeds local cost for lot ${lot.id}" }
                CurrencyLotBalance(
                    lotId = lot.id,
                    quantityPurchasedDecimal = quantityText(purchased),
                    quantitySoldDecimal = quantityText(sold),
                    quantityRemainingDecimal = quantityText(remaining),
                    localCostRemainingDecimal = moneyText(remainingCost)
                )
            }
    }

    fun availableQuantity(
        lots: List<CurrencyLotSnapshot>,
        allocations: List<CurrencyAllocationSnapshot>
    ): String = quantityText(
        lotBalances(lots, allocations).fold(BigDecimal.ZERO) { total, lot ->
            total + DecimalText.toBigDecimal(lot.quantityRemainingDecimal)
        }
    )

    fun allocateFifo(
        lots: List<CurrencyLotSnapshot>,
        existingAllocations: List<CurrencyAllocationSnapshot>,
        quantityToSellDecimal: String
    ): CurrencySalePlan {
        val requested = positiveQuantity(quantityToSellDecimal)
        val balancesById = lotBalances(lots, existingAllocations).associateBy { it.lotId }
        val orderedLots = lots
            .filter { it.deletedAt == null }
            .sortedWith(compareBy<CurrencyLotSnapshot> { it.purchaseDate }.thenBy { it.createdAt }.thenBy { it.id })
        val available = balancesById.values.fold(BigDecimal.ZERO) { total, lot ->
            total + DecimalText.toBigDecimal(lot.quantityRemainingDecimal)
        }
        require(requested <= available) { "الكمية المطلوبة أكبر من الكمية المتاحة" }

        var needed = requested
        val drafts = buildList {
            for (lot in orderedLots) {
                if (needed.signum() == 0) break
                val balance = requireNotNull(balancesById[lot.id])
                val remainingQuantity = DecimalText.toBigDecimal(balance.quantityRemainingDecimal)
                if (remainingQuantity.signum() == 0) continue
                val take = needed.min(remainingQuantity)
                val purchased = positiveQuantity(lot.quantityPurchasedDecimal)
                val localCost = nonNegativeMoney(lot.localCostDecimal)
                val remainingCost = DecimalText.toBigDecimal(balance.localCostRemainingDecimal)
                val allocatedCost = if (take.compareTo(remainingQuantity) == 0) {
                    remainingCost
                } else {
                    localCost.multiply(take)
                        .divide(purchased, DecimalTextScale.Money.places, RoundingMode.HALF_UP)
                        .min(remainingCost)
                }
                add(
                    FifoAllocationDraft(
                        lotId = lot.id,
                        quantitySoldDecimal = quantityText(take),
                        allocatedLocalCostDecimal = moneyText(allocatedCost)
                    )
                )
                needed -= take
            }
        }
        check(needed.signum() == 0) { "FIFO allocation did not satisfy the requested quantity" }
        val allocatedCost = drafts.fold(BigDecimal.ZERO) { total, item ->
            total + DecimalText.toBigDecimal(item.allocatedLocalCostDecimal)
        }
        return CurrencySalePlan(
            requestedQuantityDecimal = quantityText(requested),
            availableBeforeDecimal = quantityText(available),
            availableAfterDecimal = quantityText(available - requested),
            allocatedLocalCostDecimal = moneyText(allocatedCost),
            allocations = drafts
        )
    }

    private fun positiveQuantity(value: String): BigDecimal =
        DecimalText.toBigDecimal(DecimalText.canonicalPositive(value, DecimalTextScale.Quantity))

    private fun nonNegativeMoney(value: String): BigDecimal =
        DecimalText.toBigDecimal(DecimalText.canonicalNonNegative(value, DecimalTextScale.Money))

    private fun quantityText(value: BigDecimal): String =
        value.setScale(DecimalTextScale.Quantity.places, RoundingMode.HALF_UP).toPlainString()

    private fun moneyText(value: BigDecimal): String =
        value.setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()
}

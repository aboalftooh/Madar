package com.shift.app.domain.finance

import java.math.BigDecimal
import java.math.RoundingMode

enum class DecimalTextScale(val places: Int) {
    Money(2),
    ExchangeRate(8),
    Quantity(8)
}

object DecimalText {
    fun canonical(raw: String, scale: DecimalTextScale): String =
        parse(raw).setScale(scale.places, RoundingMode.HALF_UP).toPlainString()

    fun canonicalPositive(raw: String, scale: DecimalTextScale): String {
        val value = parse(raw).setScale(scale.places, RoundingMode.HALF_UP)
        require(value > BigDecimal.ZERO) { "Value must be greater than zero after rounding" }
        return value.toPlainString()
    }

    fun canonicalNonNegative(raw: String, scale: DecimalTextScale): String {
        val value = parse(raw)
        require(value >= BigDecimal.ZERO) { "Value must not be negative" }
        return value.setScale(scale.places, RoundingMode.HALF_UP).toPlainString()
    }

    fun moneyFromLegacyDouble(amount: Double): String =
        BigDecimal.valueOf(amount).setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()

    fun toBigDecimal(decimalText: String): BigDecimal = parse(decimalText)

    private fun parse(raw: String): BigDecimal {
        val normalized = raw.trim()
        require(normalized.isNotEmpty()) { "Decimal text must not be blank" }
        return normalized.toBigDecimalOrNull()
            ?: throw IllegalArgumentException("Invalid decimal text")
    }
}

package com.shift.app.domain.debt

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal

data class DebtOperationDraft(
    val operationId: String,
    val accountId: String,
    val direction: DebtDirection,
    val partyName: String,
    val transaction: DebtTransactionInput,
    val impact: DebtFinancialImpact,
    val requiresExplicitFullLiabilityConfirmation: Boolean = false,
    val requiresReason: Boolean = false
)

object DebtOperationFactory {
    fun opening(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        amount: String,
        occurredAtEpochMillis: Long,
        flow: DebtUserFlow = DebtUserFlow.UF1Create
    ): DebtOperationDraft {
        require(partyName.isNotBlank()) { "Debt account requires a party" }
        val money = DebtMoney.of(amount)
        require(money.value > BigDecimal.ZERO) { "Opening amount must be positive" }
        return draft(
            operationId, accountId, direction, partyName,
            DebtTransactionType.Opening, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                receivableDeltaDecimal = if (direction == DebtDirection.Receivable) money.decimalText else "0.00",
                payableDeltaDecimal = if (direction == DebtDirection.Payable) money.decimalText else "0.00",
                family = DebtFamily.F01Opening,
                flow = flow
            )
        )
    }

    fun cashPrincipal(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        amount: String,
        cashSource: DebtCashSource,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val money = DebtMoney.of(amount)
        val balanceDelta = when {
            cashSource != DebtCashSource.MadarBalance -> "0.00"
            direction == DebtDirection.Payable -> money.decimalText
            else -> negate(money.decimalText)
        }
        return draft(
            operationId, accountId, direction, partyName,
            DebtTransactionType.Increase, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                balanceDeltaDecimal = balanceDelta,
                receivableDeltaDecimal = if (direction == DebtDirection.Receivable) money.decimalText else "0.00",
                payableDeltaDecimal = if (direction == DebtDirection.Payable) money.decimalText else "0.00",
                requiresBalanceEnabled = cashSource == DebtCashSource.MadarBalance,
                externalCashWarning = cashSource == DebtCashSource.External,
                family = DebtFamily.F02CashBorrowLend,
                flow = DebtUserFlow.UF2Increase
            )
        )
    }

    fun deferredExpense(
        operationId: String,
        accountId: String,
        partyName: String,
        amount: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val money = DebtMoney.of(amount)
        return draft(
            operationId, accountId, DebtDirection.Payable, partyName,
            DebtTransactionType.Increase, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                payableDeltaDecimal = money.decimalText,
                expenseDecimal = money.decimalText,
                entersOrdinaryExpense = true,
                family = DebtFamily.F03DeferredExpense,
                flow = DebtUserFlow.UF3CompositeCreate
            )
        )
    }

    fun accruedIncome(
        operationId: String,
        accountId: String,
        partyName: String,
        amount: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val money = DebtMoney.of(amount)
        return draft(
            operationId, accountId, DebtDirection.Receivable, partyName,
            DebtTransactionType.Increase, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                receivableDeltaDecimal = money.decimalText,
                earnedIncomeDecimal = money.decimalText,
                entersOrdinaryIncome = true,
                family = DebtFamily.F04AccruedIncome,
                flow = DebtUserFlow.UF3CompositeCreate
            )
        )
    }

    fun financedAsset(
        operationId: String,
        accountId: String,
        partyName: String,
        financedAmount: String,
        assetValue: String,
        cashPaid: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val debt = DebtMoney.of(financedAmount)
        val asset = DebtMoney.of(assetValue)
        val paid = DebtMoney.of(cashPaid)
        return draft(
            operationId, accountId, DebtDirection.Payable, partyName,
            DebtTransactionType.Increase, debt, occurredAtEpochMillis,
            DebtFinancialImpact(
                balanceDeltaDecimal = negate(paid.decimalText),
                assetDeltaDecimal = asset.decimalText,
                payableDeltaDecimal = debt.decimalText,
                family = DebtFamily.F05FinancedAsset,
                flow = DebtUserFlow.UF3CompositeCreate,
                requiresBalanceEnabled = paid.value > BigDecimal.ZERO
            ),
            requiresExplicitFullLiabilityConfirmation = true
        )
    }

    fun assetSettlement(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        amount: String,
        assetValue: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val money = DebtMoney.of(amount)
        val asset = DebtMoney.of(assetValue)
        val assetDelta = if (direction == DebtDirection.Payable) negate(asset.decimalText) else asset.decimalText
        return draft(
            operationId, accountId, direction, partyName,
            DebtTransactionType.AssetSettlement, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                assetDeltaDecimal = assetDelta,
                receivableDeltaDecimal = if (direction == DebtDirection.Receivable) negate(money.decimalText) else "0.00",
                payableDeltaDecimal = if (direction == DebtDirection.Payable) negate(money.decimalText) else "0.00",
                wealthAdjustmentDecimal = canonical(asset.value - money.value),
                family = DebtFamily.F06AssetSettlement,
                flow = DebtUserFlow.UF6Settle
            )
        )
    }

    fun cashReduction(
        operationId: String,
        account: DebtAccountSnapshot,
        amount: String,
        cashSource: DebtCashSource,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        val money = DebtMoney.of(amount)
        DebtCalculator.assertCanReduce(account, money)
        val type = if (account.direction == DebtDirection.Payable) DebtTransactionType.Payment else DebtTransactionType.Collection
        val balanceDelta = when {
            cashSource != DebtCashSource.MadarBalance -> "0.00"
            account.direction == DebtDirection.Payable -> negate(money.decimalText)
            else -> money.decimalText
        }
        return draft(
            operationId, account.accountId, account.direction, account.partyName,
            type, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                balanceDeltaDecimal = balanceDelta,
                receivableDeltaDecimal = if (account.direction == DebtDirection.Receivable) negate(money.decimalText) else "0.00",
                payableDeltaDecimal = if (account.direction == DebtDirection.Payable) negate(money.decimalText) else "0.00",
                requiresBalanceEnabled = cashSource == DebtCashSource.MadarBalance,
                externalCashWarning = cashSource == DebtCashSource.External,
                family = DebtFamily.F07PaymentCollection,
                flow = if (account.direction == DebtDirection.Payable) DebtUserFlow.UF4Pay else DebtUserFlow.UF5Collect
            )
        )
    }

    fun adjustment(
        operationId: String,
        account: DebtAccountSnapshot,
        type: DebtTransactionType,
        amount: String,
        reason: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        require(type in setOf(DebtTransactionType.Waiver, DebtTransactionType.WriteOff, DebtTransactionType.GiftConversion, DebtTransactionType.Offset)) {
            "Unsupported adjustment type"
        }
        require(reason.isNotBlank()) { "Adjustment reason is required" }
        val money = DebtMoney.of(amount)
        DebtCalculator.assertCanReduce(account, money)
        return draft(
            operationId, account.accountId, account.direction, account.partyName,
            type, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                receivableDeltaDecimal = if (account.direction == DebtDirection.Receivable) negate(money.decimalText) else "0.00",
                payableDeltaDecimal = if (account.direction == DebtDirection.Payable) negate(money.decimalText) else "0.00",
                expenseDecimal = if (type == DebtTransactionType.GiftConversion) money.decimalText else "0.00",
                wealthAdjustmentDecimal = if (type == DebtTransactionType.Offset) "0.00" else negate(money.decimalText),
                family = DebtFamily.F08Adjustment,
                flow = DebtUserFlow.UF6Settle
            ),
            reason = reason,
            requiresReason = true
        )
    }

    fun organization(
        operationId: String,
        account: DebtAccountSnapshot,
        type: DebtTransactionType,
        amount: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        require(type in setOf(DebtTransactionType.SplitOut, DebtTransactionType.SplitIn, DebtTransactionType.MergeOut, DebtTransactionType.MergeIn, DebtTransactionType.TransferOut, DebtTransactionType.TransferIn)) {
            "Unsupported organization type"
        }
        val money = DebtMoney.of(amount)
        return draft(
            operationId, account.accountId, account.direction, account.partyName,
            type, money, occurredAtEpochMillis,
            DebtFinancialImpact(family = DebtFamily.F10Organization, flow = DebtUserFlow.UF7Organize)
        )
    }

    fun reversal(
        operationId: String,
        account: DebtAccountSnapshot,
        originalTransactionId: String,
        amount: String,
        reason: String,
        occurredAtEpochMillis: Long
    ): DebtOperationDraft {
        require(originalTransactionId.isNotBlank()) { "Original transaction id is required" }
        require(reason.isNotBlank()) { "Reversal reason is required" }
        val money = DebtMoney.of(amount)
        return draft(
            operationId, account.accountId, account.direction, account.partyName,
            DebtTransactionType.Reversal, money, occurredAtEpochMillis,
            DebtFinancialImpact(
                family = DebtFamily.F09ReversalCorrection,
                flow = DebtUserFlow.UF7Organize
            ),
            reason = reason,
            requiresReason = true
        ).let { draft ->
            draft.copy(
                transaction = draft.transaction.copy(originalTransactionId = originalTransactionId)
            )
        }
    }

    private fun draft(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        type: DebtTransactionType,
        money: DebtMoney,
        occurredAtEpochMillis: Long,
        impact: DebtFinancialImpact,
        requiresExplicitFullLiabilityConfirmation: Boolean = false,
        requiresReason: Boolean = false,
        reason: String? = null
    ): DebtOperationDraft {
        require(operationId.isNotBlank()) { "operationId is required" }
        require(accountId.isNotBlank()) { "accountId is required" }
        require(partyName.isNotBlank()) { "Debt account requires a party" }
        require(money.value > BigDecimal.ZERO || type in setOf(DebtTransactionType.Correction, DebtTransactionType.Reversal)) {
            "Debt transaction amount must be positive"
        }
        return DebtOperationDraft(
            operationId = operationId,
            accountId = accountId,
            direction = direction,
            partyName = partyName.trim(),
            transaction = DebtTransactionInput(
                id = "$operationId:${type.dbValue}",
                accountId = accountId,
                operationId = operationId,
                type = type,
                amount = money,
                occurredAtEpochMillis = occurredAtEpochMillis,
                reason = reason
            ),
            impact = impact,
            requiresExplicitFullLiabilityConfirmation = requiresExplicitFullLiabilityConfirmation,
            requiresReason = requiresReason
        )
    }

    private fun negate(decimalText: String): String =
        canonical(DecimalText.toBigDecimal(decimalText).negate())

    private fun canonical(value: BigDecimal): String =
        value.setScale(DecimalTextScale.Money.places).toPlainString()
}

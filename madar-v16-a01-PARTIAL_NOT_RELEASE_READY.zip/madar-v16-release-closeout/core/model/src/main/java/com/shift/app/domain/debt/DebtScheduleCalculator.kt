package com.shift.app.domain.debt

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

data class DebtScheduleDraft(
    val installmentNo: Int,
    val dueDate: String,
    val amountDecimal: String
)

object DebtScheduleCalculator {
    fun equalInstallments(totalAmountDecimal: String, firstDueDate: String, count: Int, monthlyStep: Long = 1): List<DebtScheduleDraft> {
        require(count > 0) { "Schedule count must be positive" }
        val total = DebtMoney.of(totalAmountDecimal).value
        val base = total.divide(BigDecimal(count), 2, RoundingMode.DOWN)
        var allocated = BigDecimal.ZERO
        val start = LocalDate.parse(firstDueDate)
        return (1..count).map { index ->
            val amount = if (index == count) total - allocated else base
            allocated += amount
            DebtScheduleDraft(
                installmentNo = index,
                dueDate = start.plusMonths(monthlyStep * (index - 1)).toString(),
                amountDecimal = amount.setScale(2, RoundingMode.HALF_UP).toPlainString()
            )
        }
    }

    fun statusFor(dueDate: String?, today: String, remainingDecimal: String): String =
        when {
            DebtMoney.of(remainingDecimal).value.compareTo(BigDecimal.ZERO) == 0 -> "settled"
            dueDate == null -> "no_date"
            dueDate < today -> "overdue"
            dueDate == today -> "due_today"
            else -> "upcoming"
        }
}

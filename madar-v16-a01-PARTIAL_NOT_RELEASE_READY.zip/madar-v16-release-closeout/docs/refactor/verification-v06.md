# Verification v06 — App Shell وMainViewModel

## النطاق

إزالة `MainViewModel` المركزي وتوزيع الملكية على ViewModels حسب المسؤولية، مع عزل حالة الجلسة خلف عقد واحد.

## ما تم

- حذف `MainViewModel.kt` السابق: 714 سطرًا.
- إضافة:
  - `AppSessionViewModel`: 67 سطرًا.
  - `TransactionsViewModel`: 335 سطرًا.
  - `ReportsViewModel`: 39 سطرًا.
  - `SettingsViewModel`: 38 سطرًا.
  - `BackupViewModel`: 238 سطرًا.
- إنشاء `AppSessionGateway` وAdapter وDI binding.
- نقل ترحيل مصادر الدخل القديم إلى `LegacyIncomeSourceMigrator`.
- تحديث الشاشات والمكونات لتستخدم ViewModel المالك.
- تحديث اختبار قرار تخصيص المصروف للمسار الجديد.

## الاختبارات المنفذة فعليًا

تم تجميع وتشغيل اختبارات العقود التالية بواسطة `kotlinc` وRunner محلي:

```text
MainViewModelDecompositionArchitectureTest: 4/4
AppSessionGatewayContractTest: 3/3
GoalFinancialChangeContractTest: 2/2
DebtUiCutoverContractTest: 2/2
المجموع: 11/11 ناجحة
```

## التجميع الساكن

- فحص Kotlin PSI للملفات المعدلة: `21/21` ناجح بلا أخطاء Syntax.
- تجميع دلالي بواسطة `kotlinc` مع عقود Stub:
  - `AppSessionContracts`: ناجح.
  - `AppSessionGatewayAdapter`: ناجح.
  - `AppSessionModule`: ناجح.
  - `AppSessionViewModel`: ناجح.
  - `LegacyIncomeSourceMigrator`: ناجح.
- قواعد المصدر والمعمارية: `64/64` ناجحة.

## Gradle

الأوامر التي تمت محاولتها:

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.architecture.MainViewModelDecompositionArchitectureTest" \
  --tests "com.shift.app.feature.session.AppSessionGatewayContractTest" \
  --offline

./gradlew assembleDebug --offline
```

النتيجة: لم يبدأ تهيئة المشروع؛ Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب غياب الشبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

لا يوجد ادعاء بنجاح Gradle أو Android build.

## Room والبيانات

- Room بقي الإصدار 18.
- لا توجد Migration جديدة.
- لم تتغير Entities أو DAOs أو مخططات Supabase.

## اختبار يدوي مطلوب

1. فتح التطبيق والتأكد من تنفيذ Initial Sync مرة واحدة.
2. إضافة دخل ومصروف وتعديلهما وحذفهما.
3. فتح الميزانية والتقارير والتأكد من تطابق الأرقام السابقة.
4. تعديل الملف الشخصي من Settings.
5. تصدير نسخة احتياطية ثم استيرادها.
6. تنفيذ Sync يدوي ومراجعة حالة الفشل والنجاح.
7. تسجيل الخروج الآمن والإجباري.

## النتيجة

التنفيذ المعماري والتجميع الساكن واختبارات العقود ناجحة. إغلاق V05 نهائيًا ينتظر Gradle والاختبار اليدوي داخل بيئة Android كاملة.

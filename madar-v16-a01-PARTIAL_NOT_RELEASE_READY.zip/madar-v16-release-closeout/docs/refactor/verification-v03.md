# Verification v03 — الجلسة v02: Outbox دائم ومزامنة خلفية

## الحالة

`IN_PROGRESS — IMPLEMENTED / STATIC_VERIFIED / GRADLE_BLOCKED`

نُفذت الجلسة وتحقق منها ساكنًا وسلوكيًا داخل Harness محلي. لا تُعد `DONE` حتى ينجح Gradle وMigration/Process-death على Android.

## النطاق المنفذ

- ترقية Room من 17 إلى 18 عبر `MIGRATION_17_18`.
- إنشاء `sync_outbox` وفهارسه.
- إنشاء 48 Trigger تغطي 24 جدولًا متزامنًا.
- إضافة `syncState` للجداول Legacy الأربعة.
- WorkManager بقيود `CONNECTED` وExponential Backoff وعمل فوري/دوري Unique.
- استعادة الطابور عند تشغيل التطبيق وبعد نجاح المصادقة.
- منع Push المباشر من ViewModels المعدلة باستخدام `SyncQueueGateway`.
- Idempotency بواسطة Event ID مستقر و`operationId`.
- Revision guard لمنع Worker قديم من حذف أو تعليم تعديل أحدث.

## الاختبارات المضافة

```text
com.shift.app.sync.outbox.OutboxIdempotencyTest
com.shift.app.sync.outbox.SyncWorkerRetryTest
com.shift.app.sync.outbox.SyncOutboxTransactionTest
com.shift.app.sync.outbox.ProcessDeathRecoveryTest
com.shift.app.sync.outbox.ViewModelSyncBoundaryTest
com.shift.app.sync.outbox.WorkerConfigurationTest
```

## التحقق الساكن المنجز

- Kotlin syntax: **33/33 ملفًا ناجحًا**.
- تجميع نواة Outbox وWorkManager واختباراتها عبر `kotlinc` مع عقود Stub: **ناجح**.
- الاختبارات الساكنة: **15 ناجحة، 0 فشل**.
- العقود المصدرية: **28 ناجحة، 0 فشل**.
- SQL المثبت على مخطط Room 17 داخل SQLite:
  - 51 عبارة SQL.
  - 48 Trigger.
  - 24 جدولًا متزامنًا.
- تحقق Atomicity:
  - Rollback يزيل سجل العمل وسجل Outbox معًا.
  - السجل `synced` القادم من Remote لا يدخل Outbox.
  - Snapshot قديم لا يحذف ولا يغيّر Event ذي Revision أحدث.

## نتيجة Gradle الفعلية

الأمر المجرب:

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.sync.outbox.*" \
  lintDebug assembleDebug --offline
```

لم يبدأ Gradle في تهيئة المشروع؛ Gradle 8.2.1 غير موجود محليًا وحاول Wrapper تنزيله، بينما البيئة بلا اتصال:

```text
java.net.UnknownHostException: services.gradle.org
```

لذلك لا يوجد ادعاء بنجاح Unit tests الكاملة أو Lint أو APK build.

## أوامر الإغلاق داخل بيئة Android كاملة

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.sync.outbox.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

بعد البناء يجب التأكد أن KSP أنشأ:

```text
app/schemas/com.shift.app.data.local.MadarDatabase/18.json
```

## اختبار يدوي مطلوب

1. ترقية نسخة تحتوي قاعدة Room 17 والتأكد من فتحها دون فقد بيانات.
2. إنشاء عملية بلا شبكة والتأكد من ظهور Pending.
3. قتل التطبيق كليًا ثم إعادة الشبكة وفتحه.
4. التأكد أن العملية رُفعت مرة واحدة فقط واختفت من Pending.
5. تعديل نفس العملية أثناء عمل المزامنة والتأكد أن التعديل الأحدث بقي لجولة لاحقة.
6. تسجيل الخروج/الدخول والتأكد أن خطأ المصادقة لم يمسح الطابور وأن الدخول أعاد إيقاظه.
7. تعطيل الشبكة عدة مرات والتأكد من Exponential Backoff وعدم تكرار أثر مالي.
8. فحص عدادات Pending وFailed دون ظهور بيانات حساسة.

## شرط تحويل المرحلة إلى DONE

- نجاح أوامر Gradle الثلاثة.
- وجود Schema `18.json` ومراجعته.
- نجاح Migration 17→18 على نسخة بيانات فعلية منزوعة الحساسية.
- نجاح اختبار Offline → kill process → reconnect دون فقد أو تكرار.

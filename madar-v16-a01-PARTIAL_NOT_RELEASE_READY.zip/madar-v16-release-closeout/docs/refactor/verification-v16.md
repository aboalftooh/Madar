# Verification v16 — الإغلاق وتقوية الإصدار

## النطاق

- إزالة Remote Sync المركزي وتقسيمه حسب المجالات.
- تقوية إعدادات Release والتوقيع والأسرار وR8.
- إضافة مسار CI لبناء AAB موقّع.
- تحديث Active Architecture وData Flow وSync Protocol وRelease Readiness.
- حذف توافق قديم غير مستخدم دون حذف Legacy models النشطة.

## التحقق المنجز

### Gradle Modules وDomain

- التجميع الدلالي للوحدات: **8/8 ناجح**.
- Unit tests للوحدات: **41/41 ناجحة**.
- الفحوص السلوكية العابرة للوحدات: **17/17 ناجحة**.
- Module graph: **612/612 ناجح**، بلا Cycles أو Duplicate declarations.

### المزامنة

- تجميع دلالي لنواة المزامنة والـPorts والـParticipants: **11/11 ملفًا ناجحًا** باستخدام Stubs للعقود الخارجية.
- اختبارات انحدار `SyncOrchestrator`: **5/5 ناجحة**.
- اختبارات V16 المعمارية/المصدر: **12/12 ناجحة**.
- Data Sources المقسمة: **6/6**، وكل ملف أقل من 750 سطرًا.
- Parser probe لملفات Remote الجديدة: **9/9 دون أخطاء تركيب** بعد إصلاح خطأ فعلي في `RemoteSyncPayloads.kt`.

### الإصدار والأسرار

- `validateReleaseConfiguration` يرفض Backend URL/Key أو Keystore ناقصة.
- `local.properties` و`keystore.properties` وملفات Keystore مستبعدة من Git والتسليم.
- أمثلة الإعداد آمنة ولا تحتوي أسرارًا فعلية.
- Workflow الإصدار يقرأ الأسرار من GitHub Secrets، يبني `bundleRelease` ويحذف الملفات المؤقتة.
- قواعد R8/ProGuard تغطي SQLCipher وSupabase وKotlin Serialization payloads.
- بوابة `verify_release_closeout.py`: **75/75** بعد إنشاء هذا التقرير، مع Blocker منفصل لـSchema 18.

## Gradle الفعلي

الأمر المطلوب:

```bash
./gradlew clean testDebugUnitTest lintDebug assembleDebug bundleRelease --offline --stacktrace
```

النتيجة: لم تبدأ تهيئة المشروع؛ Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب:

```text
java.net.UnknownHostException: services.gradle.org
```

هذه النتيجة عائق بيئة، وليست نجاحًا أو فشلًا لاختبارات المشروع.

## لم يُنفذ

- `testDebugUnitTest` و`lintDebug` و`assembleDebug` و`bundleRelease` عبر Gradle.
- `connectedDebugAndroidTest` على Emulator/جهاز.
- توليد ومراجعة `app/schemas/**/18.json` بواسطة Room KSP.
- تثبيت Release موقعة واختبار الترقية من نسخة فعلية سابقة.
- مراجعة AAB وR8 mapping الناتجين من Pipeline حقيقية.

## حالة المرحلة

`BLOCKED`: التنفيذ البنيوي والتوثيق والتحقق الساكن مكتمل، لكن V16 لا تتحول إلى `DONE` قبل نجاح Gradle وInstrumentation وتوليد Schema 18 واختبار التثبيت والترقية.

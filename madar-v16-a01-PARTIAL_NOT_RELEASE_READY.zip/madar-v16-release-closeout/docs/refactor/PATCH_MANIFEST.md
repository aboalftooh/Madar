# PATCH MANIFEST — Madar V16

## الهدف

إغلاق إعادة الهيكلة، إزالة Remote Sync المركزي، تقوية Release، وتوثيق المعمارية الفعلية دون تغيير Room schema أو السلوك الوظيفي المقصود.

## ملفات مضافة

### Release والأمان

- `.github/workflows/android-release.yml`
- `.gitignore`
- `keystore.properties.example`
- `tools/verify_release_closeout.py`

### Remote Sync

- `app/src/main/java/com/shift/app/sync/remote/RemoteSyncPorts.kt`
- `app/src/main/java/com/shift/app/data/remote/RemoteSyncContext.kt`
- `RemoteSyncPayloads.kt`
- `RemoteSyncRules.kt`
- `ReferenceDataRemoteSyncDataSource.kt`
- `LedgerRemoteSyncDataSource.kt`
- `AssetRemoteSyncDataSource.kt`
- `DebtRemoteSyncDataSource.kt`
- `GoalRemoteSyncDataSource.kt`
- `SettingsRemoteSyncDataSource.kt`

### الاختبارات والتوثيق

- `app/src/test/java/com/shift/app/ReleaseCloseoutArchitectureTest.kt`
- `docs/architecture/active-architecture.md`
- `docs/architecture/data-flow.md`
- `docs/architecture/sync-protocol.md`
- `docs/architecture/release-readiness.md`
- `docs/refactor/verification-v16.md`

## ملفات معدلة

- `app/build.gradle.kts`
- `app/proguard-rules.pro`
- `local.properties.example`
- `SyncManager.kt`
- `LegacyHistoryMigrationRepository.kt`
- `SyncParticipantModule.kt`
- المشاركون الستة داخل `sync/participant`.
- اختبارات Sync/Goals المرتبطة بالملكية الجديدة.
- خطة وسجل وقواعد وملكية الحزم ووثيقة Gradle Modules.

## ملفات محذوفة

- `app/src/main/java/com/shift/app/data/remote/RemoteSyncDataSource.kt`

## تغييرات مقصودة

- `SyncManager` أصبح Session facade فقط.
- كل Participant يعتمد على Remote Port حسب المجال.
- `AssetRemoteSyncDataSource` يطلب تحديث الدفتر عبر `LedgerRemoteSync` بدل استدعاء داخلي مكسور.
- Release يفشل عند placeholders أو النص `null` أو توقيع ناقص.
- لا تُحزم أسرار أو Keystore.

## لم يتغير

- Room version: 18.
- لا Migration جديدة ولا تعديل schema.
- لا حذف لنماذج Legacy النشطة.
- لا تغيير مقصود في التنقل أو واجهات المستخدم أو القواعد المالية.

## حالة التحقق

راجع `verification-v16.md`. المرحلة `BLOCKED` حتى نجاح Gradle، توليد Schema 18، Instrumentation، واختبار التثبيت والترقية.

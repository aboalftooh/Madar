# Verification v11 — Reports وRead Models

## النطاق

فصل التقارير إلى Query قراءة فقط، Domain Read Models، وPresentation لا تعرف Room أو Repositories أو الحسابات المالية.

## ما تم

- إنشاء `ReportsQuery` و`ReportsQueryAdapter`.
- إنشاء صفوف `ReportsDataset` مستقلة عن Room.
- إنشاء Read Models للفترة والثروة والاتجاه الشهري والتوزيعات.
- نقل الحسابات إلى `BuildReportsReadModelUseCase`.
- جعل `ReportsViewModel` مالك Cache الوحيد عبر `stateIn`.
- نقل `ReportsScreen` إلى الميزة وحذف ViewModel والشاشة القديمين.
- تحديث اختبارات المعمارية المتأثرة بالمسارات الجديدة.
- الحفاظ على Room الإصدار 18 دون Migration أو تعديل Schema.

## الاختبارات المنفذة

- اختبارات V11 المستهدفة: **12/12 ناجحة**.
  - القيم canonical من Ledger تتغلب على Legacy projection المرتبط.
  - حساب الثروة من الرصيد وأحدث تقييم والديون المؤكدة.
  - التوزيعات مرتبة ونسبها محسوبة مسبقًا.
  - اتجاه آخر ستة أشهر.
  - النطاق الزمني غير الصحيح.
  - منع تكرار Payment منطقيًا حسب `operationId`.
  - عقد Query للقراءة فقط وحدود Presentation/Domain/Cache.
- جميع اختبارات الحدود المعمارية الحالية: **32/32 ناجحة**.
- قواعد المصدر وفحص الملفات: **50/50 ناجحة**.

## التجميع الساكن

نجحت **5/5** مجموعات تجميع دلالي بواسطة `kotlinc` مع Stubs:

1. Reports Domain models وRead Model calculator.
2. Observe/Build use cases.
3. ReportsQueryAdapter.
4. ReportsViewModel.
5. ReportsFeatureModule.

كما اجتاز `ReportsScreen.kt` فحص توازن الصياغة، ولم يظهر Compiler probe أي تشخيص Syntax؛ فشل Probe فقط بسبب غياب مكتبات Android/Compose من classpath المحلي.

## Gradle

جُربت الأوامر:

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.reports.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

توقفت قبل تهيئة المشروع لأن Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` والبيئة بلا شبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

لذلك لا يُدعى نجاح Gradle أو APK أو Lint الكامل.

## Room والبيانات

- Room بقي الإصدار **18**.
- `app/schemas` لم يتغير.
- لا Migration جديدة.
- Legacy fallback بقي للسجلات غير المرتبطة فقط؛ حذفه مؤجل حتى Parity على بيانات إنتاج مجهولة الهوية.

## اختبار يدوي مطلوب

1. فتح التقارير ومقارنة الأرقام مع لوحة التحكم لنفس الشهر.
2. تغيير تاريخ البداية والنهاية والتحقق من KPIs والتوزيعات.
3. التحقق من الدخل حسب المصدر والمصروف حسب الغرض والمستفيد.
4. التحقق من صافي الثروة مع أصل مقيّم ودين لك ودين عليك.
5. تعديل عملية مالية ثم العودة للتقارير والتأكد من تحديثها دون إعادة فتح التطبيق.

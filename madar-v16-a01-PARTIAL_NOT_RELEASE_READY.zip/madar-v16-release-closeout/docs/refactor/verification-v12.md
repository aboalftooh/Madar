# Verification v12 — نمط Presentation موحد

## النطاق

تطبيق نمط `Route / Screen / ViewModel / UiState / UiEvent` على ميزتي الديون والتقارير دون تغيير قواعد العمل أو Room.

## ما تم

- إنشاء `DebtsRoute` و`ReportsRoute` لحقن ViewModels وجمع State.
- جعل `DebtsScreen` و`ReportsScreen` دوال عرض نقية دون ViewModel أو `collectAsState`.
- إنشاء `DebtsUiEvent` و`ReportsUiEvent` وربطهما بـ`onEvent` داخل ViewModels.
- إزالة تمرير `DebtsViewModel` إلى مكونات الديون ونوافذها.
- فصل نوافذ عمليات الديون إلى `DebtActionSheets.kt`.
- تقليص `DebtsScreen` من 905 إلى 409 أسطر؛ `ReportsScreen` أصبحت 438 سطرًا.
- تحديث Navigation والاختبارات المعمارية القديمة.

## الاختبارات المنفذة

### اختبارات الحدود والمصدر

- النتيجة: **27/27 ناجحة**.
- تشمل:
  - `PresentationConventionArchitectureTest`.
  - حدود Auth وMainViewModel والتقارير والديون.
  - Canonical financial reports.
  - مسار Debt UI cutover.

### قواعد المصدر والمعمارية

- النتيجة: **91/91 ناجحة**.
- تحققت من:
  - وجود Route/Screen/ViewModel/State/Event.
  - منع Hilt وFlow collection وViewModel داخل الشاشات النقية.
  - منع Data وRoom داخل Presentation للديون والتقارير.
  - معالجة جميع أحداث `DebtsUiEvent` السبعة عشر داخل ViewModel.
  - استخدام MainScreen للـRoutes.
  - حد 500 سطر للشاشات المعدلة.
  - توازن Kotlin لجميع الملفات المعدلة.
  - ثبات Room 18 وعدم تغير schemas.

## التجميع الساكن

نجحت أربع مجموعات دلالية باستخدام Kotlin compiler وعقود Stub:

1. Debts UI contract + UI models + `DebtsViewModel`.
2. Reports UI contract + `ReportsViewModel`.
3. `DebtsRoute` وربط State/Event.
4. `ReportsRoute` وربط State/Event.

كما نجح فحص Syntax/Delimiter لجميع ملفات Kotlin المعدلة: **16/16**.

## Gradle

جرت محاولة:

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.architecture.PresentationConventionArchitectureTest"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

توقفت الأوامر قبل تهيئة المشروع لأن Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` والبيئة بلا إنترنت:

```text
java.net.UnknownHostException: services.gradle.org
```

لذلك لم يُدّعَ نجاح Gradle أو Android build.

## Room

- الإصدار: **18**.
- لا Migration جديدة.
- ملفات `app/schemas` لم تتغير.

## الاختبار اليدوي المطلوب

1. فتح مركز الديون والبحث وتغيير التبويبات.
2. فتح دين جديد وتنفيذ عملية مركبة لكل نوع.
3. فتح تفاصيل دين وتنفيذ زيادة/خفض/تسوية/عكس/جدولة.
4. فتح التقارير وتغيير تاريخ البداية والنهاية.
5. التحقق من بقاء التصميم والنتائج المالية دون تغيير.

## النتيجة

V12 منفذة وتحققت ساكنًا. تبقى بوابة Gradle واختبار الجهاز قبل تحويل المرحلة إلى `DONE`.

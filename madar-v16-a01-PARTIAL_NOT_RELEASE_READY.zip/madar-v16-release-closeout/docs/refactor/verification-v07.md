# Verification v07 — V06 توحيد Ledger والتحويل من Legacy

## النطاق

تحويل التاريخ المالي والديون القديمة إلى النموذج القائم على Decimal، مع إبقاء البيانات الأصلية، ومنع التكرار، وفحص تطابق الأرصدة والتقارير.

## ما تم

- إنشاء `LegacyFinancialCutoverPlanner` و`LegacyFinancialCutoverCoordinator`.
- دمج ترحيل التاريخ والديون داخل معاملة Room واحدة.
- إنشاء Fingerprint موحد وثابت باستخدام SHA-256.
- منع التنفيذ عند تغير البيانات بين المعاينة والتنفيذ.
- فحص Parity للدخل والمصروف والمستحقات والالتزامات.
- توفير Rollback للسجلات Pending فقط مع تنظيف Outbox.
- إبقاء سجلات `Transaction` و`Debt` القديمة دون حذف.
- تحويل Dashboard وBudget وReports إلى Ledger-aware calculations.
- ربط Wizard الفعلي بمنسق التحويل المالي الكامل وإظهار الديون المرشحة للمراجعة.

## الاختبارات المنفذة فعليًا

تم تجميع وتشغيل اختبارات V06 بواسطة `kotlinc` وRunner محلي:

```text
LegacyLedgerParityTest: 2/2
LegacyMigrationIdempotencyTest: 2/2
FinancialBalanceParityTest: 2/2
LegacyCutoverRollbackTest: 2/2
FinancialCanonicalArchitectureTest: 3/3
المجموع: 11/11 ناجحة
```

كما نُفذت 19 حالة منطق مباشرة تغطي:

- تطابق الأرصدة.
- فرق قرش واحد.
- ثبات Fingerprint وترتيب الديون.
- Idempotency وConflict.
- منع Rollback بعد المزامنة أو تغير المصدر.
- أولوية Decimal Ledger على قيمة Legacy `Double`.
- Fallback للسجلات غير المرحّلة.

النتيجة: `19/19` ناجحة.

## التجميع الساكن

- فحص Kotlin syntax لكل الملفات المعدلة: `27/27` ناجح.
- تجميع دلالي بواسطة `kotlinc` مع عقود Stub:
  - Finance domain/report: ناجح.
  - Legacy debt migrator: ناجح.
  - Legacy history repository: ناجح.
  - Financial cutover coordinator: ناجح.
  - Legacy cutover ViewModel: ناجح.
- تجميع ملفات اختبارات V06: ناجح.
- قواعد المصدر والمعمارية: `71/71` ناجحة.

## Gradle

تمت محاولة:

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.LegacyLedgerParityTest" \
  --tests "com.shift.app.LegacyMigrationIdempotencyTest" \
  --tests "com.shift.app.FinancialBalanceParityTest" \
  --tests "com.shift.app.LegacyCutoverRollbackTest" \
  --tests "com.shift.app.architecture.FinancialCanonicalArchitectureTest"

./gradlew testDebugUnitTest lintDebug assembleDebug
```

النتيجة: لم يبدأ تهيئة المشروع. حاول Gradle Wrapper تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب غياب الشبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

لا يوجد ادعاء بنجاح Gradle أو Android build.

## Room والبيانات

- Room بقي الإصدار 18.
- لا توجد Migration جديدة.
- أضيفت Queries فقط للرجوع والتحقق.
- بيانات Legacy لا تُحذف.
- Rollback يمنع حذف أي سجل خرج من Pending أو تغير بعد التحويل.

## اختبار يدوي مطلوب

1. أخذ نسخة احتياطية من قاعدة بيانات اختبار واقعية.
2. فتح معالج التحويل ومراجعة عدد المعاملات والديون وحالات المراجعة.
3. تنفيذ التحويل ومقارنة Dashboard وBudget وReports قبل وبعده.
4. إعادة التنفيذ والتأكد أنه No-op بلا تكرار.
5. قطع الشبكة وإغلاق التطبيق أثناء المزامنة ثم إعادة فتحه.
6. تجربة Rollback قبل المزامنة على نسخة اختبار فقط.
7. التأكد أن Rollback يُرفض بعد رفع أي سجل.
8. تشغيل Migration/Instrumented tests على جهاز أو Emulator.

## النتيجة

التنفيذ، اختبارات V06، والتجميع الساكن ناجحة. إغلاق المرحلة نهائيًا ينتظر Gradle والاختبار اليدوي وإثبات Parity على نسخة بيانات إنتاج مجهولة الهوية.

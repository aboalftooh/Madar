# Verification v10 — Backup وRestore

## النطاق

تفكيك المدير المركزي للنسخ الاحتياطي، إضافة Manifest متوافق، وفصل القراءة والتحقق والتخطيط والتطبيق مع Restore ذري.

## ما تم

- حذف `BackupManager` وViewModel القديم.
- إنشاء Finance/Asset/Debt/Goal Codecs.
- إنشاء `BackupGateway` وManifest وإصدار الملف وبصمته.
- تشغيل الاستعادة داخل Transaction واحدة مع Rollback لحالة DataStore الخارجية.
- إزالة معرفة `SettingsScreen` بكيانات Room وDTOs وخطة الاستعادة.
- الحفاظ على Room الإصدار 18 دون Migration.

## الاختبارات المنفذة

- V10 المستهدفة: **15/15 ناجحة**.
- جميع اختبارات الحدود المعمارية الحالية: **28/28 ناجحة**.
- قواعد المصدر: **36/36 ناجحة**.

## التجميع الساكن

نجحت **8/8** مجموعات تجميع دلالي بواسطة `kotlinc` مع Stubs، وتشمل:

1. Domain وDocument codec والذرية والمنقح.
2. Gateway adapter.
3. Backup ViewModel.
4. Finance codec.
5. Asset codec.
6. Debt codec.
7. Goal codec.
8. DI module.

جميع ملفات Kotlin الإنتاجية الجديدة وعددها 14 غُطيت بالتجميع الدلالي. تعديل `SettingsScreen` تحقق عبر اختبارات الحدود وفحص المصدر؛ تجميع Android/Compose الكامل يحتاج Gradle.

## Gradle

الأوامر المطلوبة جُربت:

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.backup.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

توقفت قبل تهيئة المشروع لأن Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` والبيئة بلا شبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

لذلك لا يُدعى نجاح Gradle أو APK.

## اختبار يدوي مطلوب

1. تصدير نسخة ثم استيرادها بوضع Merge.
2. استيرادها بوضع Replace والتحقق من عدد الحذف.
3. تجربة ملف JSON تالف ونسخة من تطبيق مختلف.
4. قطع العملية أثناء الاستعادة والتأكد أن البيانات لم تتغير جزئيًا.
5. فتح التطبيق بعد الاستعادة والتأكد من المالية والأصول والديون والأهداف.

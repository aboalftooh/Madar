# Madar — ملكية الحزم بعد V16

## Composition root

| الحزمة | الملكية |
|---|---|
| `di/DatabaseModule.kt` | إنشاء Room وSQLCipher والهجرات فقط |
| `di/NetworkModule.kt` | Supabase client وAuth فقط |
| `di/PreferencesModule.kt` | إنشاء `PreferencesManager` فقط |
| `sync/di/SyncInfrastructureModule.kt` | Outbox DAO وجدولة WorkManager |

## Feature DI

| الميزة | الوحدة | ما تملكه |
|---|---|---|
| Ledger | `feature/ledger/di/LedgerDataModule.kt` | Transactions، Balance، Payments، مصادر الدخل، المستفيدون، History migration DAOs |
| Assets | `feature/assets/di/AssetDataModule.kt` | Asset وTransactions وValuations وCurrency lots DAOs |
| Debts | `feature/debts/di/DebtDataModule.kt` | Legacy debt وDebt ledger DAOs |
| Goals | `feature/goals/di/GoalFeatureModule.kt` | Goal DAOs وGoal contracts وMeasurement registry |
| Auth | `feature/auth/di/AuthSessionModule.kt` | Auth وSession contracts |
| Backup | `feature/backup/di/BackupFeatureModule.kt` | Backup gateway |
| Reports | `feature/reports/di/ReportsFeatureModule.kt` | Reports query |

## Presentation المنقولة

```text
feature/auth/presentation/*
feature/session/presentation/AppSessionViewModel.kt
```

الحزم القديمة المتبقية انتقالية، ولا تُنقل جماعيًا. تُنقل عند معالجة الميزة مع اختبار حدودها.

## ملكية أدوات الاختبار بعد V14

| المسار | الملكية |
|---|---|
| `data/local/migration/*` | خطط SQL النقية القابلة للاختبار |
| `data/local/sync/SyncOutboxSqlPlan.kt` | المصدر الوحيد لـOutbox SQL |
| `app/src/test/.../testing/*` | Test doubles لعقود الميزات فقط |
| `app/src/androidTest/.../migration/*` | تنفيذ الهجرات على SQLite فعلي |
| `.github/workflows/android-ci.yml` | بوابات التحقق على نسخة نظيفة |

لا تنتقل Test doubles إلى Production، ولا تستورد اختبارات ViewModel Room أو Supabase.


## ملكية Gradle Modules بعد V15

| الوحدة | المحتوى المملوك | يعتمد على |
|---|---|---|
| `:core:model` | الأنواع والحاسبات المالية/الديون المشتركة | لا شيء |
| `:core:sync` | عقود المزامنة، النتائج، Checkpoints، Queue contract | Coroutines فقط |
| `:feature:ledger` | تخطيط Legacy financial cutover | `:core:model` |
| `:feature:auth` | Auth/Session contracts والنتائج | Coroutines فقط |
| `:feature:assets` | Asset models/contracts/use cases | `:core:model` |
| `:feature:debts` | Debt models/contracts/use cases | `:core:model` |
| `:feature:goals` | Goals domain/templates/evaluation/contracts | `:core:model` |
| `:feature:reports` | Reports query/read models/calculator | `:core:model` |
| `:app` | UI، Navigation، Room، Supabase، WorkManager، Hilt adapters | الوحدات السابقة |

`core:database` و`core:network` و`core:testing` و`feature:settings` ليست وحدات بعد؛ بقاؤها داخل `app` مقصود حتى تستقر اتجاهات الاعتماديات.

## ملكية Remote Sync بعد V16

| المجال | العقد | التنفيذ |
|---|---|---|
| Session | `sync/remote/SyncSessionRemote` | `data/remote/RemoteSyncContext` |
| Reference Data | `ReferenceDataRemoteSync` | `ReferenceDataRemoteSyncDataSource` |
| Ledger | `LedgerRemoteSync` | `LedgerRemoteSyncDataSource` |
| Assets | `AssetRemoteSync` | `AssetRemoteSyncDataSource` |
| Debts | `DebtRemoteSync` | `DebtRemoteSyncDataSource` |
| Goals | `GoalRemoteSync` | `GoalRemoteSyncDataSource` |
| Settings | `SettingsRemoteSync` | `SettingsRemoteSyncDataSource` |

`SyncManager` و`SyncOrchestrator` يملكان دورة التشغيل فقط. DTO/Mapping وSupabase/Room تبقى داخل Data owner.

## ملكية الإصدار

| المسار | الملكية |
|---|---|
| `app/build.gradle.kts` | التوقيع، BuildConfig، Release validation |
| `app/proguard-rules.pro` | R8/ProGuard runtime contracts |
| `.github/workflows/android-release.yml` | Signed AAB pipeline |
| `tools/verify_release_closeout.py` | بوابة بنية الإصدار |
| `docs/architecture/release-readiness.md` | قرار وحواجز الإصدار |


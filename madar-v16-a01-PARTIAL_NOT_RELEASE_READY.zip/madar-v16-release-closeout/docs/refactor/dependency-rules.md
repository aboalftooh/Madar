# Madar — قواعد الاعتماديات الانتقالية

## الاتجاه المسموح

```text
Presentation -> Domain Use Cases / Queries / Contracts
Data Adapter -> Domain Contract
Coordinator -> Multiple Domain Contracts
Infrastructure -> External SDKs
App Shell -> Feature entry points
```

## الممنوع

- `ViewModel -> DAO`.
- `ViewModel -> MadarDatabase`.
- `ViewModel -> SyncManager/SyncParticipant implementation`.
- `ViewModel -> Supabase/Sentry/WorkManager`.
- `ViewModel -> PreferencesManager` للجلسة أو قواعد العمل.
- `Screen/Composable -> Room Entity`.
- `Domain -> Android/AndroidX`.
- `Domain -> Room Entity/DAO`.
- `Domain -> data.repository implementation`.
- `Feature A -> Feature B concrete repository`.
- `UseCase -> MadarDatabase` جديد.
- إضافة كود جديد إلى `utils` بلا مالك واضح.
- استخدام `Double` أو `Float` لعملية مالية جديدة.
- استدعاء Push شبكي مباشر بعد كل عملية من ViewModel.
- الاعتماد على ساعة الهاتف وحدها لحل تعارض مالي.

## قاعدة Feature

كل ميزة معدلة تتجه تدريجيًا إلى:

```text
feature/<name>/
├── presentation/
├── domain/
├── data/
└── di/
```

الاعتماد المسموح داخلها:

```text
presentation -> domain
data -> domain
```

يُمنع:

```text
domain -> data
presentation -> data implementation
```

## قاعدة Room

- تبقى قاعدة Room واحدة أثناء الانتقال.
- DAO يستهلكه Data implementation التابع لمالك المجال فقط.
- لا يصل Feature إلى DAO مملوك لFeature أخرى.
- العلاقات العابرة تُنفذ عبر Port أو Query أو Coordinator.
- كل تغيير Schema يتطلب:
  - Migration صريحة.
  - Schema JSON مصدرة.
  - Migration test من أقدم نسخة مدعومة.
  - اختبار ترقية على نسخة بيانات فعلية منزوعة الحساسية.

## قاعدة المعاملات المالية

- العملية المالية العابرة للجداول تملك Transaction Boundary واحدة.
- `operationId` إلزامي للعمليات القابلة لإعادة المحاولة.
- الكتابة المالية وسجل Outbox تتمان داخل معاملة Room نفسها.
- لا تُعتبر العملية متزامنة قبل تأكيد الخادم.
- جميع القيم المالية الجديدة تستخدم Decimal canonical و`BigDecimal` للحساب.
- التقريب والسياسة النقدية يملكان مصدرًا واحدًا.

## قاعدة المزامنة

الهدف:

```text
SyncOrchestrator
  -> SyncParticipant contracts
      -> Feature Data implementation
          -> DAO + Remote API
```

- `SyncOrchestrator` لا يعرف DAOs أو Room Entities أو أسماء الجداول.
- كل Participant يملك Checkpoint مستقلًا أو Cursor موثقًا.
- لا يتقدم Checkpoint عند فشل جزئي.
- Outbox دائم هو مصدر العمليات Pending.
- Retry يتم عبر WorkManager، لا `viewModelScope` فقط.
- Pull لا يمسح تغييرًا محليًا Pending.
- التعارض المالي يحتاج Revision/Server ordering أو سياسة موثقة، لا وقت الجهاز فقط.

## قاعدة Auth وSession بعد v04

```text
AuthScreen
  -> AuthViewModel
      -> AuthGateway
      -> SessionReader
      -> SessionBootstrapper
      -> SessionCleanup

SessionCleanupCoordinator
  -> SessionSyncGateway
  -> SessionWorkController
  -> AccountLocalDataCleaner
  -> SessionWriter
  -> AuthGateway
```

القواعد الملزمة:

- `AuthViewModel` لا يستورد Data أو Room أو Supabase أو WorkManager أو `SyncManager`.
- Supabase Auth يوجد خلف `SupabaseAuthGateway` و`PreferencesSessionStore` فقط ضمن هذا المسار.
- تنظيف Room يوجد خلف `RoomAccountLocalDataCleaner` ويعمل داخل معاملة واحدة.
- الخروج الآمن يبدأ بمزامنة التغييرات، وأي `PartialFailure` أو تغير مصادقة يمنع الحذف.
- الخروج الإجباري يتجاوز خطوة المزامنة فقط بعد قرار المستخدم، ولا يتجاوز قفل الجلسة أو إيقاف WorkManager.
- يلغى العمل الفوري والدوري وتُنتظر نتيجة الإلغاء قبل حذف Outbox والبيانات.
- ترتيب التنظيف ثابت: إيقاف العمل -> حذف البيانات -> مسح تفضيلات الحساب -> إنهاء جلسة المصادقة.
- فشل Remote sign-out لا يعيد بيانات محذوفة؛ تُمسح الجلسة المحلية كـfallback.
- البريد المحفوظ يبقى Device-owned ولا يُمسح مع Account-scoped state.

الممنوع:

- `AuthViewModel -> MadarDatabase/DAO/Repository`.
- `AuthViewModel -> Supabase Auth`.
- `AuthViewModel -> SyncManager/SyncQueueGateway/WorkManager`.
- تنظيف Outbox أو بيانات الحساب خارج `SessionCleanupCoordinator` في مسار الخروج.
- حذف البيانات بعد فشل المزامنة دون اختيار الخروج الإجباري.

## قاعدة Ledger وLegacy

- لا تضاف ميزة جديدة إلى `Transaction` أو `Debt` القديمين.
- Legacy code مسموح فقط للقراءة أو الترحيل أو التوافق المؤقت.
- لا يُحذف Legacy قبل إثبات Parity ووجود Rollback.
- التقارير الجديدة تقرأ من المصدر المالي المعتمد فقط.

## قاعدة الأصول

```text
Assets Presentation
  -> Asset Use Cases / Queries
      -> AssetGateway
          -> Asset Data Adapter
```

- لا تستورد Presentation `Asset`, `AssetTransaction`, `AssetValuation` كـRoom Entities.
- أي تأثير على الرصيد أو الدين يتم عبر Port/Coordinator.
- عمليات شراء/بيع/تقييم/تحويل الأصل تبقى Idempotent وذرية.

## قاعدة الديون

```text
Debts Presentation
  -> Debt Use Cases / Queries
      -> DebtGateway
```

- `DebtsViewModel` لا يحقن `DebtAccountDao` أو `AssetDao`.
- التسوية بأصل أو نقد عملية عابرة تُنفذ عبر Coordinator/Ports.
- الجدولة والاستحقاق ضمن ملكية Feature الديون.

## قاعدة الأهداف

```text
Goals Presentation
  -> Goal Use Cases / Queries
      -> GoalGateway
```

- Goal Domain Models ليست Room Entities.
- Measurement Providers تعتمد على Read contracts، لا DAOs.
- `FinancialChangeOutbox` الخاص بالأهداف لا يُستخدم كبديل لـSync Outbox.

## قاعدة Backup وRestore

- كل Feature يملك Codec لبياناته.
- `BackupManifest` يحدد الإصدار والتوافق.
- Restore إما كامل داخل Transaction أو مرفوض قبل التطبيق.
- لا يعرف ViewModel تفاصيل DTOs لكل المجالات.
- لا تُكتب الأسرار أو مفاتيح Supabase أو PIN raw داخل النسخة.

## قاعدة Presentation

النمط المفضل تدريجيًا:

```text
Route -> ViewModel -> UiState
Screen <- UiState
Screen -> UiEvent -> ViewModel
ViewModel -> UiEffect عند الحاجة
```

- Composables لا تنفذ قواعد مالية.
- UI Models منفصلة عن Data Models.
- Navigation لا يُستخدم كService locator.
- لا تُقسم شاشة لمجرد عدد الأسطر؛ تُقسم حسب مسؤوليات فعلية.

## قاعدة DI

- Modules حسب المسؤولية والميزة.
- `AppModule` لا يبقى مالك كل DAOs والخدمات.
- لا Binding مكرر لنفس العقد.
- Constructor Injection هو الافتراضي.
- Service locator أو access global ممنوع للكود الجديد.

## قاعدة Core

لا يُنقل شيء إلى Core لأنه "قد يُعاد استخدامه".

شروط النقل:

1. مستهلكان فعليان على الأقل، أو بنية تحتية مشتركة مؤكدة.
2. معنى واحد ثابت.
3. لا يحمل قواعد مجال خاص.
4. لا ينشئ اعتمادًا دائريًا.

## قاعدة الوقت والمعرفات

- الكود الجديد يعتمد على `Clock` و`IdGenerator` contracts.
- يمنع انتشار `System.currentTimeMillis()` و`UUID.randomUUID()` داخل Domain.
- ذلك ضروري لاختبارات المزامنة والتعارض وIdempotency.

## قاعدة الاختبارات المعمارية

يجب إنشاء اختبارات تمنع رجوع المخالفات:

```text
NoViewModelDaoDependencyTest
NoPresentationRoomEntityTest
NoDomainAndroidDependencyTest
NoDomainDataDependencyTest
NoFeatureConcreteCrossDependencyTest
NoNewLegacyFinancialWriteTest
```

اختبارات المصدر النصية مسموحة مؤقتًا فقط، ويُفضل استبدالها باختبارات بنيوية أو سلوكية.

## حدود Outbox والمزامنة الخلفية

الاتجاه الانتقالي المسموح:

```text
Presentation / ViewModel
  -> SyncQueueGateway
      <- SyncWorkScheduler
          -> WorkManager + SyncOutboxDao

SyncOutboxWorker
  -> SyncOutboxProcessor
      -> SyncManager الحالي
```

القواعد:

- Presentation لا تعرف `SyncOutboxDao` أو `SyncWorkScheduler` أو WorkManager.
- ViewModel لا يستدعي Push شبكيًا؛ يكتب العملية محليًا ثم يطلب إيقاظ الطابور عبر `SyncQueueGateway`.
- كتابة السجل المحلي وOutbox يجب أن تكونا داخل معاملة SQLite واحدة؛ Triggers في Room 18 تفرض ذلك أثناء الانتقال.
- Event ID مستقر ويُشتق من مالك الجدول و`operationId` أو المفتاح الأساسي.
- لا يُحذف حدث بعد الرفع إلا بشرط تطابق `eventId + revision` الملتقطين في Snapshot.
- تعديل أحدث أثناء عمل Worker يرفع Revision ويبقى Pending لجولة لاحقة.
- خطأ المصادقة لا يحذف Outbox ولا ينشئ Retry loop دائمًا؛ نجاح الدخول يعيد جدولة العمل.
- العمل الفوري Unique والعمل الدوري لا يحلان محل Outbox؛ Outbox هو مصدر الحقيقة للعمليات غير المرفوعة.
- Room schema الحالية بعد v02 هي 18. أي تعديل لاحق يتطلب Migration جديدة ولا يعدّل `MIGRATION_17_18` بعد إصدارها.

الممنوع:

- `ViewModel -> SyncOutboxDao`.
- `ViewModel -> SyncWorkScheduler` التنفيذي.
- `ViewModel -> WorkManager`.
- حذف Snapshot كامل بلا Revision guard.
- اعتبار `Result.success()` دليلًا على رفع البيانات دون فحص نتيجة `SyncOutboxProcessor`.
- مسح Outbox عند فشل مؤقت أو غياب المصادقة.

## حدود Sync Participants بعد v03

الاتجاه الحالي:

```text
SyncManager (Session facade)
  -> SyncOrchestrator
      -> Set<SyncParticipant>
          -> Feature DAOs + RemoteSyncDataSource الانتقالي

SyncOrchestrator
  -> SyncCheckpointStore
      <- PreferencesSyncCheckpointStore
```

القواعد الملزمة:

- `SyncManager` لا يستورد DAO أو Room أو `MadarDatabase` أو `SupabaseClient`.
- `SyncOrchestrator` لا يعرف أسماء الجداول أو Remote DTOs أو DAOs.
- إضافة مجال متزامن جديد تتم عبر `SyncParticipant` وHilt `@IntoSet`، لا بتعديل قائمة مركزية داخل `SyncManager`.
- كل Pull operation يحدد `SyncCheckpointKey` الخاص به، ولا يُحفظ إلا داخل نفس الخطوة المعزولة الناجحة.
- ترتيب المشاركين تحدده `order`، وجميع Pulls تسبق Pushes، وجميع Pushes تسبق Finalize.
- فشل Participant لا يمنع تجربة Participant مستقل، لكنه يمنع تقدم `lastSync` العام.
- عمليات متعددة السجلات تجمع مرة واحدة باستخدام `groupBy/associateBy`، ويمنع البحث الكامل المتكرر لكل `operationId`.
- `RemoteSyncDataSource` طبقة انتقالية فقط؛ ممنوع إضافة مجال جديد إليها. تنقل DTOs وMapping تدريجيًا إلى Data الخاصة بالمشارك المالك.
- عملية مرتبطة بأصل لا يرفعها Ledger وAssets معًا؛ `RoomAssetOperationIndex` يحدد الملكية أثناء الانتقال.

الممنوع:

- إعادة حقن DAOs في `SyncManager` أو `SyncOrchestrator`.
- استدعاء Participant concrete من Participant آخر.
- حفظ Checkpoint خارج الخطوة المعزولة الخاصة بعملية Pull.
- تقدم `lastSync` عند وجود فشل في Pull أو Push أو Finalize أو تخزين Checkpoint.

## حدود App Shell بعد v05

```text
MainScreen -> AppSessionViewModel -> AppSessionGateway
MainScreen -> TransactionsViewModel
Dashboard/Budget/AddTransaction -> TransactionsViewModel
ReportsScreen -> ReportsViewModel -> ObserveReportsUseCase -> ReportsQuery
SettingsScreen -> SettingsViewModel + BackupViewModel + AppSessionViewModel + TransactionsViewModel
```

الممنوع:

- إعادة إنشاء `MainViewModel` كحاوية خدمات عامة.
- تمرير ViewModel مركزي بين جميع صفحات التطبيق.
- حقن `SyncManager` أو `PreferencesManager` أو Repositories داخل `AppSessionViewModel`.
- تنفيذ ترحيل مصادر الدخل داخل Presentation.
- إضافة مسؤوليات النسخ الاحتياطي أو التقارير إلى `TransactionsViewModel`.

المسموح انتقاليًا:

- اعتماد `TransactionsViewModel` و`BackupViewModel` على التنفيذ الحالي حتى مراحل المجالات المخصصة.

## حدود المالية بعد v06

الاتجاه المسموح:

```text
Dashboard / Budget
  -> FinancialReportCalculator ledger-aware API
      -> BalanceTransaction + Payment Decimal

ReportsScreen
  -> ReportsReadModel
      -> BuildReportsReadModelUseCase
          -> Report-owned Decimal rows
          -> Legacy fallback للسجلات غير المرتبطة فقط

Legacy migration UI
  -> LegacyFinancialCutoverCoordinator
      -> History migration + Debt migration
      -> Parity verification + fingerprint + pending-only rollback
```

القواعد الملزمة:

- Ledger وPayments وDebt Ledger هي مصدر الحقيقة المالي بعد ارتباط سجل Legacy بها.
- `Transaction.amount` و`Debt.amount` مسار توافق مؤقت، ولا يجوز استخدامهما في نموذج مالي جديد.
- أي مبلغ مالي جديد يُخزن كنص Decimal ويُحسب بـ`BigDecimal`، وليس `Double`.
- التقارير الإنتاجية تستخدم overloads التي تستقبل `BalanceTransaction` و`Payment`.
- لا يُنفذ ترحيل التاريخ أو الديون منفردًا من Presentation؛ التنفيذ عبر `LegacyFinancialCutoverCoordinator`.
- Fingerprint المعاينة يجب أن يطابق Fingerprint التنفيذ، وإلا يُرفض التحويل.
- فحص Parity إلزامي قبل النجاح وبعد الكتابة.
- بيانات Legacy الأصلية لا تُحذف أثناء التحويل.
- Rollback مسموح فقط ما دامت جميع السجلات الناتجة Pending ولم تُعدل أو تُزامن.
- حذف سجلات التحويل يتطلب تنظيف Outbox المرتبط داخل نفس معاملة Room.

الممنوع:

- إضافة حقل مالي جديد من نوع `Double` أو `Float`.
- استخدام overloads القديمة لـ`FinancialReportCalculator` في شاشة إنتاجية جديدة أو معدلة.
- تنفيذ `prepareCommit/applyLocally` لترحيل التاريخ مباشرة من ViewModel.
- اعتبار وجود Marker وحده دليلًا على صحة التحويل دون Parity.
- حذف بيانات Legacy قبل تحقق نسخة إنتاج مجهولة الهوية وخطة Rollback معتمدة.
## حدود ميزة الأصول بعد v07

الاتجاه المسموح:

```text
AssetsRoute / PaymentsScreen
  -> AssetsViewModel / AssetDetailsViewModel
      -> Asset Use Cases
          -> AssetGateway
              <- AssetGatewayAdapter
                  -> AssetRepository + Session lock + SyncQueue

AssetRepository
  -> AssetOperationFactory
  -> Room DAOs داخل Data فقط
```

القواعد الملزمة:

- Presentation للأصول تستخدم Domain Models فقط، ولا تستورد Room Entities.
- ViewModels تعتمد على Use Cases ولا تعرف `AssetRepository` أو `SyncManager` أو `SyncQueueGateway`.
- `AssetGatewayAdapter` هو نقطة الترجمة الوحيدة بين Room Entities وDomain Models.
- أي Command يمر عبر قفل الجلسة قبل تنفيذ المعاملة المحلية.
- فشل إيقاظ WorkManager بعد نجاح الكتابة المحلية لا يلغي العملية؛ Outbox الدائم يبقى مصدر الحقيقة.
- حساب الملخص والقيمة الحالية والكمية المتاحة للعملة يوجد في Domain Use Case، لا داخل Screen أو Room Entity.
- عمليات الأصل متعددة الصفوف تبقى ذات `operationId` واحد ويستمر رفعها مركبًا عبر `AssetSyncParticipant`.
- `AssetOperationFactory` Data-internal لأنه يبني Room Entities؛ يمنع استدعاؤه من Presentation.
- `FOREIGN_CURRENCY_ASSET_TYPE` مملوك لنموذج Domain، وليس لحزمة Repository.

الممنوع:

- `feature/assets/presentation -> com.shift.app.data.*`.
- `AssetsViewModel -> AssetRepository/DAO/MadarDatabase/SyncManager`.
- إعادة تمرير Room `Asset` إلى `PaymentsScreen` أو Components الميزة.
- تنفيذ حساب القيمة أو FIFO داخل Composable.
- إضافة Command جديد مباشرة إلى Screen دون Use Case وGateway.
- جعل `AssetSyncParticipant` يعتمد على Presentation أو ViewModel.


## حدود ميزة الديون بعد v08

الاتجاه المسموح:

```text
DebtsScreen
  -> DebtsViewModel
      -> ObserveDebtCenterUseCase / DebtCommandUseCases
          -> DebtGateway
              <- DebtGatewayAdapter
                  -> Debt-owned DAOs + transitional Debt repositories

GoalEditorViewModel
  -> ObservePayableDebtAccountsUseCase
      -> DebtGateway

DebtGatewayAdapter
  -> DebtSettlementAssetQuery
      -> AssetGateway

DebtGatewayAdapter
  -> DebtGoalScopePort
      <- FinancialGoalDebtScopeAdapter
```

القواعد الملزمة:

- Presentation للديون تستخدم Domain Models وUse Cases فقط.
- `DebtsViewModel` و`GoalEditorViewModel` لا يستوردان DAO أو Room Entity أو Repository تنفيذيًا.
- قراءة أصل للتسوية تمر عبر `DebtSettlementAssetQuery` و`AssetGateway`، لا عبر `AssetDao`.
- قراءة/تحديث نطاق هدف مرتبط بالدين تمر عبر `DebtGoalScopePort`، لا عبر DAO هدف داخل Presentation.
- كل أمر كتابة يمر بقفل الجلسة قبل التنفيذ المحلي، ثم يطلب إيقاظ طابور المزامنة بعد نجاح الكتابة.
- المبالغ الجديدة تُطبّع إلى Decimal داخل حدود Domain/Use Case، ولا يضاف `Double` مالي جديد.
- تسوية الدين بالأصل تبقى عملية ذرية ويجب ألا تُجزأ بين ViewModel وRepositories متعددة.
- الحزمة القديمة `ui/debt` ممنوعة، ولا يُعاد إنشاء `DebtsScreen` خارج الميزة.
- `DebtLedgerRepository` تنفيذ انتقالي خلف Adapter فقط؛ ممنوع حقنه في Presentation أو Feature أخرى.

الممنوع:

- `feature/debts/presentation -> com.shift.app.data.*`.
- `DebtsViewModel -> DebtAccountDao/DebtLedgerRepository/SyncManager`.
- `GoalEditorViewModel -> DebtAccountDao`.
- `feature/debts -> AssetDao/FinancialGoalDao` مباشرة.
- تنفيذ تسوية الدين بالأصل داخل Composable أو ViewModel.


## حدود Backup وRestore بعد v10

```text
SettingsScreen -> BackupViewModel -> BackupGateway
BackupGatewayAdapter -> BackupDocumentCodec -> Feature-owned Codecs
RestoreAtomicityGuard -> Room transaction + compensating external rollback
```

القواعد الملزمة:

- Presentation لا تستورد Room Entities أو Backup DTOs.
- `BackupDocumentCodec` لا يعرف كيانات الميزات؛ يعرف `BackupSectionCodec` فقط.
- كل Codec يملك Mapping والتحقق والتخطيط الخاص بميزته.
- الاستعادة إما كاملة داخل Transaction أو تُرفض قبل تغيير البيانات.
- `CancellationException` لا يتحول إلى خطأ عمل.
- الأخطاء لا تعرض Token أو بريدًا أو هاتفًا أو PIN أو Payload حساسًا.
- ممنوع إعادة إنشاء `BackupManager` مركزي أو بناء خطة الاستعادة داخل Screen.


## حدود Reports وRead Models بعد v11

```text
ReportsScreen
  -> ReportsViewModel
      -> ObserveReportsUseCase
          -> ReportsQuery
              <- ReportsQueryAdapter
                  -> Finance/Asset repositories + Debt DAOs داخل Data فقط

BuildReportsReadModelUseCase
  -> ReportsDataset
  -> ReportsReadModel
```

القواعد الملزمة:

- `ReportsScreen` يقرأ `ReportsReadModel` واحدًا، ولا يجمع Room Entities أو ينفذ حسابات مالية.
- `ReportsViewModel` يعتمد على `ObserveReportsUseCase` فقط، ولا يعرف DAO أو Repository أو `MadarDatabase`.
- `ReportsQuery` عقد قراءة فقط؛ يمنع إضافة insert/update/delete/upsert إليه.
- جميع صفوف Query وRead Models مملوكة لميزة التقارير ولا تحمل annotations أو أنواع Room.
- الحسابات المالية والتوزيعات والنسب داخل Domain Use Case، وليس داخل Compose أو Data Adapter.
- `ReportsQueryAdapter` هو المالك الوحيد للقراءة العابرة للميزات في V11.
- Cache الوحيد هو `stateIn` داخل ViewModel؛ يمنع Cache عام داخل Adapter أو Singleton mutable state.
- Legacy fallback مسموح فقط للسجل غير المرتبط بالـLedger، ويزال بعد Parity معتمد.

الممنوع:

- `feature/reports/presentation -> com.shift.app.data.*`.
- `ReportsViewModel -> DAO/Repository/MadarDatabase`.
- `ReportsScreen -> FinancialReportCalculator`.
- تمرير `Transaction/Payment/Asset/DebtAccount` Room Entities إلى Presentation.
- إضافة Command كتابة أو مزامنة إلى `ReportsQuery`.


## نمط Presentation بعد v12

```text
FeatureRoute
  -> يجمع UiState من FeatureViewModel
  -> يمرر onEvent
      -> FeatureScreen النقية
          -> Components / Action Sheets

FeatureViewModel
  -> Use Cases / Domain contracts
```

القواعد الملزمة:

- `Route` وحدها تملك `hiltViewModel()` و`collectAsState()`.
- `Screen` لا تستقبل ViewModel ولا تجمع Flow ولا تستورد Data/Room.
- جميع أفعال المستخدم تمر عبر `FeatureUiEvent` إلى `ViewModel.onEvent`.
- `FeatureUiEffect` يضاف فقط للأحداث أحادية الاستهلاك عند وجود حاجة فعلية.
- الشاشات المعدلة التي تتجاوز 500 سطر تُفصل إلى Screen ومكونات/Sheets دون تغيير السلوك.
- Read Models المملوكة للميزة مسموحة في Presentation؛ Room Entities وData DTOs ممنوعة.
- Navigation يستدعي `FeatureRoute`، وليس Screen قابلة للحقن.

الممنوع:

- `FeatureScreen(vm: FeatureViewModel = hiltViewModel())`.
- `collectAsState()` داخل Screen النقية.
- تمرير ViewModel إلى Child Composable أو Dialog/Sheet.
- `feature/*/presentation -> com.shift.app.data.*` أو `androidx.room`.
- تنفيذ Command أو حساب مالي داخل Composable بدل إطلاق Event.

حدود V12 الحالية:

```text
DebtsRoute -> DebtsScreen -> DebtsUiEvent -> DebtsViewModel
ReportsRoute -> ReportsScreen -> ReportsUiEvent -> ReportsViewModel
```


## حدود DI وPackage-by-Feature بعد v13

```text
DatabaseModule -> Room + SQLCipher + Migrations only
NetworkModule -> Supabase client/Auth only
PreferencesModule -> PreferencesManager only
Feature Data Module -> DAOs owned by that feature
SyncInfrastructureModule -> Sync Outbox + Work scheduling contracts
```

القواعد الملزمة:

- `AppModule` المركزي ممنوع إعادة إنشائه.
- بناء قاعدة البيانات لا يوفّر DAOs ولا Repositories.
- كل DAO يوفَّر من Module المجال المالك له؛ Goal DAOs تبقى داخل Goal DI.
- أسماء دوال `@Provides` فريدة على مستوى المشروع لمنع Duplicate bindings.
- `AuthViewModel` وشاشات المصادقة مملوكة لـ`feature/auth/presentation`.
- `AppSessionViewModel` مملوك لـ`feature/session/presentation`.
- Navigation وApp Shell يستوردان Feature entry points ولا يعيدان الاعتماد على `ui/auth` أو ViewModel قديم.
- نقل الملف بين الحزم يجب أن يكون Move-only ما لم يوثق تغيير سلوكي منفصل.
- لا تُنقل الحزم القديمة دفعة واحدة؛ تُنقل عند ثبات حدود الميزة واختبارها.

الممنوع:

- Module مركزي يوفّر Database وNetwork وPreferences وكل DAOs معًا.
- تكرار Provider/Binder لنفس العقد أو DAO.
- وضع Feature Presentation خارج `feature/<name>/presentation` بعد نقلها.
- اعتماد Presentation المنقولة على `com.shift.app.data.*` أو Room أو Managers تنفيذية.
- استخراج Gradle Module قبل نجاح حدود الحزمة داخل `app`.

## قواعد الاختبارات بعد V14

- اختبار السلوك هو الأصل؛ اختبار `readText()/contains()` لا يثبت التنفيذ ويُسمح به مؤقتًا لحدود المصدر فقط.
- أي Migration جديدة يجب أن تملك خطة تنفيذية قابلة للاختبار وInstrumentation test على SQLite حقيقي.
- سجل الهجرات مركزي ومتصل؛ يمنع تسجيل Migration في `DatabaseModule` يدويًا خارج `ALL_MIGRATIONS`.
- SQL المشترك بين Fresh install وMigration له مصدر واحد، ولا ينسخ بين Room callback والهجرة.
- Fault Injection يجب أن يكون No-op افتراضيًا في الإنتاج ومحدد النقاط في الاختبار.
- اختبارات ViewModel تستخدم Test doubles لعقود Domain؛ يمنع إنشاء Room أو SDK داخل الاختبار.
- تعارضات المزامنة تختبر جهازين، Pending local، Failed local، وClock skew.
- CI على نسخة نظيفة بوابة إلزامية قبل الدمج: Unit + Lint + Debug assemble، ثم Instrumentation للهجرات الحرجة.
- لا يُعلن نجاح Gradle أو Instrumentation إذا شُغلت بدائل Stubs فقط؛ تُسجل النتيجتان منفصلتين.


## حدود Gradle Modules بعد V15

```text
app
├── core:model
├── core:sync
├── feature:ledger -> core:model
├── feature:auth
├── feature:assets -> core:model
├── feature:debts -> core:model
├── feature:goals -> core:model
└── feature:reports -> core:model
```

القواعد الملزمة:

- `app` هو Composition Root الوحيد ويسمح له بالاعتماد على الوحدات المستخرجة.
- Feature Module لا يعتمد على Feature Module أخرى.
- `core:model` و`core:sync` لا يعتمدان على `app` أو أي Feature.
- وحدات Domain تمنع استيراد Android وAndroidX وRoom وData وUI وViewModel وSDKs الخارجية.
- Public API الذي يعرض نوعًا من Core أو `Flow` يستخدم `api`؛ بقية الاعتماديات تستخدم `implementation`.
- لا يكرر أي ملف Kotlin بين `app` والوحدات؛ النقل Move-only.
- أي اعتماد جديد يجب أن يمر بفحص `tools/verify_module_graph.py` ويظل Graph بلا Cycles.
- تغيير `internal` إلى `public` مسموح فقط عند عبور حد Module وموثق؛ لا تُكشف تفاصيل Data.

الممنوع:

- `feature:A -> feature:B` عبر Project dependency أو Import مباشر.
- `core:* -> feature:*`.
- نقل Room Entity أو DAO أو Supabase DTO إلى Domain Module.
- إنشاء Module فارغ لمجرد مطابقة مخطط مستقبلي.
- استخراج `core:database` قبل إزالة اعتماده على نماذج Feature.

## حدود Remote Sync والإصدار بعد V16

```text
SyncParticipant -> Feature Remote Port <- Feature Remote Data Source
SyncManager -> SyncSessionRemote + SyncOrchestrator
```

القواعد الملزمة:

- يمنع إعادة إنشاء Remote Sync مركزي يعرف كل المجالات.
- كل Participant يعتمد على عقد داخل `sync/remote`، لا على `data.remote` implementation.
- `SyncManager` لا يعرف DAO أو Room أو Supabase أو RPC.
- Data Source لكل مجال أقل من 750 سطرًا؛ أي نمو يتطلب Mapper/Transport أصغر.
- Release build يفشل عند غياب Supabase URL/Key أو Keystore properties.
- ملفات `local.properties` و`keystore.properties` وKeystore ممنوعة من Git والتسليم.
- Workflow الإصدار يأخذ الأسرار من GitHub Secrets ويحذف الملفات المؤقتة دائمًا.
- لا يُعلن Release جاهزًا دون Schema Room مطابق، Instrumentation، واختبار ترقية موقعة.


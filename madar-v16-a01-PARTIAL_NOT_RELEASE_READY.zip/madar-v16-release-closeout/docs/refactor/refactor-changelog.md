# سجل إعادة هيكلة Madar

## v00 — الفحص والتخطيط

### أضيف

- `refactor-plan.md`.
- `dependency-rules.md`.
- `verification-v01.md` لخط الأساس.
- `verification-v02.md` لمواصفة التحقق من أول مرحلة حرجة.
- ترتيب تنفيذ يقدم سلامة المزامنة على تقسيم Modules.
- بوابة Build/Test موحدة لكل مرحلة.

### رُصد

- المشروع `Single-Module` ويحتوي Module واحدًا باسم `app`.
- Room database الحالية باسم `MadarDatabase` وإصدارها 17.
- 183 ملف إنتاجي و76 ملف اختبار و269 اختبارًا معرفًا بـ`@Test`.
- `SyncManager` بحجم 2,460 سطرًا ويعتمد على قاعدة البيانات وعدد كبير من DAOs.
- `BackupManager` بحجم 1,284 سطرًا.
- `MainViewModel` يعتمد على 11 مكوّنًا ويملك مسؤوليات متعددة.
- `AuthViewModel` يعتمد مباشرة على Supabase Auth وPreferences وRepositories وRoom وSync.
- ViewModels وشاشات تستورد Room Entities وDAOs وData repositories مباشرة.
- Domain الخاص بالأهداف يستورد Room entities و`FinancialGoalRepository` التنفيذي.
- نموذج مالي قديم قائم على `Double` ما زال يعمل بجانب Ledger أحدث قائم على Decimal.
- `FinancialChangeOutbox` الحالي خاص بتغييرات تقييم الأهداف، وليس Outbox عام لمزامنة الشبكة.
- Gradle Wrapper مضبوط على `9.0-milestone-1` بدل إصدار Stable.
- ملفات SQL المطلوبة لثلاثة اختبارات عقود غير موجودة في الحزمة.
- لا يوجد `.gitignore` في جذر الحزمة، بينما `local.properties` موجود ويحتوي إعدادات حساسة.

### لم يتغير

- لم يُعدّل أي Production Code.
- لم يتغير Room schema/version 17.
- لم تتغير واجهات التطبيق أو قواعد العمل.
- لم تتغير Supabase tables أو RPCs.
- لم تُحذف أي ملفات قديمة.

### التحقق

- فحص هيكل المشروع والاعتماديات والأحجام: ناجح.
- فحص وجود Gradle root وWrapper وVersion Catalog: ناجح.
- Gradle build/tests: لم تُشغّل بسبب غياب Android SDK واتصال التنزيل في بيئة الفحص.
- لا يوجد ادعاء بأن اختبارات المشروع الحالية ناجحة.

---


## v01 — أمان دورة المزامنة

### أضيف

- `SyncSafety.kt` ويحتوي:
  - `SyncParticipant` بمؤشر مستقل لكل مجال مزامنة.
  - `SyncRunResult` بنتائج `Success / PartialFailure / AuthenticationRequired`.
  - `SyncStepFailure` وتشغيل الخطوات المعزولة مع عدم ابتلاع Cancellation.
- تخزين `sync_checkpoints_v1` داخل DataStore مع توافق رجعي من `last_sync`.
- اختبارات:
  - `SyncCheckpointTest`.
  - `InitialSyncSafetyTest`.
  - `PendingLocalChangeSurvivesPullTest`.
  - `PartialSyncFailureTest`.
  - `ClockSkewConflictTest`.

### عُدّل

- `initialSyncOnce()` ينفذ دورة Pull ثم Push كاملة، ولا يثبت الجلسة إلا بعد `Success`.
- `SyncManager` يستخدم Checkpoint مستقلًا لكل Participant.
- `lastSync` أصبح يمثل آخر دورة ثنائية مكتملة فقط، ويُحفظ بقيمة وقت بداية الدورة.
- الفشل الجزئي لا يحدّث `lastSync` ويُرجع نتيجة صريحة قابلة لإعادة المحاولة.
- أخطاء Pull الخاصة بالإعدادات وترحيل التاريخ لم تعد تُبتلع.
- `SyncMergePolicy` يمنع Remote من استبدال سجل Pending/Failed/Conflict.
- السجلات Legacy المعدلة بعد Checkpoint المجال لا تُستبدل أثناء Pull.
- `AuthViewModel` يمنع Logout العادي عند فشل المزامنة.
- `LegacyHistoryMigrationViewModel` لا يتابع الترحيل قبل نجاح المزامنة.
- `MainViewModel` يعرض فشلًا جزئيًا بدل اعتباره نجاحًا.

### لم يتغير

- Room schema/version بقي 17.
- لم تُضف Migration.
- لم تتغير Supabase tables أو RPC names أو Payload contracts.
- لم يتغير تصميم الشاشات أو التنقل أو قواعد الحساب المالي.
- Outbox الدائم وWorkManager مؤجلان للمرحلة 02.

### التحقق

- فحص Kotlin syntax للملفات المعدلة: ناجح، 8 ملفات.
- تجميع `SyncSafety.kt` و`SyncMergePolicy.kt` بواسطة `kotlinc`: ناجح.
- تجميع `PreferencesManager.kt` بعقود Stub: ناجح.
- تجميع اختبارات أمان المزامنة بعقود JUnit/Coroutines Stub: ناجح.
- تشغيل 11 اختبارًا ساكنًا: ناجح.
- فحص 16 عقدًا مصدريًا لأمان Checkpoint والنتائج والاستدعاءات: ناجح.
- Gradle لم يبدأ لأن التوزيعة غير موجودة محليًا والبيئة بلا اتصال: `UnknownHostException: services.gradle.org`.
- الاختبار اليدوي ما زال مطلوبًا.

---

## قالب إضافة إصدار لاحق

```text
## vNN — اسم المرحلة

### أضيف
- ...

### عُدّل
- ...

### حُذف
- ...

### لم يتغير
- ...

### التحقق
- الأوامر التي شُغّلت فعلًا.
- النتيجة الفعلية.
- الاختبار اليدوي.
- أي قيود أو فشل متبقٍ.
```

---

## v02 — Outbox دائم ومزامنة خلفية

### أضيف

- جدول Room عام باسم `sync_outbox` مع حالات Pending/Failed وعدّادات المحاولة وموعد المحاولة التالية.
- `SyncOutboxDao` بعمليات إدراج مدمجة، مراقبة العدادات، وحذف/فشل مشروطين بالـRevision.
- `SyncOutboxSchema` لإنشاء الجدول والفهارس و48 Trigger تغطي 24 جدولًا متزامنًا.
- `SyncQueueGateway` كحد تستعمله Presentation لطلب المزامنة وقراءة Pending/Failed.
- `SyncOutboxProcessor` لمعالجة Snapshot ثابت من Outbox.
- `SyncOutboxWorker` و`SyncWorkScheduler` باستخدام WorkManager.
- WorkManager بقيود شبكة، Retry، Exponential Backoff، عمل فوري Unique، وعمل دوري كل 15 دقيقة.
- استعادة تلقائية للطابور عند تشغيل التطبيق وبعد عودة جلسة المصادقة.
- اختبارات:
  - `OutboxIdempotencyTest`.
  - `SyncWorkerRetryTest`.
  - `SyncOutboxTransactionTest`.
  - `ProcessDeathRecoveryTest`.
  - `ViewModelSyncBoundaryTest`.
  - `WorkerConfigurationTest`.

### عُدّل

- Room schema من 17 إلى 18 مع `MIGRATION_17_18`.
- أضيف `syncState` إلى الجداول المالية القديمة: العمليات، الديون، مصادر الدخل، ومستفيدي المصروفات.
- ثُبت SQL default بقيمة `pending` على كيانات Legacy الأربعة لمطابقة Migration ومنع فشل Room schema validation.
- الكتابات المحلية في Repositories القديمة أصبحت Pending، بينما Pull البعيد يكتب Synced مباشرة.
- `SyncManager` يرفع Pending فقط ويحوّل السجل إلى Synced بعد نجاح الخادم.
- ViewModels المعدلة تطلب المزامنة عبر `SyncQueueGateway` بدل استدعاء Push مباشر.
- `MainViewModel` يقرأ عدادات المزامنة من العقد بدل DAO.
- `ShiftApplication` يبدأ استعادة Outbox والمزامنة الدورية.
- Gradle Wrapper استُبدل من milestone إلى Gradle 8.2.1 المتوافق مع AGP 8.2.2.

### حماية إضافية

- `operationId` يولد Event ID ثابتًا لمنع تكرار العملية عند إعادة المحاولة.
- كل إعادة إدراج لنفس الحدث ترفع `revision`.
- Worker يحذف أو يعلّم بالفشل فقط عندما يطابق Revision الذي التقطه؛ لذلك لا يمكن لرفع قديم حذف تعديل أحدث.
- خطأ المصادقة يحتفظ بالسجلات ولا يدخل WorkManager في Retry loop دائم؛ تسجيل الدخول يعيد إيقاظ الطابور.

### لم يتغير

- عقود Supabase وأسماء الجداول وRPCs.
- تصميم الشاشات والتنقل وقواعد الحساب المالي.
- `FinancialChangeOutbox` الخاص بإبطال تقييم الأهداف؛ بقي منفصلًا عن Sync Outbox العام.
- لا توجد إعادة كتابة لـ`SyncManager`؛ تفكيكه إلى Participants مؤجل للجلسة التالية.

### التحقق

- فحص Kotlin syntax: ناجح لـ33 ملفًا معدلًا.
- تجميع ساكن فعلي للنواة الجديدة واختباراتها بواسطة `kotlinc` مع عقود Stub: ناجح.
- تشغيل 15 اختبارًا ساكنًا: ناجح، 0 فشل.
- فحص 28 عقدًا مصدريًا: ناجح.
- تطبيق 51 عبارة SQL على مخطط Room 17 داخل SQLite: ناجح.
- إنشاء 48 Trigger على 24 جدولًا: ناجح.
- تحقق Atomic rollback وSynced skip وRevision race: ناجح.
- Gradle الكامل لم يبدأ لأن Gradle 8.2.1 غير مخزن محليًا والبيئة بلا اتصال: `UnknownHostException: services.gradle.org`.
- `18.json` واختبار Migration على جهاز ينتظران تشغيل Gradle/KSP داخل بيئة Android كاملة.

## v03 — Sync Participants ومنسق المزامنة

### أضيف

- عقد `SyncParticipant` و`SyncOperation`.
- `SyncOrchestrator` لترتيب Pull ثم Push ثم Finalize.
- `SyncCheckpointStore` و`PreferencesSyncCheckpointStore`.
- ستة Participants: المراجع، الدفتر، الأصول، الديون، الأهداف، والإعدادات.
- `RoomAssetOperationIndex` لمنع دفع عملية الأصل مرتين بين Ledger وAssets.
- Hilt multibinding داخل `SyncParticipantModule`.
- اختبارات `SyncOrchestratorTest` و`SyncParticipantArchitectureTest`.

### عُدّل

- تقلص `SyncManager` من 2,624 سطرًا في نسخة v02 إلى 65 سطرًا، وأصبح مسؤولًا عن Session mutex والواجهة العامة فقط.
- نُقل التنفيذ البعيد الحالي إلى `RemoteSyncDataSource` كطبقة انتقالية.
- تغير اسم مفاتيح المؤشرات من `SyncParticipant` إلى `SyncCheckpointKey` لمنع خلطها بعقد المشارك.
- انتقلت ملكية اختيار Pending وتجميع عمليات الرفع إلى Participants.
- استُخدمت خرائط `associateBy/groupBy` بدل `filter` المتكرر لكل `operationId`.
- نُقلت عملية إصلاح المدفوعات غير المكتملة إلى مرحلة Finalize بعد اكتمال جميع Push participants.
- أصبح حفظ Checkpoint جزءًا من الخطوة المعزولة نفسها؛ فشل التخزين لا يوقف بقية Participants ولا يسمح بتقدم المؤشر العام.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- Outbox وWorkManager وRevision guard من v02.
- أسماء جداول Supabase وRPCs وحل التعارض الحالي.
- سلوك الواجهة وقواعد الحسابات المالية.

### التحقق

- فحص Syntax للملفات المعدلة: 20/20 ناجح.
- تجميع دلالي للنواة الجديدة بواسطة `kotlinc` وعقود Stub: 14 ملفًا ناجحًا.
- اختبارات مستهدفة: 10 ناجحة، 0 فشل.
- قواعد مصدرية/معمارية: 37 ناجحة، 0 فشل.
- Gradle tests/build لم يبدآ بسبب عدم وجود Gradle 8.2.1 محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `RemoteSyncDataSource` ما زال ملفًا كبيرًا يضم Remote DTO/Mapping لعدة مجالات. المنسق وواجهة الجلسة مفصولان، لكن نقل هذه التفاصيل إلى Data الخاصة بكل Participant ما زال مطلوبًا قبل إغلاق المرحلة بالكامل.

## v04 — فصل Auth وSession وLogout

### أضيف

- عقود `AuthGateway` و`SessionReader` و`SessionWriter`.
- `SessionBootstrapper` و`SessionCleanup` ونتائج خروج صريحة.
- `SessionSyncGateway` و`AccountLocalDataCleaner` و`SessionWorkController`.
- `SupabaseAuthGateway` لعزل Supabase Auth عن Presentation.
- `PreferencesSessionStore` لعزل تفضيلات الحساب والجلسة.
- `RoomAccountLocalDataCleaner` لتنظيف بيانات الحساب داخل معاملة Room واحدة.
- `SyncManagerSessionGateway` لعزل واجهة المزامنة وقفل الجلسة.
- `WorkManagerSessionWorkController` لإلغاء وانتظار أعمال المزامنة قبل حذف البيانات.
- `SessionBootstrapCoordinator` لتهيئة الدخول والتسجيل وإيقاظ Outbox.
- `SessionCleanupCoordinator` لترتيب الخروج الآمن والإجباري.
- `AuthSessionModule` بثمانية Bindings واضحة.
- اختبارات: `AuthViewModelTest` و`SessionCleanupCoordinatorTest` و`LogoutWithPendingChangesTest` و`AuthBoundaryArchitectureTest`.

### عُدّل

- `AuthViewModel` تقلص من مالك مباشر لـSupabase وRoom وRepositories والمزامنة إلى مستهلك لأربعة عقود فقط.
- تسجيل الدخول يمر عبر `AuthGateway` ثم `SessionBootstrapper`.
- التسجيل يحفظ إعدادات الحساب ويطلب المزامنة خلف المنسق.
- الخروج العادي يمنع الحذف عند `PartialFailure` أو تغير المصادقة.
- الخروج الإجباري يتجاوز محاولة الرفع فقط بعد قرار المستخدم، لكنه يحافظ على قفل الجلسة وإيقاف WorkManager والتنظيف المنظم.
- فشل Remote sign-out يتبعه مسح Local auth session.

### حُذف من AuthViewModel

- حقن `MadarDatabase`.
- حقن سبعة Repositories.
- حقن `SyncManager` و`SyncQueueGateway`.
- حقن Supabase `Auth` و`PreferencesManager`.
- استدعاءات `deleteAll` و`withTransaction` وتنظيف Outbox.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- تصميم شاشات الدخول والتسجيل والاستعادة والإعدادات والتنقل.
- سلوك منع الخروج العادي عند فشل المزامنة.
- خيار الخروج الإجباري مع تحذير فقد البيانات.
- مفاتيح DataStore وعقود Supabase Auth.

### التحقق

- التجميع الدلالي لكل ملفات Auth/Session الجديدة و`AuthViewModel`: ناجح.
- تجميع ملفات الاختبار المستهدفة: ناجح.
- تشغيل 10 اختبارات مستهدفة: ناجح، 0 فشل.
- فحص 44 قاعدة مصدرية ومعمارية: ناجح، 0 فشل.
- Room بقي الإصدار 18 ولا يوجد `MIGRATION_18_19`.
- Gradle tests/build لم يبدآ بسبب عدم وجود Gradle 8.2.1 محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

## v05 — تفكيك App Shell وMainViewModel

### أضيف

- `AppSessionGateway` ونتائج مزامنة جلسة صريحة.
- `AppSessionGatewayAdapter` لعزل `SyncManager` وPreferences وOutbox عن Presentation.
- `LegacyIncomeSourceMigrator` لنقل ترحيل مصادر الدخل خارج ViewModel.
- `AppSessionViewModel` لحالة المزامنة العامة فقط.
- `TransactionsViewModel` لعمليات الدخل والمصروف ومصادر الدخل والمستفيدين والميزانية.
- `ReportsViewModel` لقراءات التقارير.
- `SettingsViewModel` لإعدادات الملف الشخصي والعملة.
- `BackupViewModel` للنسخ الاحتياطي والاستعادة.
- `MainViewModelDecompositionArchitectureTest`.
- `AppSessionGatewayContractTest`.

### عُدّل

- `MainScreen` يعتمد على `AppSessionViewModel` و`TransactionsViewModel` فقط.
- Dashboard وBudget ومكونات إضافة العمليات تستخدم `TransactionsViewModel`.
- Reports يستخدم `ReportsViewModel`.
- Settings يستخدم ViewModels مالكة منفصلة للجلسة والملف والنسخ الاحتياطي والعمليات.
- Plans لم يعد يستقبل ViewModel مركزيًا.
- اختبار قرار تمويل المصروف أصبح يقرأ `TransactionsViewModel`.

### حُذف

- `MainViewModel.kt` بحجمه السابق البالغ 714 سطرًا.
- تمرير ViewModel مركزي عبر شاشات Dashboard وReports وPlans وSettings.
- ملكية ترحيل مصادر الدخل من طبقة Presentation.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- قواعد الحساب المالي وLedger والأصول والديون والأهداف.
- Outbox وWorkManager وسياسة Checkpoint.
- تصميم الشاشات ومسارات التنقل.

### التحقق

- فحص Syntax: 21/21 ملف Kotlin معدل ناجح.
- تجميع دلالي لعقود الجلسة والـAdapter والـViewModel والـMigrator بواسطة `kotlinc` مع Stubs: ناجح.
- اختبارات عقود مصدرية: 11/11 ناجحة.
- قواعد معمارية: 64/64 ناجحة.
- Gradle tests/build لم يبدآ بسبب غياب Gradle 8.2.1 محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `TransactionsViewModel` و`BackupViewModel` ما زالا يعتمدان على Repositories وRoom/Sync تنفيذية؛ نقل هذه التفاصيل خلف عقود الميزات مقرر في مراحل Ledger وBackup وReports.

## v06 — توحيد Ledger والتحويل من Legacy

### أضيف

- `LegacyFinancialCutoverPlanner` وبصمة SHA-256 موحدة للتاريخ والديون.
- `LegacyFinancialCutoverCoordinator` لتنفيذ التاريخ والديون داخل معاملة Room واحدة.
- فحص Parity للدخل والمصروف والمستحقات والالتزامات قبل اعتماد التحويل.
- معاينة ديون ثابتة الترتيب مع Fingerprint ومجاميع Decimal وسجل مراجعة للقيم غير الصالحة.
- Rollback مقيد بالسجلات Pending فقط، مع تنظيف Outbox وعدم حذف بيانات Legacy الأصلية.
- اختبارات: `LegacyLedgerParityTest` و`LegacyMigrationIdempotencyTest` و`FinancialBalanceParityTest` و`LegacyCutoverRollbackTest` و`FinancialCanonicalArchitectureTest`.

### عُدل

- أصبحت Dashboard وBudget وReports تستخدم Ledger-aware APIs وتقرأ المبالغ المرتبطة من `BalanceTransaction` و`Payment`.
- بقيت معاملات Legacy غير المرتبطة مرئية مؤقتًا عبر Fallback قائم على `Double` حتى اكتمال التحويل.
- رُبط `LegacyHistoryMigrationViewModel` وWizard بمنسق التحويل المالي الموحد بدل تنفيذ ترحيل التاريخ وحده.
- أضيفت أعداد الديون المرشحة وحالات المراجعة إلى شاشة المعاينة.
- أضيفت عمليات DAO اللازمة للتحقق والرجوع الآمن دون Schema جديد.
- وُسم `DebtRepository` القديم كمسار توافق/ترحيل فقط، ووُثقت `Transaction.amount` كإسقاط Legacy.

### لم يتغير

- Room بقي الإصدار 18؛ لا Migration جديدة.
- بيانات `Transaction` و`Debt` القديمة لم تُحذف.
- مخططات Supabase وأسماء الجداول لم تتغير.
- العمليات المالية الجديدة القائمة على Decimal بقيت كما هي.

### التحقق

- اختبارات JUnit المستهدفة: 11/11 ناجحة.
- اختبارات منطق إضافية مباشرة: 19/19 ناجحة.
- فحص Syntax للملفات المعدلة: 27/27 ناجح.
- تجميع دلالي بخمس مجموعات (`domain`, `debt migrator`, `history repository`, `cutover coordinator`, `cutover ViewModel`): ناجح.
- قواعد المصدر والمعمارية: 71/71 ناجحة.
- Gradle لم يبدأ تهيئة المشروع بسبب غياب `gradle-8.2.1` محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- لا يزال `Double` موجودًا في نماذج Legacy لتوافق البيانات غير المرحّلة فقط.
- لا يُحذف Legacy قبل إثبات Parity على نسخة بيانات إنتاج مجهولة الهوية، ونجاح Gradle والاختبار اليدوي.
## v07 — حدود ميزة الأصول

### أضيف

- Domain Models مستقلة للأصل والعملية والتقييم ودفعات العملة وتخصيصات البيع.
- `AssetGateway` كعقد وحيد لطبقة Presentation.
- `ObserveAssetsUseCase` و`ObserveAssetSummariesUseCase` و`ObserveAssetDetailsUseCase`.
- Use Cases للإنشاء ودورة الحياة والتعديل.
- `AssetGatewayAdapter` و`AssetEntityMapper` وHilt binding خاص بالميزة.
- اختبارات الحدود والـUse Cases ومصنع العمليات وSync Participant.

### عُدل

- نُقل `AssetOperationFactory` و`AssetOperationRecords` إلى Data الخاصة بميزة الأصول.
- انخفض `AssetRepository` من 1,216 إلى 627 سطرًا بعد فصل بناء العمليات.
- نُقلت `AssetsViewModel` و`AssetDetailsViewModel` إلى `feature/assets/presentation`.
- قُسمت شاشة الأصول إلى `AssetsRoute` و`AssetOverviewContent` و`AssetDialogs`.
- `PaymentsScreen` أصبح يستخدم Domain Asset وViewModel الميزة بدل Room Entity والحزمة القديمة.
- `MainScreen` أصبح يستورد Route الميزة الجديدة.

### حُذف

- `viewmodel/AssetsViewModel.kt`.
- `ui/screens/AssetsScreen.kt`.
- اعتماد Presentation للأصول على `AssetRepository` وRoom Entities و`SyncManager` و`SyncQueueGateway`.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- منطق شراء/إضافة/تحسين/صيانة/تقييم/بيع الأصل.
- منطق FIFO للأصول النقدية الأجنبية.
- Outbox و`AssetSyncParticipant` والرفع المركب حسب `operationId`.
- تصميم الشاشات ومسارات التنقل وسلوك الحفظ المقصود.

### التحقق

- اختبارات V07 المستهدفة: 14/14 ناجحة.
- فحص Syntax للملفات المعدلة: 25/25 ناجح، مع حذف ملفين قديمين مقصودًا.
- تجميع دلالي لخمس مجموعات: Domain، Factory/Mapper، Repository، Adapter، ViewModels — ناجح.
- قواعد المصدر والمعمارية: 86/86 ناجحة.
- Gradle tests/build/lint لم تبدأ بسبب غياب Gradle 8.2.1 محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `AssetRepository` ما زال يجمع Query وBackup وPersistence commands؛ الفصل النهائي إلى Stores أصغر مؤجل بعد نجاح Gradle لتقليل مخاطرة تغيير المعاملات.
- `ReportsViewModel` وGoal completion ما زالا يستخدمان `AssetRepository` مباشرة؛ سينتقلان إلى Query Ports في مراحل Reports/Goals.


## v08 — حدود ميزة الديون

### أضيف

- Domain Models مستقلة للحسابات والعمليات والدفعات والجداول والتسويات.
- `DebtGateway` كعقد وحيد لطبقة Presentation والأهداف المستهلكة لبيانات الدين.
- `ObserveDebtCenterUseCase` و`ObservePayableDebtAccountsUseCase`.
- Use Cases لأوامر الإنشاء والدفع والتحصيل والمقاصة والتحويل والجدولة والأرشفة والتسوية.
- `DebtGatewayAdapter` و`DebtEntityMapper` وHilt binding خاص بالميزة.
- `DebtSettlementAssetQuery` يقرأ الأصول عبر `AssetGateway` بدل `AssetDao`.
- `DebtGoalScopePort` لعزل نطاق أهداف الديون عن التنفيذ الحالي للأهداف.
- اختبارات Use Cases وAdapter وViewModel والحدود وتسوية الدين بالأصل.

### عُدل

- نُقلت شاشات ومكونات وViewModels الديون إلى `feature/debts/presentation`.
- أصبح `DebtsViewModel` يعتمد على Use Cases فقط ولا يستورد DAO أو Repository تنفيذيًا.
- أصبح `GoalEditorViewModel` يقرأ حسابات الالتزامات عبر `ObservePayableDebtAccountsUseCase` بدل `DebtAccountDao`.
- `MainScreen` أصبح يستورد شاشة الديون من الحزمة المالكة الجديدة.
- أوامر الديون تمر عبر قفل الجلسة ثم تطلب إيقاظ Outbox بعد نجاح الكتابة المحلية.
- حُدثت اختبارات Presentation القديمة لتستخدم الحزمة الجديدة.

### حُذف

- الحزمة القديمة `ui/debt` بكامل ملفاتها.
- `ui/screens/DebtsScreen.kt` القديم.
- اعتماد Presentation للديون على DAOs وRoom Entities و`DebtLedgerRepository` و`SyncManager`.
- اعتماد `GoalEditorViewModel` المباشر على `DebtAccountDao`.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- قواعد إنشاء الحسابات والدفع والتحصيل والمقاصة والتحويل والجدولة والأرشفة.
- المعاملات الذرية لتسوية الدين بالأصل.
- Outbox وWorkManager وParticipants وسياسة Checkpoint.
- تصميم الشاشات ومسارات التنقل وسلوك الحفظ المقصود.

### التحقق

- الاختبارات المستهدفة: 31/31 ناجحة.
- فحص Syntax: 38/38 ملف Kotlin ناجح، مع حذف 16 ملفًا قديمًا مقصودًا.
- التجميع الدلالي لأربع مجموعات: Domain، Data/Adapters، ViewModel، DI — ناجح.
- قواعد المصدر والمعمارية: 148/148 ناجحة.
- Gradle tests/build/lint لم تبدأ بسبب غياب Gradle 8.2.1 محليًا وعدم توفر الشبكة: `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `DebtLedgerRepository` ما زال تنفيذًا مركزيًا كبيرًا خلف `DebtGatewayAdapter` ويجمع الحسابات والعمليات والجدولة والتعاملات العابرة؛ تفكيكه إلى Stores/Coordinators أصغر مؤجل حتى نجاح Gradle واختبارات الجهاز.
- `GoalEditorViewModel` ما زال يعتمد على تنفيذ الأهداف الحالي وRoom Models الخاصة بها؛ يعالج ذلك في V09.


## v10 — فصل Backup وRestore

### أضيف

- `BackupManifest` بإصدار وتوافق أدنى/أعلى وبصمة للملف.
- `BackupGateway` و`BackupGatewayAdapter`.
- أربعة Codecs: Finance وAssets وDebts وGoals.
- `RestoreAtomicityGuard` وتقرير Restore آمن.
- اختبارات التوافق وRound-trip والذرية والملفات التالفة والحدود.

### عُدل

- `SettingsScreen` يستخدم `BackupViewModel` الجديد ولا يجمع Room Entities أو يبني خطط الاستعادة.
- الاستعادة تعيد التخطيط من الملف وتنفذ داخل Transaction واحدة، ثم توقظ Outbox.
- أخطاء المستخدم ثابتة، والمراجع لا تحتوي بيانات حساسة.

### حُذف

- `utils/BackupManager.kt`.
- `viewmodel/BackupViewModel.kt`.
- اختبارات المدير المركزي القديمة واستُبدلت باختبارات العقود الجديدة.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- مفاتيح النسخة القديمة العليا مدعومة بوضع Legacy.
- بيانات المالية والأصول والديون والأهداف المقصودة في النسخة.

### التحقق

- اختبارات V10: 15/15 ناجحة.
- الاختبارات المعمارية الحالية: 28/28 ناجحة.
- قواعد المصدر: 36/36 ناجحة.
- التجميع الدلالي: 8/8 مجموعات ناجحة وتشمل جميع ملفات الإنتاج الجديدة.
- Gradle توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.


## v11 — Reports وRead Models

### أضيف

- `ReportsQuery` كعقد قراءة فقط.
- `ReportsDataset` وصفوف Query مملوكة للتقارير بدل Room Entities.
- `ReportsReadModel` وPeriod/Wealth/Trend/Category read models.
- `BuildReportsReadModelUseCase` و`ObserveReportsUseCase`.
- `ReportsQueryAdapter` وHilt binding مستقل.
- اختبارات Query وRead Model وحدود الاعتماديات.

### عُدل

- نُقلت شاشة التقارير وViewModel إلى `feature/reports/presentation`.
- `ReportsScreen` يجمع State واحدًا ولا ينفذ حسابات مالية أو يدمج كيانات Room.
- `MainScreen` يستورد شاشة الميزة الجديدة.
- اختبارات المعمارية المالية وتفكيك MainViewModel حُدثت لتعكس حدود V11.
- Cache التقارير أصبح مملوكًا لـ`ReportsViewModel.stateIn` فقط؛ Adapter بلا Cache.

### حُذف

- `viewmodel/ReportsViewModel.kt` القديم الذي كان يحقن `MadarDatabase` وRepositories.
- `ui/screens/ReportsScreen.kt` القديم.
- حسابات الفترة والثروة والتوزيعات من داخل Composable.

### لم يتغير

- Room schema بقي الإصدار 18؛ لا Migration جديدة.
- قواعد Ledger Decimal ومبدأ عدم احتساب Payment غير reportable كمصروف.
- Legacy fallback بقي مؤقتًا للسجلات غير المرتبطة فقط حتى إثبات Cutover على بيانات إنتاج.
- تصميم الشاشة ومسار التنقل ومرشح التاريخ.

### التحقق

- اختبارات V11 المستهدفة: 12/12 ناجحة.
- جميع اختبارات الحدود المعمارية الحالية: 32/32 ناجحة.
- التجميع الدلالي: 5/5 مجموعات ناجحة: Domain، Use Cases، Query Adapter، ViewModel، DI.
- قواعد المصدر وفحص الملفات: 50/50 ناجحة.
- Gradle توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `ReportsQueryAdapter` يقرأ من Repositories وDebt DAOs داخل Data؛ استخراج SQL Read Models محسّنة يؤجل إلى ما بعد قياس الأداء على بيانات كبيرة.
- Legacy Transaction fallback لا يُحذف قبل نجاح Parity على نسخة إنتاج مجهولة الهوية.


## v12 — نمط Presentation موحد

### أضيف

- `DebtsRoute` و`ReportsRoute` كطبقة Route تملك Hilt وجمع الـState فقط.
- `DebtsPresentationContract` ويضم `DebtsUiEvent` لجميع أحداث البحث والتبويب والعمليات.
- `ReportsPresentationContract` ويضم `ReportsUiState` و`ReportsUiEvent`.
- `DebtActionSheets.kt` لفصل نوافذ العمليات عن شاشة مركز الديون.
- `PresentationConventionArchitectureTest` لحماية Route/Screen/ViewModel/State/Event ومنع Data leaks.

### عُدل

- `MainScreen` ينتقل إلى `DebtsRoute` و`ReportsRoute` بدل الشاشات القابلة للحقن.
- `DebtsScreen` أصبحت دالة عرض نقية تستقبل `DebtCenterState` و`DebtsUiEvent` دون ViewModel أو Flow collection.
- `DebtsViewModel` أصبح يملك `onEvent` واحدًا يوجّه أحداث العرض إلى Use Cases الحالية.
- `ReportsScreen` أصبحت دالة عرض نقية تستقبل `ReportsUiState` وتطلق أحداث التاريخ فقط.
- `ReportsViewModel` أصبح يعرّض `uiState` واحدًا ويتعامل مع `ReportsUiEvent`.
- حُدثت اختبارات V05/V06/V08/V11 لتعكس Route ownership والمسارات الحالية.

### حُذف

- حقن `DebtsViewModel` و`ReportsViewModel` داخل Composables المسماة Screen.
- تمرير ViewModel إلى مكونات ونوافذ الديون الداخلية.
- جمع `StateFlow` داخل الشاشات النقية.

### لم يتغير

- Room بقي الإصدار 18؛ لا Migration ولا Schema جديد.
- قواعد الديون وعملياتها وUse Cases وOutbox والمزامنة.
- حسابات التقارير وRead Models ومرشح التاريخ.
- تصميم الشاشتين ومسارات المستخدم المقصودة.

### التحقق

- اختبارات الحدود والمصدر المستهدفة: 27/27 ناجحة.
- قواعد المصدر والمعمارية: 91/91 ناجحة.
- التجميع الدلالي: 4/4 مجموعات ناجحة: Debts contract/ViewModel، Reports contract/ViewModel، DebtsRoute، ReportsRoute.
- فحص Kotlin للملفات المعدلة: 16/16 متوازنة، ولا توجد أخطاء Syntax.
- `DebtsScreen`: انخفضت من 905 إلى 409 أسطر؛ `ReportsScreen`: 438 سطرًا.
- Gradle توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- Assets وGoals ما زالت بعض شاشاتها تستقبل ViewModels أو Domain models مباشرة؛ يطبق النمط عليها تدريجيًا عند تعديلها بدل إعادة كتابة شاملة.
- الاختبار اليدوي ومسارات DatePicker والعمليات المركبة يحتاجان جهازًا/بيئة Android كاملة.


## v13 — تقسيم DI وPackage-by-Feature

### أضيف

- `DatabaseModule` لبناء Room وSQLCipher والهجرات فقط.
- `NetworkModule` لـSupabase client وAuth.
- `PreferencesModule` لـ`PreferencesManager`.
- `LedgerDataModule` و`AssetDataModule` و`DebtDataModule` لملكية DAOs حسب المجال.
- `SyncInfrastructureModule` لـ`SyncOutboxDao` و`SyncQueueGateway`.
- `DiPackageByFeatureArchitectureTest` لمنع عودة الوحدة المركزية والتكرار والمسارات القديمة.
- توثيق ملكية الحزم والوحدات.

### عُدل

- نُقلت شاشات وViewModel المصادقة إلى `feature/auth/presentation`.
- نُقل `AppSessionViewModel` إلى `feature/session/presentation`.
- حُدثت `NavGraph` و`MainScreen` و`SettingsScreen` لاستيراد نقاط دخول الميزات الجديدة.
- حُدثت اختبارات Auth وSession وGoals وOutbox وLegacy لتتبع المسارات وRoom 18 الحالية.

### حُذف

- `di/AppModule.kt` المركزي.
- الحزمة القديمة `ui/auth`.
- `viewmodel/AppSessionViewModel.kt` القديم.

### لم يتغير

- Room بقي الإصدار 18؛ لا Migration ولا Schema جديد.
- سلوك تسجيل الدخول والتسجيل والاستعادة والخروج والمزامنة.
- إعداد SQLCipher ومفتاح قاعدة البيانات وسلسلة الهجرات.
- قواعد المالية والأصول والديون والأهداف والتقارير.

### التحقق

- اختبارات الانحدار المصدرية: 66/66 ناجحة.
- قواعد المصدر والمعمارية: 223/223 ناجحة.
- التجميع الدلالي لوحدات DI الجديدة: 7/7 ناجح.
- التجميع الدلالي لـAuth وSession Presentation: ناجح.
- فحص Syntax لملفات العرض والربط المعدلة: 8/8 ناجح.
- Gradle توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### دين انتقالي متبقٍ

- `feature/ledger` يملك DI فقط حاليًا؛ Presentation وData المالية العامة ما زالت في الحزم القديمة.
- PIN وSettings وبقية الشاشات القديمة تنتقل عند معالجة ميزاتها، لا بنقل جماعي.
- `GoalFeatureModule` ما زال Composition Root ثقيلًا لقياسات متعددة المجالات ويحتاج Ports أدق لاحقًا.


## v14 — تقوية الاختبارات والمخاطر

### أضيف

- `SqlMigrationExecutor` و`Migration17To18Plan` كخطة هجرة قابلة للاختبار دون Android.
- `SyncOutboxSqlPlan` كمصدر SQL واحد للهجرة وRoom callback والاختبارات.
- `MadarDatabase.ALL_MIGRATIONS` كسجل مركزي متصل للهجرات 2→18.
- `MigrationChainTest` و`Migration17To18InstrumentationTest`.
- `RestoreFaultPoint` و`RestoreFaultInjector` مع ثماني نقاط فشل محددة.
- `RestoreFaultInjectionTest` و`MultiDeviceConflictTest`.
- `SyncMergeDecision` لشرح نتيجة التعارض بدل Boolean فقط.
- `FakeDebtGateway` لاختبارات ViewModel عبر العقود.
- `.github/workflows/android-ci.yml` لبوابات Unit/Lint/Build/Instrumentation.

### عُدل

- `MIGRATION_17_18` يفوض الخطة التنفيذية بدل SQL مضمّن داخل `MadarDatabase`.
- `DatabaseModule` يستخدم `ALL_MIGRATIONS` بدل قائمة يدوية قابلة للنسيان.
- `SyncOutboxSchema` أصبح Adapter رقيقًا حول خطة SQL النقية.
- `RestoreAtomicityGuard` يدعم Fault Injection دون تغيير مسار الإنتاج الافتراضي.
- `SyncMergePolicy` يحافظ على `shouldApplyRemote` ويضيف قرارًا مفسرًا.
- `DebtsViewModelTest` أصبح اختبار سلوك حقيقيًا بدل فحص النص.
- `SyncOutboxTransactionTest` أصبح ينفذ خطة الهجرة ويتحقق من آثارها.

### لم يتغير

- Room بقي الإصدار 18؛ لا Migration أو Schema جديد.
- SQL الفعلي لـ17→18 ومالكو Outbox وعدد Triggers بقيت كما هي.
- سلوك Restore في الإنتاج؛ Injector الافتراضي No-op.
- قواعد الدمج الحالية؛ أضيف نوع قرار وتغطية فقط.
- Gradle Wrapper وملفات Schema 16/17.

### التحقق

- سيناريوهات سلوكية منفذة مباشرة: 17/17 ناجحة.
- قواعد V14: 147/147 ناجحة.
- تجميع Android Outbox adapter: 1/1 ناجح.
- تجميع Migration instrumentation مع Stubs: 1/1 ناجح.
- ملفات `readText` انخفضت من 47 إلى 45.
- Gradle وconnected tests توقفا قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### دين متبقٍ

- 45 ملف اختبار ما زال يستخدم قراءة المصدر؛ يُستبدل تدريجيًا حسب المخاطر.
- Schema 18 لم يُولد لأن KSP/Gradle لم يعمل في البيئة الحالية.
- Instrumentation test موجود لكنه لم يُشغّل على جهاز/محاكي بعد.


## v15 — استخراج Gradle Modules المستقرة

### أضيف

- وحدات `core:model` و`core:sync`.
- وحدات `feature:ledger/auth/assets/debts/goals/reports`.
- Build files وAndroid manifests لكل وحدة.
- `tools/verify_module_graph.py`.
- `docs/architecture/gradle-modules.md`.
- اختبارات مستقلة لـAuth domain وLedger cutover.

### عُدل

- `settings.gradle.kts` وVersion Catalog وRoot/App Gradle لإعلان الوحدات والاعتماديات.
- نقل 57 ملف Production و11 ملف Test إلى المالك الجديد دون تغيير Package names.
- نقل Sync contracts/outcomes من `data.remote` إلى `core:sync` وتحديث المستهلكين.
- تحديث اختبارات Architecture التي كانت تعتمد على مسارات `app/src/main` القديمة.
- تحديث GitHub Actions لفحص Module graph ورفع تقارير جميع الوحدات.

### حُذف من app

- نسخ Domain المنقولة إلى الوحدات الجديدة.
- `data/remote/SyncSafety.kt` بعد نقل ملكيته إلى `core:sync`.

### لم يتغير

- Room بقي الإصدار 18؛ لا Migration ولا Schema جديد.
- Package names العامة وسلوك UI والتنقل والمزامنة والحسابات المالية.
- Room وSupabase وWorkManager وCompose وHilt adapters بقيت داخل `app`.

### التحقق

- التجميع الدلالي للوحدات: 8/8 ناجح.
- اختبارات الوحدات المنقولة: 41/41 ناجحة.
- فحوص السلوك العابرة للوحدات: 17/17 ناجحة.
- اختبارات الحدود والمصدر: 25/25 ناجحة.
- انحدار SyncOrchestrator: 5/5 ناجح.
- Module graph: 599/599 ناجح، بلا Cycles أو Duplicate declarations.
- فحوص بنية Gradle/CI/Room: 13/13 ناجحة.
- تجميع SyncOrchestrator وSyncManager مع العقود الجديدة: 2/2 ناجح.
- Gradle الكامل توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### دين متبقٍ

- استخراج `core:database/network/testing` و`feature:settings` مؤجل حتى منع الاعتماد العكسي على Features.
- لا تُغلق V15 نهائيًا قبل نجاح Gradle وCI على نسخة نظيفة.


## v16 — الإغلاق وتقوية الإصدار

### أضيف

- عقود Remote Sync حسب المجال داخل `sync/remote`.
- ستة Remote Data Sources مستقلة للمراجع والدفتر والأصول والديون والأهداف والإعدادات.
- `validateReleaseConfiguration` لمنع Release بإعدادات Backend أو توقيع ناقصة.
- `.gitignore` وأمثلة آمنة لـ`local.properties` و`keystore.properties`.
- قواعد R8/ProGuard لـSQLCipher وSupabase وKotlin Serialization.
- `.github/workflows/android-release.yml` لبناء AAB موقّع من GitHub Secrets.
- وثائق Active Architecture وData Flow وSync Protocol وRelease Readiness.
- `ReleaseCloseoutArchitectureTest` و`tools/verify_release_closeout.py`.

### عُدل

- `SyncManager` يعتمد على `SyncSessionRemote` ولا يعرف التنفيذ البعيد.
- Participants تعتمد على Feature Remote Ports.
- `SyncParticipantModule` يربط كل Port بالـData Source المالك.
- إعدادات BuildConfig تستخدم قيمًا فارغة بدل النص `"null"`.
- اختبارات المزامنة والأهداف تتبع الملفات الجديدة.

### حُذف

- `RemoteSyncDataSource.kt` المركزي ذي 2,299 سطرًا.
- `LegacyHistoryMigrationRepository.applyServerCommitted` غير المستخدم.

### لم يتغير

- Room بقي الإصدار 18، دون Migration جديدة.
- مخطط SQL والمزامنة والـRPCs وسلوك المستخدم المقصود.
- Legacy financial/debt models؛ حذفها مؤجل إلى اعتماد ترحيل إنتاجي رسمي.

### التحقق

- 8/8 وحدات Domain تجمعت دلاليًا.
- 41/41 Unit tests و17/17 فحوص سلوكية نجحت.
- 5/5 اختبارات انحدار SyncOrchestrator نجحت.
- 11 ملفًا من نواة المزامنة تجمعت دلاليًا مع عقود Stub.
- ملفات Remote المقسمة اجتازت فحص Parser بعد إصلاح خطأ Payload حقيقي.
- Module graph: 612/612 بلا Cycles أو Duplicate declarations.
- Gradle توقف قبل تهيئة المشروع بسبب `UnknownHostException: services.gradle.org`.

### حواجز الإغلاق

- Room schema 18 غير مولد.
- Instrumentation والتثبيت والترقية الموقعة لم تُنفذ في هذه البيئة.


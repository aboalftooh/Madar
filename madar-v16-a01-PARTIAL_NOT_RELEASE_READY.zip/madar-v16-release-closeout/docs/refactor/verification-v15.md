# Verification V15 — Gradle Modules

## النطاق

استخراج الحدود المستقرة إلى Gradle Modules فعلية، مع منع Cycles والاعتماد العكسي، ودون تغيير Room أو السلوك المالي.

## الوحدات

```text
:core:model
:core:sync
:feature:ledger
:feature:auth
:feature:assets
:feature:debts
:feature:goals
:feature:reports
```

## نتائج التحقق

- Production Kotlin المنقول: 57 ملفًا.
- Test Kotlin المنقول/المضاف: 11 ملفًا.
- التجميع الدلالي المستقل: 8/8 وحدات ناجحة.
- اختبارات الوحدة الفعلية عبر Runner: 41/41 ناجحة.
- فحوص السلوك العابرة للوحدات: 17/17 ناجحة.
- اختبارات الحدود/المصدر: 25/25 ناجحة.
- اختبارات انحدار المزامنة: 5/5 ناجحة.
- تجميع `SyncOrchestrator` و`SyncManager` بعد نقل العقود: 2/2 ناجح.
- فحص Module graph: 599/599 ناجح.
- فحوص Gradle catalog/YAML/settings/Room: 13/13 ناجحة.
- لا توجد Cycles أو Duplicate Kotlin declarations.
- لا توجد استيرادات Android/Room/Data/UI داخل الوحدات المستخرجة.
- Room بقي الإصدار 18؛ لا Migration أو Schema جديد.

## Gradle

الأمر المطلوب:

```bash
./gradlew clean testDebugUnitTest lintDebug assembleDebug
```

النتيجة في البيئة الحالية: لم يبدأ تهيئة المشروع؛ Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب:

```text
java.net.UnknownHostException: services.gradle.org
```

لا تُعد بدائل `kotlinc` وStubs نجاحًا لـGradle؛ هي تحقق ساكن/سلوكي منفصل.

## الحالة

`IN_PROGRESS`: التنفيذ البرمجي والتحقق الساكن منجزان. الإغلاق النهائي ينتظر Gradle/CI متصلًا، ثم قرار استخراج Database/Network/Testing/Settings بعد تصحيح حدودها.

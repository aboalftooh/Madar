# Madar — خطة الإصلاح وإعادة الهيكلة التدريجية

## الهدف

تحويل المشروع تدريجيًا من `Single-Module Layered Monolith` ذي حدود مخترقة إلى `Modular Monolith` حسب الميزات، مع تقديم سلامة البيانات والمزامنة على تحسين شكل الحزم، والحفاظ على السلوك الحالي وعدم تنفيذ إعادة كتابة شاملة.

## أساس الخطة

الخطة مبنية على فحص:

- 183 ملف Kotlin إنتاجي، بنحو 29,005 أسطر.
- 76 ملف اختبار، تتضمن 269 اختبارًا.
- كان المشروع Module واحدًا باسم `app`؛ أصبح في V15 تسع وحدات تشمل `app` وثماني وحدات مستقرة.
- قاعدة Room باسم `MadarDatabase`؛ انتقلت في الجلسة v02 من الإصدار 17 إلى 18 عبر Migration صريحة.
- كان `SyncManager` بحجم 2,460 سطرًا؛ أصبح واجهة جلسة صغيرة، وفُكك `RemoteSyncDataSource` ذي 2,299 سطرًا في V16 إلى ستة Data Sources خلف Ports حسب المجال. حُذف `BackupManager` المركزي في v10 واستُبدل بـFeature-owned Codecs وGateway.
- اعتماد ViewModels مباشرة على DAOs وRoom Entities وRepositories و`SyncManager` و`PreferencesManager`.
- وجود نموذج مالي قديم قائم على `Double` بجانب Ledger أحدث قائم على Decimal/`BigDecimal`.
- مواد التعلم الخاصة بـSOLID، فصل المسؤوليات، MVVM، Repository، Dependency Inversion، تقليل الاقتران، التقسيم التدريجي، والعمل عبر وكلاء البرمجة بخطوات صغيرة قابلة للتحقق.

## القرار المعماري

الهدف النهائي ليس Microservices ولا إعادة كتابة التطبيق، بل:

```text
Modular Monolith

:app
  -> feature modules
  -> core contracts/infrastructure

داخل كل Feature:
Presentation -> Domain -> Repository Contract
Data Adapter -> Repository Contract
Infrastructure -> External SDK
```

يبدأ الفصل داخل Module `app` أولًا. لا تُستخرج Gradle Modules إلا بعد ثبات الحدود واختبارها.

## قواعد التنفيذ

1. سلامة البيانات والمزامنة تسبق تحسين أسماء الحزم وتقسيم Modules.
2. لا تُنفذ إعادة هيكلة وتغيير سلوك وظيفي في Patch واحد.
3. كل مرحلة صغيرة، مستقلة، قابلة للتراجع، ولها اختبار قبول محدد.
4. لا يتغير Room schema دون Migration واختبار Migration كامل.
5. لا يُقدَّم ادعاء نجاح لأي Build أو Test لم يُشغّل فعليًا.
6. آخر نسخة كاملة من المشروع هي مصدر الحقيقة الوحيد.
7. لا يُحذف النموذج القديم قبل إثبات تطابق النتائج والترحيل على نسخة بيانات حقيقية.
8. لا يُنقل شيء إلى `core` دون مستهلكين فعليين ومعنى مشترك ثابت.
9. لا يبدأ استخراج Gradle Modules قبل إزالة الاعتماديات العكسية داخل `app`.
10. كل مرحلة تنتهي بالبوابة العامة التالية:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug
```

11. المراحل التي تغيّر Room أو مسارات UI تتطلب أيضًا:

```bash
./gradlew connectedDebugAndroidTest
```

12. الأسرار و`local.properties` وملفات التوقيع ممنوعة من Git ومن حزم التسليم.

## حالات العمل

- `NOT_STARTED`: لم يبدأ.
- `IN_PROGRESS`: جارٍ التنفيذ.
- `BLOCKED`: متوقف بسبب اعتماد أو بيئة أو ملف مفقود.
- `DONE`: نُفذ وتحقق عبر البوابات المحددة.

## التقدم العام

| المرحلة | الحالة | النتيجة المطلوبة |
|---|---|---|
| 00. خط الأساس وبيئة البناء | BLOCKED | Build واختبارات قابلة للتكرار من نسخة نظيفة |
| 01. أمان دورة المزامنة | IN_PROGRESS | نُفذ وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 02. Outbox دائم وWorkManager | IN_PROGRESS | نُفذ وتحقق ساكنًا؛ Gradle واختبار Migration على جهاز متبقيان |
| 03. Sync Participants | IN_PROGRESS | نُفذ وتحقق ساكنًا؛ Gradle وتقسيم Remote DTO/Mapping النهائي متبقيان |
| 04. Auth وSession وLogout | IN_PROGRESS | نُفذ وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 05. App Shell وMainViewModel | IN_PROGRESS | نُفذ الفصل وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 06. Ledger والترحيل من Legacy | IN_PROGRESS | نُفذ التحويل الموحد وتحقق ساكنًا؛ Gradle وبيانات إنتاج مجهولة الهوية متبقيان |
| 07. Assets | IN_PROGRESS | نُفذت الحدود والفصل وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 08. Debts | IN_PROGRESS | نُفذت الحدود وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 09. Goals | IN_PROGRESS | نُفذت الحدود وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 10. Backup وRestore | IN_PROGRESS | نُفذ الفصل وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 11. Reports وRead Models | IN_PROGRESS | نُفذت الحدود وRead Models وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 12. Presentation Convention | IN_PROGRESS | طُبق على Debts وReports وتحقق ساكنًا؛ بقية الميزات تطبق تدريجيًا عند تعديلها |
| 13. DI وPackage-by-Feature | IN_PROGRESS | نُفذ التقسيم والنقل وتحقق ساكنًا؛ Gradle والاختبار اليدوي متبقيان |
| 14. تقوية الاختبارات | IN_PROGRESS | نُفذت اختبارات سلوك وهجرة وفشل وتعارض وCI؛ Gradle والجهاز متبقيان |
| 15. Gradle Module Extraction | IN_PROGRESS | استُخرجت 8 وحدات مستقرة بلا Cycles؛ Gradle وModules المتداخلة متبقية |
| 16. الإغلاق والإصدار | BLOCKED | نُفذ الإغلاق والتوثيق وتقوية Release؛ Gradle/Schema 18/Instrumentation/ترقية فعلية متبقية |

---

## المرحلة 00 — تثبيت خط الأساس وبيئة البناء

### الأعمال

- استبدال Gradle Wrapper التجريبي `9.0-milestone-1` بتوزيعة Stable متوافقة مع AGP `8.2.2`.
- توثيق JDK وAndroid SDK المطلوبين.
- إنشاء `.gitignore` ومنع `local.properties` وKeystore والملفات السرية.
- استعادة ملفات SQL المرجعية المطلوبة للاختبارات:
  - `docs/supabase_assets_rpc.sql`
  - `docs/supabase_debt_rpc.sql`
  - `docs/supabase_financial_goals.sql`
- تشغيل البناء من Clone/نسخة نظيفة.
- حفظ نتائج البناء والاختبارات قبل أي تعديل.

### الاختبارات

```bash
./gradlew --version
./gradlew clean testDebugUnitTest lintDebug assembleDebug
```

### الاختبار اليدوي

- فتح التطبيق.
- تسجيل الدخول.
- فتح Dashboard والأرصدة والأصول والديون والأهداف.
- إضافة عملية بسيطة ثم إغلاق التطبيق وفتحه.

### شرط الإغلاق

- جميع أوامر Gradle تعمل من جذر المشروع.
- لا توجد أسرار داخل Git أو حزمة التسليم.
- فشل أي اختبار موجود موثق قبل بدء الإصلاح.

### الحالة الحالية

`BLOCKED`: صُحح Gradle Wrapper في v02 إلى الإصدار المستقر 8.2.1، لكن بيئة الفحص الحالية لا تحتوي التوزيعة محليًا ولا اتصالًا لتنزيلها، ولا Android SDK. كما أن ملفات SQL الثلاثة المطلوبة لاختبارات العقود غير موجودة في الحزمة.

---

## المرحلة 01 — إصلاح أمان دورة المزامنة

### الهدف

إغلاق احتمال فقدان أو تجاوز تغييرات محلية عند فشل الرفع أو عند تقدم `lastSync` بصورة غير صحيحة.

### الأعمال

- استبدال `lastSync` العام بـCheckpoint واضح لكل Sync Participant أو Cursor موثق من الخادم.
- منع تحديث أي Checkpoint إلا بعد نجاح خطوات المجال المطلوبة بالكامل.
- فصل نتيجة المزامنة إلى `Success / PartialFailure / AuthenticationRequired` بدل الاعتماد على الاستثناء العام فقط.
- تحديد سياسة صريحة للتغييرات المحلية Pending قبل Pull.
- منع `initialSyncOnce()` من اعتبار Pull وحده مزامنة مكتملة.
- عدم تحويل صف محلي إلى `Synced` إلا بعد نجاح استجابة الخادم.
- توثيق سياسة التعارض وعدم جعل ساعة الهاتف المرجع الوحيد.

### الاختبارات الجديدة

```text
SyncCheckpointTest
InitialSyncSafetyTest
PendingLocalChangeSurvivesPullTest
PartialSyncFailureTest
ClockSkewConflictTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.sync.SyncCheckpointTest" \
  --tests "com.shift.app.sync.InitialSyncSafetyTest" \
  --tests "com.shift.app.sync.PendingLocalChangeSurvivesPullTest" \
  --tests "com.shift.app.sync.PartialSyncFailureTest" \
  --tests "com.shift.app.sync.ClockSkewConflictTest"

./gradlew testDebugUnitTest lintDebug assembleDebug
```

### الاختبار اليدوي

1. إنشاء عملية محليًا دون شبكة.
2. إغلاق التطبيق وفتحه.
3. إعادة الشبكة وتنفيذ Sync.
4. التأكد من وصول العملية وعدم اختفائها.
5. تعطيل Endpoint واحد والتأكد أن Checkpoint الخاص به لا يتقدم.

### شرط الإغلاق

لا يوجد سيناريو يفقد تغييرًا محليًا أو يتخطاه بسبب Checkpoint متقدم.

### الحالة الحالية

`IN_PROGRESS`: اكتمل التنفيذ البرمجي والتحقق الساكن. أضيفت Checkpoints مستقلة، وأصبحت المزامنة الأولية Pull ثم Push، ومنع تحديث `lastSync` عند Partial Failure، وحُميت السجلات Pending من الاستبدال أثناء Pull. بقي تشغيل Gradle والاختبارات اليدوية داخل بيئة تحتوي توزيع Gradle وAndroid SDK قبل تحويلها إلى `DONE`.

---

## المرحلة 02 — Outbox دائم ومزامنة خلفية

### الأعمال

- إنشاء Outbox عام للمزامنة، منفصل عن `FinancialChangeOutbox` الخاص بإبطال تقييم الأهداف.
- كتابة التغيير المالي وسجل Outbox داخل معاملة Room واحدة.
- إضافة WorkManager مع Retry وExponential Backoff وقيود الشبكة.
- جعل العمليات Idempotent باستخدام `operationId` ونسخة متوقعة عند الحاجة.
- منع ViewModels من استدعاء Push مباشرًا بعد كل عملية.
- إضافة شاشة/حالة تشخيصية لعدد Pending وFailed دون كشف بيانات حساسة.

### الاختبارات الجديدة

```text
SyncOutboxTransactionTest
SyncWorkerRetryTest
OutboxIdempotencyTest
ProcessDeathRecoveryTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.sync.outbox.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

كل تغيير محلي يبقى قابلًا للرفع بعد قتل التطبيق أو انقطاع الشبكة، ولا يتكرر ماليًا عند إعادة المحاولة.

### الحالة الحالية

`IN_PROGRESS`: نُفذ Outbox عام دائم في Room 18، وربطت به 24 جدولًا متزامنًا عبر 48 Trigger، وأضيف WorkManager بقيود شبكة وExponential Backoff واستعادة عند تشغيل التطبيق. أصبحت واجهات العرض تطلب المزامنة عبر `SyncQueueGateway` بدل Push مباشر، وأضيفت حماية Revision حتى لا يحذف Worker تعديلًا أحدث من Snapshot الذي رفعه. نجح التجميع الساكن واختبارات الجلسة والتحقق الذري داخل SQLite. بقي تشغيل Gradle، توليد Schema `18.json` بواسطة KSP، واختبار Migration/Process death على جهاز قبل تحويل المرحلة إلى `DONE`.

### اختبارات إضافية منفذة

```text
ViewModelSyncBoundaryTest
WorkerConfigurationTest
```

---

## المرحلة 03 — تحويل المزامنة إلى Participants

### الأعمال

- إنشاء عقد `SyncParticipant`.
- تقسيم المزامنة إلى Participants مملوكة للمجالات:
  - Settings
  - Legacy Transactions
  - Ledger/Payments
  - Assets
  - Debts
  - Goals
- جعل `SyncOrchestrator` مسؤولًا عن الترتيب والنتائج فقط.
- نقل Mapping وRemote DTOs لكل مجال إلى Data الخاص به.
- إزالة حقن جميع DAOs من المنسق المركزي.
- استخدام خرائط وفهارس بدل `filter` المتكرر داخل حلقات العمليات.

### الاختبارات الجديدة

```text
SyncOrchestratorTest
SyncParticipantArchitectureTest
SyncOrchestrationContractTest
SyncCheckpointTest
InitialSyncSafetyTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.sync.participant.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

`SyncOrchestrator` لا يعرف Room Entities أو DAOs أو جداول Supabase الخاصة بالمجالات.

### الحالة الحالية

`IN_PROGRESS`: نُفذ `SyncParticipant` و`SyncOperation` و`SyncOrchestrator`، وربطت ستة Participants عبر Hilt multibinding. أصبح `SyncManager` واجهة جلسة من 65 سطرًا لا تعرف Room أو DAO أو Supabase، وانتقلت قراءة Pending وتجميع العمليات إلى المشاركين مع خرائط `groupBy` بدل التصفية المتكررة. نجح التجميع الدلالي للنواة الجديدة، ونجحت 10 اختبارات و37 قاعدة مصدرية. بقي تشغيل Gradle في بيئة Android كاملة، كما بقي نقل Remote DTO/Mapping من `RemoteSyncDataSource` الانتقالي إلى ملفات Data الخاصة بكل مجال قبل اعتبار التفكيك مكتملًا بالكامل.

---

## المرحلة 04 — فصل Auth وSession وLogout

### الأعمال

- إنشاء `AuthGateway` و`SessionReader` و`SessionWriter`.
- إنشاء `SessionCleanupCoordinator` لعملية الخروج.
- نقل Supabase Auth وPreferences وDB cleanup خلف Adapters/Coordinator.
- جعل `AuthViewModel` يعتمد على عقود Auth/Session فقط.
- منع ViewModel من حقن `MadarDatabase` وRepositories و`SyncManager`.
- تثبيت ترتيب: Sync pending → قرار المستخدم عند الفشل → تنظيف محلي → إنهاء الجلسة.

### الاختبارات الجديدة

```text
AuthViewModelTest
SessionCleanupCoordinatorTest
LogoutWithPendingChangesTest
AuthBoundaryArchitectureTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.auth.*"
./gradlew testDebugUnitTest --tests "com.shift.app.architecture.AuthBoundaryArchitectureTest"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### الاختبار اليدوي

- دخول صحيح وخاطئ.
- استعادة كلمة المرور.
- خروج مع مزامنة ناجحة.
- خروج مع مزامنة فاشلة ثم اختيار الإلغاء.
- خروج إجباري مع تحذير فقد البيانات غير المرفوعة.

### شرط الإغلاق

`AuthViewModel` لا يستورد Data أو Room أو Supabase أو Sync implementation.

### الحالة الحالية

`IN_PROGRESS`: أضيفت عقود `AuthGateway` و`SessionReader/Writer`، وأصبح `AuthViewModel` يعتمد على عقود المصادقة والجلسة فقط. انتقلت تهيئة الجلسة إلى `SessionBootstrapCoordinator`، وانتقل الخروج الآمن والإجباري إلى `SessionCleanupCoordinator`. أصبح ترتيب الخروج: مزامنة آمنة عند الطلب، ثم قفل الجلسة، ثم إيقاف WorkManager، ثم تنظيف Room داخل معاملة، ثم مسح تفضيلات الحساب، ثم إنهاء جلسة Supabase مع fallback لمسح الجلسة المحلية. نجح التجميع الدلالي والاختبارات المستهدفة والقواعد المعمارية. بقي تشغيل Gradle والاختبار اليدوي داخل بيئة Android كاملة قبل تحويل المرحلة إلى `DONE`.

---

## المرحلة 05 — تفكيك App Shell و`MainViewModel`

### الأعمال

- حصر مسؤوليات `MainViewModel` الحالية.
- إنشاء ViewModels مالكة لكل Feature بدل تجميع كل البيانات والعمليات مركزيًا.
- إنشاء `AppSessionViewModel` لحالة الجلسة العامة فقط.
- نقل النسخ الاحتياطي والاستعادة والإعدادات والمزامنة إلى ملاكها.
- منع Navigation من استخدام ViewModel عملاق كحاوية خدمات.

### الاختبارات الجديدة

```text
MainViewModelBoundaryTest
AppSessionViewModelTest
FeatureOwnershipArchitectureTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.architecture.*Ownership*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

لا يوجد ViewModel ينسق الأصول والديون والأهداف والنسخ الاحتياطي والمزامنة في وقت واحد.

### الحالة الحالية

`IN_PROGRESS`: حُذف `MainViewModel` نهائيًا، وأصبحت الملكية موزعة على `AppSessionViewModel` و`TransactionsViewModel` و`ReportsViewModel` و`SettingsViewModel` و`BackupViewModel`. أصبح App Shell يعتمد على حالة الجلسة ومدخل العمليات فقط، بينما انتقلت المزامنة العامة خلف `AppSessionGateway`. نجحت اختبارات العقود والتجميع الساكن والقواعد المعمارية. بقي تشغيل Gradle والاختبار اليدوي قبل تحويل المرحلة إلى `DONE`.

---

## المرحلة 06 — توحيد Ledger والترحيل من Legacy

### الأعمال

- تجميد إضافة قدرات جديدة إلى `Transaction` و`Debt` القديمين.
- تعريف مصدر الحقيقة المالي: Ledger وPayments وDebt Ledger.
- توثيق Mapping بين القديم والجديد.
- تشغيل ترحيل Idempotent مع Fingerprint ونتيجة مراجعة.
- مقارنة الأرصدة والتقارير قبل وبعد الترحيل.
- إزالة `Double` من أي نموذج مالي جديد.
- عدم حذف القديم قبل تحقق بيانات إنتاج منسوخة ومجهولة الهوية.

### الاختبارات الجديدة

```text
LegacyLedgerParityTest
LegacyMigrationIdempotencyTest
FinancialBalanceParityTest
LegacyCutoverRollbackTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.legacy.*"
./gradlew testDebugUnitTest --tests "com.shift.app.finance.*Parity*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

الأرصدة والتقارير متطابقة، وكل عملية مالية جديدة تستخدم Decimal canonical فقط.

### الحالة الحالية

`IN_PROGRESS`: أضيف منسق تحويل مالي موحد يجمع ترحيل التاريخ والديون داخل معاملة Room واحدة، ببصمة SHA-256 وفحص Parity وRollback مقيد بالسجلات المحلية غير المتزامنة. أصبحت Dashboard وBudget وReports تقرأ القيم المرتبطة من Ledger Decimal، مع إبقاء `Double` كمسار توافق للسجلات القديمة غير المرحّلة فقط. رُبط المعالج الفعلي بالمنسق الموحد، ونجحت اختبارات V06 والتجميع الساكن. بقي تشغيل Gradle، الاختبار اليدوي، وإثبات التطابق على نسخة بيانات إنتاج مجهولة الهوية قبل الإغلاق والحذف النهائي للمسار القديم.

---

## المرحلة 07 — حدود ميزة الأصول

### الأعمال

- إنشاء Domain Models و`AssetGateway`.
- إبقاء DAOs وRoom Entities داخل Data.
- تقسيم `AssetRepository` إلى عمليات أصغر أو Services حسب السيناريو.
- فصل شراء/بيع/تقييم/تحويل/عملات عبر Use Cases واضحة.
- توفير Ports للرصيد والديون بدل استدعاء Repositories التنفيذية.
- تقسيم `AssetsScreen` إلى Route + Components + Feature screens.

### الاختبارات الجديدة

```text
AssetGatewayAdapterTest
AssetUseCasesTest
AssetBoundaryArchitectureTest
AssetSyncParticipantTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.assets.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

Presentation للأصول لا يستورد Room Entity أو `SyncManager`، وعمليات الأصل الذرية محفوظة.

### الحالة الحالية

`IN_PROGRESS`: أضيفت Domain Models مستقلة و`AssetGateway` وUse Cases للقراءة والإنشاء ودورة حياة الأصل والتعديل. أصبح `AssetGatewayAdapter` المالك الوحيد لربط Presentation بالتنفيذ الحالي والجلسة وطابور المزامنة. نُقل `AssetOperationFactory` إلى Data الخاصة بالميزة، وانخفض `AssetRepository` من 1,216 إلى 627 سطرًا. نُقلت ViewModels والشاشات إلى `feature/assets` وقُسمت الشاشة إلى Route وOverview وDialogs، ولم تعد Presentation تستورد Room Entities أو `SyncManager`. نجحت 14/14 اختبارات مستهدفة، و86/86 قاعدة مصدرية، والتجميع الدلالي لخمس مجموعات. بقي Gradle والاختبار اليدوي على جهاز قبل الإغلاق النهائي.

---

## المرحلة 08 — حدود ميزة الديون

### الأعمال

- إنشاء `DebtGateway` وDomain Models خاصة بالديون.
- إزالة DAOs من `DebtsViewModel` و`GoalEditorViewModel`.
- إبقاء Settlement والتسويات والجدولة داخل Use Cases/Coordinator واضح.
- توفير Query للأصول المتاحة بدل حقن `AssetDao`.
- فصل `DebtLedgerRepository` إلى وحدات حسب الحساب والعملية والجدولة إن لزم.

### الاختبارات الجديدة

```text
DebtGatewayAdapterTest
DebtsViewModelTest
DebtBoundaryArchitectureTest
DebtAssetSettlementIntegrationTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.debts.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

ميزة الديون لا تصل مباشرة إلى DAO مملوك للأصول أو الأهداف أو الرصيد.

### الحالة الحالية

`IN_PROGRESS`: أضيفت Domain Models و`DebtGateway` وUse Cases مستقلة للقراءة والأوامر، ونُقلت شاشات وViewModels الديون إلى `feature/debts`. أصبح `DebtsViewModel` يعتمد على Use Cases فقط، وأزيل `DebtAccountDao` من `GoalEditorViewModel` لصالح `ObservePayableDebtAccountsUseCase`. قراءة الأصول المتاحة للتسوية تمر عبر `DebtSettlementAssetQuery` و`AssetGateway`، ونطاق أهداف الديون يمر عبر Port خاص. نجحت 31/31 اختبارات مستهدفة، و148/148 قاعدة مصدرية، وفحص Syntax لـ38/38 ملفًا، والتجميع الدلالي لأربع مجموعات. بقي Gradle والاختبار اليدوي، كما بقي `DebtLedgerRepository` تنفيذًا انتقاليًا خلف Adapter ويحتاج تفكيكًا لاحقًا بعد تثبيت بوابة البناء.

---

## المرحلة 09 — حدود ميزة الأهداف

### الأعمال

- نقل Goal Domain Models خارج `data.local.entities.goals`.
- جعل Templates وMeasurement Providers وUse Cases تعتمد على Domain فقط.
- إنشاء `GoalGateway` وQueries للأهداف.
- منع ViewModels من حقن `FinancialGoalDao` و`DebtAccountDao`.
- إبقاء `FinancialChangeOutbox` خاصًا بإبطال القياس، لا مزامنة الشبكة.
- تقليل اعتماد `AppModule` على تفاصيل القياس والـDAOs.

### الاختبارات الجديدة

```text
GoalGatewayAdapterTest
GoalDomainIndependenceTest
GoalBoundaryArchitectureTest
GoalMeasurementProviderTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.goals.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

حزمة Domain للأهداف لا تستورد Android أو Room أو `data.repository`.

---

## المرحلة 10 — فصل Backup وRestore

### الأعمال

- تقسيم `BackupManager` إلى Codecs مملوكة للميزات.
- إنشاء `BackupManifest` برقم إصدار وتوافق أدنى/أعلى.
- فصل قراءة الملف والتحقق والتخطيط والتطبيق.
- تطبيق Restore داخل معاملة واضحة مع تقرير أخطاء.
- منع ViewModel من معرفة DTOs الخاصة بكل مجال.
- إضافة Redaction للبيانات الحساسة في سجلات الأخطاء.

### الاختبارات الجديدة

```text
BackupManifestCompatibilityTest
BackupCodecRoundTripTest
RestoreAtomicityTest
CorruptBackupRejectionTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.backup.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

لا يوجد Manager واحد يعرف جميع كيانات التطبيق، والاستعادة إما كاملة أو لا تُطبّق.

### الحالة الحالية

`IN_PROGRESS`: حُذف `BackupManager` وViewModel القديم، وقُسمت البيانات إلى أربعة Codecs مملوكة للمالية والأصول والديون والأهداف. أضيف Manifest بإصدار وتوافق، وفُصل inspect/plan/restore، وأصبحت الاستعادة داخل Transaction واحدة مع تعويض DataStore، ونجحت الاختبارات والتجميع الساكن. بقي تشغيل Gradle والاختبار اليدوي داخل بيئة مكتملة.

---

## المرحلة 11 — Reports وRead Models

### الأعمال

- إنشاء Query contracts وRead Models مخصصة للتقارير.
- منع Screens من دمج Room Entities الخام.
- إبقاء حسابات المال في Domain calculators.
- إزالة الاعتماد على النموذج القديم بعد اكتمال Cutover.
- تحديد Cache owner وعدم استخدام Cache عام غير واضح.

### الاختبارات الجديدة

```text
ReportsQueryTest
ReportReadModelTest
ReportsBoundaryArchitectureTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.reports.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

التقارير تقرأ فقط ولا تعدل بيانات المجالات، ولا تستقبل DAOs مباشرة.

### الحالة الحالية

`IN_PROGRESS`: أُنشئ `ReportsQuery` و`ReportsDataset` وRead Models مملوكة للتقارير، ونُقلت الحسابات إلى `BuildReportsReadModelUseCase`. حُذف `ReportsViewModel` القديم ونُقلت الشاشة إلى `feature/reports/presentation` وأصبحت تقرأ State واحدًا فقط. نجحت اختبارات V11 والتجميع الساكن واختبارات الحدود الحالية. بقي Gradle والاختبار اليدوي، كما يبقى Legacy fallback حتى إثبات Cutover على بيانات إنتاج مجهولة الهوية.

---

## المرحلة 12 — نمط Presentation موحد

### الأعمال

اعتماد تدريجي للنمط:

```text
FeatureRoute
FeatureScreen
FeatureViewModel
FeatureUiState
FeatureUiEvent
FeatureUiEffect عند الحاجة
```

- إنشاء UI Models بدل تمرير Room Entities.
- تقسيم الشاشات التي تتجاوز 500 سطرًا عند تعديل ميزتها.
- توحيد التعامل مع الأخطاء والتحميل والعمليات أحادية الاستهلاك.
- عدم إعادة كتابة جميع الشاشات دفعة واحدة.

### الاختبارات

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

كل Feature معدلة تتبع النمط، ولا تتسرب Data models إلى Composables.

### الحالة الحالية

`IN_PROGRESS`: طُبق النمط فعليًا على ميزتي الديون والتقارير بوصفهما آخر ميزتين معدلتين والأكثر احتكاكًا بالواجهة. أضيفت `DebtsRoute` و`ReportsRoute` لملكية Hilt وجمع الـState، وأصبحت `DebtsScreen` و`ReportsScreen` دوال عرض نقية تستقبل `UiState` و`UiEvent` فقط. أضيف `DebtsUiEvent` و`ReportsUiEvent` مع dispatch مركزي داخل ViewModels، ونُقلت نوافذ عمليات الديون إلى `DebtActionSheets.kt` فانخفضت شاشة الديون من 905 إلى 409 أسطر، وبقيت شاشة التقارير 438 سطرًا. لا تستورد الشاشتان ViewModel أو Room أو Data ولا تجمعان Flow. نجحت 27/27 اختبارات حدود ومصدر، و91/91 قاعدة تحقق، والتجميع الدلالي لأربع مجموعات. بقي تطبيق النمط تدريجيًا على Assets وGoals وBackup/Auth عند تعديل شاشاتها، وتشغيل Gradle واختبارات الجهاز في بيئة Android متصلة قبل تحويل المرحلة إلى `DONE`.

---

## المرحلة 13 — تقسيم DI وPackage-by-Feature داخل `app`

### الأعمال

تقسيم `AppModule` إلى:

```text
DatabaseModule
NetworkModule
SyncModule
SessionModule
RepositoryModule
Feature-specific modules
```

ثم نقل الحزم إلى:

```text
feature/<name>/presentation
feature/<name>/domain
feature/<name>/data
feature/<name>/di
infrastructure/sync
infrastructure/backup
```

### الاختبارات الجديدة

```text
DependencyRulesArchitectureTest
NoDuplicateBindingsTest
PackageOwnershipTest
```

### أوامر التحقق

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.architecture.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

لا توجد Bindings مكررة، ولا يعتمد Domain على Data، وحدود الميزات قابلة للرؤية داخل Module واحد.

### الحالة الحالية

`IN_PROGRESS`: حُذف `AppModule` المركزي واستُبدل بوحدات مستقلة للبناء المحلي، الشبكة، التفضيلات، Ledger DAOs، Asset DAOs، Debt DAOs، Goal DI، وSync infrastructure. نُقلت Presentation الخاصة بالمصادقة إلى `feature/auth/presentation`، ونُقل `AppSessionViewModel` إلى `feature/session/presentation` مع تحديث Navigation وApp Shell دون تغيير السلوك. أضيف `DiPackageByFeatureArchitectureTest`، وحُدثت اختبارات المصدر القديمة لتتبع الحزم وRoom 18 الحالية. نجحت 66/66 اختبارات انحدار مصدرية، و223/223 قاعدة معمارية ومصدرية، وتجميع DI الدلالي 7/7، وتجميع Auth/Session الدلالي، وفحص Syntax لثمانية ملفات UI. بقي تشغيل Gradle والاختبار اليدوي داخل بيئة Android متصلة قبل تحويل المرحلة إلى `DONE`. الحزم المالية العامة وPIN/Settings ما زالت انتقالية وتُنقل عند معالجة ميزاتها بدل نقل شامل غير آمن.

---

## المرحلة 14 — تقوية الاختبارات

### الأعمال

- تقليل اختبارات `readText()/contains()` الهشة واستبدالها باختبارات سلوك أو Architecture tests مناسبة.
- إضافة Migration tests من أقدم نسخة مدعومة إلى 17 وما بعدها.
- إضافة Fault injection للمزامنة والنسخ الاحتياطي.
- إضافة اختبار جهازين وتعارضات وتغيير الساعة.
- إضافة Test doubles للعقود بدل Room/SDK في اختبارات ViewModel.
- إنشاء CI يشغل البوابات على نسخة نظيفة.

### المنفذ في V14

- استخراج `Migration17To18Plan` و`SyncOutboxSqlPlan` كخطط تنفيذية بلا Android، واستخدامهما فعليًا من Room.
- إضافة `MigrationChainTest` للتأكد من اتصال جميع الهجرات من 2 إلى 18.
- إضافة Instrumentation test ينفذ 17→18 على SQLite فعليًا ويتحقق من الأعمدة و48 Trigger وOutbox seed.
- إضافة ثماني نقاط Fault Injection داخل Restore واختبارات فشل قبل/بعد الكتابة الخارجية والرجوع العكسي.
- إضافة `SyncMergeDecision` واختبار أربعة سيناريوهات لجهازين وانحراف الساعة.
- استبدال اختباري DebtsViewModel وSyncOutbox النصيين باختبارات سلوك تستخدم `FakeDebtGateway` وخطة SQL فعلية.
- إضافة GitHub Actions لتشغيل Unit/Lint/Assemble وInstrumentation على API 34.
- خفض ملفات الاختبارات التي تستخدم `readText` من 47 إلى 45؛ البقية دين مرحلي وليست مقبولة كبديل نهائي لاختبارات السلوك.

### أوامر التحقق

```bash
./gradlew clean testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

### شرط الإغلاق

الاختبارات تثبت السلوك والمخاطر، لا مجرد وجود كلمات داخل ملفات المصدر.

### الحالة الحالية

`IN_PROGRESS`: نجحت 17/17 سيناريوهات سلوكية مكافئة بتجميع Kotlin وتشغيل مباشر، و147/147 قاعدة V14، وتجميع Android adapter وMigration instrumentation مع Stubs. تعذر Gradle وconnected tests قبل تهيئة المشروع بسبب عدم توفر Gradle 8.2.1 محليًا وغياب الاتصال بـ`services.gradle.org`. لا تتحول المرحلة إلى `DONE` قبل نجاح GitHub CI أو بيئة Android متصلة، وتوليد Schema 18 من KSP ومراجعته.

---

## المرحلة 15 — استخراج Gradle Modules

### الهدف

فرض حدود Compile-time تدريجيًا بعد استقرار Package-by-Feature، دون نقل Room أو Supabase أو Compose قبل تثبيت ملكيتها.

### الوحدات المستخرجة في V15

```text
:core:model
:core:sync
:feature:ledger
:feature:auth
:feature:assets
:feature:debts
:feature:goals
:feature:reports
```

### الأعمال المنفذة

- تحويل الوحدات الثماني إلى Android Library Modules مستقلة بـJava/Kotlin 17 وminSdk 26.
- نقل 57 ملف Kotlin إنتاجي ثابت من `app` إلى مالكيه الجدد:
  - النواة المالية/الديون المشتركة إلى `core:model`.
  - عقود ونتائج المزامنة ومفاتيح Checkpoint إلى `core:sync`.
  - خطة التحويل المالي إلى `feature:ledger`.
  - عقود ونماذج وUse Cases الخاصة بـAuth/Assets/Debts/Goals/Reports إلى وحداتها.
- نقل 11 ملف اختبار إلى الوحدات المالكة وإضافة اختبارات Auth وLedger مستقلة.
- إبقاء Package names الحالية لتجنب تغيير سلوكي أو Migration غير ضرورية.
- إضافة Dependencies صريحة من `app`، واستخدام `api` فقط عندما يظهر نوع Core/Flow في Public API.
- منع Feature من الاعتماد على Feature أخرى؛ جميع الوحدات تعتمد على `core:model` أو لا تعتمد على مشروع آخر.
- نقل `SyncSafety` من حزمة Data إلى `core:sync` وتحديث جميع الاستيرادات.
- تحديث اختبارات الحدود التي كانت تفترض وجود Domain داخل `app/src/main`.
- إضافة `tools/verify_module_graph.py` لفحص Cycles، التكرار، الاستيرادات الممنوعة، وارتباط `app` بكل الوحدات.
- تحديث CI ليشغل فحص Graph قبل Unit/Lint/Assemble ويرفع تقارير جميع الوحدات.

### لم يُستخرج بعد

- `core:database`: يعتمد حاليًا على نماذج Goals وRoom ownership متداخل؛ استخراجه الآن سيخلق اتجاه اعتماد خاطئ.
- `core:network`: Remote models وMappers ما زالت مرتبطة بكيانات Data متعددة.
- `core:testing`: يحتاج Test Fixtures مستقرة بدل نقل Fakes متفرقة.
- `feature:settings`: لا توجد حدود Domain مستقرة كافية بعد.
- Data/Presentation للميزات تبقى داخل `app`؛ V15 استخرج Domain المستقر فقط.

### أوامر التحقق

```bash
python3 tools/verify_module_graph.py
./gradlew clean testDebugUnitTest lintDebug assembleDebug
```

### شرط الإغلاق

- Dependency graph أحادي الاتجاه ولا توجد Cycles أو Duplicate classes.
- جميع وحدات Domain خالية من Android/Room/Data/UI imports.
- Gradle يبني جميع الوحدات ويشغّل Unit/Lint/Assemble من نسخة نظيفة.

### الحالة الحالية

`IN_PROGRESS`: نجح التجميع الدلالي للوحدات 8/8، و41/41 اختبار وحدة، و17/17 فحص سلوكي، و25/25 اختبار حدود/مصدر، و5/5 اختبارات انحدار للمزامنة، و599/599 فحص Graph، و13/13 فحص بنية. بقي Gradle الفعلي محجوبًا لأن Wrapper يحاول تنزيل Gradle 8.2.1 والبيئة بلا اتصال (`UnknownHostException: services.gradle.org`). كما أن `core:database/network/testing` و`feature:settings` مؤجلة حتى تصحيح اتجاه اعتمادياتها.

---

## المرحلة 16 — الإغلاق والإصدار

### الأعمال

- حذف Adapters الانتقالية والحزم القديمة غير المستخدمة.
- حذف Legacy models بعد ترحيل واعتماد رسمي فقط.
- تحديث Active Architecture وData Flow وSync Protocol.
- تشغيل Unit وMigration وInstrumentation tests.
- بناء Debug وRelease واختبار التثبيت والترقية من نسخة فعلية.
- مراجعة ProGuard/Sentry/Secrets ونسخة قاعدة البيانات.

### أوامر التحقق النهائية

```bash
./gradlew clean testDebugUnitTest lintDebug assembleDebug bundleRelease
./gradlew connectedDebugAndroidTest
```

### شرط النجاح النهائي

- لا فقد بيانات في سيناريوهات Offline/Retry/Process death.
- السلوك المالي محفوظ ومقارن بنتائج Legacy.
- لا توجد God Objects مركزية في Sync أو Backup أو ViewModels أو DI.
- الحدود معززة بالاختبارات وGradle Modules.
- Release قابل للتثبيت والترقية دون كسر قاعدة البيانات.

### الحالة الحالية

`BLOCKED`: فُكك Remote Sync إلى ستة Data Sources خلف Ports، وأضيف تحقق Release والأسرار والتوقيع وR8 وWorkflow لبناء AAB، وحُذفت واجهة توافق غير مستخدمة، ووُثقت المعمارية وتدفق البيانات وبروتوكول المزامنة. نجحت اختبارات الوحدات والسلوك والمزامنة والحدود والتجميع الساكن المتاح. لا يمكن إغلاق المرحلة قبل نجاح Gradle الفعلي، توليد Room schema 18، تشغيل Instrumentation، واختبار تثبيت/ترقية Release موقعة.

---

## بروتوكول تسليم كل مرحلة

كل إصدار يتضمن:

1. `madar-full-vNN.zip`: المشروع الكامل بعد المرحلة.
2. `patch-vNN.zip`: الملفات الجديدة والمعدلة فقط.
3. `PATCH_MANIFEST.md`: قائمة الملفات وأسباب التغيير.
4. `verification-vNN.md`: ما شُغّل ونتيجته الفعلية.
5. تحديث `refactor-plan.md` و`refactor-changelog.md`.
6. نسخة Room schema الجديدة عند تغيير الإصدار.
7. نتيجة الاختبار اليدوي بوضوح.

## قاعدة المصدر الوحيد

- يلزم إرسال نسخة كاملة جديدة عند تعديل المشروع محليًا أو دمج Patch من مصدر آخر.
- عند التعارض، أحدث نسخة كاملة يرسلها المالك هي مصدر الحقيقة.

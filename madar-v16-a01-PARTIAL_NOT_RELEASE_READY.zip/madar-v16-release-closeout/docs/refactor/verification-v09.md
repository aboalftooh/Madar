# Verification v09 — V08 حدود ميزة الديون

## النطاق

فصل ميزة الديون إلى Presentation/Domain/Data واضحة، وإزالة DAOs وRepositories التنفيذية من ViewModels، مع الحفاظ على المعاملات الذرية وOutbox وRoom 18.

## ما تم

- إنشاء Domain Models وCommands و`DebtGateway`.
- إنشاء Use Cases للقراءة وأوامر الديون.
- إنشاء `DebtGatewayAdapter` وMapper وHilt binding.
- نقل شاشة ومكونات وViewModels الديون إلى `feature/debts`.
- إزالة `DebtAccountDao` من `GoalEditorViewModel`.
- توفير Query للأصول عبر `AssetGateway` بدل `AssetDao`.
- عزل نطاق أهداف الديون خلف Port.
- إبقاء قفل الجلسة وإيقاظ Outbox بعد نجاح الكتابة المحلية.

## الاختبارات المنفذة فعليًا

```text
اختبارات V08 الجديدة واختبارات الانحدار المستهدفة        31/31
--------------------------------------------------------------
الإجمالي                                                   31/31
```

النتيجة: ناجحة، 0 فشل.

## التجميع الساكن

### فحص Syntax

- 38/38 ملف Kotlin جديد أو معدل: ناجح.
- 16 ملفًا قديمًا حُذفت مقصودًا بعد نقل Presentation إلى الحزمة الجديدة.

### التجميع الدلالي بواسطة kotlinc مع Stubs

```text
1. Debt Domain + Gateway + Use Cases                 ناجح
2. Data Mappers + Adapters + Ports                   ناجح
3. DebtsViewModel + Use Cases                        ناجح
4. DebtFeatureModule                                 ناجح
```

ملاحظة: ملفات Compose فُحصت نحويًا وحدوديًا، ولم تُجمع دلاليًا خارج Gradle لغياب Android/Compose SDK dependencies.

## القواعد المعمارية

- 148/148 قاعدة مصدرية ومعمارية: ناجحة.
- Presentation لا تستورد Data أو Room أو Sync.
- `GoalEditorViewModel` لا يستورد `DebtAccountDao`.
- Feature الديون لا تستورد `AssetDao` أو `FinancialGoalDao` مباشرة.
- Room بقي الإصدار 18 ولا يوجد `MIGRATION_18_19`.

## Gradle

الأوامر التالية جُربت:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

لم تبدأ تهيئة المشروع؛ Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب عدم توفر الشبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

هذه نتيجة بيئية وليست نجاحًا أو فشلًا لاختبارات Gradle.

## الاختبار اليدوي المطلوب

1. فتح شاشة الديون والتنقل بين المستحقات والالتزامات والبحث.
2. إنشاء حساب مستحق وحساب التزام.
3. تسجيل تحصيل ودفع جزئي وكامل.
4. إنشاء أصل ممول وبيع آجل.
5. تسوية دين بأصل نشط والتحقق من حالة الأصل وقيمته.
6. تنفيذ مقاصة وتحويل وجدولة وأرشفة وعكس عملية.
7. فتح هدف سداد دين والتحقق من ظهور حسابات الالتزامات.
8. إغلاق التطبيق بعد عملية وفتحه والتحقق من بقائها ودخولها طابور المزامنة.

## أوامر إعادة التحقق داخل بيئة كاملة

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.debts.*"
./gradlew testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

## حالة الإغلاق

`IN_PROGRESS`: التنفيذ والاختبارات والتجميع الساكن مكتملة. تبقى بوابة Gradle والاختبار اليدوي على جهاز Android قبل `DONE`.

# Verification v04 — الجلسة v03: Sync Participants

## الحالة

`IN_PROGRESS — IMPLEMENTED / STATIC_VERIFIED / GRADLE_BLOCKED`

اكتمل فصل واجهة الجلسة والمنسق وملكية خطوات المزامنة. لا تعد المرحلة `DONE` قبل نجاح Gradle، واختبار مزامنة فعلي، واستكمال توزيع Remote DTO/Mapping الانتقالي.

## النطاق المنفذ

- إنشاء `SyncParticipant` و`SyncOperation`.
- إنشاء `SyncOrchestrator` يعتمد على مجموعة Participants عبر Hilt multibinding.
- إنشاء ستة Participants:
  - `ReferenceDataSyncParticipant`.
  - `LedgerSyncParticipant`.
  - `AssetSyncParticipant`.
  - `DebtSyncParticipant`.
  - `GoalSyncParticipant`.
  - `SettingsSyncParticipant`.
- إنشاء `SyncCheckpointStore` لعزل DataStore عن المنسق.
- تقليص `SyncManager` إلى واجهة جلسة من 65 سطرًا.
- نقل التنفيذ البعيد القديم إلى `RemoteSyncDataSource` الانتقالي.
- الحفاظ على Checkpoint مستقل لكل Pull operation.
- تشغيل Finalize بعد اكتمال جميع Push operations.
- استخدام خرائط `groupBy/associateBy` لتجميع العمليات بدل البحث المتكرر.
- منع رفع عملية الأصل مرتين بواسطة `RoomAssetOperationIndex`.

## الملفات الجديدة الأساسية

```text
app/src/main/java/com/shift/app/sync/SyncParticipant.kt
app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt
app/src/main/java/com/shift/app/sync/SyncCheckpointStore.kt
app/src/main/java/com/shift/app/sync/PreferencesSyncCheckpointStore.kt
app/src/main/java/com/shift/app/sync/di/SyncParticipantModule.kt
app/src/main/java/com/shift/app/sync/participant/*
app/src/main/java/com/shift/app/data/remote/RemoteSyncDataSource.kt
app/src/test/java/com/shift/app/sync/SyncOrchestratorTest.kt
app/src/test/java/com/shift/app/sync/SyncParticipantArchitectureTest.kt
```

## الاختبارات المنفذة

الاختبارات التي شُغلت داخل Harness محلي:

```text
SyncOrchestratorTest.participantsRunByOrderWithPullBeforePush
SyncOrchestratorTest.failedPullDoesNotAdvanceItsCheckpointOrGlobalCheckpoint
SyncOrchestratorTest.changedAuthenticationStopsRunWithoutAdvancingGlobalCheckpoint
SyncOrchestratorTest.checkpointWriteFailureIsIsolatedAndBlocksGlobalCheckpoint
SyncParticipantArchitectureTest.facadeAndOrchestratorAreInfrastructureAgnostic
SyncParticipantArchitectureTest.sixFeatureParticipantsAreRegisteredThroughMultibinding
SyncParticipantArchitectureTest.oldRemoteDataSourceNoLongerOwnsSessionOrFullRunOrchestration
SyncCheckpointTest.fullSyncUsesRunStartAsCheckpoint
SyncCheckpointTest.participantKeysAreStableAndUnique
InitialSyncSafetyTest.initialSyncRunsCompleteTwoWayCycle
```

النتيجة:

```text
10 passed
0 failed
```

## التجميع الساكن

- Kotlin syntax للملفات المعدلة: **20/20 ناجح**.
- تجميع دلالي لواجهة الجلسة والمنسق والعقود والـParticipants عبر `kotlinc` مع عقود Stub: **14 ملفًا ناجحًا**.
- قواعد مصدرية ومعمارية: **37 ناجحة، 0 فشل**.
- Room schema بقي **18**، ولم تُضف Migration.

## قواعد التحقق المهمة

- `SyncManager` لا يحتوي DAO أو Room أو Supabase.
- `SyncOrchestrator` لا يحتوي DAO أو Room أو Supabase أو أسماء جداول.
- جميع Pull operations تسبق Push operations.
- جميع Finalize operations تأتي بعد Push.
- فشل Participant مستقل لا يمنع تجربة بقية Participants.
- أي فشل يمنع تحديث `lastSync` العام.
- فشل كتابة Checkpoint يُعزل داخل نفس الخطوة ويمنع تقدم المؤشر العام.
- Outbox ما زال يدخل عبر `SyncManager.syncAll()` ويحافظ على Revision guard.

## محاولة Gradle الفعلية

الأوامر المجربة:

```bash
./gradlew --offline testDebugUnitTest
./gradlew --offline lintDebug assembleDebug
```

النتيجة في الأمرين:

```text
Downloading https://services.gradle.org/distributions/gradle-8.2.1-bin.zip
java.net.UnknownHostException: services.gradle.org
```

لم يبدأ Gradle في تهيئة المشروع؛ لذلك لا يوجد ادعاء بنجاح Unit tests الكاملة أو Lint أو APK build.

## أوامر الإغلاق داخل بيئة Android كاملة

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.sync.SyncOrchestratorTest" \
  --tests "com.shift.app.sync.SyncParticipantArchitectureTest" \
  --tests "com.shift.app.SyncOrchestrationContractTest" \
  --tests "com.shift.app.sync.SyncCheckpointTest" \
  --tests "com.shift.app.sync.InitialSyncSafetyTest"

./gradlew testDebugUnitTest
./gradlew lintDebug assembleDebug
```

## اختبار يدوي مطلوب

1. مزامنة حساب يحتوي بيانات في جميع المجالات الستة.
2. تعطيل Endpoint خاص بمجال واحد والتأكد أن المجالات الأخرى تستمر.
3. التأكد أن Checkpoint المجال الفاشل لا يتقدم.
4. إعادة الشبكة والتأكد أن الجولة التالية تكمل المجال الفاشل دون تكرار مالي.
5. تسجيل الخروج أثناء المزامنة والتأكد من عدم تقدم `lastSync`.
6. إنشاء عملية أصل مرتبطة برصيد والتأكد أنها تصل مرة واحدة فقط.

## القيد المتبقي

`RemoteSyncDataSource` ما زال يحتوي تفاصيل Remote وMapping لعدة مجالات. لم يعد منسقًا ولا يملك Session lifecycle، لكنه ما زال دينًا انتقاليًا يجب تقسيمه إلى Data implementations خاصة بالمشاركين قبل إغلاق المرحلة نهائيًا.

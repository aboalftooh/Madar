# Verification v08 — حدود ميزة الأصول

## النطاق

فصل ميزة الأصول إلى Presentation/Domain/Data واضحة، مع الحفاظ على العمليات الذرية وOutbox وRoom 18 وسلوك المزامنة الحالي.

## ما تم

- إنشاء Domain Models وRequests و`AssetGateway`.
- إنشاء Use Cases للقراءة والملخص والتفاصيل والإنشاء ودورة الحياة والتعديل.
- إنشاء `AssetGatewayAdapter` وMapper وHilt binding.
- نقل مصنع العمليات إلى Data الخاصة بالميزة.
- تقليص `AssetRepository` من 1,216 إلى 627 سطرًا.
- نقل ViewModels وشاشة الأصول إلى `feature/assets`.
- تقسيم الشاشة إلى Route وOverview وDialogs.
- تحديث `PaymentsScreen` لاستخدام Domain Asset.
- إبقاء `AssetSyncParticipant` والرفع المركب دون تغيير سلوكي.

## الاختبارات المنفذة فعليًا

```text
AssetUseCasesTest                                      3/3
AssetGatewayAdapterTest                                2/2
AssetBoundaryArchitectureTest                          4/4
AssetSyncParticipantTest                               2/2
AssetOperationFactoryRegressionTest                    3/3
-----------------------------------------------------------
الإجمالي                                                14/14
```

النتيجة: ناجحة، 0 فشل.

## التجميع الساكن

### فحص Syntax

- 25/25 ملف Kotlin جديد أو معدل: ناجح.
- حُذف ملفان قديمان مقصودًا: `viewmodel/AssetsViewModel.kt` و`ui/screens/AssetsScreen.kt`.

### التجميع الدلالي بواسطة kotlinc مع Stubs

```text
1. Asset Domain + Gateway + Use Cases                 ناجح
2. Room entities + AssetOperationFactory + Mapper     ناجح
3. AssetRepository + DAOs + transaction contracts     ناجح
4. AssetGatewayAdapter + session/sync contracts        ناجح
5. Assets ViewModels + use cases                       ناجح
```

ملاحظة: ملفات Compose فُحصت نحويًا وحدوديًا، ولم تُجمع دلاليًا خارج Gradle لغياب Android/Compose SDK dependencies في البيئة.

## القواعد المعمارية

- 86/86 قاعدة مصدرية ومعمارية: ناجحة.
- Presentation لا تحتوي imports من Data أو Room أو Sync.
- Domain لا يعتمد على Android أو Data.
- `AssetGatewayAdapter` يملك Mapping وقفل الجلسة وجدولة المزامنة.
- Room بقي الإصدار 18 ولا يوجد `MIGRATION_18_19`.

## Gradle

الأوامر المطلوبة جُربت:

```bash
./gradlew testDebugUnitTest --tests "com.shift.app.feature.assets.*"
./gradlew assembleDebug
./gradlew lintDebug
```

لم تبدأ تهيئة المشروع؛ Gradle Wrapper حاول تنزيل `gradle-8.2.1-bin.zip` وفشل بسبب عدم توفر الشبكة:

```text
java.net.UnknownHostException: services.gradle.org
```

هذه نتيجة بيئية وليست نجاحًا أو فشلًا لاختبارات Gradle.

## الاختبار اليدوي المطلوب

1. فتح قائمة الأصول وعرض القيم الحالية.
2. إضافة أصل سابق وشراء أصل جديد.
3. إضافة تحسين وصيانة وتقييم.
4. بيع أصل والتراجع عن البيع.
5. شراء عملة أجنبية وإضافة Lot وبيع كمية جزئية.
6. تعديل وحذف العمليات من شاشة التفاصيل.
7. تنفيذ شراء/تحسين/صيانة من شاشة المدفوعات.
8. إغلاق التطبيق بعد العملية وفتحه والتحقق من بقاء العملية والمزامنة.

## حالة الإغلاق

`IN_PROGRESS`: التنفيذ والاختبارات الساكنة مكتملة. تبقى بوابة Gradle والاختبار اليدوي على جهاز Android قبل `DONE`.

# Verification v01 — خط الأساس قبل التعديل

## الحالة

`BLOCKED`

التحقق الساكن تم، لكن Build واختبارات Gradle لم تُشغّل في بيئة الفحص الحالية.

## ما تم

- فك المشروع الكامل والتحقق من وجود:
  - `settings.gradle.kts`.
  - `build.gradle.kts`.
  - `gradlew` و`gradle-wrapper.properties`.
  - `gradle/libs.versions.toml`.
  - Module `app`.
- إحصاء المشروع:
  - 183 ملف Kotlin إنتاجي.
  - نحو 29,005 أسطر إنتاجية.
  - 76 ملف اختبار.
  - 269 اختبارًا معرفًا بـ`@Test`.
- التحقق من Room:
  - `MadarDatabase`.
  - الإصدار 17.
  - Schema JSON متوفرة للإصدارين 16 و17.
- التحقق من أكبر نقاط التركيز:
  - `SyncManager.kt`: 2,460 سطرًا.
  - `BackupManager.kt`: 1,284 سطرًا.
  - `AssetRepository.kt`: 1,216 سطرًا.
  - `AssetsScreen.kt`: 1,066 سطرًا.
  - `MainViewModel.kt`: 784 سطرًا.
- التحقق من مخالفات حدود فعلية:
  - `AuthViewModel` يحقن Supabase Auth وPreferences و7 Repositories تقريبًا وRoom وSync.
  - `MainViewModel` يحقن 11 مكوّنًا.
  - `DebtsViewModel` يحقن DAOs وRepositories تنفيذية.
  - `GoalsViewModel` و`GoalEditorViewModel` يحقنان DAOs.
  - Screens تستورد Room Entities مباشرة.
  - Goal domain يستورد Room entities وData repository implementation.
- التحقق من وجود نموذج مالي Legacy بـ`Double` ونموذج Ledger أحدث بـDecimal.
- التحقق من أن WorkManager غير مضاف حاليًا كاعتمادية للمزامنة.

## الموانع المكتشفة

1. Gradle Wrapper يشير إلى:

```text
gradle-9.0-milestone-1-bin.zip
```

وهو توزيع تجريبي وليس Baseline ثابتًا للمشروع.

2. بيئة الفحص الحالية لا تحتوي Android SDK.

3. بيئة الفحص الحالية بلا اتصال لتنزيل Gradle والتبعيات.

4. ملفات SQL التالية المطلوبة في اختبارات العقود غير موجودة:

```text
docs/supabase_assets_rpc.sql
docs/supabase_debt_rpc.sql
docs/supabase_financial_goals.sql
```

5. لا يوجد `.gitignore` في جذر الحزمة، بينما `local.properties` موجود ويحتوي قيم إعداد حساسة.

## ما لم يتم

لم تُشغّل الأوامر التالية، ولا يُدعى نجاحها:

```bash
./gradlew clean testDebugUnitTest lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

## أوامر التحقق المطلوبة في بيئة المشروع

بعد تثبيت Wrapper Stable واستعادة ملفات SQL:

```bash
./gradlew --version
./gradlew clean
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

على جهاز أو Emulator:

```bash
./gradlew connectedDebugAndroidTest
```

## اختبار يدوي لخط الأساس

1. تثبيت التطبيق فوق نسخة سابقة للتأكد من Migration.
2. تسجيل الدخول والخروج واستعادة كلمة المرور.
3. إضافة دخل ومصروف.
4. إضافة حركة رصيد ودفعة.
5. شراء أصل وتقييمه وبيعه أو فقده.
6. إنشاء دين وتسجيل سداد.
7. إنشاء هدف وتسجيل تمويل أو تقدم.
8. تشغيل Sync ثم إغلاق التطبيق وفتحه.
9. إنشاء Backup ثم Restore على نسخة اختبار.
10. مطابقة الرصيد وصافي الثروة قبل وبعد Restore.

## شرط تحويل الحالة إلى DONE

- نجاح جميع أوامر Gradle من نسخة نظيفة.
- توثيق أي اختبار موروث فاشل قبل التعديل.
- نجاح الاختبار اليدوي الأساسي.
- إزالة الأسرار من حزمة المشروع ومستودع Git.

# Verification v05 — الجلسة v04: Auth وSession وLogout

## الحالة

`IN_PROGRESS — IMPLEMENTED / STATIC_VERIFIED / GRADLE_BLOCKED`

اكتمل الفصل البرمجي والتحقق الساكن. لا تعد المرحلة `DONE` قبل نجاح Gradle والاختبارات اليدوية على جهاز أو Emulator.

## النطاق المنفذ

- إنشاء عقود المصادقة والجلسة والتنظيف.
- عزل Supabase Auth داخل `SupabaseAuthGateway`.
- عزل DataStore والجلسة داخل `PreferencesSessionStore`.
- نقل تنظيف Room والمستودعات إلى `RoomAccountLocalDataCleaner`.
- عزل `SyncManager` خلف `SessionSyncGateway`.
- إلغاء وانتظار WorkManager الفوري والدوري قبل تنظيف الحساب.
- إنشاء `SessionBootstrapCoordinator` للدخول والتسجيل.
- إنشاء `SessionCleanupCoordinator` للخروج الآمن والإجباري.
- تقليص اعتماديات `AuthViewModel` إلى:
  - `AuthGateway`.
  - `SessionReader`.
  - `SessionBootstrapper`.
  - `SessionCleanup`.
- الحفاظ على Room الإصدار 18 دون Migration.

## ترتيب الخروج الآمن

```text
synchronizePendingChanges
  -> withExclusiveSession
      -> cancelAndAwaitSessionWork
      -> clearAccountData داخل Room transaction
      -> clearAccountScopedState
      -> signOut
      -> clearLocalAuthSession عند فشل Remote sign-out
```

عند `PartialFailure` أو `AuthenticationRequired` تتوقف العملية قبل أي حذف.

## الملفات الإنتاجية الجديدة

```text
app/src/main/java/com/shift/app/feature/auth/domain/AuthContracts.kt
app/src/main/java/com/shift/app/feature/auth/data/SupabaseAuthGateway.kt
app/src/main/java/com/shift/app/feature/auth/data/PreferencesSessionStore.kt
app/src/main/java/com/shift/app/feature/auth/data/RoomAccountLocalDataCleaner.kt
app/src/main/java/com/shift/app/feature/auth/data/SyncManagerSessionGateway.kt
app/src/main/java/com/shift/app/feature/auth/data/WorkManagerSessionWorkController.kt
app/src/main/java/com/shift/app/feature/auth/session/SessionBootstrapCoordinator.kt
app/src/main/java/com/shift/app/feature/auth/session/SessionCleanupCoordinator.kt
app/src/main/java/com/shift/app/feature/auth/di/AuthSessionModule.kt
```

## الملف الإنتاجي المعدل

```text
app/src/main/java/com/shift/app/ui/auth/AuthViewModel.kt
```

## الاختبارات المضافة

```text
com.shift.app.feature.auth.AuthViewModelTest
com.shift.app.feature.auth.SessionCleanupCoordinatorTest
com.shift.app.feature.auth.LogoutWithPendingChangesTest
com.shift.app.architecture.AuthBoundaryArchitectureTest
```

## الاختبارات التي شُغلت داخل Harness محلي

```text
SessionCleanupCoordinatorTest.successfulLogoutSyncsThenCleansInsideExclusiveSession
SessionCleanupCoordinatorTest.forceLogoutSkipsSyncButStillUsesExclusiveCleanup
SessionCleanupCoordinatorTest.remoteSignOutFailureFallsBackToLocalSessionClear
LogoutWithPendingChangesTest.authenticationChangeAlsoBlocksDestructiveCleanup
LogoutWithPendingChangesTest.failedPendingSyncBlocksLogoutWithoutDeletingAnything
AuthViewModelTest.loginDelegatesAuthenticationAndSessionBootstrap
AuthViewModelTest.blockedLogoutUsesBlockedCallbackOnly
AuthBoundaryArchitectureTest.sessionCoordinatorOwnsSafeLogoutOrder
AuthBoundaryArchitectureTest.authViewModelDependsOnlyOnAuthSessionContracts
AuthBoundaryArchitectureTest.destructiveCleanupIsOwnedByRoomAdapterNotPresentation
```

النتيجة:

```text
10 passed
0 failed
```

## التجميع الساكن

- تجميع دلالي لملفات Auth/Session الجديدة و`AuthViewModel` بواسطة `kotlinc` مع عقود Stub: **ناجح**.
- تجميع ملفات الاختبار الأربعة: **ناجح**.
- قواعد مصدرية ومعمارية: **44 ناجحة، 0 فشل**.
- Room schema: **18**.
- Migration جديدة: **لا يوجد**.

## قواعد التحقق المهمة

- `AuthViewModel` لا يحتوي Import من `data` أو `sync`.
- `AuthViewModel` لا يعرف `PreferencesManager` أو `MadarDatabase` أو Supabase أو WorkManager.
- `AuthViewModel` لا يحتوي عمليات حذف أو معاملات Room.
- فشل المزامنة يمنع تنظيف الحساب والخروج.
- الخروج الإجباري يتجاوز المزامنة فقط.
- WorkManager يلغى قبل تنظيف البيانات.
- تنظيف Room داخل Transaction واحدة.
- Outbox العام وOutbox الأهداف يُحذفان ضمن تنظيف الحساب.
- Remote sign-out failure يؤدي إلى local session clear.
- Hilt يوفر ثمانية Bindings بلا Service locator جديد.

## محاولة Gradle الفعلية

الأوامر المجربة:

```bash
./gradlew --offline testDebugUnitTest \
  --tests "com.shift.app.feature.auth.*" \
  --tests "com.shift.app.architecture.AuthBoundaryArchitectureTest"

./gradlew --offline lintDebug assembleDebug
```

النتيجة في الأمرين:

```text
Downloading https://services.gradle.org/distributions/gradle-8.2.1-bin.zip
java.net.UnknownHostException: services.gradle.org
```

لم يبدأ Gradle في تهيئة المشروع؛ لذلك لا يوجد ادعاء بنجاح Unit tests الكاملة أو Lint أو APK build.

## أوامر الإغلاق داخل بيئة Android كاملة

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.feature.auth.*" \
  --tests "com.shift.app.architecture.AuthBoundaryArchitectureTest"

./gradlew testDebugUnitTest
./gradlew lintDebug assembleDebug
```

## الاختبار اليدوي المطلوب

1. دخول صحيح مع تذكر البريد.
2. دخول صحيح دون تذكر البريد.
3. تسجيل حساب جديد مع الاسم ونوع العمل.
4. استعادة كلمة المرور والتحقق من OTP.
5. خروج بعد مزامنة ناجحة والتأكد من الانتقال للدخول.
6. تعطيل الشبكة وإنشاء عملية ثم محاولة الخروج؛ يجب ظهور تحذير البيانات غير المزامنة دون حذفها.
7. إعادة الشبكة واختيار إعادة المحاولة؛ يجب نجاح الخروج بعد الرفع.
8. اختيار الخروج الإجباري والتأكد من حذف البيانات المحلية والجلسة.
9. إغلاق التطبيق وفتحه بعد الخروج؛ يجب ألا تعود جلسة المستخدم السابق.
10. التأكد أن البريد المتذكر يبقى بينما بيانات الحساب تُمسح.

## القيد المتبقي

`AuthViewModel` ما زال في الحزمة القديمة `ui/auth` حفاظًا على مسارات Compose الحالية. نقله إلى `feature/auth/presentation` مؤجل إلى مرحلة Package-by-Feature أو عند تعديل Navigation، لتجنب خلط إعادة الهيكلة مع تغيير مسارات UI في نفس الجلسة.

# Verification v02 — أمان دورة المزامنة

## الحالة

`IN_PROGRESS — IMPLEMENTED / STATIC_VERIFIED / GRADLE_BLOCKED`

اكتمل التنفيذ البرمجي والتحقق الساكن. لا تُعد المرحلة `DONE` قبل نجاح Gradle والاختبار اليدوي.

## النطاق المنفذ

- Checkpoint مستقل لكل Sync Participant.
- منع تقدم `lastSync` بعد Partial Failure.
- تحويل Initial Sync من Pull فقط إلى Pull ثم Push.
- حماية Pending/Failed/Conflict من الاستبدال أثناء Pull.
- حماية سجلات Legacy المعدلة بعد Checkpoint الخاص بالمجال.
- نتيجة صريحة: `Success / PartialFailure / AuthenticationRequired`.
- عدم ابتلاع أخطاء Pull في الإعدادات وترحيل التاريخ.
- منع Logout العادي عند فشل المزامنة.

## الملفات الجديدة

```text
app/src/main/java/com/shift/app/data/remote/SyncSafety.kt
app/src/test/java/com/shift/app/sync/SyncCheckpointTest.kt
app/src/test/java/com/shift/app/sync/InitialSyncSafetyTest.kt
app/src/test/java/com/shift/app/sync/PendingLocalChangeSurvivesPullTest.kt
app/src/test/java/com/shift/app/sync/PartialSyncFailureTest.kt
app/src/test/java/com/shift/app/sync/ClockSkewConflictTest.kt
```

## الملفات المعدلة

```text
app/src/main/java/com/shift/app/data/remote/SyncManager.kt
app/src/main/java/com/shift/app/utils/PreferencesManager.kt
app/src/main/java/com/shift/app/utils/SyncMergePolicy.kt
app/src/main/java/com/shift/app/viewmodel/MainViewModel.kt
app/src/main/java/com/shift/app/viewmodel/LegacyHistoryMigrationViewModel.kt
app/src/main/java/com/shift/app/ui/auth/AuthViewModel.kt
app/src/test/java/com/shift/app/SyncMergePolicyTest.kt
```

## التحقق الساكن المنجز

### 1. فحص بناء الجملة

استخدم Kotlin PSI Compiler Parser على جميع ملفات Kotlin المعدلة.

```text
KOTLIN_SYNTAX_OK 8
```

### 2. تجميع منطق الأمان

جُمعت الملفات التالية بواسطة `kotlinc-jvm 1.9.0`:

```text
SyncSafety.kt
SyncMergePolicy.kt
StaticHarness.kt
```

النتيجة:

```text
STATIC_SYNC_SAFETY_OK
```

### 3. التجميع الساكن

جُمعت من المصدر الحالي بواسطة `kotlinc-jvm 1.9.0`:

```text
SyncSafety.kt
SyncMergePolicy.kt
PreferencesManager.kt — مع عقود Stub لـAndroid/DataStore/Security/JSON/Coroutines
اختبارات أمان المزامنة — مع عقود JUnit/Coroutines Stub
```

النتيجة:

```text
STATIC_COMPILE_OK
```

كما نجح فحص Kotlin PSI لجميع ملفات Kotlin المعدلة. لا يمثل ذلك بديلًا عن تجميع Android الكامل عبر Gradle.

### 4. تجميع وتشغيل اختبارات المزامنة

جُمعت اختبارات الأمان مع عقود JUnit/Coroutines Stub، ثم شُغلت 11 دالة اختبار.

```text
STATIC_TESTS_OK 11
```

### 5. فحص العقود المصدرية

تم التحقق من 16 شرطًا، أهمها:

- Initial Sync يستدعي الدورة الكاملة.
- `initialSyncedUserId` لا يتغير إلا بعد Success.
- لا يوجد `setLastSync(System.currentTimeMillis())`.
- `setLastSync` يحدث مرة واحدة وبعد فحص الفشل.
- كل Incremental Pull يملك Participant محددًا.
- Checkpoint المجال يُحفظ فقط بعد نجاح Pull.
- أخطاء Pull المطلوبة لا تُبتلع.
- Logout يمنع المسح عند Partial Failure.

النتيجة:

```text
STATIC_SOURCE_CONTRACTS_OK 16
```

## محاولة Gradle الفعلية

شُغّل:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug --offline
```

النتيجة: لم يبدأ Gradle في تكوين المشروع؛ حاول تنزيل:

```text
https://services.gradle.org/distributions/gradle-9.0-milestone-1-bin.zip
```

ثم توقف بسبب:

```text
java.net.UnknownHostException: services.gradle.org
```

إذًا لا يوجد ادعاء بنجاح Unit Tests أو Lint أو APK Build عبر Gradle.

## الاختبارات المضافة للتشغيل داخل المشروع الكامل

```bash
./gradlew testDebugUnitTest \
  --tests "com.shift.app.sync.SyncCheckpointTest" \
  --tests "com.shift.app.sync.InitialSyncSafetyTest" \
  --tests "com.shift.app.sync.PendingLocalChangeSurvivesPullTest" \
  --tests "com.shift.app.sync.PartialSyncFailureTest" \
  --tests "com.shift.app.sync.ClockSkewConflictTest" \
  --tests "com.shift.app.SyncMergePolicyTest"

./gradlew testDebugUnitTest lintDebug assembleDebug
```

## الاختبار اليدوي المطلوب

1. إنشاء عملية محلية دون شبكة.
2. محاولة المزامنة والتأكد من ظهور فشل دون اختفاء العملية.
3. إغلاق التطبيق وفتحه ثم إعادة الشبكة والمزامنة.
4. التأكد من وصول العملية مرة واحدة.
5. تعطيل Endpoint واحد والتأكد أن Checkpoint الخاص به لا يتقدم.
6. محاولة Logout أثناء فشل المزامنة والتأكد من عدم مسح البيانات.
7. تنفيذ Force Logout فقط بعد قبول المستخدم فقدان Pending يدويًا.

## ثبات قاعدة البيانات

```text
Room version = 17
Schema diff = none
Migration added = none
```

## ما لم يُنفذ في هذه المرحلة

- Outbox شبكي دائم.
- WorkManager Retry بعد قتل التطبيق.
- Idempotency شامل لكل عمليات Legacy.
- Server revision لجميع الجداول.
- اختبار جهازين فعليين وانحراف الساعة.

هذه البنود تخص المرحلة 02 وما بعدها.

## شرط الإغلاق

تتحول الحالة إلى `DONE` بعد:

1. نجاح اختبارات Gradle المحددة.
2. نجاح `lintDebug` و`assembleDebug`.
3. نجاح الاختبار اليدوي أعلاه.
4. توثيق النتيجة دون بيانات حساسة.

# Verification v14 — تقوية الاختبارات

## النطاق

تقوية اختبارات الهجرات، النسخ الاحتياطي، تعارضات المزامنة، وViewModels، مع إنشاء CI وعدم تغيير سلوك التطبيق أو Room schema.

## ما تم

- استخراج خطة هجرة 17→18 وخطة Outbox SQL إلى مكونات JVM نقية مستخدمة فعليًا من Room.
- توحيد قائمة الهجرات 2→18 داخل `ALL_MIGRATIONS`.
- إضافة اختبار SQLite Instrumentation ينفذ الترقية ويتحقق من:
  - أعمدة `syncState` الأربعة.
  - 48 Trigger لـ24 جدولًا.
  - إنشاء Outbox event عند كتابة Pending.
  - وجود حدث إيقاظ الهجرة.
- إضافة ثماني نقاط Fault Injection إلى Restore مع الحفاظ على No-op افتراضي.
- إضافة اختبار جهازين وانحراف الساعة بثلاثة قرارات دمج واضحة.
- تحويل اختبار `DebtsViewModel` إلى سلوك حقيقي عبر `FakeDebtGateway`.
- تحويل اختبار Outbox migration من قراءة المصدر إلى تنفيذ الخطة.
- إنشاء GitHub Actions لبناء نظيف واختبارات Instrumentation.

## الاختبارات والتجميع المنفذ فعليًا

### سيناريوهات Kotlin السلوكية

- Migration/Outbox وMulti-device merge: **8/8 ناجحة**.
- Restore Fault Injection: **6/6 ناجحة**.
- Debt ViewModel وDebt query عبر Test double: **3/3 ناجحة**.
- الإجمالي: **17/17 ناجحة**.

### التجميع الساكن الدلالي

- `SqlMigrationExecutor + Migration17To18Plan + SyncOutboxSqlPlan + SyncMergePolicy`: ناجح.
- `RestoreAtomicityGuard` مع عقود Stub: ناجح.
- `DebtsViewModel + Use Cases + FakeDebtGateway` مع Lifecycle/Hilt Stubs: ناجح.
- Android `SyncOutboxSchema` adapter مع AndroidX Stubs: **1/1 ناجح**.
- `Migration17To18InstrumentationTest` مع Android/SQLite Stubs: **1/1 ناجح**.
- فحص توازن Syntax للملفات المعدلة: **15/15 ناجح**.

### قواعد V14

- **147/147 ناجحة**.
- تتضمن اتصال الهجرات، 24 مالك Outbox، 48 Trigger، نقاط الفشل، حدود Test doubles، CI، الأمن، وعدم تغيير Wrapper أو Schemas.
- اختبارات قراءة المصدر انخفضت من **47 إلى 45** ملفًا.

## Gradle وInstrumentation

جرت محاولة:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug --stacktrace
./gradlew connectedDebugAndroidTest --stacktrace
```

توقف الأمران قبل تهيئة المشروع:

```text
java.net.UnknownHostException: services.gradle.org
```

البيئة لا تحتوي Gradle 8.2.1 محليًا ولا اتصالًا لتنزيله؛ لذلك لا يُدّعى نجاح Gradle أو تشغيل اختبار SQLite على جهاز.

## Room والأمان

- Room بقي الإصدار **18**.
- لم تتغير ملفات Schema 16/17.
- لم تتغير Gradle Wrapper binaries.
- لا توجد `local.properties` أو Keystore في الحزمة.
- SQL 17→18 لم يتغير وظيفيًا؛ نُقل فقط إلى خطة واحدة قابلة للاختبار.

## المطلوب داخل بيئة متصلة

1. تشغيل GitHub CI أو أوامر Gradle محليًا.
2. توليد ومراجعة `app/schemas/.../18.json` عبر KSP.
3. تشغيل `Migration17To18InstrumentationTest` على محاكي API 34.
4. اختبار ترقية نسخة قاعدة فعلية منزوعة الحساسية من 17 إلى 18.
5. استبدال اختبارات المصدر المتبقية تدريجيًا، بدءًا بالمزامنة وLegacy migration.

## النتيجة

V14 منفذة ومتحققة سلوكيًا وساكنًا. تبقى بوابة Gradle/Android قبل تحويل المرحلة إلى `DONE`.

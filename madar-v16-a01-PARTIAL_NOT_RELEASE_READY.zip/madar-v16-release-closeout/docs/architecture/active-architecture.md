# Madar — Active Architecture after V16

## النمط الفعلي

التطبيق **Modular Monolith** من تسع وحدات Gradle:

```text
:app
├── :core:model
├── :core:sync
├── :feature:ledger
├── :feature:auth
├── :feature:assets
├── :feature:debts
├── :feature:goals
└── :feature:reports
```

`app` هو Composition Root ويملك Android وCompose وRoom وSupabase وWorkManager وHilt adapters. الوحدات المستخرجة تملك Domain contracts والنماذج والحسابات الحتمية فقط.

## اتجاه الاعتماد

```text
Presentation Route
  -> ViewModel
    -> Use Case / Domain Contract
      <- Data Adapter داخل app
        -> Room / Supabase / WorkManager
```

القواعد:

- `core:*` لا يعتمد على `app` أو Feature.
- Feature لا يعتمد على Feature أخرى.
- Presentation لا يستورد DAO أو Room Entity أو Supabase.
- العلاقات العابرة للمجالات تمر عبر Port أو Coordinator.
- قاعدة Room واحدة، لكن كل DAO يستهلكه Data owner الخاص بمجاله.

## المزامنة

```text
SyncManager (جلسة وقفل فقط)
  -> SyncOrchestrator (ترتيب وتشغيل ونتائج)
    -> 6 SyncParticipants
      -> Feature Remote Ports
        <- 6 Remote Data Sources
          -> Supabase + Room
```

الـParticipants: Reference Data، Ledger، Assets، Debts، Goals، Settings. لا يعرف `SyncManager` أي DAO أو Supabase API.

## التخزين والاستعادة

- Room هو مصدر الحقيقة المحلي.
- Outbox دائم وWorkManager مسؤولان عن إعادة المحاولة.
- Backup/Restore موزع على Feature-owned codecs خلف `BackupGateway`.
- الاستعادة ذرية وتملك نقاط Fault Injection في الاختبارات.

## الديون المقصودة المتبقية

- `core:database` و`core:network` لم يُستخرجا؛ بقاؤهما داخل `app` يمنع اعتمادًا عكسيًا على Features.
- Legacy finance/debt models لم تُحذف؛ ما زالت مطلوبة للمقارنة والترحيل والنسخ القديمة.
- بعض Presentation القديمة ستنتقل عند تعديل ميزتها، لا بنقل جماعي.

# Madar — Release Readiness after V16

## مكتمل داخل V16

- تقسيم `RemoteSyncDataSource` ذي 2299 سطرًا إلى ستة Data Sources حسب المجال.
- Release validation يرفض URL/Key/Keystore ناقصة.
- ملفات الأسرار والتوقيع مستبعدة من Git وحزم التسليم.
- ProGuard/R8 rules تغطي SQLCipher وSupabase وKotlin Serialization payloads.
- CI للـDebug والـInstrumentation، وWorkflow منفصل لبناء AAB موقّع من GitHub Secrets.
- توثيق المعمارية وتدفق البيانات وبروتوكول المزامنة.

## نتائج التحقق المحلي المتاح

- 8/8 وحدات Domain تجمعت دلاليًا.
- 41/41 Unit tests للوحدات نجحت.
- 17/17 فحوص سلوكية عابرة للوحدات نجحت.
- 5/5 اختبارات انحدار للمزامنة نجحت.
- اختبارات V16 المعمارية والمصدر نجحت.
- Module graph بلا Cycles أو Duplicate declarations.

## حواجز الإصدار المتبقية

1. Gradle Wrapper غير مخزن محليًا والبيئة بلا إنترنت؛ لم تعمل `testDebugUnitTest/lint/assemble/bundle` الفعلية.
2. `18.json` غير مولد داخل `app/schemas`؛ يجب توليده بواسطة Room KSP ومراجعته قبل الإصدار.
3. `Migration17To18InstrumentationTest` موجود لكنه لم يُشغّل على جهاز أو Emulator هنا.
4. لم يُختبر تثبيت نسخة Release موقعة ولا الترقية من APK إنتاجي سابق.
5. يلزم تشغيل Workflow الإصدار بأسرار حقيقية والتحقق من AAB وMapping file.

## قرار الإصدار

الحالة: **BLOCKED**. الكود والتوثيق وبوابات التحقق الساكنة جاهزة، لكن لا يُعتمد Release قبل إغلاق الحواجز الخمسة أعلاه.

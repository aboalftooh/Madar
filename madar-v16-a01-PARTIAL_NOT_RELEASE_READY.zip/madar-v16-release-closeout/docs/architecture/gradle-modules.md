# Gradle Modules — V16

## Dependency direction

```text
app
├── core:model
├── core:sync
├── feature:ledger ──> core:model
├── feature:auth
├── feature:assets ──> core:model
├── feature:debts ──> core:model
├── feature:goals ──> core:model
└── feature:reports ──> core:model
```

## Scope

- `core:model`: shared financial/debt value types and deterministic calculators; Android-free.
- `core:sync`: synchronization contracts, checkpoint keys and run outcomes; Android-free.
- `feature:ledger`: legacy-to-ledger cutover planning only.
- `feature:*`: stable Domain contracts, models and use cases only.
- `app`: Android UI, Room, Supabase, WorkManager, Hilt bindings and adapters.

## Rules

- Feature modules never depend on another feature module.
- Domain modules cannot import Android, Room, Compose, Data or UI packages.
- `app` is the composition root and may depend on all extracted modules.
- Data and Presentation extraction is deferred until their ownership is stable.

## V16 composition details

- Remote sync contracts ما زالت داخل `app` لأنها تعرض Room-owned types؛ نقلها إلى `core:sync` سيخلق اعتمادًا غير صحيح.
- الستة Remote Data Sources implementations تبقى في `app/data/remote`.
- الإغلاق لا يضيف Module جديدًا؛ يحافظ على Graph المستقر ويزيل God Object داخل Composition Root.


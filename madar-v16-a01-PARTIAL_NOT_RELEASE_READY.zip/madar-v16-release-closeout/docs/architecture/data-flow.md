# Madar — Data Flow after V16

## القراءة

```text
Room Flow/Query
  -> Data Adapter
    -> Domain Read Model / Repository Contract
      -> Use Case
        -> ViewModel UiState
          -> Route
            -> Pure Screen
```

- التقارير تستقبل `ReportsReadModel` جاهزًا؛ لا تحسب الأرقام داخل Compose.
- الأصول والديون والأهداف تقرأ عبر Gateways وUse Cases.
- Room Entities لا تعبر إلى Presentation في الميزات المفصولة.

## الكتابة المالية

```text
UI Event
  -> ViewModel
    -> Command Use Case
      -> Repository transaction
        ├── Ledger/Feature rows
        └── Sync Outbox row في المعاملة نفسها
```

القيمة المالية canonical Decimal/`BigDecimal`. `Double` محصور في توافق Legacy، ولا يُستخدم مصدرًا للحساب الجديد.

## المزامنة الخلفية

```text
Local commit + Outbox
  -> WorkManager
    -> SyncQueueGateway
      -> SyncManager
        -> SyncOrchestrator
          -> Participant push/pull
```

فشل الشبكة لا يحذف Outbox، وإعادة المحاولة تستخدم `operationId` وRevision لمنع التكرار أو حذف تعديل أحدث.

## النسخ الاحتياطي والاستعادة

```text
Settings UI -> BackupViewModel -> BackupGateway
  -> BackupDocumentCodec
    -> Finance / Assets / Debts / Goals codecs
```

الاستعادة تتحقق من المستند قبل الكتابة، ثم تعمل داخل Transaction مع تعويض خارجي عند الحاجة.

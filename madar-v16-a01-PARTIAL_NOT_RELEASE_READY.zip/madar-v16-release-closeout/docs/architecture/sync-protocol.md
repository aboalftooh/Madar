# Madar — Sync Protocol after V16

## دورة المزامنة

1. `SyncManager` يأخذ Mutex للجلسة ويثبت `authenticatedUserId`.
2. `SyncOrchestrator` يرتب المشاركين حسب `order`.
3. ينفذ Pull لكل Participant، ويحدث Checkpoint الخاص بالجدول بعد نجاح عمليته فقط.
4. ينفذ `afterPull` فقط إذا لم تفشل أي عملية Pull.
5. يقرأ آخر Global checkpoint ثم ينفذ Push لكل Participant.
6. ينفذ Finalize operations، مثل إصلاح عمليات الدفع غير المكتملة.
7. إذا تغيّر المستخدم أثناء الدورة، تعاد `AuthenticationRequired` ولا يتقدم المؤشر العام.
8. إذا فشلت خطوة، تستمر الخطوات المستقلة وتعود `PartialFailure` دون تحديث Global checkpoint.
9. عند النجاح فقط، يُحفظ **وقت بداية الدورة** كـGlobal checkpoint حتى لا تُتخطى كتابة حدثت أثناء المزامنة.

## الملكية

| Participant | Remote port | المسؤولية |
|---|---|---|
| Reference Data | `ReferenceDataRemoteSync` | مصادر الدخل والمستفيدون |
| Ledger | `LedgerRemoteSync` | المعاملات والدفتر والمدفوعات والترحيل |
| Assets | `AssetRemoteSync` | الأصول وحركاتها وتقييمها والعملات |
| Debts | `DebtRemoteSync` | Legacy debt وDebt ledger |
| Goals | `GoalRemoteSync` | الأهداف وقياساتها وتمويلها |
| Settings | `SettingsRemoteSync` | إعدادات المستخدم |

## Outbox والتعارض

- الطلب المحلي يُسجل مع Outbox داخل Transaction واحدة.
- WorkManager يعيد المحاولة مع Backoff.
- حذف عنصر Outbox مشروط بالـRevision الذي رُفع؛ تعديل أحدث لا يُحذف بواسطة Snapshot قديم.
- العمليات المالية تستخدم `operationId` للـIdempotency.
- دمج السجل البعيد لا يستبدل Pending/Failed المحلي تلقائيًا.

## ما لا يُسمح به

- Push مباشر من ViewModel.
- تقدم Checkpoint بعد فشل الخطوة.
- اعتماد Participant على Concrete remote data source.
- اعتماد حل التعارض على ساعة الهاتف وحدها.

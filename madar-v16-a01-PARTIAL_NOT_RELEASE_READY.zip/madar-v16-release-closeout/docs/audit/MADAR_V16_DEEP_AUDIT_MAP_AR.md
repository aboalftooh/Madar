# مدار V16 — جرد المشروع وخريطة التدقيق العميق

**التاريخ:** 2026-09-10  
**النسخة المرجعية الوحيدة:** `madar-v16-release-closeout-full(1).zip`  
**جذر المشروع داخل الأرشيف:** `madar-v16-release-closeout/`  
**الحالة:** `INVENTORIED_NOT_FULLY_AUDITED` — اكتمل الجرد والتقسيم، ولم يُنجز التدقيق السلوكي الكامل.

هذا تقسيم إلى **سبعة أقسام** بناءً على المسؤولية ومسارات البيانات، لا مجرد أسماء المجلدات. لكل ملف مالك تدقيق رئيسي واحد، وتضاف مراجعة مشتركة حيث تتقاطع الوظائف. القسم ليس جلسة واحدة بالضرورة؛ خصوصًا الأصول والديون، والأهداف والتقارير.

جُردت جميع ملفات الأرشيف، وقرئت نقاط الدخول والعقود ومكونات الحساب والمستودعات المالية والمزامنة والتخزين والاستعادة والبناء وعينات الاختبارات. لم تُعدل ملفات المنتج، ولم يُشغّل Gradle أو التطبيق أو اختبارات JUnit/Instrumentation، ولم يُفحص سيرفر حي. لا يعادل هذا الملف حكم جاهزية أو ضمانًا لسلامة كل دالة.

## 1. ملخص الجرد

| المؤشر | النتيجة |
|---|---:|
| الملفات الكلية، دون المجلدات | 517 |
| وحدات Gradle، بما فيها app | 9 |
| ملفات Kotlin الإنتاجية | 297 |
| أسطر Kotlin الإنتاجية، مع التعليقات والفراغات | 34,787 |
| ملفات Kotlin في src/test، تشمل ملفات المساعدة | 119 |
| ملفات Kotlin في src/androidTest | 11 |
| إجمالي ملفات Kotlin | 427 |
| بقية الملفات: إعدادات وموارد وتوثيق وغيرها | 90 |
| كيانات Room المعلنة / عقود DAO | 27 / 27 |
| إصدار قاعدة البيانات في الكود | 18 |
| مخططات Room المحفوظة | 16 و17 فقط |

القيم الإحصائية محسوبة من الحزمة نفسها. عدد ملفات الاختبار ليس عدد الاختبارات الناجحة ولا نسبة تغطية. يوجد 374 ظهورًا لتعليمة `@Test` في ملفات `src/test` و11 في `src/androidTest`؛ هذا عد نصي فقط. المرجع التفصيلي القابل للفحص: `MADAR_V16_AUDIT_FILE_INVENTORY.json`.

اسم مشروع Gradle هو `ShiftApp`، والحزمة `com.shift.app`، وإصدار التطبيق المصرح به `1.1.2` ورقمه `112`؛ تسمية V16 هنا تسمية حزمة/مرحلة وليست versionCode. الدليل: `settings.gradle.kts` و`app/build.gradle.kts:29–44`.

| القسم | النطاق | جميع الملفات | Kotlin إنتاجي | ملفات اختبار/مساعدة | أسطر Kotlin الإنتاجي |
|---|---|---:|---:|---:|---:|
| A01 | الحساب والجلسة والأمان الشخصي | 27 | 21 | 6 | 2,100 |
| A02 | الحركات المالية والرصيد والمدفوعات | 43 | 32 | 11 | 4,590 |
| A03 | الأصول والعملات والديون | 112 | 81 | 31 | 8,614 |
| A04 | الأهداف والميزانية والتقارير | 97 | 60 | 37 | 7,826 |
| A05 | المزامنة وعقود السيرفر | 83 | 59 | 23 | 4,865 |
| A06 | قاعدة البيانات والترحيل والنسخ والاستعادة | 51 | 32 | 17 | 5,256 |
| A07 | الواجهات العامة والمعمارية والبناء والإطلاق | 104 | 12 | 5 | 1,536 |
| **المجموع** | **تغطية جميع ملفات الأرشيف مرة واحدة** | **517** | **297** | **130** | **34,787** |

العد يشمل مستندات النسخ السابقة والموارد وملفات البناء. كثرة الملفات في A07 لا تعني كثرة منطق التطبيق؛ معظم الموارد والتوثيق هناك. لا يضاف عدد المراجعات المشتركة إلى مجموع الملفات.

### خريطة الوحدات الفعلية

| الوحدة | Kotlin إنتاجي | وظيفتها في هذه الحزمة |
|---|---:|---|
| `:app` | 240 | Android/Compose/Room/Supabase/WorkManager/Hilt، ومستودعات البيانات والواجهات |
| `:core:model` | 9 | أنواع وحسابات المال والديون |
| `:core:sync` | 4 | عقود المزامنة والنتائج ونقاط الاستئناف |
| `:feature:auth` | 1 | عقود الحساب والجلسة |
| `:feature:ledger` | 1 | خطة LegacyFinancialCutover، وليس كامل الدفتر التشغيلي |
| `:feature:assets` | 5 | نماذج وعقود وأوامر الأصول |
| `:feature:debts` | 5 | نماذج وعقود وأوامر الديون |
| `:feature:goals` | 28 | قوالب وقياس وتقييم وتمويل الأهداف وعقودها |
| `:feature:reports` | 4 | بيانات التقارير وحسابها وعقود قراءتها |

الوحدات المسجلة مثبتة في `settings.gradle.kts`، واعتماد app عليها في `app/build.gradle.kts:81–89`. وجود حزم Backup وSession داخل app لا يجعلها وحدات Gradle مستقلة. المسارات التالية جميعها نسبية إلى جذر الأرشيف.

## 2.1. A01 — الحساب والجلسة والأمان الشخصي

**حجم القسم:** 27 ملفًا؛ 21 Kotlin إنتاجي و6 اختبار/مساعدة. **الخطر الرئيسي:** تسرب بيانات بين الحسابات، فقد بيانات عند الخروج، أو تجاوز القفل المحلي.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `feature/auth/src/main/java/com/shift/app/feature/auth/domain/AuthContracts.kt` | عقود المصادقة والجلسة ونتائج الخروج |
| `app/src/main/java/com/shift/app/feature/auth/presentation/AuthViewModel.kt` | الدخول والتسجيل واستعادة كلمة المرور والخروج؛ الأسطر 40–110 |
| `app/src/main/java/com/shift/app/feature/auth/data/SupabaseAuthGateway.kt` | تنفيذ البريد وكلمة المرور وRecovery OTP؛ الأسطر 14–49 |
| `app/src/main/java/com/shift/app/feature/auth/session/SessionCleanupCoordinator.kt` | المزامنة قبل الخروج والقفل والتنظيف؛ الأسطر 22–52 |
| `app/src/main/java/com/shift/app/feature/auth/data/RoomAccountLocalDataCleaner.kt` | حذف بيانات الحساب المحلية؛ الأسطر 27–50 |
| `app/src/main/java/com/shift/app/feature/session/presentation/AppSessionViewModel.kt` | المزامنة الأولية وحالة الواجهة |
| `app/src/main/java/com/shift/app/utils/PreferencesManager.kt` | PIN، سؤال الأمان، محاولات القفل وإعدادات الحساب المشتركة |
| `app/src/main/java/com/shift/app/ui/screens/PinScreen.kt` | واجهة إنشاء القفل والتحقق والاستعادة |

**مسار التتبع:** LoginScreen / RegisterScreen → AuthViewModel → AuthGateway → SupabaseAuthGateway، ثم SessionBootstrapCoordinator. الخروج يمر عبر SessionCleanupCoordinator → مزامنة → إيقاف العمل الخلفي → تنظيف بيانات الحساب. حدود التنقل في NavGraph يراجعها هذا القسم مع A07.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A01.1 | الدخول والتسجيل | مستخدم جديد وحالي، بريد غير مؤكد، تسجيل بلا جلسة فعالة، خطأ كلمة مرور، ضعف الشبكة، تكرار الضغط، واسترجاع التطبيق بعد الإغلاق. |
| A01.2 | استعادة كلمة المرور | طلب الرمز عند الإجراء الصحيح، رمز خاطئ/منتهي، إعادة الإرسال، العودة بين الشاشات، وتحديث كلمة المرور دون ترك جلسة أو حالة واجهة مضللة. |
| A01.3 | القفل المحلي | إنشاء PIN والتحقق وتغييره وتعطيله، سؤال الاسترداد، تدرج منع المحاولات، إعادة التشغيل وتغيير ساعة الجهاز والعودة من الخلفية. |
| A01.4 | الخروج وتبديل الحساب | الخروج العادي مع بيانات معلقة وفشل جزئي؛ مسار الخروج الذي يتجاهل البيانات المحلية؛ وضوح التأكيد؛ منع أعمال الحساب السابق من الكتابة بعد الحساب الجديد. |
| A01.5 | خصوصية الجلسة | ملكية Preferences ونقاط المزامنة، تنظيف كل بيانات الحساب دون غيرها، وحماية الرسائل والسجلات من بيانات حساسة. إعدادات Auth الفعلية تحتاج دليلًا من السيرفر. |

**معيار إغلاق القسم:** اختبارات انتقال حالة حقيقية، وتجربة حسابين منفصلين، وعدم فقد التعديلات في مسار الخروج الآمن، وإثبات سلوك مسار التجاهل الصريح. لا يُعتبر حفظ قيمة isLoggedIn وحده إثباتًا لصحة الجلسة.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/feature/auth/AuthViewModelTest.kt`
- `app/src/test/java/com/shift/app/feature/auth/LogoutWithPendingChangesTest.kt`
- `app/src/test/java/com/shift/app/feature/auth/SessionCleanupCoordinatorTest.kt`
- `app/src/test/java/com/shift/app/feature/session/AppSessionGatewayContractTest.kt`

**حدود المسؤولية:** القسم يملك منطق الحساب وPIN. تشفير قاعدة البيانات في A06، وسياسات السيرفر في A05، والتنقل العام في A07. PreferencesManager ملف مشترك يملكه A01 ويُراجع أيضًا من A02/A04/A05/A06/A07.

## 2.2. A02 — الحركات المالية والرصيد والمدفوعات

**حجم القسم:** 43 ملفًا؛ 32 Kotlin إنتاجي و11 اختبار/مساعدة. **الخطر الرئيسي:** اختلال الرصيد، احتساب دخل أو مصروف مرتين، أو فصل العملية عن أثرها النقدي عند التعديل والحذف.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `core/model/src/main/java/com/shift/app/domain/finance/FinancialRules.kt` | القواعد المالية المشتركة |
| `core/model/src/main/java/com/shift/app/domain/finance/DecimalText.kt` | صيغة الأرقام العشرية |
| `app/src/main/java/com/shift/app/data/repository/FinancialLedgerRepository.kt` | الرصيد الافتتاحي والمدفوعات والاستبدال والحذف؛ الأسطر 76–241 |
| `app/src/main/java/com/shift/app/data/repository/TransactionRepository.kt` | إنشاء وتعديل وحذف الدخل المرتبط؛ الأسطر 92–247 |
| `app/src/main/java/com/shift/app/viewmodel/TransactionsViewModel.kt` | أحداث الحركات المالية وحالة عرضها |
| `app/src/main/java/com/shift/app/viewmodel/PaymentsViewModel.kt` | أوامر المدفوعات |
| `app/src/main/java/com/shift/app/viewmodel/BalanceViewModel.kt` | قراءة الرصيد وأوامره |
| `app/src/main/java/com/shift/app/ui/screens/PaymentsScreen.kt` | واجهة المدفوعات |
| `app/src/main/java/com/shift/app/ui/components/AddTransactionSheet.kt` | إدخال الحركة المالية |

**مسار التتبع:** DashboardScreen / AddTransactionSheet / PaymentsScreen / BalanceScreen → ViewModels → TransactionRepository أو FinancialLedgerRepository → DAOs وقيود الأثر المالي. القراءة الموحدة للتقارير تُراجع في A04، والنشر للمزامنة في A05.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A02.1 | الدخل والمصروفات | كل نوع من الحركة، المصدر والمستفيد والغرض والتاريخ، وربط الدخل بالرصيد أو عدم ربطه وفق المسار الموجود. |
| A02.2 | الرصيد والمدفوعات | تفعيل الرصيد والرصيد الافتتاحي، الدفعة، الارتباط بين Payment وBalanceTransaction، وسياسة الرصيد غير الكافي كما ينفذها الكود. |
| A02.3 | التعديل والحذف | تعديل القيمة والتاريخ والتصنيف والارتباط، استبدال دفعة، حذف العملية، الحفاظ على التاريخ ومنع القيود اليتيمة أو التكرار. |
| A02.4 | الأرقام والعملات | Decimal وBigDecimal وحدود Double/Float القديمة، التقريب والمدخلات العربية والفواصل والصفر والقيم السالبة والكبيرة، وعدم جمع عملات مختلفة دون مسار تحويل محدد. |
| A02.5 | مطابقة المخرجات | رصيد البداية + التدفقات الداخلة − الخارجة = رصيد النهاية؛ مطابقة صفحات الرصيد والحركات والتقارير، ثم تكرار المطابقة بعد المزامنة والترحيل. |

**معيار إغلاق القسم:** لكل إنشاء/تعديل/حذف جدول قبل/بعد يوضح الحركة والدفعة والرصيد. تُختبر إعادة إرسال العملية نفسها، ويثبت عدم تضاعف الأثر في الواجهة أو قاعدة البيانات أو التقرير.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/FinancialBalanceParityTest.kt`
- `app/src/test/java/com/shift/app/IncomeLedgerFactoryTest.kt`
- `app/src/test/java/com/shift/app/FinancialLedgerSchemaTest.kt`
- `app/src/test/java/com/shift/app/FinancialInputTest.kt`
- `core/model/src/test/java/com/shift/app/FinancialRulesTest.kt`

**حدود المسؤولية:** يشمل واجهات المال وDAOs وEntities الخاصة بها. القواعد الخاصة بملكية الأصول والديون في A03؛ ترحيل التاريخ القديم في A06. وجود وحدة feature/ledger لا يعني أن دفتر المال التشغيلي كله موجود فيها؛ معظم التنفيذ داخل app.

## 2.3. A03 — الأصول والعملات والديون

**حجم القسم:** 112 ملفًا؛ 81 Kotlin إنتاجي و31 اختبار/مساعدة. **الخطر الرئيسي:** خلق أو إسقاط دين، بيع أصل أو عملة أكثر من المتاح، أو تنفيذ جزء من شراء ممول دون بقية آثاره.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/usecase/AssetCommandUseCases.kt` | أوامر الأصول |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/usecase/DebtCommandUseCases.kt` | أوامر الديون |
| `core/model/src/main/java/com/shift/app/domain/finance/CurrencyAssetCalculator.kt` | حسابات رصيد العملة وتخصيصاتها |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtCalculator.kt` | حسابات الدين الأساسية |
| `app/src/main/java/com/shift/app/data/repository/AssetRepository.kt` | شراء وبيع وسداد وتقييم وتصحيح الأصل؛ الأسطر 108–398 |
| `app/src/main/java/com/shift/app/feature/assets/data/AssetOperationFactory.kt` | بناء سجلات العملية المرتبطة |
| `app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt` | مصروف آجل ودخل مستحق وشراء ممول وتسوية ومقاصة وعكس؛ الأسطر 87–565 |
| `app/src/main/java/com/shift/app/data/repository/DebtOrganizationRepository.kt` | نقل الطرف والجدولة والأرشفة |
| `app/src/main/java/com/shift/app/domain/debt/reminders/DebtReminderScheduler.kt` | جدولة تذكيرات الديون |

**مسار التتبع:** AssetsScreen → AssetsViewModel → عقود/أوامر الأصول → AssetGatewayAdapter → AssetRepository. DebtsRoute → DebtsViewModel → عقود/أوامر الديون → DebtGatewayAdapter → DebtLedgerRepository. العمليات الممولة تربط الأصل والدين والدفعة والرصيد داخل مسار واحد.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A03.1 | دورة الأصل | أصل سابق، شراء، دفعة، تقييم، بيع، تعديل الاقتناء والدفعات والتقييم والبيع، حذف العملية والتراجع عن البيع. |
| A03.2 | أصول العملات | شراء دفعات عملة وإضافتها، بيع جزئي وكامل، تخصيص تكلفة الشراء، الكمية المتاحة، التقريب، منع البيع الزائد، وتعديل عملية بعد استهلاك جزء من دفعتها. |
| A03.3 | دورة الدين | افتتاح حساب، مال مستلم/مدفوع كأصل دين، مصروف مؤجل، دخل مستحق، تحصيل وسداد جزئي وكامل، تخفيض وتصحيح وعكس. |
| A03.4 | العمليات المركبة | شراء أصل ممول، بيع أصل على الدين، التسوية بأصل، المقاصة بين التزام ومستحق، وضمان تطابق جميع القيود المشتركة مع A02. |
| A03.5 | تنظيم الدين | نقل الدين لطرف آخر، الجدول الزمني، الأرشفة، المراجعة الناتجة من ترحيل ديون Legacy، والإشعارات والإلغاء بعد السداد. |
| A03.6 | الواجهات والتزامن | الوصول لكل أمر من الشاشة الفعلية، معاينة أثره، عدم تنفيذ الضغط مرتين، ثم تعارض جهازين على الأصل أو الدين نفسه مع A05. |

**معيار إغلاق القسم:** إثبات حفظ إجمالي الأصل/الدين وعدم حدوث أثر نقدي أو مصروفي مكرر، مع معاملات ذرية للعمليات المركبة. كل تعديل/عكس يراجع الروابط والسجلات التابعة لا السجل الرئيسي فقط.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/AssetOperationsTest.kt`
- `app/src/test/java/com/shift/app/DebtScenarioCoverageTest.kt`
- `app/src/test/java/com/shift/app/DebtFinancedAssetOperationsTest.kt`
- `app/src/test/java/com/shift/app/DebtAssetSettlementTest.kt`
- `app/src/test/java/com/shift/app/feature/debts/DebtAssetSettlementIntegrationTest.kt`
- `feature/assets/src/test/java/com/shift/app/feature/assets/AssetUseCasesTest.kt`

**حدود المسؤولية:** جُمعت الأصول والديون لأن المصدر يربطهما مباشرة في الشراء الممول والتسوية والبيع الآجل. هذا قسم كبير يحتاج جلسات فرعية؛ لا يُضغط في جلسة واحدة. SQL/RPC الخاصة به في A05، وترحيل الديون القديمة في A06.

## 2.4. A04 — الأهداف والميزانية والتقارير

**حجم القسم:** 97 ملفًا؛ 60 Kotlin إنتاجي و37 اختبار/مساعدة. **الخطر الرئيسي:** تقدم هدف غير صحيح، حجز أو استهلاك أموال مرتين، أو تقارير تبدو صحيحة بينما تجمع مصادر متكررة.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `feature/goals/src/main/java/com/shift/app/domain/goals/evaluation/GoalEvaluationEngine.kt` | تقييم الأهداف |
| `feature/goals/src/main/java/com/shift/app/domain/goals/evaluation/GoalInvalidationProcessor.kt` | إعادة التقييم بعد التغيير المالي |
| `feature/goals/src/main/java/com/shift/app/domain/goals/funding/GoalFundingCalculator.kt` | حسابات تمويل الهدف |
| `app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt` | دورة الهدف والتمويل وتقدير التكلفة وقرارات النطاق |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomAssetGoalCompletion.kt` | اكتمال هدف شراء أصل نقدًا أو بتمويل؛ الأسطر 22–73 |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomGoalDebtPayment.kt` | سداد دين من مسار الهدف؛ الأسطر 23–65 |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomCostGoalCompletion.kt` | تنفيذ مسار هدف التكلفة؛ يلزم أيضًا تدقيق اتساق تعريفاته وربطه |
| `app/src/main/java/com/shift/app/feature/reports/data/ReportsQueryAdapter.kt` | دمج بيانات المال والأصول والديون؛ الأسطر 25–128 |
| `feature/reports/src/main/java/com/shift/app/feature/reports/domain/usecase/ReportsReadModelCalculator.kt` | حساب نموذج التقارير |
| `app/src/main/java/com/shift/app/ui/screens/plans/PlansScreen.kt` | تبويبا الميزانية والأهداف؛ الأسطر 32–80 |

**مسار التتبع:** PlansScreen → GoalsListScreen / GoalEditorScreen / GoalDetailsScreen → ViewModels → GoalGateway والـUseCases → FinancialGoalRepository. الأثر المالي المركب يمر عبر محولات إكمال الأهداف. ReportsRoute → ReportsViewModel → ObserveReportsUseCase → ReportsQueryAdapter → نموذج التقرير.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A04.1 | الأنواع والقياسات | أهداف الدخل والمصروفات والطوارئ وصافي الثروة وشراء أصل وسداد دين والتكلفة؛ القالب والشرط والفترة والنطاق وخط الأساس لكل نوع. |
| A04.2 | دورة الحياة | إنشاء وتعديل وحذف وانتقالات الحالة وإعادة الفتح بحسب العقد، Expected Revision، النشاط والتاريخ، والعمليات المتكررة. |
| A04.3 | التمويل والميزانية | تخصيص وإلغاء تخصيص واستهلاك وتقدير تكلفة، أثر الإنفاق على الأموال المحجوزة، وعدم تحويل الحجز وحده إلى دخل أو مصروف. |
| A04.4 | الإكمال المركب | شراء الأصل أو تمويله من هدف، إكمال هدف التكلفة، سداد دين من هدف؛ مطابقة أثرها مع A02/A03 ومنع إكمال الهدف دون السجلات المرتبطة. |
| A04.5 | التقارير وإعادة التقييم | الفلاتر والفترات وحدود التاريخ، استبعاد المحذوف والمكرر بعد Legacy، مصادر الرصيد وصافي الثروة، وإعادة الحساب عند تصحيح محلي أو مسحوب من السيرفر. |
| A04.6 | اختبارات المسار الفعلي | التحقق من أن اختبارات الأهداف تشغل الشاشات والمنطق المقصود، لا مجرد أسماء الأنواع؛ مراجعة علم FINANCIAL_GOALS_PHASE_1 وحالات التحميل والخطأ. |

**معيار إغلاق القسم:** أرقام متوقعة مستقلة لكل مثال مالي تقارن بالهدف والتقرير؛ اختبار تعديل سابق يعيد التقييم دون تكرار التمويل؛ وإكمال هدف عبر واجهة فعلية مع فحص السجلات المرتبطة.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/goals/GoalEvaluationEngineTest.kt`
- `app/src/test/java/com/shift/app/goals/GoalFinancialChangeContractTest.kt`
- `app/src/test/java/com/shift/app/goals/GoalSpecializedCompletionContractTest.kt`
- `app/src/test/java/com/shift/app/feature/reports/ReportsQueryTest.kt`
- `feature/reports/src/test/java/com/shift/app/feature/reports/ReportReadModelTest.kt`
- `app/src/androidTest/java/com/shift/app/goals/GoalPhase1EndToEndUiTest.kt`

**حدود المسؤولية:** FinancialChangeOutbox الخاص بإعادة تقييم الأهداف هنا، وليس هو SyncOutbox الشبكي في A05. واجهات الميزانية والتقارير هنا، أما سلامة أرقامها الأصلية فتراجع مع A02/A03.

## 2.5. A05 — المزامنة وعقود السيرفر

**حجم القسم:** 83 ملفًا؛ 59 Kotlin إنتاجي و23 اختبار/مساعدة. **الخطر الرئيسي:** فقد تعديل محلي، إعادة إحياء حذف، تكرار قيد مالي، أو اعتماد بيانات مستخدم آخر.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `core/sync/src/main/java/com/shift/app/sync/SyncParticipant.kt` | عقد المشاركين ونتائج التشغيل |
| `app/src/main/java/com/shift/app/data/remote/SyncManager.kt` | جلسة التشغيل والقفل |
| `app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt` | Pull ثم المعالجة المحلية ثم Push ثم Finalize؛ الأسطر 18–68 |
| `app/src/main/java/com/shift/app/sync/outbox/SyncOutboxProcessor.kt` | معالجة قائمة العمليات المعلقة |
| `app/src/main/java/com/shift/app/sync/outbox/SyncWorkScheduler.kt` | جدولة ومحاولة استرداد العمل |
| `app/src/main/java/com/shift/app/data/local/sync/SyncOutboxSqlPlan.kt` | SQL وربط تغييرات الجداول بالطابور |
| `app/src/main/java/com/shift/app/sync/remote/RemoteSyncPorts.kt` | العقود بين المشاركين ومصادر البيانات |
| `app/src/main/java/com/shift/app/data/remote/RemoteSyncContext.kt` | سحب الصفحات وفلتر المالك والزمن؛ الأسطر 80–101 |
| `app/src/main/java/com/shift/app/data/remote/RemoteSyncPayloads.kt` | حزم RPC وأسماؤها؛ الأسطر 154–156 |

**مسار التتبع:** كتابة محلية → SyncOutbox/SQL triggers → SyncWorkScheduler وWorkManager → SyncOutboxProcessor → SyncManager → SyncOrchestrator → المشاركون الستة → Remote Ports → مصادر Supabase. المجالات الستة: Reference Data وLedger وAssets وDebts وGoals وSettings.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A05.1 | التغطية والجدولة | جدول Entity × إنشاء/تعديل/حذف × Push/Pull × pending/failed؛ إثبات تغطية كل كيان يحتاج مزامنة، وتحديد الكيانات المحلية عمدًا. |
| A05.2 | الذرية والإقرار | حفظ التغيير وOutbox، حماية التعديل الأحدث عند وصول الإقرار، operationId وrevision، الفشل الجزئي، وإعادة المحاولة دون مضاعفة القيود. |
| A05.3 | السحب والتعارض | حماية pending المحلي، الحذف المتزامن، انحراف الساعة، تساوي updated_at، تغير البيانات أثناء التصفح، وأكثر من 1000 صف لكل مجال، وفشل فك صف بعيد. |
| A05.4 | الجلسة والعمل الخلفي | انتهاء الجلسة وتبديل الحساب، الإلغاء وموت العملية وإعادة التشغيل، جدولة الاسترداد، Backoff، وتفسير عداد الفشل والنجاح الجزئي للمستخدم. |
| A05.5 | عقد السيرفر | مقارنة RPC الثلاثة مع تطبيقها الفعلي، ملكية user_id وRLS وصلاحيات الجداول والإجراءات، الحدود والقيود والتكرار على السيرفر، وترتيب السجلات التابعة. |
| A05.6 | تجربة جهازين | نفس الحساب على جهازين: تعديل/حذف متعارض، بيع عملة متزامن، سداد الدين نفسه، واستعادة نسخة ثم مزامنتها. تقارن النتيجة محليًا وبعيدًا. |

**معيار إغلاق القسم:** لا تضيع عملية ولا تتكرر آثارها بعد انقطاع الشبكة أو العملية؛ فشل خطوة لا يمنح مزامنة كاملة ناجحة؛ وملكية كل سجل تُثبت من تنفيذ السيرفر لا من فلتر العميل فقط. تغطية المصدر المحلي لا تكفي لإغلاق تدقيق السيرفر.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/sync/SyncOrchestratorTest.kt`
- `app/src/test/java/com/shift/app/sync/PendingLocalChangeSurvivesPullTest.kt`
- `app/src/test/java/com/shift/app/sync/MultiDeviceConflictTest.kt`
- `app/src/test/java/com/shift/app/sync/outbox/ProcessDeathRecoveryTest.kt`
- `app/src/test/java/com/shift/app/sync/outbox/OutboxIdempotencyTest.kt`
- `app/src/test/java/com/shift/app/AssetRpcSqlContractTest.kt`
- `app/src/test/java/com/shift/app/DebtRpcSqlContractTest.kt`
- `app/src/test/java/com/shift/app/goals/GoalRpcSqlContractTest.kt`

**حدود المسؤولية:** جميع Remote Models وDataSources وParticipants تملكها A05 في الجرد، لكن دلالات حزم المال والأصول والديون والأهداف تستلزم مراجعي A02/A03/A04. ملفات تنفيذ السيرفر غير موجودة في الحزمة؛ لا يُفترض نجاحها أو فشلها من غيابها.

## 2.6. A06 — قاعدة البيانات والترحيل والنسخ والاستعادة

**حجم القسم:** 51 ملفًا؛ 32 Kotlin إنتاجي و17 اختبار/مساعدة. **الخطر الرئيسي:** تعذر فتح بيانات المستخدم، ترحيل يكرر التاريخ، أو استعادة تترك نصف البيانات القديمة ونصف الجديدة.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt` | تعريف 27 كيانًا وإصدار Room 18؛ الأسطر 14–74؛ وسلسلة الهجرات |
| `app/src/main/java/com/shift/app/di/DatabaseModule.kt` | SQLCipher ومفتاح القاعدة والهجرات؛ الأسطر 24–51 |
| `app/src/main/java/com/shift/app/data/local/migration/Migration17To18Plan.kt` | خطة الترحيل 17→18 |
| `app/schemas/com.shift.app.data.local.MadarDatabase/16.json` | المخطط المحفوظ للإصدار 16 |
| `app/schemas/com.shift.app.data.local.MadarDatabase/17.json` | المخطط المحفوظ للإصدار 17 |
| `app/src/main/java/com/shift/app/data/migration/LegacyDebtMigrator.kt` | ترحيل الديون القديمة |
| `app/src/main/java/com/shift/app/data/migration/LegacyFinancialCutoverCoordinator.kt` | تنسيق الانتقال المالي القديم |
| `app/src/main/java/com/shift/app/data/repository/LegacyHistoryMigrationRepository.kt` | ترحيل التاريخ وتكراره وآثاره |
| `app/src/main/java/com/shift/app/feature/backup/data/BackupGatewayAdapter.kt` | inspect/plan/restore وقفل الجلسة؛ الأسطر 48–114 |
| `app/src/main/java/com/shift/app/feature/backup/data/RestoreAtomicityGuard.kt` | حدود المعاملة وتعويض الحالة الخارجية |

**مسار التتبع:** DatabaseModule → MadarDatabase/SQLCipher → Migrations. النسخ: SettingsScreen → BackupViewModel → BackupGatewayAdapter → BackupDocumentCodec → Finance/Assets/Debts/Goals codecs. الاستعادة تخطط أولًا ثم تدخل قفل الجلسة وRestoreAtomicityGuard، وبعدها تطلب المزامنة.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A06.1 | المخطط والهجرات | كل جدول وعمود وفهرس ومفتاح وعلاقة؛ مطابقة Entities مع مخطط KSP؛ اختبار 17→18 وترقيات الإصدارات المدعومة ببيانات واقعية مجهولة الهوية. |
| A06.2 | التشفير والتخزين | إنشاء المفتاح وإعادة فتح القاعدة، فقد المفتاح أو تلف الملف ونقص المساحة، ترقية التطبيق الموقع، وعدم تحويل خطأ فتح قاعدة إلى مسح صامت. |
| A06.3 | الانتقال من Legacy | المديونية والتاريخ المالي ومصادر الدخل، علامات الترحيل وإعادته واستكماله بعد الانقطاع، المطابقة قبل/بعد، ومراجعة البيانات التي لا يمكن تصنيفها آليًا. |
| A06.4 | التصدير والتوافق | تغطية المال والأصول والديون والأهداف والإعدادات، صيغة manifest وإصدار المستند، القيم العشرية والتواريخ والحذف والروابط، وخصوصية الملف المصدر. |
| A06.5 | الاستعادة الذرية | فحص الملف التالف أو الناقص أو الأحدث، أوضاع الاستيراد المعرفة بالعقد، الفشل في كل Codec، التراجع عن Room والحالة الخارجية، وتكرار استيراد الملف. |
| A06.6 | الاستعادة مع المزامنة | بيانات معلقة وقت الاستيراد، تبديل الجلسة أثناء التخطيط أو التطبيق، نجاح محلي مع فشل الجدولة، وحفظ العلاقات بعد رفع البيانات وسحبها على جهاز آخر. |

**معيار إغلاق القسم:** مقارنة كل الجداول والأرصدة والروابط قبل/بعد الترقية والاستعادة، مع حقن فشل في منتصف كل قسم وإثبات الرجوع الكامل. اختبار خطة SQL مصغرة لا يغني عن Migration على مخطط Room الكامل وقاعدة مشفرة.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/MigrationChainTest.kt`
- `app/src/androidTest/java/com/shift/app/migration/Migration17To18InstrumentationTest.kt`
- `app/src/test/java/com/shift/app/LegacyMigrationIdempotencyTest.kt`
- `app/src/test/java/com/shift/app/backup/BackupCodecRoundTripTest.kt`
- `app/src/test/java/com/shift/app/backup/RestoreFaultInjectionTest.kt`
- `app/src/test/java/com/shift/app/backup/CorruptBackupRejectionTest.kt`

**حدود المسؤولية:** ملفات Entity/DAO الخاصة بالميزة تبقى في قسمها الوظيفي كمالك رئيسي، ويجب على A06 مراجعتها كجزء من المخطط الكلي. ملف ShiftDatabase المشترك لا يجعل جميع قواعد المال والديون مسؤوليته وحده. Schema 18 غائب في المصدر الحالي.

## 2.7. A07 — الواجهات العامة والمعمارية والبناء والإطلاق

**حجم القسم:** 104 ملفًا؛ 12 Kotlin إنتاجي و5 اختبار/مساعدة. **الخطر الرئيسي:** وجود كود لا يتجمع أو واجهات لا يصلها المستخدم، أو إصدار موقع يفشل رغم اجتياز فحوص نصية.

### نقاط الدخول والملفات المرجعية

| الملف | سبب إدراجه |
|---|---|
| `settings.gradle.kts` | الوحدات التسع المسجلة |
| `app/build.gradle.kts` | اعتماديات التطبيق وإعدادات الإصدار والتوقيع وبوابته |
| `gradle/libs.versions.toml` | نسخ الاعتماديات والإضافات المثبتة في المشروع |
| `app/src/main/java/com/shift/app/MainActivity.kt` | مدخل التطبيق وسلوك العودة من الخلفية |
| `app/src/main/java/com/shift/app/ShiftApplication.kt` | تهيئة التطبيق والخدمات |
| `app/src/main/java/com/shift/app/navigation/NavGraph.kt` | مسارات المصادقة وPIN والرئيسية؛ الأسطر 18–39 و51–130 |
| `app/src/main/java/com/shift/app/ui/screens/MainScreen.kt` | الصفحات السبع وطلبات التحرير؛ الأسطر 37–105 |
| `app/src/main/java/com/shift/app/ui/screens/SettingsScreen.kt` | واجهة الإعدادات المشتركة والنسخ والمزامنة والخروج |
| `.github/workflows/android-ci.yml` | البناء والاختبارات وInstrumentation |
| `.github/workflows/android-release.yml` | بناء الإصدار الموقع |
| `tools/verify_module_graph.py` | فحص اتجاه الوحدات والتعريفات |
| `tools/verify_release_closeout.py` | بوابات إغلاق هيكلية ونصية |

**مسار التتبع:** MadarApplication/MainActivity → MadarNavGraph → MainScreen → Dashboard/Balance/Assets/Plans/Debts/Reports/Settings. هذا القسم يراجع الاتصال العام، بينما وظيفة كل شاشة ومخرجاتها تراجع في مالكها A01–A06.

### الجلسات الفرعية المطلوبة

| الرمز | المهمة | ما يجب فحصه |
|---|---|---|
| A07.1 | بوابة التجميع أولًا | اتساق package/import/class وتعريفات Hilt وKSP؛ تعقب المسارات القديمة بعد النقل؛ تحقق Debug وRelease والاختبارات من نسخة نظيفة عند توافر بيئة البناء. |
| A07.2 | الواجهات والتنقل | زر الرجوع والقفل والدوران وموت العملية، لوحات المفاتيح وRTL والأرقام العربية، التمرير والنوافذ ورسائل الخطأ والنقر المتكرر، ووصول المستخدم لكل ميزة معلنة. |
| A07.3 | المعمارية والقديم | اتجاه اعتماد الوحدات، مصادر الحساب الموحدة، DAO عبر الواجهة، الكود النشط والميت، ومدى مطابقة ملفات architecture/refactor للمصدر الفعلي. |
| A07.4 | قيمة الاختبارات | تمييز اختبار نص/عقد/حاسبة/سلوك/واجهة/E2E؛ فحص مدخلات الاختبارات والملفات المفقودة؛ عدم مساواة عدد @Test أو سكربت PASS بتغطية المنتج. |
| A07.5 | الإصدار والتشغيل | التوقيع والأسرار وR8/ProGuard وتهيئة SQLCipher/Supabase/Sentry وWorkManager؛ تثبيت Release نظيف وترقيته من نسخة سابقة وفحص تقارير CI الناتجة فعلًا. |

**معيار إغلاق القسم:** سجل تجميع واختبارات للنسخة نفسها، اختبار تشغيل Release موقع وترقية فعلية، وربط كل ميزة بمدخل واجهة واختبار سلوك. أي تحقق متعذر يبقى NOT_RUN/BLOCKED ولا يتحول إلى PASS بسبب وثيقة سابقة.

**أمثلة اختبارات موجودة يجب مراجعة معناها ثم تشغيلها:**
- `app/src/test/java/com/shift/app/ReleaseCloseoutArchitectureTest.kt`
- `app/src/test/java/com/shift/app/architecture/DiPackageByFeatureArchitectureTest.kt`
- `app/src/test/java/com/shift/app/architecture/MainViewModelDecompositionArchitectureTest.kt`
- `app/src/test/java/com/shift/app/architecture/PresentationConventionArchitectureTest.kt`

**حدود المسؤولية:** ملفات البناء وموارد التطبيق والتوثيق وواجهاته العامة هنا. لا تُعاد مراجعة منطق كل شاشة في هذا القسم بدل مالكها؛ تراجع فقط واجهات الربط والأداء والسلوك العام. فحص المتطلبات الخارجية المتغيرة للإصدار يحتاج تحققًا مستقلًا عند الإطلاق.

## 3. نقاط الربط التي تمنع فجوات التدقيق

كل سيناريو أدناه له نتيجة مشتركة؛ لا يكفي نجاح فحص كل قسم منفردًا. في كل تجربة تُسجل المعرّفات وoperationId والقيم العشرية قبل/بعد وحالات المزامنة.

| الرمز | السيناريو | الأقسام المطلوبة | الإثبات المطلوب |
|---|---|---|---|
| X01 | خروج مع بيانات معلقة ثم دخول حساب آخر | A01، A05، A06، A07 | لا تسرب حسابات، ولا حذف غير معلن، ولا كتابة خلفية للحساب السابق |
| X02 | إنشاء دخل مرتبط بالرصيد ثم تعديله وحذفه | A02، A04، A05 | تطابق الحركة والرصيد والتقرير محليًا وبعد المزامنة |
| X03 | شراء أصل ممول بدفعة نقدية | A03، A02، A04، A05، A06 | الأصل والدين والدفعة والرصيد والهدف — عند ربطه — متسقة وذرية |
| X04 | تسوية دين بأصل أو مقاصة دينين | A03، A02، A04، A05 | لا نقد وهمي ولا إسقاط قيمة من الأصل/الدين دون أثر مقابل |
| X05 | بيع عملة من جهازين فوق الكمية المتاحة | A03، A05، A02 | رفض أو فض تعارض موثق يحافظ على الكمية والتكلفة والرصيد |
| X06 | هدف شراء أصل نقدًا/بالتمويل | A04، A03، A02، A05 | استهلاك التمويل مرة واحدة، وإنشاء آثار الشراء كاملة |
| X07 | سداد دين من الهدف ثم تصحيح السداد | A04، A03، A02، A05 | تطابق الدين وتقدم الهدف والرصيد قبل التصحيح وبعده |
| X08 | مصروف يمس أموال أهداف محجوزة | A04، A02 | تطبيق سياسة التخصيص الموجودة دون احتساب الحجز مصروفًا مرتين |
| X09 | تصحيح مالي يسحب من السيرفر | A05، A02، A03، A04 | إعادة تقييم الأهداف والتقارير وعدم ضياع تعديل محلي أحدث |
| X10 | استعادة تفشل في منتصف أحد الأقسام | A06، A01، A05 | رجوع قاعدة البيانات والإعدادات معًا وعدم جدولة رفع لحالة ناقصة |
| X11 | ترقية بيانات 17 إلى 18 وبها عمليات معلقة | A06، A05، A02، A03، A04 | حفظ كل السجلات والروابط والأرصدة وتغطية Outbox |
| X12 | إعادة تشغيل ترحيل Legacy بعد انقطاع | A06، A02، A03، A04، A05 | عدم التكرار، وقابلية استكمال الترحيل، وتطابق الأرقام والتاريخ |
| X13 | تثبيت Release موقع وترقيته ثم استعادة ومزامنة | A07، A01، A06، A05 | فتح قاعدة مشفرة، تهيئة الخدمات، وعدم انهيار R8 أو فقد الجلسة |

### قاعدة الملكية

ملفات DAOs وEntities للمال والأصول والديون والأهداف مسندة لقسم الميزة، ولكن A06 ملزم بمراجعتها كمخطط واحد، وA05 ملزم بمراجعة تغطيتها عند المزامنة. لا يعني امتلاك A05 لـRemote DTOs أنه يقرر دلالتها المالية دون مالك المجال.

`PreferencesManager.kt` و`ShiftDatabase.kt` و`SettingsScreen.kt` وملفات إكمال الهدف المركب نقاط مشتركة صريحة. عمود `secondary_review_sections` في الجرد الآلي يساعد في التوجيه؛ هو اقتراح مراجعين مبني على مراجع المصدر ومسؤوليات مشتركة، وليس تحليل اعتماد رمزي كاملًا من المترجم.

## 4. ملاحظات مثبتة أثناء الجرد — وليست قائمة عيوب كاملة

### INV-01 — مراجع SyncState من مسار قديم

`app/src/main/java/com/shift/app/ui/screens/MainScreen.kt:35` و`app/src/main/java/com/shift/app/ui/screens/SettingsScreen.kt:49` تستوردان `com.shift.app.viewmodel.SyncState`. التعريف الموجود في المصدر هو `com.shift.app.feature.session.presentation.SyncState` داخل `feature/session/presentation/AppSessionViewModel.kt:19–24`، ولم يوجد تعريف بالمسار المستورد في ملفات المشروع. هذه مخالفة ربط في المصدر تستحق فحص التجميع أولًا في A07 مع A01؛ لم يُشغّل المترجم هنا.

### INV-02 — مخطط Room 18 غير موجود

`app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt:44–45` يحدد version 18 مع تصدير المخطط. الحزمة تحتوي `16.json` و`17.json` فقط تحت `app/schemas/com.shift.app.data.local.MadarDatabase/`. أكد سكربت الإغلاق نفسه غياب `18.json`. هذا نقص دليل مخطط الترقية، وليس إثباتًا مستقلًا لفشل كل عمليات الترحيل.

### INV-03 — ثلاث مدخلات SQL للاختبارات غائبة عن الحزمة

| الملف المفقود | اختبار يطلبه صراحة |
|---|---|
| `docs/supabase_assets_rpc.sql` | `app/src/test/java/com/shift/app/AssetRpcSqlContractTest.kt:10–14` |
| `docs/supabase_debt_rpc.sql` | `app/src/test/java/com/shift/app/DebtRpcSqlContractTest.kt:8–11` |
| `docs/supabase_financial_goals.sql` | `app/src/test/java/com/shift/app/goals/GoalRpcSqlContractTest.kt:9–12` |

لا توجد ملفات SQL في الأرشيف أصلًا. الاختبارات المذكورة تقرأ هذه الملفات، ولا تملك مدخلاتها في هذه الحزمة. في المقابل، المصدر يعلن RPCs باسم `upsert_asset_operation` و`upsert_debt_operation` و`apply_financial_goal_operation` في `RemoteSyncPayloads.kt:154–156`. غياب التنفيذ المحلي لا يثبت غيابه عن السيرفر؛ حالة تدقيق تطبيقه البعيد **UNKNOWN / BLOCKED_BY_MISSING_EVIDENCE** حتى توافره.

### INV-04 — اسم اختبار EndToEnd لا يثبت دورة مستخدم كاملة

`app/src/androidTest/java/com/shift/app/goals/GoalPhase1EndToEndUiTest.kt:16–27` يرسم تسميات أنواع الأهداف ويتحقق من ظهور نصين. لا ينشئ هدفًا ويموله ويكمله عبر التطبيق وقاعدة البيانات. لذلك لا يجوز استخدام اسمه وحده دليلًا على نجاح سيناريو E2E. كما أن استيراد `arabicLabel` في السطر 8 يشير إلى `com.shift.app.viewmodel`، بينما تعريف `GoalType.arabicLabel` موجود في `feature/goals/presentation/GoalsViewModel.kt:278`؛ يراجع ضمن بوابة ربط الاختبارات.

### INV-05 — حالة الإطلاق في وثائق الحزمة نفسها BLOCKED

`docs/architecture/release-readiness.md` و`docs/refactor/verification-v16.md` تصفان الإصدار بأنه BLOCKED وتفصلان غياب تحقق Gradle/Instrumentation/Schema/Release. هذه تقارير سابقة ضمن المصدر، وليست نتائج تشغيل جديدة في هذه الجلسة. لا يغير اسم الأرشيف release-closeout هذه الحالة تلقائيًا.

## 5. ما تحقق فعليًا في هذه الجلسة

قورنت الملفات المستخرجة بالأرشيف بايتًا ببايت: **517/517 دون تغيير**. وشُغلت أداتا التحقق المحليتان التاليتان كما هما:

```text
$ python tools/verify_module_graph.py
PASS: 612 module-boundary checks
PASS: dependency graph is acyclic
PASS: no duplicate Kotlin declarations across modules
```
```text
$ python tools/verify_release_closeout.py
PASS: 75/75 release-closeout checks
BLOCKERS:
- Room schema 18.json has not been generated by KSP/Gradle
```

نجاح 612 فحصًا و75 فحصًا يخص شروط السكربتين فقط. يعتمد جزء منها على وجود نصوص وملفات واتجاه وحدات، ولا يثبت التجميع أو صحة المال أو تشغيل الواجهة. ظهور BLOCKERS في السكربت الثاني مهم حتى مع رجوعه بكود خروج 0.

**لم يُنفذ هنا:** Gradle compilation، أو JUnit، أو Android instrumentation، أو APK/AAB، أو تسجيل الدخول الحقيقي، أو اختبارات جهازين، أو SQL/RLS على سيرفر. لم يُدّع عائق بيئة جديد من دون تجربة؛ البناء خارج نطاق الجرد الحالي أصلًا.

## 6. ترتيب التدقيق المقترح

ابدأ ببوابة صغيرة من **A07.1** لتثبيت سلامة المصدر ومدخلات الاختبارات، ثم **A01 → A06 → A05 → A02 → A03 → A04**، واختم **A07** وتجارب الربط X01–X13. البدء بسلامة الحساب والبيانات يمنع أن يخفي فقد البيانات نتائج التدقيق المالي.

يمكن مواصلة التدقيق الساكن إذا تعذر البناء، لكن يبقى تحقق التشغيل **NOT_RUN/BLOCKED**. ترتيب الأقسام لا يعني أن مراجع المال ينتظر نهاية كل فحص للسيرفر؛ تُسجل تبعياته ويُغلق الاختبار المشترك عند اكتمال الأدلة.

لكل جلسة يُختار رمز فرعي محدد من الجداول، وليس عنوانًا عامًا مثل «افحص المزامنة». عند الحاجة يقسم A03 إلى جلسات أصول ثم عملات ثم ديون ثم معاملات مشتركة، ويقسم A04 إلى أهداف ثم تمويل ثم إكمال ثم تقارير.

### مخرجات كل جلسة

| الحقل | المطلوب |
|---|---|
| النسخة | اسم الأرشيف وبصمته، أو commit محدد عند الانتقال إلى مستودع |
| النطاق | رمز القسم والجلسة، والملفات المراجعة فعلًا وغير المراجعة |
| مسار الدليل | واجهة → ViewModel → UseCase/Contract → Repository/Adapter → DAO/Remote، بأسماء الدوال والأسطر |
| النتائج | المشكلة والدليل وشروط حدوثها وأثرها؛ فصل العيب المؤكد عن الاحتمال |
| التحقق | الأمر/الاختبار والبيئة والنتيجة الفعلية ومقارنة قبل/بعد؛ لا يكفي ذكر وجود اختبار |
| حالة كل بند | NOT_STARTED / IN_REVIEW / PASS / FAIL / BLOCKED / NOT_RUN |
| المشترك | رموز X التي شملها الفحص، والقسم المسؤول عن الإغلاق المشترك |
| المتبقي | ما لم يثبت بعد والمهمة التالية المحددة |

لا يتحول القسم إلى PASS لمجرد قراءة جميع الملفات. يلزم إغلاق سيناريوهاته ومراجعة روابطه وتوثيق ما نفذ. أي عائق في دليل السيرفر أو الجهاز يبقى ظاهرًا، ولا يستبدل باستنتاج من Mock أو نص توثيقي.

### أدلة غير موجودة بالحزمة وتلزم لإغلاق التدقيق الكامل

تحتاج الأجزاء البعيدة نسخة SQL الفعلية للجداول وRPC وسياسات RLS والصلاحيات وإعدادات Auth غير السرية. وتحتاج بوابة الإطلاق نتائج بناء للنسخة نفسها، ومخطط Room 18 المولد، وبيانات ترقية مجهولة الهوية أو APK سابق موقع بالتوقيع نفسه، وسجلات تجارب الجهازين. لا حاجة لإدراج كلمات المرور أو مفاتيح الخدمة أو ملفات التوقيع السرية في تقارير التدقيق.

## 7. جرد جميع الملفات، دون تكرار

الملفات أدناه موزعة بحسب المالك الرئيسي. «اختبار» يشمل ملفات دعم الاختبار، وليس حكمًا بوجود حالة اختبار داخل كل ملف. عدد الأسطر للملف النصي كاملًا، أما المورد الثنائي فتعرض له شرطة. سرد أسماء موارد الخطوط لا يتضمن إرفاق ملفات الخطوط.

للفحص الآلي والبصمات لكل ملف استخدم `MADAR_V16_AUDIT_FILE_INVENTORY.json` المرفق. مجموع صفوف الأقسام السبعة يساوي 517؛ لا يوجد ملف غير مسند ولا مسند لمالكين رئيسيين.

### A01 — الحساب والجلسة والأمان الشخصي (27 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/src/main/java/com/shift/app/di/PreferencesModule.kt` | Kotlin إنتاجي | 19 | — |
| `app/src/main/java/com/shift/app/feature/auth/data/PreferencesSessionStore.kt` | Kotlin إنتاجي | 33 | — |
| `app/src/main/java/com/shift/app/feature/auth/data/RoomAccountLocalDataCleaner.kt` | Kotlin إنتاجي | 53 | A02، A03، A06 |
| `app/src/main/java/com/shift/app/feature/auth/data/SupabaseAuthGateway.kt` | Kotlin إنتاجي | 51 | — |
| `app/src/main/java/com/shift/app/feature/auth/data/SyncManagerSessionGateway.kt` | Kotlin إنتاجي | 28 | A05 |
| `app/src/main/java/com/shift/app/feature/auth/data/WorkManagerSessionWorkController.kt` | Kotlin إنتاجي | 23 | A05 |
| `app/src/main/java/com/shift/app/feature/auth/di/AuthSessionModule.kt` | Kotlin إنتاجي | 49 | — |
| `app/src/main/java/com/shift/app/feature/auth/presentation/AuthViewModel.kt` | Kotlin إنتاجي | 119 | — |
| `app/src/main/java/com/shift/app/feature/auth/presentation/LoginScreen.kt` | Kotlin إنتاجي | 323 | A07 |
| `app/src/main/java/com/shift/app/feature/auth/presentation/RegisterScreen.kt` | Kotlin إنتاجي | 257 | A07 |
| `app/src/main/java/com/shift/app/feature/auth/presentation/ResetPasswordScreen.kt` | Kotlin إنتاجي | 165 | A07 |
| `app/src/main/java/com/shift/app/feature/auth/session/SessionBootstrapCoordinator.kt` | Kotlin إنتاجي | 26 | A05 |
| `app/src/main/java/com/shift/app/feature/auth/session/SessionCleanupCoordinator.kt` | Kotlin إنتاجي | 54 | — |
| `app/src/main/java/com/shift/app/feature/session/data/AppSessionGatewayAdapter.kt` | Kotlin إنتاجي | 38 | A05، A06 |
| `app/src/main/java/com/shift/app/feature/session/di/AppSessionModule.kt` | Kotlin إنتاجي | 15 | — |
| `app/src/main/java/com/shift/app/feature/session/domain/AppSessionContracts.kt` | Kotlin إنتاجي | 23 | — |
| `app/src/main/java/com/shift/app/feature/session/presentation/AppSessionViewModel.kt` | Kotlin إنتاجي | 67 | A05، A07 |
| `app/src/main/java/com/shift/app/ui/screens/PinScreen.kt` | Kotlin إنتاجي | 337 | A07 |
| `app/src/main/java/com/shift/app/utils/PreferencesManager.kt` | Kotlin إنتاجي | 315 | A02، A04، A05، A06، A07 |
| `app/src/main/java/com/shift/app/viewmodel/PinViewModel.kt` | Kotlin إنتاجي | 44 | — |
| `app/src/test/java/com/shift/app/architecture/AuthBoundaryArchitectureTest.kt` | اختبار/مساعد | 60 | A05، A06 |
| `app/src/test/java/com/shift/app/feature/auth/AuthViewModelTest.kt` | اختبار/مساعد | 106 | — |
| `app/src/test/java/com/shift/app/feature/auth/LogoutWithPendingChangesTest.kt` | اختبار/مساعد | 80 | — |
| `app/src/test/java/com/shift/app/feature/auth/SessionCleanupCoordinatorTest.kt` | اختبار/مساعد | 113 | — |
| `app/src/test/java/com/shift/app/feature/session/AppSessionGatewayContractTest.kt` | اختبار/مساعد | 42 | A06 |
| `feature/auth/src/main/java/com/shift/app/feature/auth/domain/AuthContracts.kt` | Kotlin إنتاجي | 61 | — |
| `feature/auth/src/test/java/com/shift/app/feature/auth/AuthDomainModuleTest.kt` | اختبار/مساعد | 19 | — |

### A02 — الحركات المالية والرصيد والمدفوعات (43 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/src/main/java/com/shift/app/data/local/dao/BalanceTransactionDao.kt` | Kotlin إنتاجي | 54 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/ExpenseBeneficiaryDao.kt` | Kotlin إنتاجي | 36 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/IncomeSourceDao.kt` | Kotlin إنتاجي | 39 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/PaymentDao.kt` | Kotlin إنتاجي | 57 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/TransactionDao.kt` | Kotlin إنتاجي | 41 | A06 |
| `app/src/main/java/com/shift/app/data/local/entities/BalanceTransaction.kt` | Kotlin إنتاجي | 55 | A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/ExpenseBeneficiary.kt` | Kotlin إنتاجي | 17 | A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/IncomeSource.kt` | Kotlin إنتاجي | 18 | A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/Payment.kt` | Kotlin إنتاجي | 78 | A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/Transaction.kt` | Kotlin إنتاجي | 38 | A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/ExpenseBeneficiaryRepository.kt` | Kotlin إنتاجي | 18 | A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/FinancialLedgerRepository.kt` | Kotlin إنتاجي | 283 | A04، A06 |
| `app/src/main/java/com/shift/app/data/repository/IncomeSourceRepository.kt` | Kotlin إنتاجي | 19 | A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/TransactionRepository.kt` | Kotlin إنتاجي | 258 | A04، A05، A06 |
| `app/src/main/java/com/shift/app/domain/finance/BalanceCalculator.kt` | Kotlin إنتاجي | 19 | A06 |
| `app/src/main/java/com/shift/app/feature/ledger/di/LedgerDataModule.kt` | Kotlin إنتاجي | 24 | A06 |
| `app/src/main/java/com/shift/app/ui/components/AddTransactionSheet.kt` | Kotlin إنتاجي | 609 | A06، A07 |
| `app/src/main/java/com/shift/app/ui/components/ExpenseBeneficiaryEditorSheet.kt` | Kotlin إنتاجي | 110 | A06، A07 |
| `app/src/main/java/com/shift/app/ui/components/IncomeSourceEditorSheet.kt` | Kotlin إنتاجي | 154 | A06، A07 |
| `app/src/main/java/com/shift/app/ui/screens/BalanceScreen.kt` | Kotlin إنتاجي | 494 | A06، A07 |
| `app/src/main/java/com/shift/app/ui/screens/DashboardScreen.kt` | Kotlin إنتاجي | 334 | A06، A07 |
| `app/src/main/java/com/shift/app/ui/screens/PaymentsScreen.kt` | Kotlin إنتاجي | 719 | A03، A06، A07 |
| `app/src/main/java/com/shift/app/utils/ExpenseTextNormalizer.kt` | Kotlin إنتاجي | 20 | — |
| `app/src/main/java/com/shift/app/utils/FinanceCalculations.kt` | Kotlin إنتاجي | 68 | A06 |
| `app/src/main/java/com/shift/app/utils/FinancialInput.kt` | Kotlin إنتاجي | 9 | — |
| `app/src/main/java/com/shift/app/utils/NumberDisplayFormatter.kt` | Kotlin إنتاجي | 62 | — |
| `app/src/main/java/com/shift/app/viewmodel/BalanceViewModel.kt` | Kotlin إنتاجي | 213 | A01، A04، A05، A06 |
| `app/src/main/java/com/shift/app/viewmodel/PaymentsViewModel.kt` | Kotlin إنتاجي | 152 | A05، A06 |
| `app/src/main/java/com/shift/app/viewmodel/TransactionsViewModel.kt` | Kotlin إنتاجي | 337 | A01، A04، A05، A06، A07 |
| `app/src/test/java/com/shift/app/BalanceCalculatorTest.kt` | اختبار/مساعد | 61 | A06 |
| `app/src/test/java/com/shift/app/ExpenseTextNormalizerTest.kt` | اختبار/مساعد | 22 | — |
| `app/src/test/java/com/shift/app/FinanceCalculationsTest.kt` | اختبار/مساعد | 83 | A06 |
| `app/src/test/java/com/shift/app/FinancialBalanceParityTest.kt` | اختبار/مساعد | 52 | A06 |
| `app/src/test/java/com/shift/app/FinancialInputTest.kt` | اختبار/مساعد | 23 | — |
| `app/src/test/java/com/shift/app/FinancialLedgerSchemaTest.kt` | اختبار/مساعد | 58 | A05، A06 |
| `app/src/test/java/com/shift/app/IncomeLedgerFactoryTest.kt` | اختبار/مساعد | 48 | A06 |
| `app/src/test/java/com/shift/app/NumberDisplayFormatterTest.kt` | اختبار/مساعد | 26 | — |
| `app/src/test/java/com/shift/app/architecture/FinancialCanonicalArchitectureTest.kt` | اختبار/مساعد | 65 | A06 |
| `core/model/src/main/java/com/shift/app/domain/finance/DecimalText.kt` | Kotlin إنتاجي | 39 | A06 |
| `core/model/src/main/java/com/shift/app/domain/finance/FinancialRules.kt` | Kotlin إنتاجي | 138 | — |
| `core/model/src/main/java/com/shift/app/domain/finance/FinancialTypes.kt` | Kotlin إنتاجي | 78 | A05 |
| `core/model/src/test/java/com/shift/app/DecimalTextTest.kt` | اختبار/مساعد | 63 | A06 |
| `core/model/src/test/java/com/shift/app/FinancialRulesTest.kt` | اختبار/مساعد | 79 | — |

### A03 — الأصول والعملات والديون (112 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/src/main/java/com/shift/app/data/local/dao/AssetDao.kt` | Kotlin إنتاجي | 38 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/AssetTransactionDao.kt` | Kotlin إنتاجي | 41 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/AssetValuationDao.kt` | Kotlin إنتاجي | 41 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/CurrencyAssetLotDao.kt` | Kotlin إنتاجي | 42 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/CurrencyAssetSaleAllocationDao.kt` | Kotlin إنتاجي | 42 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtAccountDao.kt` | Kotlin إنتاجي | 45 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtDao.kt` | Kotlin إنتاجي | 29 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtLinkDao.kt` | Kotlin إنتاجي | 28 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtMigrationReviewDao.kt` | Kotlin إنتاجي | 39 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtScheduleDao.kt` | Kotlin إنتاجي | 29 | A06 |
| `app/src/main/java/com/shift/app/data/local/dao/DebtTransactionDao.kt` | Kotlin إنتاجي | 47 | A06 |
| `app/src/main/java/com/shift/app/data/local/entities/Asset.kt` | Kotlin إنتاجي | 34 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/AssetTransaction.kt` | Kotlin إنتاجي | 36 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/AssetValuation.kt` | Kotlin إنتاجي | 31 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/CurrencyAssetLot.kt` | Kotlin إنتاجي | 45 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/CurrencyAssetSaleAllocation.kt` | Kotlin إنتاجي | 50 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/Debt.kt` | Kotlin إنتاجي | 22 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/DebtAccount.kt` | Kotlin إنتاجي | 55 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/DebtLink.kt` | Kotlin إنتاجي | 48 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/DebtMigrationReview.kt` | Kotlin إنتاجي | 29 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/DebtSchedule.kt` | Kotlin إنتاجي | 42 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/local/entities/DebtTransaction.kt` | Kotlin إنتاجي | 72 | A02، A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/AssetRepository.kt` | Kotlin إنتاجي | 627 | A02، A04، A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt` | Kotlin إنتاجي | 713 | A02، A04، A05، A06 |
| `app/src/main/java/com/shift/app/data/repository/DebtOperationRecords.kt` | Kotlin إنتاجي | 27 | A02، A06 |
| `app/src/main/java/com/shift/app/data/repository/DebtOrganizationRepository.kt` | Kotlin إنتاجي | 104 | A06 |
| `app/src/main/java/com/shift/app/data/repository/DebtRepository.kt` | Kotlin إنتاجي | 46 | A02، A04، A05، A06 |
| `app/src/main/java/com/shift/app/domain/debt/DebtReportCalculator.kt` | Kotlin إنتاجي | 125 | A02، A06 |
| `app/src/main/java/com/shift/app/domain/debt/reminders/DebtNotificationFactory.kt` | Kotlin إنتاجي | 43 | — |
| `app/src/main/java/com/shift/app/domain/debt/reminders/DebtReminderScheduler.kt` | Kotlin إنتاجي | 153 | — |
| `app/src/main/java/com/shift/app/domain/debt/reminders/DebtReminderWorker.kt` | Kotlin إنتاجي | 21 | — |
| `app/src/main/java/com/shift/app/feature/assets/data/AssetEntityMapper.kt` | Kotlin إنتاجي | 88 | A02، A06 |
| `app/src/main/java/com/shift/app/feature/assets/data/AssetGatewayAdapter.kt` | Kotlin إنتاجي | 111 | A02، A05 |
| `app/src/main/java/com/shift/app/feature/assets/data/AssetOperationFactory.kt` | Kotlin إنتاجي | 568 | A02، A06 |
| `app/src/main/java/com/shift/app/feature/assets/di/AssetDataModule.kt` | Kotlin إنتاجي | 22 | A06 |
| `app/src/main/java/com/shift/app/feature/assets/di/AssetFeatureModule.kt` | Kotlin إنتاجي | 17 | — |
| `app/src/main/java/com/shift/app/feature/assets/presentation/AssetDialogs.kt` | Kotlin إنتاجي | 599 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/assets/presentation/AssetOverviewContent.kt` | Kotlin إنتاجي | 451 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/assets/presentation/AssetPresentationModels.kt` | Kotlin إنتاجي | 25 | A02 |
| `app/src/main/java/com/shift/app/feature/assets/presentation/AssetsRoute.kt` | Kotlin إنتاجي | 168 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/assets/presentation/AssetsViewModel.kt` | Kotlin إنتاجي | 211 | A02 |
| `app/src/main/java/com/shift/app/feature/debts/data/AssetDebtSettlementQueryAdapter.kt` | Kotlin إنتاجي | 27 | A02 |
| `app/src/main/java/com/shift/app/feature/debts/data/DebtEntityMapper.kt` | Kotlin إنتاجي | 46 | A06 |
| `app/src/main/java/com/shift/app/feature/debts/data/DebtGatewayAdapter.kt` | Kotlin إنتاجي | 169 | A05، A06 |
| `app/src/main/java/com/shift/app/feature/debts/data/FinancialGoalDebtScopeAdapter.kt` | Kotlin إنتاجي | 15 | A04 |
| `app/src/main/java/com/shift/app/feature/debts/di/DebtDataModule.kt` | Kotlin إنتاجي | 24 | A06 |
| `app/src/main/java/com/shift/app/feature/debts/di/DebtFeatureModule.kt` | Kotlin إنتاجي | 29 | A04 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtAccountCard.kt` | Kotlin إنتاجي | 22 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtActionSheets.kt` | Kotlin إنتاجي | 576 | A02، A06، A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtCollectionSheet.kt` | Kotlin إنتاجي | 23 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtCorrectionRoute.kt` | Kotlin إنتاجي | 15 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtDateField.kt` | Kotlin إنتاجي | 25 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtDetailsScreen.kt` | Kotlin إنتاجي | 24 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtImpactPreview.kt` | Kotlin إنتاجي | 17 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtMoneyField.kt` | Kotlin إنتاجي | 34 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtOperationRoute.kt` | Kotlin إنتاجي | 30 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtOperationWizard.kt` | Kotlin إنتاجي | 26 | — |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtOrganizationRoute.kt` | Kotlin إنتاجي | 15 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtPaymentSheet.kt` | Kotlin إنتاجي | 40 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtSettlementRoute.kt` | Kotlin إنتاجي | 27 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtUiModels.kt` | Kotlin إنتاجي | 37 | — |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtsPresentationContract.kt` | Kotlin إنتاجي | 109 | — |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtsRoute.kt` | Kotlin إنتاجي | 21 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtsScreen.kt` | Kotlin إنتاجي | 409 | A07 |
| `app/src/main/java/com/shift/app/feature/debts/presentation/DebtsViewModel.kt` | Kotlin إنتاجي | 236 | — |
| `app/src/test/java/com/shift/app/AssetOperationsTest.kt` | اختبار/مساعد | 348 | A02، A05، A06 |
| `app/src/test/java/com/shift/app/AssetSchemaTest.kt` | اختبار/مساعد | 31 | A06 |
| `app/src/test/java/com/shift/app/DebtAccrualOperationsTest.kt` | اختبار/مساعد | 46 | A02 |
| `app/src/test/java/com/shift/app/DebtAdjustmentOperationsTest.kt` | اختبار/مساعد | 36 | — |
| `app/src/test/java/com/shift/app/DebtAdvancedUiRoutesTest.kt` | اختبار/مساعد | 15 | — |
| `app/src/test/java/com/shift/app/DebtAssetSettlementTest.kt` | اختبار/مساعد | 37 | — |
| `app/src/test/java/com/shift/app/DebtCenterUiContractTest.kt` | اختبار/مساعد | 22 | — |
| `app/src/test/java/com/shift/app/DebtDatabaseSchemaTest.kt` | اختبار/مساعد | 73 | A05، A06 |
| `app/src/test/java/com/shift/app/DebtDomainTest.kt` | اختبار/مساعد | 175 | A02، A06 |
| `app/src/test/java/com/shift/app/DebtEndToEndTest.kt` | اختبار/مساعد | 129 | A02، A05، A06 |
| `app/src/test/java/com/shift/app/DebtFinancedAssetOperationsTest.kt` | اختبار/مساعد | 43 | A02 |
| `app/src/test/java/com/shift/app/DebtLedgerRepositoryContractTest.kt` | اختبار/مساعد | 36 | — |
| `app/src/test/java/com/shift/app/DebtOperationWizardTest.kt` | اختبار/مساعد | 25 | — |
| `app/src/test/java/com/shift/app/DebtOrganizationRepositoryTest.kt` | اختبار/مساعد | 36 | A02 |
| `app/src/test/java/com/shift/app/DebtReductionSheetTest.kt` | اختبار/مساعد | 21 | A02 |
| `app/src/test/java/com/shift/app/DebtReminderSchedulerTest.kt` | اختبار/مساعد | 85 | — |
| `app/src/test/java/com/shift/app/DebtReportCalculatorTest.kt` | اختبار/مساعد | 68 | A02، A06 |
| `app/src/test/java/com/shift/app/DebtScenarioCoverageTest.kt` | اختبار/مساعد | 32 | — |
| `app/src/test/java/com/shift/app/DebtUiCutoverContractTest.kt` | اختبار/مساعد | 41 | A06 |
| `app/src/test/java/com/shift/app/feature/assets/AssetBoundaryArchitectureTest.kt` | اختبار/مساعد | 66 | A06 |
| `app/src/test/java/com/shift/app/feature/assets/AssetGatewayAdapterTest.kt` | اختبار/مساعد | 32 | A07 |
| `app/src/test/java/com/shift/app/feature/assets/AssetOperationFactoryRegressionTest.kt` | اختبار/مساعد | 86 | A02، A06 |
| `app/src/test/java/com/shift/app/feature/assets/AssetSyncParticipantTest.kt` | اختبار/مساعد | 30 | — |
| `app/src/test/java/com/shift/app/feature/debts/DebtAssetSettlementIntegrationTest.kt` | اختبار/مساعد | 34 | — |
| `app/src/test/java/com/shift/app/feature/debts/DebtBoundaryArchitectureTest.kt` | اختبار/مساعد | 59 | A02، A06 |
| `app/src/test/java/com/shift/app/feature/debts/DebtGatewayAdapterTest.kt` | اختبار/مساعد | 36 | A02، A04 |
| `app/src/test/java/com/shift/app/feature/debts/DebtsViewModelTest.kt` | اختبار/مساعد | 123 | — |
| `app/src/test/java/com/shift/app/testing/debts/FakeDebtGateway.kt` | اختبار/مساعد | 64 | — |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtCalculator.kt` | Kotlin إنتاجي | 76 | A02 |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtFinancialImpact.kt` | Kotlin إنتاجي | 26 | — |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtOperationFactory.kt` | Kotlin إنتاجي | 317 | A02 |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtScheduleCalculator.kt` | Kotlin إنتاجي | 39 | — |
| `core/model/src/main/java/com/shift/app/domain/debt/DebtTypes.kt` | Kotlin إنتاجي | 131 | A02 |
| `core/model/src/main/java/com/shift/app/domain/finance/CurrencyAssetCalculator.kt` | Kotlin إنتاجي | 153 | A02 |
| `core/model/src/test/java/com/shift/app/CurrencyAssetCalculatorTest.kt` | اختبار/مساعد | 93 | A02 |
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/model/AssetCommands.kt` | Kotlin إنتاجي | 86 | A02 |
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/model/AssetModels.kt` | Kotlin إنتاجي | 95 | A02 |
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/repository/AssetGateway.kt` | Kotlin إنتاجي | 42 | A02 |
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/usecase/AssetCommandUseCases.kt` | Kotlin إنتاجي | 45 | A02 |
| `feature/assets/src/main/java/com/shift/app/feature/assets/domain/usecase/ObserveAssetUseCases.kt` | Kotlin إنتاجي | 142 | A02 |
| `feature/assets/src/test/java/com/shift/app/feature/assets/AssetUseCasesTest.kt` | اختبار/مساعد | 189 | A02 |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/model/DebtCommands.kt` | Kotlin إنتاجي | 128 | — |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/model/DebtModels.kt` | Kotlin إنتاجي | 90 | — |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/repository/DebtGateway.kt` | Kotlin إنتاجي | 52 | — |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/usecase/DebtCommandUseCases.kt` | Kotlin إنتاجي | 70 | — |
| `feature/debts/src/main/java/com/shift/app/feature/debts/domain/usecase/ObserveDebtUseCases.kt` | Kotlin إنتاجي | 122 | — |
| `feature/debts/src/test/java/com/shift/app/feature/debts/DebtUseCasesTest.kt` | اختبار/مساعد | 159 | — |

### A04 — الأهداف والميزانية والتقارير (97 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/src/androidTest/java/com/shift/app/goals/AssetPurchaseGoalUiTest.kt` | اختبار Android | 26 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/CostFundingGoalUiTest.kt` | اختبار Android | 26 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/DebtPayoffGoalUiTest.kt` | اختبار Android | 24 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/EmergencyFundGoalUiTest.kt` | اختبار Android | 24 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/ExpenseGoalsUiTest.kt` | اختبار Android | 30 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/GoalFundingUiTest.kt` | اختبار Android | 66 | A06، A07 |
| `app/src/androidTest/java/com/shift/app/goals/GoalLifecycleUiTest.kt` | اختبار Android | 29 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/GoalPhase1EndToEndUiTest.kt` | اختبار Android | 29 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/GoalSmokeTest.kt` | اختبار Android | 23 | A07 |
| `app/src/androidTest/java/com/shift/app/goals/IncomeGrowthGoalUiTest.kt` | اختبار Android | 26 | A07 |
| `app/src/main/java/com/shift/app/data/local/dao/goals/FinancialGoalDaos.kt` | Kotlin إنتاجي | 233 | A06 |
| `app/src/main/java/com/shift/app/data/local/entities/goals/FinancialGoalEntities.kt` | Kotlin إنتاجي | 375 | A02، A06 |
| `app/src/main/java/com/shift/app/data/repository/FinancialChangePublisher.kt` | Kotlin إنتاجي | 54 | A06 |
| `app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt` | Kotlin إنتاجي | 696 | A02، A06 |
| `app/src/main/java/com/shift/app/domain/finance/FinancialReportCalculator.kt` | Kotlin إنتاجي | 360 | A02، A03، A06 |
| `app/src/main/java/com/shift/app/feature/goals/data/GoalCompletionAdapter.kt` | Kotlin إنتاجي | 19 | A02 |
| `app/src/main/java/com/shift/app/feature/goals/data/GoalEntityMapper.kt` | Kotlin إنتاجي | 62 | A06 |
| `app/src/main/java/com/shift/app/feature/goals/data/GoalGatewayAdapter.kt` | Kotlin إنتاجي | 84 | A06 |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomAssetGoalCompletion.kt` | Kotlin إنتاجي | 74 | A02، A03، A05، A06 |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomCostGoalCompletion.kt` | Kotlin إنتاجي | 108 | A02، A03، A05، A06 |
| `app/src/main/java/com/shift/app/feature/goals/data/RoomGoalDebtPayment.kt` | Kotlin إنتاجي | 67 | A02، A03، A05، A06 |
| `app/src/main/java/com/shift/app/feature/goals/di/GoalFeatureModule.kt` | Kotlin إنتاجي | 125 | A02، A03، A06 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/AssetGoalCompletionScreen.kt` | Kotlin إنتاجي | 94 | A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/CostGoalCompletionScreen.kt` | Kotlin إنتاجي | 68 | A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/DebtGoalPaymentScreen.kt` | Kotlin إنتاجي | 55 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/GoalDetailsScreen.kt` | Kotlin إنتاجي | 342 | A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/GoalEditorScreen.kt` | Kotlin إنتاجي | 312 | A03، A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/GoalEditorViewModel.kt` | Kotlin إنتاجي | 345 | A02، A03 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/GoalsListScreen.kt` | Kotlin إنتاجي | 306 | A02، A07 |
| `app/src/main/java/com/shift/app/feature/goals/presentation/GoalsViewModel.kt` | Kotlin إنتاجي | 311 | A02 |
| `app/src/main/java/com/shift/app/feature/reports/data/ReportsQueryAdapter.kt` | Kotlin إنتاجي | 149 | A02، A03، A06 |
| `app/src/main/java/com/shift/app/feature/reports/di/ReportsFeatureModule.kt` | Kotlin إنتاجي | 17 | — |
| `app/src/main/java/com/shift/app/feature/reports/presentation/ReportsPresentationContract.kt` | Kotlin إنتاجي | 17 | — |
| `app/src/main/java/com/shift/app/feature/reports/presentation/ReportsRoute.kt` | Kotlin إنتاجي | 17 | A07 |
| `app/src/main/java/com/shift/app/feature/reports/presentation/ReportsScreen.kt` | Kotlin إنتاجي | 438 | A07 |
| `app/src/main/java/com/shift/app/feature/reports/presentation/ReportsViewModel.kt` | Kotlin إنتاجي | 47 | — |
| `app/src/main/java/com/shift/app/ui/screens/BudgetGoalsScreen.kt` | Kotlin إنتاجي | 157 | A02، A06، A07 |
| `app/src/main/java/com/shift/app/ui/screens/plans/PlansScreen.kt` | Kotlin إنتاجي | 82 | A07 |
| `app/src/test/java/com/shift/app/FinancialReportCalculatorTest.kt` | اختبار/مساعد | 253 | A02، A03، A06 |
| `app/src/test/java/com/shift/app/PaymentReportingRulesTest.kt` | اختبار/مساعد | 18 | A02 |
| `app/src/test/java/com/shift/app/feature/goals/GoalBoundaryArchitectureTest.kt` | اختبار/مساعد | 23 | A06 |
| `app/src/test/java/com/shift/app/feature/goals/GoalDomainIndependenceTest.kt` | اختبار/مساعد | 19 | — |
| `app/src/test/java/com/shift/app/feature/goals/GoalMeasurementProviderTest.kt` | اختبار/مساعد | 32 | A02، A03 |
| `app/src/test/java/com/shift/app/feature/goals/data/GoalGatewayAdapterTest.kt` | اختبار/مساعد | 15 | — |
| `app/src/test/java/com/shift/app/feature/reports/ReportsBoundaryArchitectureTest.kt` | اختبار/مساعد | 67 | A03، A06 |
| `app/src/test/java/com/shift/app/feature/reports/ReportsQueryTest.kt` | اختبار/مساعد | 37 | A03، A06 |
| `app/src/test/java/com/shift/app/goals/AssetPurchaseGoalTest.kt` | اختبار/مساعد | 217 | — |
| `app/src/test/java/com/shift/app/goals/CostFundingGoalTest.kt` | اختبار/مساعد | 66 | A02 |
| `app/src/test/java/com/shift/app/goals/DebtPayoffGoalTest.kt` | اختبار/مساعد | 117 | A02، A03، A06 |
| `app/src/test/java/com/shift/app/goals/EmergencyFundGoalTest.kt` | اختبار/مساعد | 113 | A02 |
| `app/src/test/java/com/shift/app/goals/ExpenseGoalsTest.kt` | اختبار/مساعد | 138 | A02 |
| `app/src/test/java/com/shift/app/goals/GoalDomainContractTest.kt` | اختبار/مساعد | 143 | — |
| `app/src/test/java/com/shift/app/goals/GoalEvaluationEngineTest.kt` | اختبار/مساعد | 250 | A02 |
| `app/src/test/java/com/shift/app/goals/GoalFinancialChangeContractTest.kt` | اختبار/مساعد | 35 | A02، A03 |
| `app/src/test/java/com/shift/app/goals/GoalLifecycleTest.kt` | اختبار/مساعد | 46 | — |
| `app/src/test/java/com/shift/app/goals/GoalOutboxTest.kt` | اختبار/مساعد | 113 | — |
| `app/src/test/java/com/shift/app/goals/GoalPhase1EndToEndTest.kt` | اختبار/مساعد | 149 | A06 |
| `app/src/test/java/com/shift/app/goals/GoalPhase1ManifestTest.kt` | اختبار/مساعد | 41 | — |
| `app/src/test/java/com/shift/app/goals/GoalRuntimeWiringContractTest.kt` | اختبار/مساعد | 37 | — |
| `app/src/test/java/com/shift/app/goals/GoalSpecializedCompletionContractTest.kt` | اختبار/مساعد | 50 | A02 |
| `app/src/test/java/com/shift/app/goals/IncomeGrowthGoalTest.kt` | اختبار/مساعد | 99 | — |
| `app/src/test/java/com/shift/app/goals/NetWorthGrowthGoalTest.kt` | اختبار/مساعد | 92 | A02، A03 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/evaluation/GoalEvaluationEngine.kt` | Kotlin إنتاجي | 253 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/evaluation/GoalInvalidationProcessor.kt` | Kotlin إنتاجي | 163 | A02 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/evaluation/GoalMeasurementRegistry.kt` | Kotlin إنتاجي | 66 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/funding/GoalFundingCalculator.kt` | Kotlin إنتاجي | 157 | A02 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/AssetPurchaseMeasurementProvider.kt` | Kotlin إنتاجي | 73 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/DebtPayoffMeasurementProvider.kt` | Kotlin إنتاجي | 45 | A03 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/EmergencyFundMeasurementProvider.kt` | Kotlin إنتاجي | 44 | A02 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/ExpenseGoalMeasurementProvider.kt` | Kotlin إنتاجي | 56 | A06 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/IncomeGoalMeasurementProvider.kt` | Kotlin إنتاجي | 55 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/measurement/NetWorthMeasurementProvider.kt` | Kotlin إنتاجي | 74 | A02، A03 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/model/GoalModels.kt` | Kotlin إنتاجي | 79 | A02 |
| `feature/goals/src/main/java/com/shift/app/domain/goals/model/GoalTypes.kt` | Kotlin إنتاجي | 72 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/AssetPurchaseGoalTemplate.kt` | Kotlin إنتاجي | 206 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/CostFundingGoalTemplate.kt` | Kotlin إنتاجي | 110 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/DebtPayoffGoalTemplate.kt` | Kotlin إنتاجي | 123 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/EmergencyFundGoalTemplate.kt` | Kotlin إنتاجي | 110 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/ExpenseGoalTemplates.kt` | Kotlin إنتاجي | 100 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/IncomeGrowthGoalTemplate.kt` | Kotlin إنتاجي | 92 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/templates/NetWorthGrowthGoalTemplate.kt` | Kotlin إنتاجي | 95 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteAssetPurchaseGoal.kt` | Kotlin إنتاجي | 25 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteCostGoal.kt` | Kotlin إنتاجي | 22 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/GoalCostUseCases.kt` | Kotlin إنتاجي | 22 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/GoalFundingUseCases.kt` | Kotlin إنتاجي | 21 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/GoalLifecycleUseCases.kt` | Kotlin إنتاجي | 62 | — |
| `feature/goals/src/main/java/com/shift/app/domain/goals/usecase/RecordGoalDebtPayment.kt` | Kotlin إنتاجي | 20 | A02 |
| `feature/goals/src/main/java/com/shift/app/feature/goals/domain/model/GoalDomainModels.kt` | Kotlin إنتاجي | 191 | — |
| `feature/goals/src/main/java/com/shift/app/feature/goals/domain/model/GoalMeasurementRows.kt` | Kotlin إنتاجي | 11 | A03، A06 |
| `feature/goals/src/main/java/com/shift/app/feature/goals/domain/repository/GoalGateway.kt` | Kotlin إنتاجي | 70 | A02 |
| `feature/goals/src/test/java/com/shift/app/goals/GoalFundingTest.kt` | اختبار/مساعد | 117 | A02 |
| `feature/goals/src/test/java/com/shift/app/goals/TestMoney.kt` | اختبار/مساعد | 7 | A02 |
| `feature/reports/src/main/java/com/shift/app/feature/reports/domain/model/ReportsModels.kt` | Kotlin إنتاجي | 147 | A02، A03، A06 |
| `feature/reports/src/main/java/com/shift/app/feature/reports/domain/repository/ReportsQuery.kt` | Kotlin إنتاجي | 9 | — |
| `feature/reports/src/main/java/com/shift/app/feature/reports/domain/usecase/ObserveReportsUseCase.kt` | Kotlin إنتاجي | 18 | — |
| `feature/reports/src/main/java/com/shift/app/feature/reports/domain/usecase/ReportsReadModelCalculator.kt` | Kotlin إنتاجي | 221 | A02، A03، A06 |
| `feature/reports/src/test/java/com/shift/app/feature/reports/ReportReadModelTest.kt` | اختبار/مساعد | 119 | A02، A03، A06 |

### A05 — المزامنة وعقود السيرفر (83 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/src/main/java/com/shift/app/data/local/dao/SyncOutboxDao.kt` | Kotlin إنتاجي | 104 | A06 |
| `app/src/main/java/com/shift/app/data/local/entities/SyncOutboxEntity.kt` | Kotlin إنتاجي | 46 | A06 |
| `app/src/main/java/com/shift/app/data/local/sync/SyncOutboxSchema.kt` | Kotlin إنتاجي | 30 | A06 |
| `app/src/main/java/com/shift/app/data/local/sync/SyncOutboxSqlPlan.kt` | Kotlin إنتاجي | 127 | — |
| `app/src/main/java/com/shift/app/data/remote/AssetRemoteSyncDataSource.kt` | Kotlin إنتاجي | 666 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/DebtRemoteSyncDataSource.kt` | Kotlin إنتاجي | 498 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/DebtSyncBundle.kt` | Kotlin إنتاجي | 32 | A03 |
| `app/src/main/java/com/shift/app/data/remote/GoalRemoteSyncDataSource.kt` | Kotlin إنتاجي | 326 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/LedgerRemoteSyncDataSource.kt` | Kotlin إنتاجي | 471 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/ReferenceDataRemoteSyncDataSource.kt` | Kotlin إنتاجي | 188 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/RemoteAsset.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteAssetTransaction.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteAssetValuation.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteBalanceTransaction.kt` | Kotlin إنتاجي | 13 | A02 |
| `app/src/main/java/com/shift/app/data/remote/RemoteCurrencyAssetLot.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteCurrencyAssetSaleAllocation.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebt.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebtAccount.kt` | Kotlin إنتاجي | 26 | A03 |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebtLink.kt` | Kotlin إنتاجي | 21 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebtMigrationReview.kt` | Kotlin إنتاجي | 20 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebtSchedule.kt` | Kotlin إنتاجي | 23 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteDebtTransaction.kt` | Kotlin إنتاجي | 25 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteExpenseBeneficiary.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteIncomeSource.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteLedgerHistoryMigration.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/RemotePayloadDecoder.kt` | Kotlin إنتاجي | 40 | — |
| `app/src/main/java/com/shift/app/data/remote/RemotePayment.kt` | Kotlin إنتاجي | 13 | A02 |
| `app/src/main/java/com/shift/app/data/remote/RemoteSettings.kt` | Kotlin إنتاجي | 11 | — |
| `app/src/main/java/com/shift/app/data/remote/RemoteSyncContext.kt` | Kotlin إنتاجي | 107 | A01، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/RemoteSyncPayloads.kt` | Kotlin إنتاجي | 217 | A02، A04 |
| `app/src/main/java/com/shift/app/data/remote/RemoteSyncRules.kt` | Kotlin إنتاجي | 28 | A02، A06 |
| `app/src/main/java/com/shift/app/data/remote/RemoteTransaction.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/data/remote/SettingsRemoteSyncDataSource.kt` | Kotlin إنتاجي | 132 | A01، A02، A03، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/SupabaseClient.kt` | Kotlin إنتاجي | 17 | A07 |
| `app/src/main/java/com/shift/app/data/remote/SyncManager.kt` | Kotlin إنتاجي | 67 | — |
| `app/src/main/java/com/shift/app/data/remote/goals/GoalSyncMapper.kt` | Kotlin إنتاجي | 97 | A02، A04، A06 |
| `app/src/main/java/com/shift/app/data/remote/goals/RemoteFinancialGoalModels.kt` | Kotlin إنتاجي | 208 | A04 |
| `app/src/main/java/com/shift/app/di/NetworkModule.kt` | Kotlin إنتاجي | 22 | — |
| `app/src/main/java/com/shift/app/sync/PreferencesSyncCheckpointStore.kt` | Kotlin إنتاجي | 16 | A01 |
| `app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt` | Kotlin إنتاجي | 110 | — |
| `app/src/main/java/com/shift/app/sync/di/SyncInfrastructureModule.kt` | Kotlin إنتاجي | 22 | A06 |
| `app/src/main/java/com/shift/app/sync/di/SyncParticipantModule.kt` | Kotlin إنتاجي | 49 | — |
| `app/src/main/java/com/shift/app/sync/outbox/SyncOutboxPolicy.kt` | Kotlin إنتاجي | 47 | A06 |
| `app/src/main/java/com/shift/app/sync/outbox/SyncOutboxProcessor.kt` | Kotlin إنتاجي | 56 | A06 |
| `app/src/main/java/com/shift/app/sync/outbox/SyncOutboxWorker.kt` | Kotlin إنتاجي | 36 | — |
| `app/src/main/java/com/shift/app/sync/outbox/SyncWorkScheduler.kt` | Kotlin إنتاجي | 104 | A06 |
| `app/src/main/java/com/shift/app/sync/participant/AssetSyncParticipant.kt` | Kotlin إنتاجي | 146 | A02، A06 |
| `app/src/main/java/com/shift/app/sync/participant/DebtSyncParticipant.kt` | Kotlin إنتاجي | 34 | A06 |
| `app/src/main/java/com/shift/app/sync/participant/GoalSyncParticipant.kt` | Kotlin إنتاجي | 26 | A04 |
| `app/src/main/java/com/shift/app/sync/participant/LedgerSyncParticipant.kt` | Kotlin إنتاجي | 173 | A02، A06 |
| `app/src/main/java/com/shift/app/sync/participant/ReferenceDataSyncParticipant.kt` | Kotlin إنتاجي | 46 | A06 |
| `app/src/main/java/com/shift/app/sync/participant/RoomAssetOperationIndex.kt` | Kotlin إنتاجي | 29 | A02، A06 |
| `app/src/main/java/com/shift/app/sync/participant/SettingsSyncParticipant.kt` | Kotlin إنتاجي | 29 | A01 |
| `app/src/main/java/com/shift/app/sync/remote/RemoteSyncPorts.kt` | Kotlin إنتاجي | 69 | A02، A04، A06 |
| `app/src/main/java/com/shift/app/utils/SyncMergePolicy.kt` | Kotlin إنتاجي | 52 | — |
| `app/src/test/java/com/shift/app/AssetRpcSqlContractTest.kt` | اختبار/مساعد | 35 | — |
| `app/src/test/java/com/shift/app/DebtRpcSqlContractTest.kt` | اختبار/مساعد | 53 | A06 |
| `app/src/test/java/com/shift/app/DebtSyncContractTest.kt` | اختبار/مساعد | 35 | A03 |
| `app/src/test/java/com/shift/app/RemotePayloadDecoderTest.kt` | اختبار/مساعد | 68 | A06 |
| `app/src/test/java/com/shift/app/SyncMergePolicyTest.kt` | اختبار/مساعد | 33 | — |
| `app/src/test/java/com/shift/app/SyncOrchestrationContractTest.kt` | اختبار/مساعد | 294 | A02، A04، A06 |
| `app/src/test/java/com/shift/app/SyncRetryPolicyTest.kt` | اختبار/مساعد | 46 | A02 |
| `app/src/test/java/com/shift/app/goals/GoalRpcSqlContractTest.kt` | اختبار/مساعد | 97 | A06 |
| `app/src/test/java/com/shift/app/goals/GoalSyncContractTest.kt` | اختبار/مساعد | 96 | A04 |
| `app/src/test/java/com/shift/app/sync/ClockSkewConflictTest.kt` | اختبار/مساعد | 32 | — |
| `app/src/test/java/com/shift/app/sync/InitialSyncSafetyTest.kt` | اختبار/مساعد | 24 | — |
| `app/src/test/java/com/shift/app/sync/MultiDeviceConflictTest.kt` | اختبار/مساعد | 66 | — |
| `app/src/test/java/com/shift/app/sync/PartialSyncFailureTest.kt` | اختبار/مساعد | 24 | — |
| `app/src/test/java/com/shift/app/sync/PendingLocalChangeSurvivesPullTest.kt` | اختبار/مساعد | 30 | — |
| `app/src/test/java/com/shift/app/sync/SyncOrchestratorTest.kt` | اختبار/مساعد | 146 | — |
| `app/src/test/java/com/shift/app/sync/SyncParticipantArchitectureTest.kt` | اختبار/مساعد | 60 | A06 |
| `app/src/test/java/com/shift/app/sync/outbox/OutboxIdempotencyTest.kt` | اختبار/مساعد | 23 | — |
| `app/src/test/java/com/shift/app/sync/outbox/ProcessDeathRecoveryTest.kt` | اختبار/مساعد | 29 | — |
| `app/src/test/java/com/shift/app/sync/outbox/SyncOutboxTransactionTest.kt` | اختبار/مساعد | 70 | — |
| `app/src/test/java/com/shift/app/sync/outbox/SyncWorkerRetryTest.kt` | اختبار/مساعد | 65 | A06 |
| `app/src/test/java/com/shift/app/sync/outbox/ViewModelSyncBoundaryTest.kt` | اختبار/مساعد | 25 | — |
| `app/src/test/java/com/shift/app/sync/outbox/WorkerConfigurationTest.kt` | اختبار/مساعد | 37 | — |
| `core/sync/src/main/java/com/shift/app/sync/SyncCheckpointStore.kt` | Kotlin إنتاجي | 7 | — |
| `core/sync/src/main/java/com/shift/app/sync/SyncParticipant.kt` | Kotlin إنتاجي | 17 | — |
| `core/sync/src/main/java/com/shift/app/sync/SyncQueueGateway.kt` | Kotlin إنتاجي | 17 | — |
| `core/sync/src/main/java/com/shift/app/sync/SyncSafety.kt` | Kotlin إنتاجي | 75 | A02، A04، A06 |
| `core/sync/src/test/java/com/shift/app/sync/SyncCheckpointTest.kt` | اختبار/مساعد | 21 | — |
| `docs/architecture/sync-protocol.md` | توثيق | 39 | — |

### A06 — قاعدة البيانات والترحيل والنسخ والاستعادة (51 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `app/schemas/com.shift.app.data.local.MadarDatabase/16.json` | مخطط Room | 2304 | — |
| `app/schemas/com.shift.app.data.local.MadarDatabase/17.json` | مخطط Room | 3447 | — |
| `app/src/androidTest/java/com/shift/app/migration/Migration17To18InstrumentationTest.kt` | اختبار Android | 115 | A05 |
| `app/src/main/java/com/shift/app/data/backup/DebtBackupPayload.kt` | Kotlin إنتاجي | 52 | A03 |
| `app/src/main/java/com/shift/app/data/backup/GoalBackupPayload.kt` | Kotlin إنتاجي | 121 | A04 |
| `app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt` | Kotlin إنتاجي | 1016 | A01، A02، A03، A04، A05، A07 |
| `app/src/main/java/com/shift/app/data/local/dao/LedgerHistoryMigrationDao.kt` | Kotlin إنتاجي | 36 | — |
| `app/src/main/java/com/shift/app/data/local/entities/LedgerHistoryMigration.kt` | Kotlin إنتاجي | 35 | A02، A05 |
| `app/src/main/java/com/shift/app/data/local/migration/Migration17To18Plan.kt` | Kotlin إنتاجي | 24 | A05 |
| `app/src/main/java/com/shift/app/data/local/migration/SqlMigrationExecutor.kt` | Kotlin إنتاجي | 8 | — |
| `app/src/main/java/com/shift/app/data/migration/LegacyDebtMigrationPlanner.kt` | Kotlin إنتاجي | 147 | A02، A03 |
| `app/src/main/java/com/shift/app/data/migration/LegacyDebtMigrator.kt` | Kotlin إنتاجي | 248 | A02، A03، A05 |
| `app/src/main/java/com/shift/app/data/migration/LegacyFinancialCutoverCoordinator.kt` | Kotlin إنتاجي | 187 | A02، A03 |
| `app/src/main/java/com/shift/app/data/repository/LegacyHistoryMigrationRepository.kt` | Kotlin إنتاجي | 310 | A02، A05 |
| `app/src/main/java/com/shift/app/di/DatabaseModule.kt` | Kotlin إنتاجي | 53 | A01، A02، A03، A04، A05، A07 |
| `app/src/main/java/com/shift/app/domain/finance/LegacyHistoryMigrationPlanner.kt` | Kotlin إنتاجي | 352 | A02 |
| `app/src/main/java/com/shift/app/feature/backup/data/BackupDocumentCodec.kt` | Kotlin إنتاجي | 93 | — |
| `app/src/main/java/com/shift/app/feature/backup/data/BackupGatewayAdapter.kt` | Kotlin إنتاجي | 150 | A05 |
| `app/src/main/java/com/shift/app/feature/backup/data/BackupRedactor.kt` | Kotlin إنتاجي | 32 | — |
| `app/src/main/java/com/shift/app/feature/backup/data/BackupSectionCodec.kt` | Kotlin إنتاجي | 56 | — |
| `app/src/main/java/com/shift/app/feature/backup/data/RestoreAtomicityGuard.kt` | Kotlin إنتاجي | 66 | — |
| `app/src/main/java/com/shift/app/feature/backup/data/codec/AssetBackupCodec.kt` | Kotlin إنتاجي | 285 | A02، A03 |
| `app/src/main/java/com/shift/app/feature/backup/data/codec/BackupJson.kt` | Kotlin إنتاجي | 22 | — |
| `app/src/main/java/com/shift/app/feature/backup/data/codec/DebtBackupCodec.kt` | Kotlin إنتاجي | 236 | A03 |
| `app/src/main/java/com/shift/app/feature/backup/data/codec/FinanceBackupCodec.kt` | Kotlin إنتاجي | 637 | A01، A02 |
| `app/src/main/java/com/shift/app/feature/backup/data/codec/GoalBackupCodec.kt` | Kotlin إنتاجي | 171 | A05 |
| `app/src/main/java/com/shift/app/feature/backup/di/BackupFeatureModule.kt` | Kotlin إنتاجي | 17 | — |
| `app/src/main/java/com/shift/app/feature/backup/domain/model/BackupModels.kt` | Kotlin إنتاجي | 129 | — |
| `app/src/main/java/com/shift/app/feature/backup/domain/repository/BackupGateway.kt` | Kotlin إنتاجي | 13 | — |
| `app/src/main/java/com/shift/app/feature/backup/presentation/BackupViewModel.kt` | Kotlin إنتاجي | 93 | — |
| `app/src/main/java/com/shift/app/feature/debts/presentation/LegacyDebtMigrationRoute.kt` | Kotlin إنتاجي | 14 | A03، A07 |
| `app/src/main/java/com/shift/app/feature/session/data/LegacyIncomeSourceMigrator.kt` | Kotlin إنتاجي | 74 | A01، A05 |
| `app/src/main/java/com/shift/app/ui/components/LegacyHistoryMigrationWizard.kt` | Kotlin إنتاجي | 143 | A07 |
| `app/src/main/java/com/shift/app/viewmodel/LegacyHistoryMigrationViewModel.kt` | Kotlin إنتاجي | 224 | A01، A02، A05 |
| `app/src/test/java/com/shift/app/LegacyCutoverRollbackTest.kt` | اختبار/مساعد | 44 | A02 |
| `app/src/test/java/com/shift/app/LegacyDebtMigratorTest.kt` | اختبار/مساعد | 38 | A02، A03 |
| `app/src/test/java/com/shift/app/LegacyHistoryMigrationPlannerTest.kt` | اختبار/مساعد | 145 | A02 |
| `app/src/test/java/com/shift/app/LegacyHistoryRepositoryContractTest.kt` | اختبار/مساعد | 53 | A02 |
| `app/src/test/java/com/shift/app/LegacyLedgerParityTest.kt` | اختبار/مساعد | 113 | A02 |
| `app/src/test/java/com/shift/app/LegacyMigrationIdempotencyTest.kt` | اختبار/مساعد | 42 | A02 |
| `app/src/test/java/com/shift/app/MigrationChainTest.kt` | اختبار/مساعد | 21 | — |
| `app/src/test/java/com/shift/app/backup/BackupBoundaryArchitectureTest.kt` | اختبار/مساعد | 48 | — |
| `app/src/test/java/com/shift/app/backup/BackupCodecRoundTripTest.kt` | اختبار/مساعد | 46 | — |
| `app/src/test/java/com/shift/app/backup/BackupManifestCompatibilityTest.kt` | اختبار/مساعد | 28 | — |
| `app/src/test/java/com/shift/app/backup/CorruptBackupRejectionTest.kt` | اختبار/مساعد | 31 | — |
| `app/src/test/java/com/shift/app/backup/RestoreAtomicityTest.kt` | اختبار/مساعد | 71 | — |
| `app/src/test/java/com/shift/app/backup/RestoreFaultInjectionTest.kt` | اختبار/مساعد | 121 | — |
| `app/src/test/java/com/shift/app/backup/SuspendTest.kt` | اختبار/مساعد | 14 | — |
| `app/src/test/java/com/shift/app/goals/GoalMigration16To17Test.kt` | اختبار/مساعد | 119 | — |
| `feature/ledger/src/main/java/com/shift/app/domain/finance/LegacyFinancialCutover.kt` | Kotlin إنتاجي | 212 | A02 |
| `feature/ledger/src/test/java/com/shift/app/feature/ledger/LegacyFinancialCutoverModuleTest.kt` | اختبار/مساعد | 28 | A02 |

### A07 — الواجهات العامة والمعمارية والبناء والإطلاق (104 ملفًا)

| الملف النسبي | النوع | الأسطر | مراجعة مشتركة |
|---|---|---:|---|
| `.github/workflows/android-ci.yml` | إعداد/بناء/آخر | 68 | — |
| `.github/workflows/android-release.yml` | إعداد/بناء/آخر | 68 | — |
| `.gitignore` | إعداد/بناء/آخر | 19 | — |
| `CHECKSUMS.sha256` | إعداد/بناء/آخر | 516 | — |
| `app/build.gradle.kts` | إعداد/بناء/آخر | 174 | — |
| `app/proguard-rules.pro` | إعداد/بناء/آخر | 14 | — |
| `app/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 25 | — |
| `app/src/main/ic_launcher-playstore.png` | إعداد/بناء/آخر | — | — |
| `app/src/main/java/com/shift/app/MainActivity.kt` | Kotlin إنتاجي | 43 | — |
| `app/src/main/java/com/shift/app/ShiftApplication.kt` | Kotlin إنتاجي | 39 | A04، A05 |
| `app/src/main/java/com/shift/app/navigation/NavGraph.kt` | Kotlin إنتاجي | 133 | A01 |
| `app/src/main/java/com/shift/app/ui/components/DonutChart.kt` | Kotlin إنتاجي | 48 | — |
| `app/src/main/java/com/shift/app/ui/components/LineChart.kt` | Kotlin إنتاجي | 66 | — |
| `app/src/main/java/com/shift/app/ui/screens/MainScreen.kt` | Kotlin إنتاجي | 296 | A01، A02، A03، A04، A05 |
| `app/src/main/java/com/shift/app/ui/screens/SettingsScreen.kt` | Kotlin إنتاجي | 699 | A01، A04، A05، A06 |
| `app/src/main/java/com/shift/app/ui/theme/Color.kt` | Kotlin إنتاجي | 35 | — |
| `app/src/main/java/com/shift/app/ui/theme/Theme.kt` | Kotlin إنتاجي | 30 | — |
| `app/src/main/java/com/shift/app/ui/theme/Type.kt` | Kotlin إنتاجي | 65 | — |
| `app/src/main/java/com/shift/app/utils/ErrorMessages.kt` | Kotlin إنتاجي | 44 | — |
| `app/src/main/java/com/shift/app/viewmodel/SettingsViewModel.kt` | Kotlin إنتاجي | 38 | A01، A05 |
| `app/src/main/res/drawable/ic_launcher_background.xml` | مورد Android | 74 | — |
| `app/src/main/res/drawable/ic_launcher_foreground.xml` | مورد Android | 31 | — |
| `app/src/main/res/font/cairo_bold.ttf` | مورد Android | — | — |
| `app/src/main/res/font/cairo_extrabold.ttf` | مورد Android | — | — |
| `app/src/main/res/font/cairo_regular.ttf` | مورد Android | — | — |
| `app/src/main/res/font/cairo_semibold.ttf` | مورد Android | — | — |
| `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` | مورد Android | 5 | — |
| `app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml` | مورد Android | 5 | — |
| `app/src/main/res/mipmap-hdpi/ic_launcher.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-hdpi/ic_launcher_foreground.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-hdpi/ic_launcher_round.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-mdpi/ic_launcher.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-mdpi/ic_launcher_foreground.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-mdpi/ic_launcher_round.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xhdpi/ic_launcher.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xhdpi/ic_launcher_round.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxhdpi/ic_launcher.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxhdpi/ic_launcher_round.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxxhdpi/ic_launcher.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.webp` | مورد Android | — | — |
| `app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.webp` | مورد Android | — | — |
| `app/src/main/res/values/font_certs.xml` | مورد Android | 49 | — |
| `app/src/main/res/values/strings.xml` | مورد Android | 3 | — |
| `app/src/main/res/values/themes.xml` | مورد Android | 3 | — |
| `app/src/test/java/com/shift/app/ErrorMessagesTest.kt` | اختبار/مساعد | 50 | — |
| `app/src/test/java/com/shift/app/ReleaseCloseoutArchitectureTest.kt` | اختبار/مساعد | 83 | A06 |
| `app/src/test/java/com/shift/app/architecture/DiPackageByFeatureArchitectureTest.kt` | اختبار/مساعد | 107 | A01، A02، A03، A04، A05، A06 |
| `app/src/test/java/com/shift/app/architecture/MainViewModelDecompositionArchitectureTest.kt` | اختبار/مساعد | 61 | A01، A06 |
| `app/src/test/java/com/shift/app/architecture/PresentationConventionArchitectureTest.kt` | اختبار/مساعد | 76 | — |
| `build.gradle.kts` | إعداد/بناء/آخر | 8 | — |
| `core/model/build.gradle.kts` | إعداد/بناء/آخر | 25 | — |
| `core/model/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `core/sync/build.gradle.kts` | إعداد/بناء/آخر | 23 | — |
| `core/sync/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `docs/architecture/active-architecture.md` | توثيق | 63 | — |
| `docs/architecture/data-flow.md` | توثيق | 53 | — |
| `docs/architecture/gradle-modules.md` | توثيق | 37 | — |
| `docs/architecture/release-readiness.md` | توثيق | 31 | — |
| `docs/refactor/PATCH_MANIFEST.md` | توثيق | 71 | — |
| `docs/refactor/dependency-rules.md` | توثيق | 647 | — |
| `docs/refactor/package-ownership.md` | توثيق | 85 | — |
| `docs/refactor/refactor-changelog.md` | توثيق | 783 | — |
| `docs/refactor/refactor-plan.md` | توثيق | 820 | — |
| `docs/refactor/verification-v01.md` | توثيق | 111 | — |
| `docs/refactor/verification-v02.md` | توثيق | 186 | — |
| `docs/refactor/verification-v03.md` | توثيق | 95 | — |
| `docs/refactor/verification-v04.md` | توثيق | 127 | — |
| `docs/refactor/verification-v05.md` | توثيق | 159 | — |
| `docs/refactor/verification-v06.md` | توثيق | 83 | — |
| `docs/refactor/verification-v07.md` | توثيق | 100 | — |
| `docs/refactor/verification-v08.md` | توثيق | 91 | — |
| `docs/refactor/verification-v09.md` | توثيق | 93 | — |
| `docs/refactor/verification-v10.md` | توثيق | 60 | — |
| `docs/refactor/verification-v11.md` | توثيق | 73 | — |
| `docs/refactor/verification-v12.md` | توثيق | 85 | — |
| `docs/refactor/verification-v13.md` | توثيق | 76 | — |
| `docs/refactor/verification-v14.md` | توثيق | 81 | — |
| `docs/refactor/verification-v15.md` | توثيق | 54 | — |
| `docs/refactor/verification-v16.md` | توثيق | 63 | — |
| `feature/assets/build.gradle.kts` | إعداد/بناء/آخر | 28 | — |
| `feature/assets/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `feature/auth/build.gradle.kts` | إعداد/بناء/آخر | 26 | — |
| `feature/auth/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `feature/debts/build.gradle.kts` | إعداد/بناء/آخر | 28 | — |
| `feature/debts/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `feature/goals/build.gradle.kts` | إعداد/بناء/آخر | 30 | — |
| `feature/goals/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `feature/ledger/build.gradle.kts` | إعداد/بناء/آخر | 26 | — |
| `feature/ledger/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `feature/reports/build.gradle.kts` | إعداد/بناء/آخر | 28 | — |
| `feature/reports/src/main/AndroidManifest.xml` | إعداد/بناء/آخر | 1 | — |
| `gradle/libs.versions.toml` | إعداد/بناء/آخر | 55 | — |
| `gradle/wrapper/gradle-wrapper.jar` | إعداد/بناء/آخر | — | — |
| `gradle/wrapper/gradle-wrapper.properties` | إعداد/بناء/آخر | 7 | — |
| `gradle.properties` | إعداد/بناء/آخر | 4 | — |
| `gradlew` | إعداد/بناء/آخر | 251 | — |
| `gradlew.bat` | إعداد/بناء/آخر | 94 | — |
| `keystore.properties.example` | إعداد/بناء/آخر | 5 | — |
| `local.properties.example` | إعداد/بناء/آخر | 9 | — |
| `settings.gradle.kts` | إعداد/بناء/آخر | 31 | — |
| `tools/verify_module_graph.py` | أداة تحقق | 117 | — |
| `tools/verify_release_closeout.py` | أداة تحقق | 134 | — |

## 8. بصمة المصدر وحدود اعتماد هذا الجرد

```text
SHA-256 (madar-v16-release-closeout-full(1).zip)
0fb00c109277124c5306c270be093a3ee5bf9616efb5e6ff3a56cfafb2cfc344
```

هذا الجرد خاص بهذه الحزمة وحدها. عند تغيير المصدر يُعاد حساب الملفات والبصمات ومراجعة التوزيع؛ لا تنتقل نتيجة PASS من نسخة أخرى تلقائيًا. نقطة البدء العملية التالية هي A07.1، ثم مسار الحساب A01، وفق جدول الترتيب أعلاه.

# Account access coverage — NOT ACCEPTED

This is an open-scope inventory, not proof of isolation. The delivered build source retains the original account access implementation.
Generated DAO guards and the Room 19 ownership design, where present in the patch, are not integrated into this application.

| Scope | Current delivery | Acceptance |
|---|---|---|
| `transactions` | Original production path; no new ownership guard certified | OPEN |
| `debts` | Original production path; no new ownership guard certified | OPEN |
| `income_sources` | Original production path; no new ownership guard certified | OPEN |
| `expense_beneficiaries` | Original production path; no new ownership guard certified | OPEN |
| `balance_transactions` | Original production path; no new ownership guard certified | OPEN |
| `payments` | Original production path; no new ownership guard certified | OPEN |
| `assets` | Original production path; no new ownership guard certified | OPEN |
| `asset_transactions` | Original production path; no new ownership guard certified | OPEN |
| `asset_valuations` | Original production path; no new ownership guard certified | OPEN |
| `currency_asset_lots` | Original production path; no new ownership guard certified | OPEN |
| `currency_asset_sale_allocations` | Original production path; no new ownership guard certified | OPEN |
| `ledger_history_migrations` | Original production path; no new ownership guard certified | OPEN |
| `debt_accounts` | Original production path; no new ownership guard certified | OPEN |
| `debt_transactions` | Original production path; no new ownership guard certified | OPEN |
| `debt_links` | Original production path; no new ownership guard certified | OPEN |
| `debt_schedules` | Original production path; no new ownership guard certified | OPEN |
| `debt_migration_reviews` | Original production path; no new ownership guard certified | OPEN |
| `financial_goals` | Original production path; no new ownership guard certified | OPEN |
| `goal_metrics` | Original production path; no new ownership guard certified | OPEN |
| `goal_conditions` | Original production path; no new ownership guard certified | OPEN |
| `goal_scopes` | Original production path; no new ownership guard certified | OPEN |
| `goal_funding_transactions` | Original production path; no new ownership guard certified | OPEN |
| `goal_cost_estimates` | Original production path; no new ownership guard certified | OPEN |
| `goal_evaluations` | Original production path; no new ownership guard certified | OPEN |
| `goal_activities` | Original production path; no new ownership guard certified | OPEN |
| `financial_change_outbox` | Original production path; no new ownership guard certified | OPEN |
| `sync_outbox` | Original production path; no new ownership guard certified | OPEN |
| `account_store_meta` | Proposed security table, NOT integrated | OPEN |
| `account_settings` | Proposed security table, NOT integrated | OPEN |
| `account_logout_journal` | Proposed security table, NOT integrated | OPEN |

## Account settings

- `USER_NAME`: migration to the owned Room settings store is OPEN.
- `WORK_TYPE`: migration to the owned Room settings store is OPEN.
- `BUDGET_LIMIT`: migration to the owned Room settings store is OPEN.
- `INCOME_SOURCES`: migration to the owned Room settings store is OPEN.
- `SETUP_DONE`: migration to the owned Room settings store is OPEN.
- `EXPENSE_GROUPS`: migration to the owned Room settings store is OPEN.
- `LAST_SYNC`: migration to the owned Room settings store is OPEN.
- `SYNC_CHECKPOINTS_V1`: migration to the owned Room settings store is OPEN.
- `SETTINGS_UPDATED_AT`: migration to the owned Room settings store is OPEN.
- `INCOME_SOURCES_ROOM_MIGRATED_V1`: migration to the owned Room settings store is OPEN.
- `BALANCE_ACTIVATED`: migration to the owned Room settings store is OPEN.
- `BALANCE_ACTIVATED_AT`: migration to the owned Room settings store is OPEN.
- `LOCAL_CURRENCY_CODE`: migration to the owned Room settings store is OPEN.
- `ENCRYPTION_MIGRATED_V2`: migration to the owned Room settings store is OPEN.

## Entry point inventory — outstanding

All direct DAO callers, repository entry points, Room flows, ViewModels, background goal processing, backup codecs, restore/import, sync participants, checkpoint writes, and worker callbacks still require a reviewed coverage matrix with exact methods and executed tests.

Do not infer coverage from the number of generated wrappers in an unintegrated patch.

package com.shift.app.feature.auth.domain

import kotlinx.coroutines.flow.Flow

interface AuthGateway {
    suspend fun signIn(email: String, password: String)
    suspend fun signUp(email: String, password: String)
    suspend fun requestPasswordReset(email: String)
    suspend fun updatePassword(newPassword: String)
    suspend fun verifyRecoveryOtp(email: String, code: String)
    suspend fun signOut()
    suspend fun clearLocalAuthSession()
}

interface SessionReader {
    val rememberedEmail: Flow<String>
    fun isLoggedIn(): Boolean
}

interface SessionWriter {
    suspend fun rememberEmail(email: String)
    suspend fun initializeRegisteredAccount(name: String, jobTitle: String)
    suspend fun clearAccountScopedState()
}

interface SessionBootstrapper {
    suspend fun onLogin(email: String, rememberMe: Boolean)
    suspend fun onRegistration(name: String, jobTitle: String)
}

interface SessionCleanup {
    suspend fun logout(discardUnsyncedChanges: Boolean = false): LogoutResult
}

sealed interface LogoutResult {
    data object Completed : LogoutResult
    data class Blocked(
        val failedSteps: List<String>,
        val authenticationRequired: Boolean = false,
    ) : LogoutResult
    data class Failed(val cause: Throwable) : LogoutResult
}

interface SessionSyncGateway {
    suspend fun synchronizePendingChanges(): SessionSyncResult
    suspend fun <T> withExclusiveSession(block: suspend () -> T): T
}

sealed interface SessionSyncResult {
    data object Success : SessionSyncResult
    data class PartialFailure(val failedSteps: List<String>) : SessionSyncResult
    data object AuthenticationRequired : SessionSyncResult
}

fun interface AccountLocalDataCleaner {
    suspend fun clearAccountData()
}

fun interface SessionWorkController {
    suspend fun cancelAndAwaitSessionWork()
}

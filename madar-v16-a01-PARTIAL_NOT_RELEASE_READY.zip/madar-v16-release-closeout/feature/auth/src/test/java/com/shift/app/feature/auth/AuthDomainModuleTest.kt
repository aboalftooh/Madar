package com.shift.app.feature.auth

import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionSyncResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthDomainModuleTest {
    @Test
    fun `logout and sync results preserve failure details`() {
        val logout = LogoutResult.Blocked(listOf("outbox"), authenticationRequired = true)
        val sync = SessionSyncResult.PartialFailure(listOf("assets", "debts"))

        assertTrue(logout.authenticationRequired)
        assertEquals(listOf("outbox"), logout.failedSteps)
        assertEquals(listOf("assets", "debts"), sync.failedSteps)
    }
}

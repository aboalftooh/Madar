package com.shift.app.domain.goals.measurement

import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.MetricType
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

class AssetPurchaseMeasurementProvider(
    private val realBalanceDecimal: suspend () -> String = { "0.00" },
    private val netWorthDecimal: suspend () -> String = { "0.00" },
) : GoalMeasurementProvider {
    override suspend fun measure(
        metric: GoalMetric,
        aggregate: GoalAggregate,
        asOf: Instant,
    ): GoalMeasurement {
        val settings = runCatching { GoalConfigJson.decode(aggregate.goal.configJson).settings }
            .getOrElse { return unavailable(metric, "invalid-purchase-config") }
        val financedAmount = runCatching { settings["financed"]?.let(::BigDecimal) ?: BigDecimal.ZERO }
            .getOrElse { return unavailable(metric, "invalid-purchase-financing") }
        val cashRequired = runCatching {
            GoalFundingCalculator.cashRequiredForPurchase(
                purchasePrice = BigDecimal(aggregate.goal.targetDecimal),
                financedAmount = financedAmount,
            )
        }.getOrElse { return unavailable(metric, "invalid-purchase-financing") }
        val value = when (metric.metricType) {
            MetricType.ALLOCATED_BALANCE -> money(GoalFundingCalculator.allocatedForGoal(aggregate.fundingTransactions))
            MetricType.HOUSE_TO_NET_WORTH_RATIO -> {
                val netWorth = BigDecimal(netWorthDecimal())
                if (netWorth <= BigDecimal.ZERO) {
                    return unavailable(metric, "net-worth-not-positive")
                }
                money(BigDecimal(aggregate.goal.targetDecimal).multiply(BigDecimal("100")).divide(netWorth, 2, RoundingMode.HALF_UP))
            }
            MetricType.POST_PURCHASE_AVAILABLE_BALANCE -> {
                money(
                    GoalFundingCalculator.postPurchaseAvailableBalance(
                        realBalance = BigDecimal(realBalanceDecimal()),
                        cashRequired = cashRequired,
                    ),
                )
            }
            MetricType.INSTALLMENT_AMOUNT -> settings["installment"]
                ?.let { runCatching { money(BigDecimal(it)) }.getOrNull() }
                ?: return unavailable(metric, "missing-or-invalid-installment")
            else -> return unavailable(metric, "unsupported-asset-purchase-metric")
        }
        return GoalMeasurement(
            metricId = metric.id,
            metricType = metric.metricType,
            measuredDecimal = value,
            sourceFingerprint = "asset-purchase:${metric.metricType}:$value:${asOf.toEpochMilli()}",
        )
    }

    private fun unavailable(metric: GoalMetric, reason: String) = GoalMeasurement(
        metricId = metric.id,
        metricType = metric.metricType,
        measuredDecimal = null,
        sourceFingerprint = "asset-purchase:${metric.metricType}:$reason",
        available = false,
        unavailableReason = reason,
    )

    private fun money(value: BigDecimal): String = value.setScale(2, RoundingMode.HALF_UP).toPlainString()
}

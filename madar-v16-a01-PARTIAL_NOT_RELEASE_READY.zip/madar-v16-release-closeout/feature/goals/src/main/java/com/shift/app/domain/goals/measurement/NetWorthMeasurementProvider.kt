package com.shift.app.domain.goals.measurement

import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalAssetRow
import com.shift.app.feature.goals.domain.model.GoalAssetValuationRow
import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.feature.goals.domain.model.GoalMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

class NetWorthMeasurementProvider(
    private val balanceTransactions: suspend () -> List<GoalBalanceRow> = { emptyList() },
    private val assets: suspend () -> List<GoalAssetRow> = { emptyList() },
    private val valuations: suspend () -> List<GoalAssetValuationRow> = { emptyList() },
    private val debtAccounts: suspend () -> List<GoalDebtAccountRow> = { emptyList() },
    private val debtTransactions: suspend () -> List<GoalDebtTransactionRow> = { emptyList() },
) : GoalMeasurementProvider {
    override suspend fun measure(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant): GoalMeasurement =
        measureRows(metric, asOf, balanceTransactions(), assets(), valuations(), debtAccounts(), debtTransactions())

    companion object {
        fun measureRows(
            metric: GoalMetric,
            asOf: Instant,
            balanceTransactions: List<GoalBalanceRow>,
            assets: List<GoalAssetRow>,
            valuations: List<GoalAssetValuationRow>,
            debtAccounts: List<GoalDebtAccountRow>,
            debtTransactions: List<GoalDebtTransactionRow>,
        ): GoalMeasurement {
            require(metric.metricType == MetricType.NET_WORTH)
            val cutoffDate = asOf.atZone(ZoneOffset.UTC).toLocalDate()
            val cutoffMillis = asOf.toEpochMilli()
            val realBalance = balanceTransactions.filter { it.deletedAt == null && it.date.onOrBefore(cutoffDate) }.fold(BigDecimal.ZERO) { acc, tx ->
                val amount = BigDecimal(tx.amountDecimal)
                if (tx.direction == BalanceDirection.Inflow.dbValue) acc + amount else acc - amount
            }
            val latestValuation = valuations.filter { it.deletedAt == null && it.date.onOrBefore(cutoffDate) }
                .groupBy { it.assetId }.mapValues { (_, rows) -> rows.maxWith(compareBy<GoalAssetValuationRow> { it.date }.thenBy { it.createdAt }.thenBy { it.id }) }
            var estimated = false
            val assetValue = assets.filter { it.deletedAt == null && it.createdAt <= cutoffMillis && it.status == AssetStatus.Active.dbValue }
                .fold(BigDecimal.ZERO) { acc, asset ->
                    val valuation = latestValuation[asset.id]?.valueDecimal
                    if (valuation == null) estimated = true
                    acc + BigDecimal(valuation ?: asset.acquisitionAmountDecimal)
                }
            val remainingByAccount = debtTransactions.filter { it.deletedAt == null && it.occurredAt <= cutoffMillis }
                .groupBy { it.accountId }.mapValues { (_, rows) -> rows.fold(BigDecimal.ZERO) { total, tx ->
                    total + BigDecimal(tx.amountDecimal).multiply(BigDecimal(DebtTransactionType.fromDb(tx.type).remainingSign))
                } }
            val confirmedReceivables = debtAccounts.filter { it.deletedAt == null && it.createdAt <= cutoffMillis && it.confirmed && it.direction == DebtDirection.Receivable.dbValue }
                .fold(BigDecimal.ZERO) { acc, account -> acc + (remainingByAccount[account.id] ?: BigDecimal.ZERO) }
            val confirmedPayables = debtAccounts.filter { it.deletedAt == null && it.createdAt <= cutoffMillis && it.confirmed && it.direction == DebtDirection.Payable.dbValue }
                .fold(BigDecimal.ZERO) { acc, account -> acc + (remainingByAccount[account.id] ?: BigDecimal.ZERO) }
            val netWorth = realBalance + assetValue + confirmedReceivables - confirmedPayables
            return GoalMeasurement(metric.id, MetricType.NET_WORTH, netWorth.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                "net-worth:asOf=${asOf.toEpochMilli()}:balance=$realBalance:assets=$assetValue:recv=$confirmedReceivables:pay=$confirmedPayables:estimated=$estimated", estimated = estimated)
        }

        private fun String.onOrBefore(cutoff: LocalDate): Boolean = runCatching { LocalDate.parse(this) }.getOrNull()?.let { !it.isAfter(cutoff) } == true
    }
}

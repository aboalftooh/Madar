package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalScope
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.util.UUID

data class EmergencyFundTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "صندوق الطوارئ",
    val coverageMonths: Int = 6,
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val essentialPurposeKeys: List<String> = emptyList(),
    val now: Long = System.currentTimeMillis(),
)

object EmergencyFundGoalTemplate {
    fun build(request: EmergencyFundTemplateRequest): GoalAggregate {
        require(request.coverageMonths > 0)
        val essentialKeys = request.essentialPurposeKeys.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(essentialKeys.isNotEmpty()) { "Emergency fund requires explicit essential purpose scopes" }
        val config = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "emergency_fund")))
        val target = request.coverageMonths.toBigDecimal().setScale(2).toPlainString()
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = GoalType.EMERGENCY_FUND,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = target,
            baselineDecimal = null,
            targetPercentDecimal = null,
            confirmationPeriods = 1,
            costThreshold = null,
            configJson = config,
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metric = GoalMetric(
            id = "${request.id}:metric:coverage",
            goalId = request.id,
            metricType = MetricType.EMERGENCY_COVERAGE,
            windowType = "ESSENTIAL_EXPENSE_AVERAGE",
            windowSize = 3,
            baselineDecimal = null,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val condition = GoalCondition(
            id = "${request.id}:condition:coverage",
            goalId = request.id,
            metricId = metric.id,
            kind = ConditionKind.TARGET,
            operator = ">=",
            valueDecimal = target,
            required = true,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val scopes = essentialKeys.map { purposeKey ->
            GoalScope(
                id = "${request.id}:scope:essential:$purposeKey",
                goalId = request.id,
                dimension = ScopeDimension.ESSENTIAL_PURPOSE,
                referenceId = purposeKey,
                mode = "INCLUDE",
                reason = "غرض أساسي مشمول في حساب صندوق الطوارئ",
                effectiveFrom = request.startDate,
                effectiveTo = null,
                createdAt = request.now,
                updatedAt = request.now,
                deletedAt = null,
                syncState = "PENDING",
            )
        }
        return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition), scopes = scopes)
    }
}

package com.shift.app.feature.goals.domain.repository

import com.shift.app.domain.goals.funding.AvailableSpendingImpact
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.usecase.AssetGoalCompletionRequest
import com.shift.app.domain.goals.usecase.CompleteCostGoalRequest
import com.shift.app.domain.goals.usecase.GoalDebtPaymentRequest
import com.shift.app.feature.goals.domain.model.ActiveGoalAllocation
import com.shift.app.feature.goals.domain.model.FinancialChangeEvent
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalActivity
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalCostEstimate
import com.shift.app.feature.goals.domain.model.GoalEvaluation
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.feature.goals.domain.model.GoalScope
import kotlinx.coroutines.flow.Flow

interface GoalInvalidationGateway {
    suspend fun getLiveAggregates(): List<GoalAggregate>
    suspend fun pendingChanges(limit: Int): List<FinancialChangeEvent>
    suspend fun saveEvaluation(evaluation: GoalEvaluation, activity: GoalActivity, expectedRevision: Long): Boolean
    suspend fun markChangeProcessed(eventId: String, processedAt: Long)
    suspend fun markChangeFailed(event: FinancialChangeEvent, error: String)
}

interface GoalGateway : GoalInvalidationGateway {
    fun observeActiveGoals(): Flow<List<FinancialGoal>>
    suspend fun getAggregate(goalId: String): GoalAggregate?
    suspend fun createAggregate(aggregate: GoalAggregate, operationId: String)
    suspend fun updateAggregate(aggregate: GoalAggregate, expectedRevision: Long, now: Long, operationId: String): GoalAggregate
    suspend fun softDelete(goalId: String, expectedRevision: Long, now: Long, operationId: String)
    suspend fun transition(goalId: String, expectedRevision: Long, to: GoalLifecycleStatus, operationId: String, now: Long, activityType: String): FinancialGoal

    suspend fun recordFundingTransaction(
        goalId: String,
        operationId: String,
        kind: FundingKind,
        amountDecimal: String,
        currencyCode: String,
        note: String,
        now: Long,
        relatedFundingTransactionId: String? = null,
        balanceTransactionId: String? = null,
    ): GoalFundingTransaction

    suspend fun recordCostEstimate(
        goalId: String,
        operationId: String,
        expectedDecimal: String,
        safeDecimal: String,
        currencyCode: String,
        source: String,
        note: String,
        now: Long,
        minDecimal: String? = null,
    ): GoalCostEstimate

    suspend fun recordNewDebtPayoffDecision(debtAccountId: String, include: Boolean, operationId: String, now: Long): List<GoalScope>
    suspend fun spendingImpact(expenseAmountDecimal: String): AvailableSpendingImpact
    suspend fun activeAllocationChoices(): List<ActiveGoalAllocation>
    suspend fun releaseAllocationsForOverspend(selectedFundingTransactionIds: List<String>, shortfallDecimal: String, operationId: String, balanceTransactionId: String?, now: Long): List<GoalFundingTransaction>
}

interface GoalCompletionPort {
    suspend fun completeAssetPurchase(request: AssetGoalCompletionRequest)
    suspend fun completeCostGoal(request: CompleteCostGoalRequest)
    suspend fun recordDebtPayment(request: GoalDebtPaymentRequest)
}

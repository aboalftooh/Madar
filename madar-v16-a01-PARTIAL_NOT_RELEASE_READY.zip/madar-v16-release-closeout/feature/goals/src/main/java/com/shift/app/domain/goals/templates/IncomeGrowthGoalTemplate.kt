package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.util.UUID

data class IncomeGrowthTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val targetDecimal: String,
    val baselineDecimal: String? = null,
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val windowMonths: Int = 3,
    val confirmationPeriods: Int = 3,
    val now: Long = System.currentTimeMillis(),
)

object IncomeGrowthGoalTemplate {
    fun build(request: IncomeGrowthTemplateRequest): GoalAggregate {
        require(request.windowMonths in setOf(1, 3, 6))
        require(request.confirmationPeriods in setOf(1, 2, 3))
        val configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "income_growth")))
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = GoalType.INCOME_GROWTH,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = request.targetDecimal,
            baselineDecimal = request.baselineDecimal,
            targetPercentDecimal = null,
            confirmationPeriods = request.confirmationPeriods,
            costThreshold = null,
            configJson = configJson,
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metric = GoalMetric(
            id = "${request.id}:metric:income",
            goalId = request.id,
            metricType = MetricType.INCOME,
            windowType = "CLOSED_MONTH_AVERAGE",
            windowSize = request.windowMonths,
            baselineDecimal = request.baselineDecimal,
            configJson = configJson,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val condition = GoalCondition(
            id = "${request.id}:condition:income-target",
            goalId = request.id,
            metricId = metric.id,
            kind = ConditionKind.CONFIRMATION_STREAK,
            operator = ">=",
            valueDecimal = request.targetDecimal,
            required = true,
            configJson = configJson,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition))
    }
}

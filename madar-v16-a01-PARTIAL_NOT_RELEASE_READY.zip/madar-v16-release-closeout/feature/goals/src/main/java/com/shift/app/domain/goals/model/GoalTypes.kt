package com.shift.app.domain.goals.model

enum class GoalType {
    HOUSE_PURCHASE,
    CAR_PURCHASE,
    PROJECT_FUNDING,
    TRIP_FUNDING,
    INCOME_GROWTH,
    EXPENSE_REDUCTION,
    EXPENSE_CEILING,
    EMERGENCY_FUND,
    DEBT_PAYOFF,
    NET_WORTH_GROWTH,
}

enum class MetricType {
    ALLOCATED_BALANCE,
    INCOME,
    EXPENSE,
    EMERGENCY_COVERAGE,
    DEBT_BALANCE,
    NET_WORTH,
    HOUSE_TO_NET_WORTH_RATIO,
    POST_PURCHASE_AVAILABLE_BALANCE,
    INSTALLMENT_AMOUNT,
}

enum class ConditionKind {
    TARGET,
    FUNDING,
    MAX_RATIO,
    MIN_VALUE,
    MAX_VALUE,
    CONFIRMATION_STREAK,
    EXTERNAL_CONFIRMATION,
}

enum class FundingKind {
    ALLOCATE,
    RELEASE,
    CONSUME,
    REVERSAL,
}

enum class CostThreshold {
    EXPECTED,
    SAFE,
}

enum class ScopeDimension {
    EXPENSE_TRANSACTION,
    EXPENSE_PURPOSE,
    DEBT_ACCOUNT,
    ESSENTIAL_PURPOSE,
}

enum class GoalLifecycleStatus {
    DRAFT,
    ACTIVE,
    PAUSED,
    READY,
    COMPLETED,
    CANCELLED,
    ARCHIVED,
}

enum class GoalHealthStatus {
    ON_TRACK,
    NEEDS_ATTENTION,
    BEHIND,
    UNAVAILABLE,
}

package com.shift.app.domain.goals.measurement

import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalExpenseRow
import com.shift.app.feature.goals.domain.model.GoalMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

class EmergencyFundMeasurementProvider(
    private val payments: suspend () -> List<GoalExpenseRow> = { emptyList() },
) : GoalMeasurementProvider {
    override suspend fun measure(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant): GoalMeasurement = measurePayments(metric, aggregate, asOf, payments())

    companion object {
        fun measurePayments(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant, payments: List<GoalExpenseRow>): GoalMeasurement {
            require(metric.metricType == MetricType.EMERGENCY_COVERAGE)
            val currentMonth = YearMonth.from(asOf.atZone(ZoneId.of(aggregate.goal.timezoneId)))
            val months = (1..3).map { currentMonth.minusMonths(it.toLong()) }.reversed()
            val essentialKeys = aggregate.scopes.filter { it.deletedAt == null && it.dimension == ScopeDimension.ESSENTIAL_PURPOSE }.map { it.referenceId.lowercase() }.toSet()
            if (essentialKeys.isEmpty()) return unavailable(metric, "missing-essential-purpose-scopes")
            val byMonth = payments.filter { it.deletedAt == null && it.kind in setOf("ordinary_expense", "asset_maintenance") }
                .filter { it.purposeKey.lowercase() in essentialKeys || it.purpose.lowercase() in essentialKeys }
                .map { YearMonth.parse(it.date.substring(0, 7)) to BigDecimal(it.amountDecimal) }
                .groupBy({ it.first }, { it.second }).mapValues { (_, values) -> values.fold(BigDecimal.ZERO, BigDecimal::add) }
            if (months.any { it !in byMonth }) return unavailable(metric, "missing-essential-expense-history")
            val average = months.fold(BigDecimal.ZERO) { acc, month -> acc + byMonth.getValue(month) }.divide(BigDecimal("3"), 2, RoundingMode.HALF_UP)
            if (average <= BigDecimal.ZERO) return unavailable(metric, "zero-essential-average")
            val allocated = GoalFundingCalculator.allocatedForGoal(aggregate.fundingTransactions)
            val coverage = allocated.divide(average, 2, RoundingMode.HALF_UP)
            return GoalMeasurement(metric.id, MetricType.EMERGENCY_COVERAGE, coverage.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                "emergency:${months.joinToString(",")}:avg=$average:allocated=$allocated")
        }

        private fun unavailable(metric: GoalMetric, reason: String) = GoalMeasurement(metric.id, metric.metricType, null, "emergency:$reason", available = false, unavailableReason = reason)
    }
}

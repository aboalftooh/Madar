package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalCostEstimate
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.util.UUID

data class CostFundingTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: GoalType,
    val expectedDecimal: String,
    val safeDecimal: String,
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val threshold: CostThreshold? = null,
    val now: Long = System.currentTimeMillis(),
)

object CostFundingGoalTemplate {
    fun build(request: CostFundingTemplateRequest): GoalAggregate {
        require(request.type == GoalType.PROJECT_FUNDING || request.type == GoalType.TRIP_FUNDING)
        val threshold = request.threshold ?: if (request.type == GoalType.TRIP_FUNDING) CostThreshold.SAFE else CostThreshold.EXPECTED
        val target = if (threshold == CostThreshold.SAFE) request.safeDecimal else request.expectedDecimal
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = request.type,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = target,
            baselineDecimal = null,
            targetPercentDecimal = null,
            confirmationPeriods = 1,
            costThreshold = threshold,
            configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "cost_funding"))),
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metric = GoalMetric(
            id = "${request.id}:metric:allocated",
            goalId = request.id,
            metricType = MetricType.ALLOCATED_BALANCE,
            windowType = "INSTANT",
            windowSize = 1,
            baselineDecimal = null,
            configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "cost_funding"))),
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val condition = GoalCondition(
            id = "${request.id}:condition:funding",
            goalId = request.id,
            metricId = metric.id,
            kind = ConditionKind.FUNDING,
            operator = ">=",
            valueDecimal = target,
            required = true,
            configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "cost_funding"))),
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val estimate = GoalCostEstimate(
            id = UUID.randomUUID().toString(),
            goalId = request.id,
            operationId = "initial-cost:${request.id}",
            minDecimal = null,
            expectedDecimal = request.expectedDecimal,
            safeDecimal = request.safeDecimal,
            currencyCode = request.currencyCode,
            source = "initial",
            note = "",
            effectiveAt = request.now,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition), costEstimates = listOf(estimate))
    }
}

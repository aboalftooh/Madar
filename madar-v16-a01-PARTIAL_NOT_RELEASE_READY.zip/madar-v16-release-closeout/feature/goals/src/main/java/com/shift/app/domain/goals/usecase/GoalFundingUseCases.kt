package com.shift.app.domain.goals.usecase

import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.feature.goals.domain.repository.GoalGateway
import java.util.UUID
import javax.inject.Inject

class GoalFundingUseCases @Inject constructor(private val gateway: GoalGateway) {
    suspend fun allocate(goalId: String, amountDecimal: String, currencyCode: String, note: String, operationId: String = UUID.randomUUID().toString(), now: Long = System.currentTimeMillis()): GoalFundingTransaction =
        gateway.recordFundingTransaction(goalId, operationId, FundingKind.ALLOCATE, amountDecimal, currencyCode, note, now)

    suspend fun release(goalId: String, amountDecimal: String, currencyCode: String, reason: String, operationId: String = UUID.randomUUID().toString(), now: Long = System.currentTimeMillis()): GoalFundingTransaction =
        gateway.recordFundingTransaction(goalId, operationId, FundingKind.RELEASE, amountDecimal, currencyCode, reason, now)

    suspend fun consume(goalId: String, amountDecimal: String, currencyCode: String, note: String, balanceTransactionId: String, operationId: String = UUID.randomUUID().toString(), now: Long = System.currentTimeMillis()): GoalFundingTransaction =
        gateway.recordFundingTransaction(goalId, operationId, FundingKind.CONSUME, amountDecimal, currencyCode, note, now, balanceTransactionId = balanceTransactionId)

    suspend fun reverse(goalId: String, original: GoalFundingTransaction, reason: String, operationId: String = UUID.randomUUID().toString(), now: Long = System.currentTimeMillis()): GoalFundingTransaction =
        gateway.recordFundingTransaction(goalId, operationId, FundingKind.REVERSAL, original.amountDecimal, original.currencyCode, reason, now, relatedFundingTransactionId = original.id)
}

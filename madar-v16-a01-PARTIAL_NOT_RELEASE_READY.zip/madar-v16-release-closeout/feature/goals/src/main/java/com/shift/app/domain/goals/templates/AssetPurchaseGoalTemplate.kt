package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

enum class CarPurchaseMode {
    CASH,
    FINANCED,
}

data class AssetPurchaseTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: GoalType,
    val targetDecimal: String,
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val carMode: CarPurchaseMode = CarPurchaseMode.CASH,
    val financedAmountDecimal: String? = null,
    val installmentAmountDecimal: String? = null,
    val maxInstallmentDecimal: String? = null,
    val minimumPostPurchaseBalanceDecimal: String = "0.00",
    val maxHouseRatioPercentDecimal: String = "30.00",
    val now: Long = System.currentTimeMillis(),
)

object AssetPurchaseGoalTemplate {
    fun build(request: AssetPurchaseTemplateRequest): GoalAggregate {
        require(request.type == GoalType.HOUSE_PURCHASE || request.type == GoalType.CAR_PURCHASE)
        val target = BigDecimal(request.targetDecimal)
        require(target > BigDecimal.ZERO) { "Asset purchase target must be positive" }
        val financedAmount = if (
            request.type == GoalType.CAR_PURCHASE && request.carMode == CarPurchaseMode.FINANCED
        ) {
            BigDecimal(requireNotNull(request.financedAmountDecimal) { "Financed car requires financed amount" })
                .also {
                    require(it > BigDecimal.ZERO) { "Financed amount must be positive" }
                    require(it <= target) { "Financed amount cannot exceed asset price" }
                }
        } else {
            BigDecimal.ZERO
        }
        val installmentAmount = if (
            request.type == GoalType.CAR_PURCHASE && request.carMode == CarPurchaseMode.FINANCED
        ) {
            requireNotNull(request.installmentAmountDecimal) { "Financed car requires installment amount" }
                .also { require(BigDecimal(it) > BigDecimal.ZERO) { "Installment amount must be positive" } }
        } else {
            null
        }
        val cashRequired = money(GoalFundingCalculator.cashRequiredForPurchase(target, financedAmount))
        val settings = mutableMapOf(
            "template" to "asset_purchase",
            "carMode" to request.carMode.name,
        )
        if (request.type == GoalType.CAR_PURCHASE && request.carMode == CarPurchaseMode.FINANCED) {
            settings["financed"] = money(financedAmount)
            settings["installment"] = money(BigDecimal(requireNotNull(installmentAmount)))
        }
        val config = GoalConfigJson.encode(
            VersionedGoalConfig(settings = settings),
        )
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = request.type,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = request.targetDecimal,
            baselineDecimal = null,
            targetPercentDecimal = if (request.type == GoalType.HOUSE_PURCHASE) request.maxHouseRatioPercentDecimal else null,
            confirmationPeriods = 1,
            costThreshold = CostThreshold.EXPECTED,
            configJson = config,
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metrics = mutableListOf(
            metric(request.id, MetricType.ALLOCATED_BALANCE, 0, request.now),
        )
        val conditions = mutableListOf(
            condition(request.id, "${request.id}:metric:allocated", ConditionKind.FUNDING, ">=", cashRequired, 0, request.now),
        )
        when (request.type) {
            GoalType.HOUSE_PURCHASE -> {
                metrics += metric(request.id, MetricType.HOUSE_TO_NET_WORTH_RATIO, 1, request.now)
                conditions += condition(
                    request.id,
                    "${request.id}:metric:house-ratio",
                    ConditionKind.MAX_RATIO,
                    "<=",
                    request.maxHouseRatioPercentDecimal,
                    1,
                    request.now,
                )
            }
            GoalType.CAR_PURCHASE -> {
                metrics += metric(request.id, MetricType.POST_PURCHASE_AVAILABLE_BALANCE, 1, request.now)
                conditions += condition(
                    request.id,
                    "${request.id}:metric:post-balance",
                    ConditionKind.MIN_VALUE,
                    ">=",
                    request.minimumPostPurchaseBalanceDecimal,
                    1,
                    request.now,
                )
                if (request.carMode == CarPurchaseMode.FINANCED) {
                    val maxInstallment = requireNotNull(request.maxInstallmentDecimal) {
                        "Financed car requires maximum installment"
                    }
                    require(BigDecimal(maxInstallment) > BigDecimal.ZERO) {
                        "Maximum installment must be positive"
                    }
                    metrics += metric(request.id, MetricType.INSTALLMENT_AMOUNT, 2, request.now)
                    conditions += condition(
                        request.id,
                        "${request.id}:metric:installment",
                        ConditionKind.MAX_VALUE,
                        "<=",
                        maxInstallment,
                        2,
                        request.now,
                    )
                }
            }
            else -> error("Unsupported asset purchase type")
        }
        return GoalAggregate(goal = goal, metrics = metrics, conditions = conditions)
    }

    private fun money(value: BigDecimal): String =
        value.setScale(2, RoundingMode.UNNECESSARY).toPlainString()

    private fun metric(goalId: String, type: MetricType, ordinal: Int, now: Long) = GoalMetric(
        id = when (type) {
            MetricType.ALLOCATED_BALANCE -> "$goalId:metric:allocated"
            MetricType.HOUSE_TO_NET_WORTH_RATIO -> "$goalId:metric:house-ratio"
            MetricType.POST_PURCHASE_AVAILABLE_BALANCE -> "$goalId:metric:post-balance"
            MetricType.INSTALLMENT_AMOUNT -> "$goalId:metric:installment"
            else -> "$goalId:metric:${type.name.lowercase()}"
        },
        goalId = goalId,
        metricType = type,
        windowType = "INSTANT",
        windowSize = 1,
        baselineDecimal = null,
        configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "asset_purchase"))),
        ordinal = ordinal,
        createdAt = now,
        updatedAt = now,
        deletedAt = null,
        syncState = "PENDING",
    )

    private fun condition(
        goalId: String,
        metricId: String,
        kind: ConditionKind,
        operator: String,
        valueDecimal: String,
        ordinal: Int,
        now: Long,
    ) = GoalCondition(
        id = "$goalId:condition:${kind.name.lowercase()}",
        goalId = goalId,
        metricId = metricId,
        kind = kind,
        operator = operator,
        valueDecimal = valueDecimal,
        required = true,
        configJson = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "asset_purchase"))),
        ordinal = ordinal,
        createdAt = now,
        updatedAt = now,
        deletedAt = null,
        syncState = "PENDING",
    )
}

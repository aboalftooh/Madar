package com.shift.app.domain.goals.funding

import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.goals.model.FundingKind
import java.math.BigDecimal

data class GoalFundingTotals(
    val realBalanceDecimal: String,
    val allocatedDecimal: String,
    val availableDecimal: String,
)

data class AvailableSpendingImpact(
    val expenseDecimal: String,
    val realBalanceBeforeDecimal: String,
    val allocatedBeforeDecimal: String,
    val availableBeforeDecimal: String,
    val shortfallDecimal: String,
    val availableAfterWithoutReleaseDecimal: String,
) {
    val requiresAllocationDecision: Boolean =
        DecimalText.toBigDecimal(shortfallDecimal).signum() > 0
}

object GoalFundingCalculator {
    fun cashRequiredForPurchase(
        purchasePrice: BigDecimal,
        financedAmount: BigDecimal,
    ): BigDecimal {
        require(purchasePrice >= BigDecimal.ZERO) { "Purchase price cannot be negative" }
        require(financedAmount >= BigDecimal.ZERO) { "Financed amount cannot be negative" }
        require(financedAmount <= purchasePrice) { "Financed amount cannot exceed purchase price" }
        return purchasePrice - financedAmount
    }

    fun postPurchaseAvailableBalance(
        realBalance: BigDecimal,
        cashRequired: BigDecimal,
    ): BigDecimal {
        require(cashRequired >= BigDecimal.ZERO) { "Cash required cannot be negative" }
        return realBalance - cashRequired
    }

    fun allocatedForGoal(items: List<GoalFundingTransaction>): BigDecimal =
        allocated(items)

    fun totals(
        balanceTransactions: List<GoalBalanceRow>,
        fundingTransactions: List<GoalFundingTransaction>,
    ): GoalFundingTotals {
        val real = currentBalance(balanceTransactions)
        val allocated = allocated(fundingTransactions)
        return GoalFundingTotals(
            realBalanceDecimal = money(real),
            allocatedDecimal = money(allocated),
            availableDecimal = money(real - allocated),
        )
    }

    fun wouldOverAllocate(
        balanceTransactions: List<GoalBalanceRow>,
        fundingTransactions: List<GoalFundingTransaction>,
        additionalAmountDecimal: String,
    ): Boolean {
        val real = currentBalance(balanceTransactions)
        val additional = DecimalText.toBigDecimal(
            DecimalText.canonicalPositive(additionalAmountDecimal, DecimalTextScale.Money),
        )
        return allocated(fundingTransactions) + additional > real
    }

    fun spendingImpact(
        balanceTransactions: List<GoalBalanceRow>,
        fundingTransactions: List<GoalFundingTransaction>,
        expenseAmountDecimal: String,
    ): AvailableSpendingImpact {
        val real = currentBalance(balanceTransactions)
        val allocated = allocated(fundingTransactions)
        val expense = DecimalText.toBigDecimal(
            DecimalText.canonicalPositive(expenseAmountDecimal, DecimalTextScale.Money),
        )
        val available = real - allocated
        val after = available - expense
        val shortfall = if (after.signum() < 0) after.abs() else BigDecimal.ZERO
        return AvailableSpendingImpact(
            expenseDecimal = money(expense),
            realBalanceBeforeDecimal = money(real),
            allocatedBeforeDecimal = money(allocated),
            availableBeforeDecimal = money(available),
            shortfallDecimal = money(shortfall),
            availableAfterWithoutReleaseDecimal = money(after),
        )
    }

    fun releaseCoversShortfall(
        selectedFundingTransactions: List<GoalFundingTransaction>,
        shortfallDecimal: String,
    ): Boolean {
        val shortfall = DecimalText.toBigDecimal(
            DecimalText.canonicalNonNegative(shortfallDecimal, DecimalTextScale.Money),
        )
        return allocated(selectedFundingTransactions) >= shortfall
    }

    fun remainingForAllocation(
        allocationId: String,
        items: List<GoalFundingTransaction>,
    ): BigDecimal {
        val allocation = items.firstOrNull {
            it.id == allocationId && it.deletedAt == null && it.kind == FundingKind.ALLOCATE
        } ?: return BigDecimal.ZERO
        val original = DecimalText.toBigDecimal(allocation.amountDecimal)
        val consumed = items.filter {
            it.deletedAt == null &&
                it.relatedFundingTransactionId == allocationId &&
                it.kind in setOf(FundingKind.RELEASE, FundingKind.CONSUME)
        }.fold(BigDecimal.ZERO) { total, item -> total + DecimalText.toBigDecimal(item.amountDecimal) }
        return (original - consumed).max(BigDecimal.ZERO)
    }

    private fun allocated(items: List<GoalFundingTransaction>): BigDecimal {
        val active = items.filter { it.deletedAt == null }
        val byId = active.associateBy { it.id }
        return active.fold(BigDecimal.ZERO) { total, item ->
            val amount = DecimalText.toBigDecimal(item.amountDecimal)
            when (item.kind) {
                FundingKind.ALLOCATE -> total + amount
                FundingKind.RELEASE, FundingKind.CONSUME -> total - amount
                FundingKind.REVERSAL -> {
                    val related = item.relatedFundingTransactionId?.let(byId::get)
                    when (related?.kind) {
                        FundingKind.ALLOCATE -> total - amount
                        FundingKind.RELEASE, FundingKind.CONSUME -> total + amount
                        FundingKind.REVERSAL, null -> total - amount
                    }
                }
            }
        }
    }

    private fun currentBalance(items: List<GoalBalanceRow>): BigDecimal =
        items.asSequence().filter { it.deletedAt == null }.fold(BigDecimal.ZERO) { total, item ->
            val amount = DecimalText.toBigDecimal(item.amountDecimal)
            when (item.direction) {
                BalanceDirection.Inflow.dbValue -> total + amount
                BalanceDirection.Outflow.dbValue -> total - amount
                else -> total
            }
        }

    private fun money(value: BigDecimal): String =
        value.setScale(DecimalTextScale.Money.places).toPlainString()
}

package com.shift.app.domain.goals.measurement

import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalIncomeRow
import com.shift.app.feature.goals.domain.model.GoalMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

class IncomeGoalMeasurementProvider(
    private val rows: suspend () -> List<GoalIncomeRow> = { emptyList() },
) : GoalMeasurementProvider {
    override suspend fun measure(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant): GoalMeasurement =
        measureTransactions(metric, aggregate, asOf, rows())

    companion object {
        fun measureTransactions(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant, transactions: List<GoalIncomeRow>): GoalMeasurement {
            require(metric.metricType == MetricType.INCOME)
            val currentMonth = YearMonth.from(asOf.atZone(ZoneId.of(aggregate.goal.timezoneId)))
            val window = metric.windowSize.coerceIn(1, 6)
            val closedMonths = (1..window).map { currentMonth.minusMonths(it.toLong()) }.reversed()
            val incomeByMonth = transactions
                .filter { it.deletedAt == null }
                .groupBy { YearMonth.parse(it.date.substring(0, 7)) }
                .mapValues { (_, rows) -> rows.fold(BigDecimal.ZERO) { acc, row -> acc + BigDecimal(row.amountDecimal) } }
            if (closedMonths.any { it !in incomeByMonth }) return unavailable(metric, "missing-closed-income-history")
            val average = closedMonths.fold(BigDecimal.ZERO) { acc, month -> acc + incomeByMonth.getValue(month) }
                .divide(BigDecimal.valueOf(window.toLong()), 2, RoundingMode.HALF_UP)
            val streak = consecutiveClosedSuccesses(incomeByMonth, currentMonth, BigDecimal(aggregate.goal.targetDecimal), aggregate.goal.confirmationPeriods)
            return GoalMeasurement(metric.id, MetricType.INCOME, average.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                "income:${closedMonths.joinToString(",")}:$average:streak=$streak", streak.toBigDecimal().setScale(2).toPlainString(), streak)
        }

        private fun consecutiveClosedSuccesses(incomeByMonth: Map<YearMonth, BigDecimal>, currentMonth: YearMonth, target: BigDecimal, periods: Int): Int {
            var streak = 0
            var cursor = currentMonth.minusMonths(1)
            while (streak < periods) {
                val value = incomeByMonth[cursor] ?: break
                if (value < target) break
                streak++
                cursor = cursor.minusMonths(1)
            }
            return streak
        }

        private fun unavailable(metric: GoalMetric, reason: String) = GoalMeasurement(
            metric.id, metric.metricType, null, "income:$reason", available = false, unavailableReason = reason,
        )
    }
}

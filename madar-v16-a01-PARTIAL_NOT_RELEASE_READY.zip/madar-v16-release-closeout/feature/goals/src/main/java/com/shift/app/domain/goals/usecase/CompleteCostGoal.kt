package com.shift.app.domain.goals.usecase

import com.shift.app.feature.goals.domain.repository.GoalCompletionPort
import java.util.UUID
import javax.inject.Inject

enum class CostGoalCompletionMode { KEEP_ALLOCATED, ORDINARY_EXPENSE, PROJECT_ASSET }

data class CompleteCostGoalRequest(
    val goalId: String,
    val amountDecimal: String,
    val date: String,
    val purpose: String,
    val note: String = "",
    val mode: CostGoalCompletionMode,
    val operationId: String = UUID.randomUUID().toString(),
    val now: Long = System.currentTimeMillis(),
)

class CompleteCostGoal @Inject constructor(private val port: GoalCompletionPort) {
    suspend fun complete(request: CompleteCostGoalRequest) = port.completeCostGoal(request)
}

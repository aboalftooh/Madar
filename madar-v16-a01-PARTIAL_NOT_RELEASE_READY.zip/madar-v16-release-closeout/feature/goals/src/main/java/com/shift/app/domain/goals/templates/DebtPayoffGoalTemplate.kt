package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalScope
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.util.UUID

enum class DebtPayoffScopeMode {
    ALL_PAYABLE,
    SELECTED_ACCOUNTS,
}

data class DebtPayoffTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "سداد الديون",
    val baselineDebtDecimal: String,
    val scopeMode: DebtPayoffScopeMode = DebtPayoffScopeMode.ALL_PAYABLE,
    val selectedAccountIds: List<String> = emptyList(),
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val now: Long = System.currentTimeMillis(),
)

object DebtPayoffGoalTemplate {
    fun build(request: DebtPayoffTemplateRequest): GoalAggregate {
        val selectedAccountIds = request.selectedAccountIds.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(request.scopeMode != DebtPayoffScopeMode.SELECTED_ACCOUNTS || selectedAccountIds.isNotEmpty()) {
            "Selected debt payoff scope requires at least one account"
        }
        val config = GoalConfigJson.encode(
            VersionedGoalConfig(
                settings = mapOf(
                    "template" to "debt_payoff",
                    "debtSelection" to request.scopeMode.name,
                ),
            ),
        )
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = GoalType.DEBT_PAYOFF,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = "0.00",
            baselineDecimal = request.baselineDebtDecimal,
            targetPercentDecimal = null,
            confirmationPeriods = 1,
            costThreshold = null,
            configJson = config,
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metric = GoalMetric(
            id = "${request.id}:metric:debt-balance",
            goalId = request.id,
            metricType = MetricType.DEBT_BALANCE,
            windowType = "INSTANT",
            windowSize = 1,
            baselineDecimal = request.baselineDebtDecimal,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val condition = GoalCondition(
            id = "${request.id}:condition:zero-debt",
            goalId = request.id,
            metricId = metric.id,
            kind = ConditionKind.TARGET,
            operator = "<=",
            valueDecimal = "0.00",
            required = true,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val scopes = selectedAccountIds.map { accountId ->
            GoalScope(
                id = "${request.id}:scope:debt:$accountId",
                goalId = request.id,
                dimension = ScopeDimension.DEBT_ACCOUNT,
                referenceId = accountId,
                mode = "INCLUDE",
                reason = "حساب دين مشمول في هدف السداد",
                effectiveFrom = request.startDate,
                effectiveTo = null,
                createdAt = request.now,
                updatedAt = request.now,
                deletedAt = null,
                syncState = "PENDING",
            )
        }
        return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition), scopes = scopes)
    }
}

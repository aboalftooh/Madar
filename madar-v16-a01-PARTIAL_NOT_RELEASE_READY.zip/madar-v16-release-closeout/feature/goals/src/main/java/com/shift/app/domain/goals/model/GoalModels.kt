package com.shift.app.domain.goals.model

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@JvmInline
value class GoalDecimal private constructor(val text: String) {
    val value: BigDecimal get() = DecimalText.toBigDecimal(text)

    companion object {
        fun nonNegative(text: String): GoalDecimal {
            GoalDecimalContract.requireCanonicalNonNegative(text)
            return GoalDecimal(text)
        }

        fun positive(text: String): GoalDecimal {
            GoalDecimalContract.requireCanonicalPositive(text)
            return GoalDecimal(text)
        }
    }
}

object GoalDecimalContract {
    fun requireCanonicalNonNegative(text: String): String {
        require(
            DecimalText.canonicalNonNegative(text, DecimalTextScale.Money) == text,
        ) { "Goal decimal must be canonical, non-negative money text" }
        return text
    }

    fun requireCanonicalPositive(text: String): String {
        require(
            DecimalText.canonicalPositive(text, DecimalTextScale.Money) == text,
        ) { "Goal decimal must be canonical, positive money text" }
        return text
    }

    fun requireCanonicalNullable(text: String?): String? =
        text?.let(::requireCanonicalNonNegative)
}

@Serializable
data class VersionedGoalConfig(
    val version: Int = 1,
    val settings: Map<String, String> = emptyMap(),
) {
    init {
        require(version == 1) { "Unsupported goal config version" }
        val relationalKeys = settings.keys.filter { key ->
            val normalized = key.lowercase()
            normalized.contains("amount") || normalized.contains("decimal") ||
                normalized.contains("scope") || normalized.contains("referenceid")
        }
        require(relationalKeys.isEmpty()) {
            "Goal config cannot contain financial amounts or relational scopes: $relationalKeys"
        }
    }
}

object GoalConfigJson {
    private val json = Json {
        encodeDefaults = true
        ignoreUnknownKeys = false
    }

    fun encode(config: VersionedGoalConfig): String = json.encodeToString(config)

    fun decode(raw: String): VersionedGoalConfig = json.decodeFromString(raw)
}

data class GoalProgressLine(
    val baseline: GoalDecimal?,
    val target: GoalDecimal,
    val measured: GoalDecimal?,
)

package com.shift.app.domain.goals.usecase

import com.shift.app.feature.goals.domain.repository.GoalCompletionPort
import java.util.UUID
import javax.inject.Inject

data class AssetGoalCompletionRequest(
    val goalId: String,
    val assetName: String,
    val assetType: String,
    val amountDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
    val financed: Boolean = false,
    val debtAccountId: String = UUID.randomUUID().toString(),
    val lenderName: String = "",
    val financedAmountDecimal: String = "0.00",
    val cashPaidDecimal: String = "0.00",
    val now: Long = System.currentTimeMillis(),
)

class CompleteAssetPurchaseGoal @Inject constructor(private val port: GoalCompletionPort) {
    suspend fun complete(request: AssetGoalCompletionRequest) = port.completeAssetPurchase(request)
}

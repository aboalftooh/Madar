package com.shift.app.domain.goals.measurement

import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.feature.goals.domain.model.GoalMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

class DebtPayoffMeasurementProvider(
    private val accounts: suspend () -> List<GoalDebtAccountRow> = { emptyList() },
    private val transactions: suspend () -> List<GoalDebtTransactionRow> = { emptyList() },
) : GoalMeasurementProvider {
    override suspend fun measure(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant): GoalMeasurement =
        measureDebt(metric, aggregate, accounts(), transactions())

    companion object {
        fun measureDebt(metric: GoalMetric, aggregate: GoalAggregate, accounts: List<GoalDebtAccountRow>, transactions: List<GoalDebtTransactionRow>): GoalMeasurement {
            require(metric.metricType == MetricType.DEBT_BALANCE)
            val selected = aggregate.scopes.filter { it.deletedAt == null && it.dimension == ScopeDimension.DEBT_ACCOUNT && it.mode == "INCLUDE" }.map { it.referenceId }.toSet()
            val excluded = aggregate.scopes.filter { it.deletedAt == null && it.dimension == ScopeDimension.DEBT_ACCOUNT && it.mode == "EXCLUDE" }.map { it.referenceId }.toSet()
            val includedAccounts = accounts.filter {
                it.deletedAt == null && it.confirmed && it.direction == DebtDirection.Payable.dbValue && it.id !in excluded && (selected.isEmpty() || it.id in selected)
            }
            if (includedAccounts.isEmpty()) return unavailable(metric, "no-confirmed-payable-accounts")
            val byAccount = transactions.filter { it.deletedAt == null }.groupBy { it.accountId }
            val remaining = includedAccounts.fold(BigDecimal.ZERO) { acc, account ->
                acc + byAccount.orEmpty()[account.id].orEmpty().fold(BigDecimal.ZERO) { total, tx ->
                    total + BigDecimal(tx.amountDecimal).multiply(BigDecimal(DebtTransactionType.fromDb(tx.type).remainingSign))
                }
            }.setScale(2, RoundingMode.HALF_UP)
            return GoalMeasurement(metric.id, MetricType.DEBT_BALANCE, remaining.toPlainString(),
                "debt-payoff:accounts=${includedAccounts.map { it.id }.sorted()}:remaining=$remaining")
        }

        private fun unavailable(metric: GoalMetric, reason: String) = GoalMeasurement(metric.id, metric.metricType, null, "debt-payoff:$reason", available = false, unavailableReason = reason)
    }
}

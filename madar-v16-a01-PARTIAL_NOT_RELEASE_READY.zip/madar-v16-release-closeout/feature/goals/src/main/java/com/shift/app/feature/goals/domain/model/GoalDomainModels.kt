package com.shift.app.feature.goals.domain.model

import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalDecimalContract
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension

data class FinancialGoal(
    val id: String,
    val name: String,
    val type: GoalType,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val currencyCode: String,
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val targetDecimal: String,
    val baselineDecimal: String?,
    val targetPercentDecimal: String?,
    val confirmationPeriods: Int,
    val costThreshold: CostThreshold?,
    val configJson: String,
    val revision: Long,
    val readyAt: Long?,
    val completedAt: Long?,
    val cancelledAt: Long?,
    val archivedAt: Long?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && name.isNotBlank() && currencyCode.isNotBlank())
        require(startDate.isNotBlank() && deadline.isNotBlank() && timezoneId.isNotBlank())
        require(configJson.startsWith("{\"version\":1,"))
        require(confirmationPeriods > 0 && revision >= 0)
        GoalDecimalContract.requireCanonicalNonNegative(targetDecimal)
        GoalDecimalContract.requireCanonicalNullable(baselineDecimal)
        GoalDecimalContract.requireCanonicalNullable(targetPercentDecimal)
    }
}

data class GoalMetric(
    val id: String,
    val goalId: String,
    val metricType: MetricType,
    val windowType: String,
    val windowSize: Int,
    val baselineDecimal: String?,
    val configJson: String,
    val ordinal: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalCondition(
    val id: String,
    val goalId: String,
    val metricId: String?,
    val kind: ConditionKind,
    val operator: String,
    val valueDecimal: String?,
    val required: Boolean,
    val configJson: String,
    val ordinal: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalScope(
    val id: String,
    val goalId: String,
    val dimension: ScopeDimension,
    val referenceId: String,
    val mode: String,
    val reason: String,
    val effectiveFrom: String,
    val effectiveTo: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalFundingTransaction(
    val id: String,
    val goalId: String,
    val operationId: String,
    val kind: FundingKind,
    val amountDecimal: String,
    val currencyCode: String,
    val balanceTransactionId: String?,
    val relatedFundingTransactionId: String?,
    val note: String,
    val occurredAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalCostEstimate(
    val id: String,
    val goalId: String,
    val operationId: String,
    val minDecimal: String?,
    val expectedDecimal: String,
    val safeDecimal: String,
    val currencyCode: String,
    val source: String,
    val note: String,
    val effectiveAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalEvaluation(
    val id: String,
    val goalId: String,
    val asOf: Long,
    val engineVersion: String,
    val inputFingerprint: String,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val measuredDecimal: String?,
    val targetDecimal: String?,
    val progressDecimal: String?,
    val resultJson: String,
    val correctionOfId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class GoalActivity(
    val id: String,
    val goalId: String,
    val operationId: String,
    val type: String,
    val occurredAt: Long,
    val effectiveDate: String?,
    val detailsJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
)

data class GoalAggregate(
    val goal: FinancialGoal,
    val metrics: List<GoalMetric> = emptyList(),
    val conditions: List<GoalCondition> = emptyList(),
    val scopes: List<GoalScope> = emptyList(),
    val fundingTransactions: List<GoalFundingTransaction> = emptyList(),
    val costEstimates: List<GoalCostEstimate> = emptyList(),
    val evaluations: List<GoalEvaluation> = emptyList(),
    val activities: List<GoalActivity> = emptyList(),
)

data class FinancialChangeEvent(
    val eventId: String,
    val sourceType: String,
    val sourceId: String,
    val operationId: String,
    val effectiveDate: String,
    val changedFields: String,
    val createdAt: Long,
    val processedAt: Long?,
    val attemptCount: Int,
    val lastError: String?,
)

data class ActiveGoalAllocation(
    val fundingTransactionId: String,
    val goalId: String,
    val goalName: String,
    val availableDecimal: String,
)

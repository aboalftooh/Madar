package com.shift.app.domain.goals.evaluation

import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import java.math.BigDecimal
import java.math.RoundingMode
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

const val GOAL_ENGINE_VERSION = "phase1-v2"

data class GoalConditionResult(
    val conditionId: String,
    val satisfied: Boolean,
    val available: Boolean,
    val measured: BigDecimal?,
    val expected: BigDecimal?,
)

data class GoalEvaluationDecision(
    val inputFingerprint: String,
    val engineVersion: String = GOAL_ENGINE_VERSION,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val measured: BigDecimal?,
    val target: BigDecimal,
    val progressPercent: BigDecimal?,
    val estimated: Boolean,
    val conditionResults: List<GoalConditionResult>,
)

@Singleton
class GoalEvaluationEngine @Inject constructor() {
    fun evaluate(
        aggregate: GoalAggregate,
        measurements: List<GoalMeasurement>,
        asOf: Instant,
    ): GoalEvaluationDecision {
        val byMetric = measurements.associateBy { it.metricId }
        val orderedConditions = aggregate.conditions
            .filter { it.deletedAt == null }
            .sortedWith(compareBy<GoalCondition> { it.ordinal }.thenBy { it.id })
        val primary = aggregate.metrics.sortedWith(compareBy({ it.ordinal }, { it.id }))
            .firstOrNull()?.let { byMetric[it.id] }
        val results = orderedConditions.map { condition ->
            evaluateCondition(condition, condition.metricId?.let(byMetric::get) ?: primary, aggregate)
        }
        val required = orderedConditions.zip(results).filter { it.first.required }.map { it.second }
        val allAvailable = measurements.all { it.available } && required.all { it.available }
        val ready = required.isNotEmpty() && required.all { it.available && it.satisfied }
        val lifecycle = when (aggregate.goal.lifecycleStatus) {
            GoalLifecycleStatus.ACTIVE -> if (ready) GoalLifecycleStatus.READY else GoalLifecycleStatus.ACTIVE
            GoalLifecycleStatus.READY -> if (ready) GoalLifecycleStatus.READY else GoalLifecycleStatus.ACTIVE
            else -> aggregate.goal.lifecycleStatus
        }
        val measured = primary?.measuredDecimal?.toBigDecimalOrNull()
        val target = aggregate.goal.targetDecimal.toBigDecimal()
        val primaryCondition = orderedConditions.firstOrNull {
            it.required && it.metricId == primary?.metricId
        }
        val higherIsBetter = primaryCondition?.operator?.trim()?.uppercase() !in setOf("<", "<=", "LT", "LTE")
        val progress = progressPercent(
            baseline = aggregate.goal.baselineDecimal?.toBigDecimalOrNull(),
            measured = measured,
            target = target,
            higherIsBetter = higherIsBetter,
        )
        val health = deriveHealth(
            aggregate = aggregate,
            measured = measured,
            target = target,
            allAvailable = allAvailable,
            higherIsBetter = higherIsBetter,
            bestRate = primary?.bestRateDecimal?.toBigDecimalOrNull(),
            asOf = asOf,
        )
        return GoalEvaluationDecision(
            inputFingerprint = fingerprint(aggregate, measurements),
            lifecycleStatus = lifecycle,
            healthStatus = health,
            measured = measured,
            target = target,
            progressPercent = progress,
            estimated = primary?.estimated == true,
            conditionResults = results,
        )
    }

    fun fingerprint(
        aggregate: GoalAggregate,
        measurements: List<GoalMeasurement>,
    ): String {
        val stableInput = buildString {
            append(GOAL_ENGINE_VERSION).append('|')
            with(aggregate.goal) {
                // Derived state, revision, sync state, and timestamps are deliberately excluded:
                // persisting an evaluation must not invalidate its own fingerprint.
                append(id).append('|').append(name).append('|').append(type).append('|')
                append(currencyCode).append('|').append(startDate).append('|').append(deadline).append('|')
                append(timezoneId).append('|').append(targetDecimal).append('|')
                append(baselineDecimal).append('|').append(targetPercentDecimal).append('|')
                append(confirmationPeriods).append('|').append(costThreshold).append('|')
                append(configJson).append('|').append(deletedAt).append('|')
            }
            aggregate.metrics.sortedBy { it.id }.forEach {
                append(it.id).append(':').append(it.goalId).append(':').append(it.metricType).append(':')
                append(it.windowType).append(':').append(it.windowSize).append(':').append(it.baselineDecimal).append(':')
                append(it.configJson).append(':').append(it.ordinal).append(':').append(it.deletedAt).append('|')
            }
            aggregate.conditions.sortedBy { it.id }.forEach {
                append(it.id).append(':').append(it.goalId).append(':').append(it.metricId).append(':')
                append(it.kind).append(':').append(it.operator).append(':').append(it.valueDecimal).append(':')
                append(it.required).append(':').append(it.configJson).append(':').append(it.ordinal).append(':')
                append(it.deletedAt).append('|')
            }
            aggregate.scopes.sortedBy { it.id }.forEach {
                append(it.id).append(':').append(it.goalId).append(':').append(it.dimension).append(':')
                append(it.referenceId).append(':').append(it.mode).append(':').append(it.reason).append(':')
                append(it.effectiveFrom).append(':').append(it.effectiveTo).append(':').append(it.deletedAt).append('|')
            }
            aggregate.fundingTransactions.sortedBy { it.id }.forEach {
                append(it.id).append(':').append(it.goalId).append(':').append(it.operationId).append(':')
                append(it.kind).append(':').append(it.amountDecimal).append(':').append(it.currencyCode).append(':')
                append(it.balanceTransactionId).append(':').append(it.relatedFundingTransactionId).append(':')
                append(it.note).append(':').append(it.occurredAt).append(':').append(it.deletedAt).append('|')
            }
            aggregate.costEstimates.sortedBy { it.id }.forEach {
                append(it.id).append(':').append(it.goalId).append(':').append(it.operationId).append(':')
                append(it.minDecimal).append(':').append(it.expectedDecimal).append(':').append(it.safeDecimal).append(':')
                append(it.currencyCode).append(':').append(it.source).append(':').append(it.note).append(':')
                append(it.effectiveAt).append(':').append(it.deletedAt).append('|')
            }
            measurements.sortedWith(compareBy<GoalMeasurement> { it.metricId }.thenBy { it.metricType.name })
                .forEach { measurement ->
                    append(measurement.metricId).append(':')
                    append(measurement.metricType).append(':')
                    append(measurement.measuredDecimal).append(':')
                    append(measurement.available).append(':')
                    append(measurement.bestRateDecimal).append(':')
                    append(measurement.confirmationStreak).append(':')
                    append(measurement.estimated).append(':')
                    append(measurement.sourceFingerprint).append('|')
                }
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(stableInput.toByteArray(StandardCharsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun evaluateCondition(
        condition: GoalCondition,
        measurement: GoalMeasurement?,
        aggregate: GoalAggregate,
    ): GoalConditionResult {
        val measured = measurement?.measuredDecimal?.toBigDecimalOrNull()
        val expected = (condition.valueDecimal ?: aggregate.goal.targetDecimal).toBigDecimalOrNull()
        if (measurement == null || !measurement.available || measured == null || expected == null) {
            return GoalConditionResult(condition.id, false, false, measured, expected)
        }
        val comparison = measured.compareTo(expected)
        val operator = condition.operator.trim().uppercase()
        if (operator !in setOf(">", "GT", ">=", "GTE", "<", "LT", "<=", "LTE", "=", "==", "EQ")) {
            return GoalConditionResult(condition.id, false, false, measured, expected)
        }
        val thresholdSatisfied = when (operator) {
            ">", "GT" -> comparison > 0
            ">=", "GTE" -> comparison >= 0
            "<", "LT" -> comparison < 0
            "<=", "LTE" -> comparison <= 0
            "=", "==", "EQ" -> comparison == 0
            else -> false
        }
        val confirmationSatisfied = if (condition.kind == ConditionKind.CONFIRMATION_STREAK) {
            val streak = measurement.confirmationStreak
                ?: return GoalConditionResult(condition.id, false, false, measured, expected)
            streak >= aggregate.goal.confirmationPeriods
        } else {
            true
        }
        val satisfied = thresholdSatisfied && confirmationSatisfied
        return GoalConditionResult(condition.id, satisfied, true, measured, expected)
    }

    private fun deriveHealth(
        aggregate: GoalAggregate,
        measured: BigDecimal?,
        target: BigDecimal,
        allAvailable: Boolean,
        higherIsBetter: Boolean,
        bestRate: BigDecimal?,
        asOf: Instant,
    ): GoalHealthStatus {
        if (!allAvailable || measured == null) return GoalHealthStatus.UNAVAILABLE
        val zone = runCatching { ZoneId.of(aggregate.goal.timezoneId) }.getOrNull()
            ?: return GoalHealthStatus.UNAVAILABLE
        val start = runCatching { LocalDate.parse(aggregate.goal.startDate) }.getOrNull()
            ?: return GoalHealthStatus.UNAVAILABLE
        val deadline = runCatching { LocalDate.parse(aggregate.goal.deadline) }.getOrNull()
            ?: return GoalHealthStatus.UNAVAILABLE
        if (!deadline.isAfter(start)) return GoalHealthStatus.UNAVAILABLE
        val today = asOf.atZone(zone).toLocalDate()
        val targetReached = if (higherIsBetter) measured >= target else measured <= target
        if (targetReached) return GoalHealthStatus.ON_TRACK
        if (today.isAfter(deadline)) return GoalHealthStatus.BEHIND
        val baseline = aggregate.goal.baselineDecimal?.toBigDecimalOrNull()
        if (baseline == null && !higherIsBetter) return GoalHealthStatus.NEEDS_ATTENTION
        val startValue = baseline ?: BigDecimal.ZERO
        val totalDays = java.time.temporal.ChronoUnit.DAYS.between(start, deadline)
        val elapsedDays = java.time.temporal.ChronoUnit.DAYS.between(start, today)
            .coerceIn(0, totalDays)
        val expected = startValue + (target - startValue)
            .multiply(BigDecimal.valueOf(elapsedDays))
            .divide(BigDecimal.valueOf(totalDays), 12, RoundingMode.HALF_UP)
        val onTrack = if (higherIsBetter) measured >= expected else measured <= expected
        if (onTrack) return GoalHealthStatus.ON_TRACK
        if (bestRate == null || bestRate <= BigDecimal.ZERO) return GoalHealthStatus.NEEDS_ATTENTION
        val remainingDays = java.time.temporal.ChronoUnit.DAYS.between(today, deadline)
        val projected = if (higherIsBetter) {
            measured + bestRate.multiply(BigDecimal.valueOf(remainingDays))
        } else {
            measured - bestRate.multiply(BigDecimal.valueOf(remainingDays))
        }
        val canCatchUp = if (higherIsBetter) projected >= target else projected <= target
        return if (canCatchUp) {
            GoalHealthStatus.NEEDS_ATTENTION
        } else {
            GoalHealthStatus.BEHIND
        }
    }

    private fun progressPercent(
        baseline: BigDecimal?,
        measured: BigDecimal?,
        target: BigDecimal,
        higherIsBetter: Boolean,
    ): BigDecimal? {
        if (measured == null) return null
        val start = baseline ?: if (higherIsBetter) BigDecimal.ZERO else return null
        val distance = if (higherIsBetter) target - start else start - target
        if (distance <= BigDecimal.ZERO) return null
        val achieved = if (higherIsBetter) measured - start else start - measured
        return (achieved.max(BigDecimal.ZERO) * BigDecimal("100"))
            .divide(distance, 2, RoundingMode.HALF_UP)
    }
}

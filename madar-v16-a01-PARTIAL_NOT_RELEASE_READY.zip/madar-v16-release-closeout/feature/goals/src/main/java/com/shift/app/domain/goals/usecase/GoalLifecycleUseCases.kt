package com.shift.app.domain.goals.usecase

import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.repository.GoalGateway
import javax.inject.Inject

object GoalLifecycleStateMachine {
    private val allowed = setOf(
        GoalLifecycleStatus.DRAFT to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.PAUSED,
        GoalLifecycleStatus.PAUSED to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.READY,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.COMPLETED,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.PAUSED to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.COMPLETED to GoalLifecycleStatus.ARCHIVED,
        GoalLifecycleStatus.CANCELLED to GoalLifecycleStatus.ARCHIVED,
    )

    fun requireAllowed(from: GoalLifecycleStatus, to: GoalLifecycleStatus) {
        require(from to to in allowed) { "Goal lifecycle transition $from -> $to is not allowed" }
    }

    fun isAllowed(from: GoalLifecycleStatus, to: GoalLifecycleStatus): Boolean = from to to in allowed
}

class GoalLifecycleUseCases @Inject constructor(
    private val gateway: GoalGateway,
) {
    suspend fun activate(goalId: String, expectedRevision: Long, operationId: String, now: Long) = transition(goalId, expectedRevision, GoalLifecycleStatus.ACTIVE, operationId, now)
    suspend fun pause(goalId: String, expectedRevision: Long, operationId: String, now: Long) = transition(goalId, expectedRevision, GoalLifecycleStatus.PAUSED, operationId, now)
    suspend fun resume(goalId: String, expectedRevision: Long, operationId: String, now: Long) = transition(goalId, expectedRevision, GoalLifecycleStatus.ACTIVE, operationId, now)

    suspend fun complete(goalId: String, expectedRevision: Long, operationId: String, now: Long): FinancialGoal {
        val goal = requireNotNull(gateway.getAggregate(goalId)) { "Goal $goalId does not exist" }.goal
        require(goal.type !in specializedCompletionTypes) { "هذا النوع من الأهداف يتطلب مسار الإكمال المحاسبي المتخصص" }
        return transition(goalId, expectedRevision, GoalLifecycleStatus.COMPLETED, operationId, now)
    }

    suspend fun cancel(goalId: String, expectedRevision: Long, operationId: String, now: Long) = transition(goalId, expectedRevision, GoalLifecycleStatus.CANCELLED, operationId, now)
    suspend fun archive(goalId: String, expectedRevision: Long, operationId: String, now: Long) = transition(goalId, expectedRevision, GoalLifecycleStatus.ARCHIVED, operationId, now)

    private suspend fun transition(goalId: String, expectedRevision: Long, to: GoalLifecycleStatus, operationId: String, now: Long): FinancialGoal {
        require(operationId.isNotBlank()) { "operationId is required" }
        val current = requireNotNull(gateway.getAggregate(goalId)) { "Goal $goalId does not exist" }.goal
        check(current.revision == expectedRevision) { "Goal revision changed" }
        GoalLifecycleStateMachine.requireAllowed(current.lifecycleStatus, to)
        return gateway.transition(goalId, expectedRevision, to, operationId, now, "LIFECYCLE_${to.name}")
    }
}

val specializedCompletionTypes = setOf(
    GoalType.HOUSE_PURCHASE,
    GoalType.CAR_PURCHASE,
    GoalType.PROJECT_FUNDING,
    GoalType.TRIP_FUNDING,
    GoalType.DEBT_PAYOFF,
)

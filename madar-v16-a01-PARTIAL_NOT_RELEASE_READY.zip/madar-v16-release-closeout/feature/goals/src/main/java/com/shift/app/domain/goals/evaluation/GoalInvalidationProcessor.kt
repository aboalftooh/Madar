package com.shift.app.domain.goals.evaluation

import com.shift.app.feature.goals.domain.model.FinancialChangeEvent
import com.shift.app.feature.goals.domain.model.GoalActivity
import com.shift.app.feature.goals.domain.model.GoalEvaluation
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.repository.GoalInvalidationGateway
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.MetricType
import java.math.BigDecimal
import java.time.Clock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class GoalInvalidationResult(
    val processedEvents: Int,
    val insertedEvaluations: Int,
    val failures: Int,
)

@Singleton
class GoalInvalidationProcessor @Inject constructor(
    private val gateway: GoalInvalidationGateway,
    private val registry: GoalMeasurementRegistry,
    private val engine: GoalEvaluationEngine,
) {
    private val clock: Clock = Clock.systemUTC()
    private val processingMutex = Mutex()

    suspend fun processPending(limit: Int = 100): GoalInvalidationResult = processingMutex.withLock {
        var processed = 0
        var inserted = 0
        var failures = 0
        gateway.pendingChanges(limit).forEach { event ->
            try {
                val asOf = eventAsOf(event)
                val aggregates = gateway.getLiveAggregates()
                    .filter(::isEvaluable)
                    .filter { isAffected(it, event) }
                aggregates.forEach { aggregate ->
                    val measurements = registry.measure(aggregate, asOf)
                    val decision = engine.evaluate(aggregate, measurements, asOf)
                    if (persist(aggregate, decision, event, asOf)) inserted++
                }
                gateway.markChangeProcessed(event.eventId, clock.millis())
                processed++
            } catch (error: Exception) {
                gateway.markChangeFailed(event, error.message ?: error::class.java.simpleName)
                failures++
            }
        }
        GoalInvalidationResult(processed, inserted, failures)
    }

    private suspend fun persist(
        aggregate: GoalAggregate,
        decision: GoalEvaluationDecision,
        event: FinancialChangeEvent,
        asOf: Instant,
    ): Boolean {
        val now = clock.millis()
        val evaluationId = "evaluation:${aggregate.goal.id}:${decision.inputFingerprint}"
        val previous = aggregate.evaluations.firstOrNull()
        val evaluation = GoalEvaluation(
            id = evaluationId,
            goalId = aggregate.goal.id,
            asOf = asOf.toEpochMilli(),
            engineVersion = decision.engineVersion,
            inputFingerprint = decision.inputFingerprint,
            lifecycleStatus = decision.lifecycleStatus,
            healthStatus = decision.healthStatus,
            measuredDecimal = decision.measured.canonicalOrNull(),
            targetDecimal = decision.target.canonicalOrNull(),
            progressDecimal = decision.progressPercent.canonicalOrNull(),
            resultJson = resultJson(decision, event),
            correctionOfId = previous?.takeIf {
                it.inputFingerprint != decision.inputFingerprint && it.asOf > asOf.toEpochMilli()
            }?.id,
            createdAt = now,
            updatedAt = now,
            deletedAt = null,
        )
        val activity = GoalActivity(
            id = "activity:${aggregate.goal.id}:${decision.inputFingerprint}",
            goalId = aggregate.goal.id,
            operationId = decision.inputFingerprint,
            type = "EVALUATED",
            occurredAt = now,
            effectiveDate = event.effectiveDate,
            detailsJson = "{\"eventId\":\"${jsonEscape(event.eventId)}\",\"engineVersion\":\"${decision.engineVersion}\"}",
            createdAt = now,
            updatedAt = now,
            deletedAt = null,
            syncState = "PENDING",
        )
        return gateway.saveEvaluation(evaluation, activity, aggregate.goal.revision)
    }

    private fun isEvaluable(aggregate: GoalAggregate): Boolean =
        aggregate.goal.deletedAt == null && aggregate.goal.lifecycleStatus in setOf(
            GoalLifecycleStatus.ACTIVE,
            GoalLifecycleStatus.PAUSED,
            GoalLifecycleStatus.READY,
            GoalLifecycleStatus.COMPLETED,
        )

    private fun isAffected(
        aggregate: GoalAggregate,
        event: FinancialChangeEvent,
    ): Boolean {
        if (event.sourceType == "financial_goals") return aggregate.goal.id == event.sourceId
        val affectedMetrics = when (event.sourceType) {
            "transactions" -> setOf(MetricType.INCOME, MetricType.EXPENSE, MetricType.NET_WORTH)
            "payments" -> setOf(MetricType.EXPENSE, MetricType.EMERGENCY_COVERAGE, MetricType.NET_WORTH)
            "balance_transactions" -> setOf(
                MetricType.NET_WORTH,
                MetricType.HOUSE_TO_NET_WORTH_RATIO,
                MetricType.POST_PURCHASE_AVAILABLE_BALANCE,
            )
            "assets" -> setOf(
                MetricType.NET_WORTH,
                MetricType.HOUSE_TO_NET_WORTH_RATIO,
                MetricType.POST_PURCHASE_AVAILABLE_BALANCE,
            )
            "debts" -> setOf(MetricType.DEBT_BALANCE, MetricType.NET_WORTH, MetricType.HOUSE_TO_NET_WORTH_RATIO)
            "goal_funding_transactions" -> setOf(
                MetricType.ALLOCATED_BALANCE,
                MetricType.EMERGENCY_COVERAGE,
                MetricType.POST_PURCHASE_AVAILABLE_BALANCE,
            )
            "goal_cost_estimates" -> setOf(MetricType.ALLOCATED_BALANCE)
            else -> MetricType.entries.toSet()
        }
        return aggregate.metrics.any { it.deletedAt == null && it.metricType in affectedMetrics }
    }

    private fun eventAsOf(event: FinancialChangeEvent): Instant =
        runCatching {
            LocalDate.parse(event.effectiveDate).atStartOfDay().toInstant(ZoneOffset.UTC)
        }.getOrElse { Instant.ofEpochMilli(clock.millis()) }

    private fun resultJson(decision: GoalEvaluationDecision, event: FinancialChangeEvent): String =
        "{\"version\":1,\"sourceType\":\"${jsonEscape(event.sourceType)}\"," +
            "\"sourceId\":\"${jsonEscape(event.sourceId)}\",\"estimated\":${decision.estimated},\"conditions\":" +
            decision.conditionResults.joinToString(prefix = "[", postfix = "]") {
                "{\"id\":\"${jsonEscape(it.conditionId)}\",\"available\":${it.available},\"satisfied\":${it.satisfied}}"
            } + "}"

    private fun BigDecimal?.canonicalOrNull(): String? = this?.let {
        DecimalText.canonicalNonNegative(it.max(BigDecimal.ZERO).toPlainString(), DecimalTextScale.Money)
    }

    private fun jsonEscape(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
}

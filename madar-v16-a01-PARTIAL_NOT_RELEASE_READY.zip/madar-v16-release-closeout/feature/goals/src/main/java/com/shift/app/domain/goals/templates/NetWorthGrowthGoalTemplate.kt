package com.shift.app.domain.goals.templates

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class NetWorthGrowthTemplateRequest(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "نمو صافي الثروة",
    val baselineDecimal: String,
    val fixedTargetDecimal: String? = null,
    val growthPercentDecimal: String? = null,
    val currencyCode: String = "SDG",
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val now: Long = System.currentTimeMillis(),
)

object NetWorthGrowthGoalTemplate {
    fun build(request: NetWorthGrowthTemplateRequest): GoalAggregate {
        val target = request.fixedTargetDecimal ?: BigDecimal(request.baselineDecimal)
            .multiply(BigDecimal.ONE.add(BigDecimal(requireNotNull(request.growthPercentDecimal)).divide(BigDecimal("100"), 8, RoundingMode.HALF_UP)))
            .setScale(2, RoundingMode.HALF_UP)
            .toPlainString()
        val config = GoalConfigJson.encode(VersionedGoalConfig(settings = mapOf("template" to "net_worth_growth")))
        val goal = FinancialGoal(
            id = request.id,
            name = request.name,
            type = GoalType.NET_WORTH_GROWTH,
            lifecycleStatus = GoalLifecycleStatus.DRAFT,
            healthStatus = GoalHealthStatus.UNAVAILABLE,
            currencyCode = request.currencyCode,
            startDate = request.startDate,
            deadline = request.deadline,
            timezoneId = request.timezoneId,
            targetDecimal = target,
            baselineDecimal = request.baselineDecimal,
            targetPercentDecimal = request.growthPercentDecimal,
            confirmationPeriods = 1,
            costThreshold = null,
            configJson = config,
            revision = 0,
            readyAt = null,
            completedAt = null,
            cancelledAt = null,
            archivedAt = null,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val metric = GoalMetric(
            id = "${request.id}:metric:net-worth",
            goalId = request.id,
            metricType = MetricType.NET_WORTH,
            windowType = "INSTANT",
            windowSize = 1,
            baselineDecimal = request.baselineDecimal,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        val condition = GoalCondition(
            id = "${request.id}:condition:net-worth",
            goalId = request.id,
            metricId = metric.id,
            kind = ConditionKind.TARGET,
            operator = ">=",
            valueDecimal = target,
            required = true,
            configJson = config,
            ordinal = 0,
            createdAt = request.now,
            updatedAt = request.now,
            deletedAt = null,
            syncState = "PENDING",
        )
        return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition))
    }
}

package com.shift.app.feature.goals.domain.model

/** Read-only financial projections used by goal measurement. They intentionally contain no Room types. */
data class GoalIncomeRow(val id: String, val date: String, val amountDecimal: String, val deletedAt: Long?)
data class GoalExpenseRow(val id: String, val date: String, val amountDecimal: String, val kind: String, val purpose: String, val purposeKey: String, val deletedAt: Long?)
data class GoalLegacyTransactionRow(val id: String, val date: String, val amountDecimal: String, val type: String, val balanceTransactionId: String?, val deletedAt: Long?)
data class GoalBalanceRow(val id: String, val direction: String, val amountDecimal: String, val date: String = "1970-01-01", val deletedAt: Long?)
data class GoalAssetRow(val id: String, val status: String, val acquisitionAmountDecimal: String, val createdAt: Long, val deletedAt: Long?)
data class GoalAssetValuationRow(val id: String, val assetId: String, val valueDecimal: String, val date: String, val createdAt: Long, val deletedAt: Long?)
data class GoalDebtAccountRow(val id: String, val direction: String, val confirmed: Boolean, val createdAt: Long, val deletedAt: Long?)
data class GoalDebtTransactionRow(val accountId: String, val type: String, val amountDecimal: String, val occurredAt: Long, val deletedAt: Long?)

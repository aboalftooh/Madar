package com.shift.app.domain.goals.measurement

import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.evaluation.GoalMeasurementProvider
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalExpenseRow
import com.shift.app.feature.goals.domain.model.GoalLegacyTransactionRow
import com.shift.app.feature.goals.domain.model.GoalMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

class ExpenseGoalMeasurementProvider(
    private val payments: suspend () -> List<GoalExpenseRow> = { emptyList() },
    private val legacyTransactions: suspend () -> List<GoalLegacyTransactionRow> = { emptyList() },
) : GoalMeasurementProvider {
    override suspend fun measure(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant): GoalMeasurement =
        measureRows(metric, aggregate, asOf, payments(), legacyTransactions())

    companion object {
        fun measureRows(metric: GoalMetric, aggregate: GoalAggregate, asOf: Instant, payments: List<GoalExpenseRow>, legacyTransactions: List<GoalLegacyTransactionRow>): GoalMeasurement {
            require(metric.metricType == MetricType.EXPENSE)
            val currentMonth = YearMonth.from(asOf.atZone(ZoneId.of(aggregate.goal.timezoneId)))
            val months = (1..metric.windowSize).map { currentMonth.minusMonths(it.toLong()) }.reversed()
            val excluded = aggregate.scopes.filter { it.deletedAt == null && it.dimension == ScopeDimension.EXPENSE_TRANSACTION && it.mode == "EXCLUDE" }.map { it.referenceId }.toSet()
            val paymentAmounts = payments.filter { it.deletedAt == null && it.id !in excluded && it.kind in setOf("ordinary_expense", "asset_maintenance", "debt_gift") }
                .map { YearMonth.parse(it.date.substring(0, 7)) to BigDecimal(it.amountDecimal) }
            val legacyAmounts = legacyTransactions.filter { it.deletedAt == null && it.type == "expense" && it.id !in excluded && it.balanceTransactionId == null }
                .map { YearMonth.parse(it.date.substring(0, 7)) to BigDecimal(it.amountDecimal) }
            val byMonth = (paymentAmounts + legacyAmounts).groupBy({ it.first }, { it.second }).mapValues { (_, values) -> values.fold(BigDecimal.ZERO, BigDecimal::add) }
            if (months.any { it !in byMonth }) return unavailable(metric, "missing-closed-expense-history")
            val average = months.fold(BigDecimal.ZERO) { acc, month -> acc + byMonth.getValue(month) }.divide(BigDecimal.valueOf(metric.windowSize.toLong()), 2, RoundingMode.HALF_UP)
            val streak = consecutiveAtOrBelow(byMonth, currentMonth, BigDecimal(aggregate.goal.targetDecimal), aggregate.goal.confirmationPeriods)
            return GoalMeasurement(metric.id, MetricType.EXPENSE, average.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                "expense:${months.joinToString(",")}:$average:excluded=${excluded.size}:streak=$streak", streak.toBigDecimal().setScale(2).toPlainString(), streak)
        }

        private fun consecutiveAtOrBelow(byMonth: Map<YearMonth, BigDecimal>, currentMonth: YearMonth, target: BigDecimal, periods: Int): Int {
            var streak = 0
            var cursor = currentMonth.minusMonths(1)
            while (streak < periods) {
                val value = byMonth[cursor] ?: break
                if (value > target) break
                streak++
                cursor = cursor.minusMonths(1)
            }
            return streak
        }

        private fun unavailable(metric: GoalMetric, reason: String) = GoalMeasurement(metric.id, metric.metricType, null, "expense:$reason", available = false, unavailableReason = reason)
    }
}

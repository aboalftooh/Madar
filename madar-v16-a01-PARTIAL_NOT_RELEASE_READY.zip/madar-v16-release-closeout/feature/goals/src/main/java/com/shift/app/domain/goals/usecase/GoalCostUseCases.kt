package com.shift.app.domain.goals.usecase

import com.shift.app.feature.goals.domain.model.GoalCostEstimate
import com.shift.app.feature.goals.domain.repository.GoalGateway
import java.util.UUID
import javax.inject.Inject

class GoalCostUseCases @Inject constructor(private val gateway: GoalGateway) {
    suspend fun appendCostEstimate(
        goalId: String,
        expectedDecimal: String,
        safeDecimal: String,
        currencyCode: String,
        source: String = "manual",
        note: String = "",
        operationId: String = UUID.randomUUID().toString(),
        now: Long = System.currentTimeMillis(),
        minDecimal: String? = null,
    ): GoalCostEstimate = gateway.recordCostEstimate(
        goalId, operationId, expectedDecimal, safeDecimal, currencyCode, source, note, now, minDecimal,
    )
}

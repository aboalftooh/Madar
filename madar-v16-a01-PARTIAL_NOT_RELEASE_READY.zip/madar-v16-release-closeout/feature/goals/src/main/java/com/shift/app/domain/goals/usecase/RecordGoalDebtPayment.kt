package com.shift.app.domain.goals.usecase

import com.shift.app.feature.goals.domain.repository.GoalCompletionPort
import java.util.UUID
import javax.inject.Inject

data class GoalDebtPaymentRequest(
    val goalId: String,
    val accountId: String,
    val partyName: String,
    val amountDecimal: String,
    val fromMadarBalance: Boolean,
    val completeGoalWhenPaidOff: Boolean = true,
    val operationId: String = UUID.randomUUID().toString(),
    val occurredAt: Long = System.currentTimeMillis(),
)

class RecordGoalDebtPayment @Inject constructor(private val port: GoalCompletionPort) {
    suspend fun record(request: GoalDebtPaymentRequest) = port.recordDebtPayment(request)
}

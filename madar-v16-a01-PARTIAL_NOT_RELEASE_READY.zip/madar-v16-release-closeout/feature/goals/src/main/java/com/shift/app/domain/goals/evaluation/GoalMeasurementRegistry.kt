package com.shift.app.domain.goals.evaluation

import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.domain.goals.model.MetricType
import java.time.Instant
import javax.inject.Singleton

data class GoalMeasurement(
    val metricId: String,
    val metricType: MetricType,
    val measuredDecimal: String?,
    val sourceFingerprint: String,
    val bestRateDecimal: String? = null,
    val confirmationStreak: Int? = null,
    val estimated: Boolean = false,
    val available: Boolean = measuredDecimal != null,
    val unavailableReason: String? = null,
) {
    init {
        require(metricId.isNotBlank() && sourceFingerprint.isNotBlank())
        require(confirmationStreak == null || confirmationStreak >= 0)
        require(!estimated || available)
        require(available == (measuredDecimal != null))
        if (!available) require(!unavailableReason.isNullOrBlank())
    }
}

fun interface GoalMeasurementProvider {
    suspend fun measure(
        metric: GoalMetric,
        aggregate: GoalAggregate,
        asOf: Instant,
    ): GoalMeasurement
}

/** Typed registry. Providers for concrete metrics are added by their template sessions. */
@Singleton
class GoalMeasurementRegistry {
    private val providers = linkedMapOf<MetricType, GoalMeasurementProvider>()

    @Synchronized
    fun register(metricType: MetricType, provider: GoalMeasurementProvider) {
        check(providers.putIfAbsent(metricType, provider) == null) {
            "A provider is already registered for $metricType"
        }
    }

    suspend fun measure(
        aggregate: GoalAggregate,
        asOf: Instant,
    ): List<GoalMeasurement> = aggregate.metrics
        .filter { it.deletedAt == null }
        .sortedWith(compareBy<GoalMetric> { it.ordinal }.thenBy { it.id })
        .map { metric ->
            val provider = synchronized(this) { providers[metric.metricType] }
            provider?.measure(metric, aggregate, asOf) ?: GoalMeasurement(
                metricId = metric.id,
                metricType = metric.metricType,
                measuredDecimal = null,
                sourceFingerprint = "missing-provider:${metric.metricType}",
                available = false,
                unavailableReason = "No measurement provider registered for ${metric.metricType}",
            )
        }
}

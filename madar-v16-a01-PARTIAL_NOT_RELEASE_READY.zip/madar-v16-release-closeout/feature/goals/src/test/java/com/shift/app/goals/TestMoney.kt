package com.shift.app.goals

import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale

internal fun money(value: String): String =
    DecimalText.canonical(value, DecimalTextScale.Money)

package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.model.FundingKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalFundingTest {
    @Test
    fun `allocation reduces available balance without changing real balance`() {
        val balance = listOf(
            GoalBalanceRow(id = "opening", direction = BalanceDirection.Inflow.dbValue, amountDecimal = money("1000"), date = "2026-07-18", deletedAt = null),
        )
        val funding = listOf(funding("f1", FundingKind.ALLOCATE, money("250")))

        val totals = GoalFundingCalculator.totals(balance, funding)

        assertEquals("1000.00", totals.realBalanceDecimal)
        assertEquals("250.00", totals.allocatedDecimal)
        assertEquals("750.00", totals.availableDecimal)
    }

    @Test
    fun `over allocation is rejected against real balance less active allocations`() {
        val balance = listOf(
            GoalBalanceRow(id = "opening", direction = BalanceDirection.Inflow.dbValue, amountDecimal = money("500"), date = "2026-07-18", deletedAt = null),
        )
        val funding = listOf(funding("f1", FundingKind.ALLOCATE, money("400")))

        assertTrue(GoalFundingCalculator.wouldOverAllocate(balance, funding, money("101")))
        assertFalse(GoalFundingCalculator.wouldOverAllocate(balance, funding, money("100")))
    }

    @Test
    fun `release and reversal apply the inverse funding effect`() {
        val allocate = funding("f1", FundingKind.ALLOCATE, money("300"))
        val release = funding("f2", FundingKind.RELEASE, money("50"))
        val reverseAllocate = funding(
            id = "f3",
            kind = FundingKind.REVERSAL,
            amount = money("300"),
            relatedFundingTransactionId = allocate.id,
        )
        val reverseRelease = funding(
            id = "f4",
            kind = FundingKind.REVERSAL,
            amount = money("50"),
            relatedFundingTransactionId = release.id,
        )

        assertEquals("250.00", GoalFundingCalculator.allocatedForGoal(listOf(allocate, release)).toPlainString())
        assertEquals(
            "0.00",
            GoalFundingCalculator.allocatedForGoal(listOf(allocate, release, reverseAllocate, reverseRelease)).toPlainString(),
        )
    }

    @Test
    fun `spending above available requires allocation decision and reports exact shortfall`() {
        val balance = listOf(
            GoalBalanceRow(id = "opening", direction = BalanceDirection.Inflow.dbValue, amountDecimal = money("1000"), date = "2026-07-18", deletedAt = null),
        )
        val funding = listOf(funding("f1", FundingKind.ALLOCATE, money("400")))

        val withinAvailable = GoalFundingCalculator.spendingImpact(balance, funding, money("600"))
        val aboveAvailable = GoalFundingCalculator.spendingImpact(balance, funding, money("750"))

        assertFalse(withinAvailable.requiresAllocationDecision)
        assertEquals("0.00", withinAvailable.shortfallDecimal)
        assertTrue(aboveAvailable.requiresAllocationDecision)
        assertEquals("150.00", aboveAvailable.shortfallDecimal)
        assertEquals("-150.00", aboveAvailable.availableAfterWithoutReleaseDecimal)
    }

    @Test
    fun `remaining allocation subtracts releases tied to the selected allocation`() {
        val allocation = funding("f1", FundingKind.ALLOCATE, money("400"))
        val release = funding(
            "f2",
            FundingKind.RELEASE,
            money("125"),
            relatedFundingTransactionId = allocation.id,
        )

        assertEquals(
            "275.00",
            GoalFundingCalculator.remainingForAllocation(allocation.id, listOf(allocation, release)).toPlainString(),
        )
    }

    private fun funding(
        id: String,
        kind: FundingKind,
        amount: String,
        relatedFundingTransactionId: String? = null,
    ) = GoalFundingTransaction(
        id = id,
        goalId = "goal-1",
        operationId = "op-$id",
        kind = kind,
        amountDecimal = amount,
        currencyCode = "SDG",
        balanceTransactionId = null,
        relatedFundingTransactionId = relatedFundingTransactionId,
        note = "",
        occurredAt = 1,
        createdAt = 1,
        updatedAt = 1,
        deletedAt = null,
        syncState = "PENDING",
    )
}

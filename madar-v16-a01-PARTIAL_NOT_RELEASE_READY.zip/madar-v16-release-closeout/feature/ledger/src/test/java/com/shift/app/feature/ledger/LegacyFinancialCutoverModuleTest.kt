package com.shift.app.feature.ledger

import com.shift.app.domain.finance.LegacyFinancialAmountRow
import com.shift.app.domain.finance.LegacyFinancialCutoverDecision
import com.shift.app.domain.finance.LegacyFinancialCutoverPlanner
import com.shift.app.domain.finance.LegacyFinancialRowKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LegacyFinancialCutoverModuleTest {
    @Test
    fun `fingerprint is deterministic and parity is exact`() {
        val rows = listOf(
            LegacyFinancialAmountRow("income-1", LegacyFinancialRowKind.Income, "100.00"),
            LegacyFinancialAmountRow("expense-1", LegacyFinancialRowKind.Expense, "25.00"),
        )
        val first = LegacyFinancialCutoverPlanner.plan("a".repeat(64), "b".repeat(64), 2, 0, 0, rows, rows.reversed())
        val second = LegacyFinancialCutoverPlanner.plan("a".repeat(64), "b".repeat(64), 2, 0, 0, rows.reversed(), rows)

        assertEquals(first.fingerprint, second.fingerprint)
        assertTrue(first.parity.exact)
        assertEquals(
            LegacyFinancialCutoverDecision.AlreadyCompleted,
            LegacyFinancialCutoverPlanner.executionDecision(first.fingerprint, first.fingerprint),
        )
    }
}

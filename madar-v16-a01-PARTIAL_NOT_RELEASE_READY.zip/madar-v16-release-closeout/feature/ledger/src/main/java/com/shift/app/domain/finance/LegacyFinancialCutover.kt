package com.shift.app.domain.finance

import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest

enum class LegacyFinancialRowKind {
    Income,
    Expense,
    Receivable,
    Payable,
}

data class LegacyFinancialAmountRow(
    val sourceId: String,
    val kind: LegacyFinancialRowKind,
    val amountDecimal: String,
    val excludedFromCanonical: Boolean = false,
) {
    init {
        require(sourceId.isNotBlank()) { "Source id must not be blank" }
        require(DecimalText.toBigDecimal(amountDecimal).signum() >= 0) {
            "Financial amount must not be negative"
        }
    }
}

data class FinancialParityTotals(
    val incomeDecimal: String,
    val expenseDecimal: String,
    val receivableDecimal: String,
    val payableDecimal: String,
) {
    fun value(kind: LegacyFinancialRowKind): BigDecimal = when (kind) {
        LegacyFinancialRowKind.Income -> DecimalText.toBigDecimal(incomeDecimal)
        LegacyFinancialRowKind.Expense -> DecimalText.toBigDecimal(expenseDecimal)
        LegacyFinancialRowKind.Receivable -> DecimalText.toBigDecimal(receivableDecimal)
        LegacyFinancialRowKind.Payable -> DecimalText.toBigDecimal(payableDecimal)
    }
}

data class FinancialParityDifference(
    val kind: LegacyFinancialRowKind,
    val sourceDecimal: String,
    val canonicalDecimal: String,
    val differenceDecimal: String,
)

data class FinancialParityReport(
    val source: FinancialParityTotals,
    val canonical: FinancialParityTotals,
    val differences: List<FinancialParityDifference>,
) {
    val exact: Boolean = differences.all {
        DecimalText.toBigDecimal(it.differenceDecimal).signum() == 0
    }

    fun requireExact() {
        require(exact) {
            val details = differences
                .filter { DecimalText.toBigDecimal(it.differenceDecimal).signum() != 0 }
                .joinToString { "${it.kind}:${it.differenceDecimal}" }
            "Financial cutover parity mismatch: $details"
        }
    }
}

data class LegacyFinancialCutoverPlan(
    val fingerprint: String,
    val historyCommitFingerprint: String,
    val debtSourceFingerprint: String,
    val transactionCandidateCount: Int,
    val debtCandidateCount: Int,
    val debtReviewCount: Int,
    val parity: FinancialParityReport,
) {
    init {
        require(fingerprint.matches(Regex("[0-9a-f]{64}"))) { "Invalid cutover fingerprint" }
        require(historyCommitFingerprint.matches(Regex("[0-9a-f]{64}"))) {
            "Invalid history fingerprint"
        }
        require(debtSourceFingerprint.matches(Regex("[0-9a-f]{64}"))) {
            "Invalid debt fingerprint"
        }
        require(transactionCandidateCount >= 0)
        require(debtCandidateCount >= 0)
        require(debtReviewCount >= 0)
    }
}

enum class LegacyFinancialCutoverDecision {
    Execute,
    AlreadyCompleted,
    Conflict,
}

enum class LegacyFinancialRollbackDecision {
    Allowed,
    BlockedBySyncedRows,
    BlockedByChangedSource,
    NothingToRollback,
}

object LegacyFinancialCutoverPlanner {
    fun plan(
        historyCommitFingerprint: String,
        debtSourceFingerprint: String,
        transactionCandidateCount: Int,
        debtCandidateCount: Int,
        debtReviewCount: Int,
        sourceRows: List<LegacyFinancialAmountRow>,
        canonicalRows: List<LegacyFinancialAmountRow>,
    ): LegacyFinancialCutoverPlan {
        val parity = parity(sourceRows, canonicalRows)
        val fingerprint = fingerprint(
            buildList {
                add("legacy-financial-cutover-v1")
                add("history=$historyCommitFingerprint")
                add("debts=$debtSourceFingerprint")
                add("tx-count=$transactionCandidateCount")
                add("debt-count=$debtCandidateCount")
                add("review-count=$debtReviewCount")
                addAll(fingerprintRows("source", sourceRows))
                addAll(fingerprintRows("canonical", canonicalRows))
            },
        )
        return LegacyFinancialCutoverPlan(
            fingerprint = fingerprint,
            historyCommitFingerprint = historyCommitFingerprint,
            debtSourceFingerprint = debtSourceFingerprint,
            transactionCandidateCount = transactionCandidateCount,
            debtCandidateCount = debtCandidateCount,
            debtReviewCount = debtReviewCount,
            parity = parity,
        )
    }

    fun parity(
        sourceRows: List<LegacyFinancialAmountRow>,
        canonicalRows: List<LegacyFinancialAmountRow>,
    ): FinancialParityReport {
        val source = totals(sourceRows)
        val canonical = totals(canonicalRows.filterNot { it.excludedFromCanonical })
        val differences = LegacyFinancialRowKind.entries.map { kind ->
            val sourceValue = source.value(kind)
            val canonicalValue = canonical.value(kind)
            FinancialParityDifference(
                kind = kind,
                sourceDecimal = sourceValue.moneyText(),
                canonicalDecimal = canonicalValue.moneyText(),
                differenceDecimal = canonicalValue.subtract(sourceValue).moneyText(),
            )
        }
        return FinancialParityReport(source, canonical, differences)
    }

    fun executionDecision(
        storedFingerprint: String?,
        expectedFingerprint: String,
    ): LegacyFinancialCutoverDecision = when {
        storedFingerprint == null -> LegacyFinancialCutoverDecision.Execute
        storedFingerprint == expectedFingerprint -> LegacyFinancialCutoverDecision.AlreadyCompleted
        else -> LegacyFinancialCutoverDecision.Conflict
    }

    fun rollbackDecision(
        hasMigrationRows: Boolean,
        allRowsPending: Boolean,
        currentFingerprint: String,
        expectedFingerprint: String,
    ): LegacyFinancialRollbackDecision = when {
        !hasMigrationRows -> LegacyFinancialRollbackDecision.NothingToRollback
        currentFingerprint != expectedFingerprint -> LegacyFinancialRollbackDecision.BlockedByChangedSource
        !allRowsPending -> LegacyFinancialRollbackDecision.BlockedBySyncedRows
        else -> LegacyFinancialRollbackDecision.Allowed
    }

    private fun totals(rows: List<LegacyFinancialAmountRow>): FinancialParityTotals {
        val values = LegacyFinancialRowKind.entries.associateWith { BigDecimal.ZERO }
            .toMutableMap()
        rows.forEach { row ->
            val value = DecimalText.toBigDecimal(row.amountDecimal)
            values[row.kind] = requireNotNull(values[row.kind]).add(value)
        }
        return FinancialParityTotals(
            incomeDecimal = requireNotNull(values[LegacyFinancialRowKind.Income]).moneyText(),
            expenseDecimal = requireNotNull(values[LegacyFinancialRowKind.Expense]).moneyText(),
            receivableDecimal = requireNotNull(values[LegacyFinancialRowKind.Receivable]).moneyText(),
            payableDecimal = requireNotNull(values[LegacyFinancialRowKind.Payable]).moneyText(),
        )
    }

    private fun fingerprintRows(
        prefix: String,
        rows: List<LegacyFinancialAmountRow>,
    ): List<String> = rows.sortedWith(
        compareBy<LegacyFinancialAmountRow> { it.kind.name }
            .thenBy { it.sourceId }
            .thenBy { it.amountDecimal },
    ).map { row ->
        "$prefix|${row.kind.name}|${row.sourceId}|${row.amountDecimal}|${row.excludedFromCanonical}"
    }

    private fun fingerprint(parts: List<String>): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(parts.joinToString("\n").toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun BigDecimal.moneyText(): String =
        setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()
}

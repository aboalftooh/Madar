package com.shift.app.feature.debts.domain.model

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import java.util.UUID

private fun newId(): String = UUID.randomUUID().toString()

data class OpenDebtRequest(
    val direction: DebtDirection,
    val partyName: String,
    val amountDecimal: String,
    val dueDate: String? = null,
    val includeInActivePayoffGoal: Boolean = false,
    val operationId: String = newId(),
    val accountId: String = newId(),
)

data class CashPrincipalRequest(
    val accountId: String?,
    val direction: DebtDirection,
    val partyName: String,
    val amountDecimal: String,
    val cashSource: DebtCashSource,
    val operationId: String = newId(),
    val newAccountId: String = newId(),
)

data class DeferredExpenseRequest(
    val partyName: String,
    val amountDecimal: String,
    val purpose: String,
    val note: String = "",
    val operationId: String = newId(),
    val accountId: String = newId(),
)

data class AccruedIncomeRequest(
    val partyName: String,
    val amountDecimal: String,
    val incomeCategory: String,
    val note: String = "",
    val operationId: String = newId(),
    val accountId: String = newId(),
)

data class FinancedAssetPurchaseRequest(
    val partyName: String,
    val assetType: String,
    val assetName: String,
    val financedAmountDecimal: String,
    val assetValueDecimal: String,
    val cashPaidDecimal: String,
    val operationId: String = newId(),
    val accountId: String = newId(),
    val assetId: String = newId(),
)

data class AssetSaleOnCreditRequest(
    val assetId: String,
    val buyerName: String,
    val saleAmountDecimal: String,
    val cashCollectedDecimal: String,
    val operationId: String = newId(),
    val accountId: String = newId(),
)

data class ReduceDebtRequest(
    val accountId: String,
    val amountDecimal: String,
    val cashSource: DebtCashSource = DebtCashSource.External,
    val operationId: String = newId(),
)

data class AdjustDebtRequest(
    val accountId: String,
    val type: DebtTransactionType,
    val amountDecimal: String,
    val reason: String,
    val operationId: String = newId(),
)

data class AssetSettlementRequest(
    val accountId: String,
    val assetId: String,
    val amountDecimal: String,
    val assetValueDecimal: String,
    val reason: String,
    val operationId: String = newId(),
)

data class OffsetDebtRequest(
    val payableAccountId: String,
    val receivableAccountId: String,
    val amountDecimal: String,
    val reason: String,
    val operationId: String = newId(),
)

data class ReverseDebtTransactionRequest(
    val originalTransactionId: String,
    val reason: String,
    val operationId: String = newId(),
)

data class TransferDebtRequest(
    val accountId: String,
    val newPartyName: String,
    val amountDecimal: String,
    val reason: String,
    val operationId: String = newId(),
    val targetAccountId: String = newId(),
)

data class WriteDebtScheduleRequest(
    val accountId: String,
    val totalAmountDecimal: String,
    val firstDueDate: String,
    val count: Int,
    val operationId: String = newId(),
)

data class ArchiveDebtRequest(
    val accountId: String,
    val reason: String,
    val operationId: String = newId(),
)

package com.shift.app.feature.debts.domain.repository

import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.model.DebtCommandReceipt
import com.shift.app.feature.debts.domain.model.DebtMigrationReview
import com.shift.app.feature.debts.domain.model.DebtSettlementAsset
import com.shift.app.feature.debts.domain.model.DebtTransaction
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import kotlinx.coroutines.flow.Flow

interface DebtGateway {
    fun observeAccounts(): Flow<List<DebtAccount>>
    fun observeTransactions(): Flow<List<DebtTransaction>>
    fun observeMigrationReviews(): Flow<List<DebtMigrationReview>>
    fun observeSettlementAssets(): Flow<List<DebtSettlementAsset>>

    suspend fun open(request: OpenDebtRequest): DebtCommandReceipt
    suspend fun recordCashPrincipal(request: CashPrincipalRequest): DebtCommandReceipt
    suspend fun recordDeferredExpense(request: DeferredExpenseRequest): DebtCommandReceipt
    suspend fun recordAccruedIncome(request: AccruedIncomeRequest): DebtCommandReceipt
    suspend fun recordFinancedAssetPurchase(request: FinancedAssetPurchaseRequest): DebtCommandReceipt
    suspend fun recordAssetSaleOnCredit(request: AssetSaleOnCreditRequest): DebtCommandReceipt
    suspend fun reduce(request: ReduceDebtRequest): DebtCommandReceipt
    suspend fun adjust(request: AdjustDebtRequest): DebtCommandReceipt
    suspend fun settleWithAsset(request: AssetSettlementRequest): DebtCommandReceipt
    suspend fun offset(request: OffsetDebtRequest): DebtCommandReceipt
    suspend fun reverse(request: ReverseDebtTransactionRequest): DebtCommandReceipt
    suspend fun transfer(request: TransferDebtRequest): DebtCommandReceipt
    suspend fun writeSchedule(request: WriteDebtScheduleRequest): DebtCommandReceipt
    suspend fun archive(request: ArchiveDebtRequest): DebtCommandReceipt
}

interface DebtSettlementAssetQuery {
    fun observeAvailableAssets(): Flow<List<DebtSettlementAsset>>
}

interface DebtGoalScopePort {
    suspend fun recordNewDebtDecision(accountId: String, include: Boolean, operationId: String, now: Long)
}

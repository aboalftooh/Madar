package com.shift.app.feature.debts.domain.model

import com.shift.app.domain.debt.DebtAccountStatus

data class DebtAccount(
    val id: String,
    val operationId: String,
    val direction: String,
    val partyName: String,
    val currencyCode: String,
    val dueDate: String?,
    val confirmed: Boolean,
    val archivedAt: Long?,
    val closedAt: Long?,
    val legacyDebtId: String?,
    val syncState: String,
    val deletedAt: Long?,
)

data class DebtTransaction(
    val id: String,
    val accountId: String,
    val operationId: String,
    val type: String,
    val amountDecimal: String,
    val occurredAt: Long,
    val reason: String?,
    val originalTransactionId: String?,
    val createdAt: Long,
    val deletedAt: Long?,
)

data class DebtMigrationReview(
    val id: String,
    val legacyDebtId: String,
    val proposedAccountId: String?,
    val status: String,
    val deletedAt: Long?,
)

data class DebtSettlementAsset(
    val id: String,
    val name: String,
    val valueDecimal: String,
)

data class DebtPayoffAccountOption(
    val id: String,
    val partyName: String,
    val direction: String,
)

data class DebtAccountSummary(
    val id: String,
    val partyName: String,
    val direction: String,
    val remainingDecimal: String,
    val dueDate: String?,
    val status: String,
    val calculatedStatus: DebtAccountStatus,
    val syncState: String,
    val needsReview: Boolean,
)

data class DebtTimelineItem(
    val id: String,
    val title: String,
    val amountDecimal: String,
    val occurredAt: Long,
    val operationId: String,
)

data class DebtCenterSnapshot(
    val accounts: List<DebtAccountSummary> = emptyList(),
    val timelinesByAccount: Map<String, List<DebtTimelineItem>> = emptyMap(),
    val activeAssets: List<DebtSettlementAsset> = emptyList(),
    val pendingMigrationReviews: Int = 0,
    val resolvedMigrationReviews: Int = 0,
    val totalReceivableDecimal: String = "0.00",
    val totalPayableDecimal: String = "0.00",
    val netDecimal: String = "0.00",
)

data class DebtCommandReceipt(
    val operationId: String,
    val accountId: String? = null,
    val syncRequested: Boolean,
)

class DebtSessionExpiredException : IllegalStateException("انتهت الجلسة؛ أعد تسجيل الدخول")

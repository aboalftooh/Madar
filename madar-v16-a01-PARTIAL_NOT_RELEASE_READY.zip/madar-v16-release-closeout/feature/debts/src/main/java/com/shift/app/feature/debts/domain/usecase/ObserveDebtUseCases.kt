package com.shift.app.feature.debts.domain.usecase

import com.shift.app.domain.debt.DebtAccountSnapshot
import com.shift.app.domain.debt.DebtAccountStatus
import com.shift.app.domain.debt.DebtCalculator
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtMoney
import com.shift.app.domain.debt.DebtReviewStatus
import com.shift.app.domain.debt.DebtTransactionInput
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.model.DebtAccountSummary
import com.shift.app.feature.debts.domain.model.DebtCenterSnapshot
import com.shift.app.feature.debts.domain.model.DebtPayoffAccountOption
import com.shift.app.feature.debts.domain.model.DebtTimelineItem
import com.shift.app.feature.debts.domain.model.DebtTransaction
import com.shift.app.feature.debts.domain.repository.DebtGateway
import java.math.BigDecimal
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class ObserveDebtCenterUseCase @Inject constructor(
    private val gateway: DebtGateway,
) {
    operator fun invoke(today: () -> LocalDate = LocalDate::now): Flow<DebtCenterSnapshot> = combine(
        gateway.observeAccounts(),
        gateway.observeTransactions(),
        gateway.observeMigrationReviews(),
        gateway.observeSettlementAssets(),
    ) { accounts, transactions, reviews, assets ->
        val activeAccounts = accounts.filter { it.deletedAt == null }
        val activeTransactions = transactions.filter { it.deletedAt == null }
        val transactionsByAccount = activeTransactions.groupBy(DebtTransaction::accountId)
        val pendingReviews = reviews.filter { it.deletedAt == null && it.status == DebtReviewStatus.Pending.dbValue }
        val resolvedReviews = reviews.filter { it.deletedAt == null && it.status != DebtReviewStatus.Pending.dbValue }
        var receivableTotal = BigDecimal.ZERO
        var payableTotal = BigDecimal.ZERO

        val summaries = activeAccounts.map { account ->
            val calculation = DebtCalculator.calculate(account.toSnapshot(transactionsByAccount[account.id].orEmpty()))
            receivableTotal += calculation.confirmedReceivableDecimal.toBigDecimal()
            payableTotal += calculation.confirmedPayableDecimal.toBigDecimal()
            DebtAccountSummary(
                id = account.id,
                partyName = account.partyName,
                direction = account.direction,
                remainingDecimal = calculation.remainingDecimal,
                dueDate = account.dueDate,
                status = account.statusFrom(calculation.status, today()),
                calculatedStatus = calculation.status,
                syncState = account.syncState,
                needsReview = calculation.status == DebtAccountStatus.NeedsReview || pendingReviews.any {
                    it.proposedAccountId == account.id || it.legacyDebtId == account.legacyDebtId
                },
            )
        }

        DebtCenterSnapshot(
            accounts = summaries,
            timelinesByAccount = transactionsByAccount.mapValues { (_, rows) ->
                rows.sortedWith(compareBy<DebtTransaction> { it.occurredAt }.thenBy { it.createdAt }).map { tx ->
                    DebtTimelineItem(tx.id, tx.type, tx.amountDecimal, tx.occurredAt, tx.operationId)
                }
            },
            activeAssets = assets,
            pendingMigrationReviews = pendingReviews.size,
            resolvedMigrationReviews = resolvedReviews.size,
            totalReceivableDecimal = receivableTotal.setScale(2).toPlainString(),
            totalPayableDecimal = payableTotal.setScale(2).toPlainString(),
            netDecimal = receivableTotal.subtract(payableTotal).setScale(2).toPlainString(),
        )
    }

    private fun DebtAccount.statusFrom(calculated: DebtAccountStatus, today: LocalDate): String {
        if (calculated == DebtAccountStatus.Settled || closedAt != null) return "settled"
        if (calculated == DebtAccountStatus.Archived || archivedAt != null) return "archived"
        if (calculated == DebtAccountStatus.NeedsReview) return "needs_review"
        val due = dueDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return "no_date"
        return when {
            due.isBefore(today) -> "overdue"
            due == today -> "due_today"
            else -> "upcoming"
        }
    }

    private fun DebtAccount.toSnapshot(transactions: List<DebtTransaction>) = DebtAccountSnapshot(
        accountId = id,
        direction = DebtDirection.fromDb(direction),
        partyName = partyName,
        currencyCode = currencyCode,
        confirmed = confirmed,
        archived = archivedAt != null,
        transactions = transactions.map { it.toInput() },
    )

    private fun DebtTransaction.toInput() = DebtTransactionInput(
        id = id,
        accountId = accountId,
        operationId = operationId,
        type = DebtTransactionType.fromDb(type),
        amount = DebtMoney.of(amountDecimal),
        occurredAtEpochMillis = occurredAt,
        reason = reason,
        originalTransactionId = originalTransactionId,
        isVoided = deletedAt != null,
    )
}

class ObservePayableDebtAccountsUseCase @Inject constructor(
    private val gateway: DebtGateway,
) {
    operator fun invoke(): Flow<List<DebtPayoffAccountOption>> = gateway.observeAccounts().map { accounts ->
        accounts.asSequence()
            .filter { it.deletedAt == null && it.archivedAt == null && it.confirmed }
            .filter { it.direction == DebtDirection.Payable.dbValue }
            .map { DebtPayoffAccountOption(it.id, it.partyName, it.direction) }
            .toList()
    }
}

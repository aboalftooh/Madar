package com.shift.app.feature.debts.domain.usecase

import com.shift.app.domain.debt.DebtMoney
import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DebtCommandReceipt
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import com.shift.app.feature.debts.domain.repository.DebtGateway
import javax.inject.Inject

class DebtCommandUseCases @Inject constructor(
    private val gateway: DebtGateway,
) {
    suspend fun open(request: OpenDebtRequest): DebtCommandReceipt = gateway.open(
        request.copy(amountDecimal = money(request.amountDecimal)),
    )

    suspend fun cashPrincipal(request: CashPrincipalRequest) = gateway.recordCashPrincipal(
        request.copy(amountDecimal = money(request.amountDecimal)),
    )

    suspend fun deferredExpense(request: DeferredExpenseRequest) = gateway.recordDeferredExpense(
        request.copy(amountDecimal = money(request.amountDecimal)),
    )

    suspend fun accruedIncome(request: AccruedIncomeRequest) = gateway.recordAccruedIncome(
        request.copy(amountDecimal = money(request.amountDecimal)),
    )

    suspend fun financedAsset(request: FinancedAssetPurchaseRequest) = gateway.recordFinancedAssetPurchase(
        request.copy(
            financedAmountDecimal = money(request.financedAmountDecimal),
            assetValueDecimal = money(request.assetValueDecimal),
            cashPaidDecimal = money(request.cashPaidDecimal.ifBlank { "0.00" }),
        ),
    )

    suspend fun assetSaleOnCredit(request: AssetSaleOnCreditRequest) = gateway.recordAssetSaleOnCredit(
        request.copy(
            saleAmountDecimal = money(request.saleAmountDecimal),
            cashCollectedDecimal = money(request.cashCollectedDecimal.ifBlank { "0.00" }),
        ),
    )

    suspend fun reduce(request: ReduceDebtRequest) = gateway.reduce(request.copy(amountDecimal = money(request.amountDecimal)))
    suspend fun adjust(request: AdjustDebtRequest) = gateway.adjust(request.copy(amountDecimal = money(request.amountDecimal)))
    suspend fun settleWithAsset(request: AssetSettlementRequest) = gateway.settleWithAsset(
        request.copy(amountDecimal = money(request.amountDecimal), assetValueDecimal = money(request.assetValueDecimal)),
    )
    suspend fun offset(request: OffsetDebtRequest) = gateway.offset(request.copy(amountDecimal = money(request.amountDecimal)))
    suspend fun reverse(request: ReverseDebtTransactionRequest) = gateway.reverse(request)
    suspend fun transfer(request: TransferDebtRequest) = gateway.transfer(request.copy(amountDecimal = money(request.amountDecimal)))
    suspend fun writeSchedule(request: WriteDebtScheduleRequest) = gateway.writeSchedule(
        request.copy(totalAmountDecimal = money(request.totalAmountDecimal)),
    )
    suspend fun archive(request: ArchiveDebtRequest) = gateway.archive(request)

    private fun money(value: String): String = DebtMoney.of(value).decimalText
}

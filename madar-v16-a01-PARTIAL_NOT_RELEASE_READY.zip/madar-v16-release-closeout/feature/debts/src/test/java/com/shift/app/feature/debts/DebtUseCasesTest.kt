package com.shift.app.feature.debts

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtReviewStatus
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.model.DebtCommandReceipt
import com.shift.app.feature.debts.domain.model.DebtMigrationReview
import com.shift.app.feature.debts.domain.model.DebtSettlementAsset
import com.shift.app.feature.debts.domain.model.DebtTransaction
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import com.shift.app.feature.debts.domain.repository.DebtGateway
import com.shift.app.feature.debts.domain.usecase.DebtCommandUseCases
import com.shift.app.feature.debts.domain.usecase.ObserveDebtCenterUseCase
import com.shift.app.feature.debts.domain.usecase.ObservePayableDebtAccountsUseCase
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtUseCasesTest {
    @Test
    fun `center calculates totals timelines reviews and deterministic due status`() = runBlocking {
        val gateway = FakeDebtGateway()
        gateway.accounts.value = listOf(
            account("p", DebtDirection.Payable, "مورد", "2026-07-24"),
            account("r", DebtDirection.Receivable, "عميل", "2026-07-25"),
        )
        gateway.transactions.value = listOf(
            transaction("tp", "p", "100.00"),
            transaction("tr", "r", "70.00"),
        )
        gateway.reviews.value = listOf(
            DebtMigrationReview("review", "legacy", "p", DebtReviewStatus.Pending.dbValue, null),
        )
        gateway.assets.value = listOf(DebtSettlementAsset("asset", "سيارة", "500.00"))

        val center = ObserveDebtCenterUseCase(gateway).invoke { LocalDate.of(2026, 7, 25) }.first()

        assertEquals("70.00", center.totalReceivableDecimal)
        assertEquals("100.00", center.totalPayableDecimal)
        assertEquals("-30.00", center.netDecimal)
        assertEquals("overdue", center.accounts.first { it.id == "p" }.status)
        assertEquals("due_today", center.accounts.first { it.id == "r" }.status)
        assertTrue(center.accounts.first { it.id == "p" }.needsReview)
        assertEquals("tp", center.timelinesByAccount.getValue("p").single().id)
        assertEquals("asset", center.activeAssets.single().id)
    }

    @Test
    fun `payoff options expose confirmed active payable accounts only`() = runBlocking {
        val gateway = FakeDebtGateway()
        gateway.accounts.value = listOf(
            account("payable", DebtDirection.Payable, "أ", null),
            account("receivable", DebtDirection.Receivable, "ب", null),
            account("unconfirmed", DebtDirection.Payable, "ج", null).copy(confirmed = false),
            account("archived", DebtDirection.Payable, "د", null).copy(archivedAt = 1L),
        )

        val options = ObservePayableDebtAccountsUseCase(gateway)().first()

        assertEquals(listOf("payable"), options.map { it.id })
    }

    @Test
    fun `command use case canonicalizes decimal before asset settlement`() = runBlocking {
        val gateway = FakeDebtGateway()
        val request = AssetSettlementRequest(
            accountId = "account",
            assetId = "asset",
            amountDecimal = "10",
            assetValueDecimal = "12.5",
            reason = "تسوية",
            operationId = "op-settle",
        )

        val receipt = DebtCommandUseCases(gateway).settleWithAsset(request)

        assertEquals("10.00", gateway.lastSettlement?.amountDecimal)
        assertEquals("12.50", gateway.lastSettlement?.assetValueDecimal)
        assertEquals("op-settle", receipt.operationId)
    }

    private fun account(id: String, direction: DebtDirection, party: String, dueDate: String?) = DebtAccount(
        id = id,
        operationId = "op-$id",
        direction = direction.dbValue,
        partyName = party,
        currencyCode = "SDG",
        dueDate = dueDate,
        confirmed = true,
        archivedAt = null,
        closedAt = null,
        legacyDebtId = if (id == "p") "legacy" else null,
        syncState = "pending",
        deletedAt = null,
    )

    private fun transaction(id: String, accountId: String, amount: String) = DebtTransaction(
        id = id,
        accountId = accountId,
        operationId = "op-$id",
        type = DebtTransactionType.Opening.dbValue,
        amountDecimal = amount,
        occurredAt = 1L,
        reason = null,
        originalTransactionId = null,
        createdAt = 1L,
        deletedAt = null,
    )
}

private class FakeDebtGateway : DebtGateway {
    val accounts = MutableStateFlow<List<DebtAccount>>(emptyList())
    val transactions = MutableStateFlow<List<DebtTransaction>>(emptyList())
    val reviews = MutableStateFlow<List<DebtMigrationReview>>(emptyList())
    val assets = MutableStateFlow<List<DebtSettlementAsset>>(emptyList())
    var lastSettlement: AssetSettlementRequest? = null

    override fun observeAccounts() = accounts
    override fun observeTransactions() = transactions
    override fun observeMigrationReviews() = reviews
    override fun observeSettlementAssets() = assets
    override suspend fun open(request: OpenDebtRequest) = receipt(request.operationId, request.accountId)
    override suspend fun recordCashPrincipal(request: CashPrincipalRequest) = receipt(request.operationId, request.accountId)
    override suspend fun recordDeferredExpense(request: DeferredExpenseRequest) = receipt(request.operationId, request.accountId)
    override suspend fun recordAccruedIncome(request: AccruedIncomeRequest) = receipt(request.operationId, request.accountId)
    override suspend fun recordFinancedAssetPurchase(request: FinancedAssetPurchaseRequest) = receipt(request.operationId, request.accountId)
    override suspend fun recordAssetSaleOnCredit(request: AssetSaleOnCreditRequest) = receipt(request.operationId, request.accountId)
    override suspend fun reduce(request: ReduceDebtRequest) = receipt(request.operationId, request.accountId)
    override suspend fun adjust(request: AdjustDebtRequest) = receipt(request.operationId, request.accountId)
    override suspend fun settleWithAsset(request: AssetSettlementRequest): DebtCommandReceipt {
        lastSettlement = request
        return receipt(request.operationId, request.accountId)
    }
    override suspend fun offset(request: OffsetDebtRequest) = receipt(request.operationId, request.payableAccountId)
    override suspend fun reverse(request: ReverseDebtTransactionRequest) = receipt(request.operationId)
    override suspend fun transfer(request: TransferDebtRequest) = receipt(request.operationId, request.targetAccountId)
    override suspend fun writeSchedule(request: WriteDebtScheduleRequest) = receipt(request.operationId, request.accountId)
    override suspend fun archive(request: ArchiveDebtRequest) = receipt(request.operationId, request.accountId)
    private fun receipt(operationId: String, accountId: String? = null) = DebtCommandReceipt(operationId, accountId, true)
}

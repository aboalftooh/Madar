package com.shift.app.feature.assets

import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetCommandReceipt
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetLot
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleAllocation
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import com.shift.app.feature.assets.domain.repository.AssetGateway
import com.shift.app.feature.assets.domain.usecase.CreateAssetUseCase
import com.shift.app.feature.assets.domain.usecase.ObserveAssetSummariesUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetUseCasesTest {
    @Test
    fun `summary uses latest valuation and adds improvements to acquisition`() = runBlocking {
        val gateway = FakeAssetGateway()
        gateway.assets.value = listOf(asset(acquisition = "100.00"))
        gateway.transactions.value = listOf(
            transaction(kind = AssetTransactionKind.Improvement.dbValue, amount = "25.00"),
            transaction(id = "maintenance", kind = AssetTransactionKind.Maintenance.dbValue, amount = "10.00"),
        )
        gateway.valuations.value = listOf(
            valuation(id = "old", value = "120.00", date = "2026-01-01", createdAt = 1L),
            valuation(id = "new", value = "130.00", date = "2026-02-01", createdAt = 2L),
        )

        val summary = ObserveAssetSummariesUseCase(gateway)().first().single()

        assertEquals("130.00", summary.currentValueDecimal)
        assertEquals("125.00", summary.totalInvestmentDecimal)
    }

    @Test
    fun `currency summary uses lots minus allocations`() = runBlocking {
        val gateway = FakeAssetGateway()
        gateway.assets.value = listOf(asset(type = "foreign_currency", acquisition = "0.00"))
        gateway.lots.value = listOf(
            CurrencyAssetLot(
                id = "lot-1",
                operationId = "op-lot",
                assetId = "asset-1",
                purchaseAssetTransactionId = "tx-lot",
                foreignCurrencyCode = "USD",
                quantityPurchasedDecimal = "10.00000000",
                purchaseExchangeRateDecimal = "500.00000000",
                localCostDecimal = "5000.00",
                purchaseDate = "2026-01-01",
                createdAt = 1L,
                updatedAt = 1L,
                deletedAt = null,
            ),
        )
        gateway.allocations.value = listOf(
            CurrencyAssetSaleAllocation(
                id = "allocation-1",
                operationId = "op-sale",
                assetId = "asset-1",
                saleAssetTransactionId = "tx-sale",
                lotId = "lot-1",
                quantitySoldDecimal = "3.00000000",
                allocatedLocalCostDecimal = "1500.00",
                createdAt = 2L,
                updatedAt = 2L,
                deletedAt = null,
            ),
        )

        val summary = ObserveAssetSummariesUseCase(gateway)().first().single()

        assertEquals("7.00000000", summary.availableCurrencyQuantityDecimal)
        assertEquals("5000.00", summary.totalInvestmentDecimal)
    }

    @Test
    fun `create use case delegates without data dependency`() = runBlocking {
        val gateway = FakeAssetGateway()
        val request = PurchaseAssetRequest(
            name = "حاسوب",
            type = "laptop",
            amountDecimal = "500.00",
            date = "2026-07-25",
            operationId = "op-purchase",
        )

        val receipt = CreateAssetUseCase(gateway).purchase(request)

        assertEquals("op-purchase", receipt.operationId)
        assertTrue(gateway.lastPurchase === request)
    }

    private fun asset(type: String = "car", acquisition: String) = Asset(
        id = "asset-1",
        operationId = "op-create",
        type = type,
        name = "أصل",
        status = AssetStatus.Active.dbValue,
        acquisitionMode = "preexisting",
        acquisitionAmountDecimal = acquisition,
        currencyCode = if (type == "foreign_currency") "USD" else "SDG",
        purchasePaymentId = null,
        purchaseBalanceTransactionId = null,
        currentValueCacheDecimal = null,
        currentValueCacheValuationId = null,
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
    )

    private fun transaction(id: String = "improvement", kind: String, amount: String) = AssetTransaction(
        id = id,
        operationId = "op-$id",
        assetId = "asset-1",
        kind = kind,
        amountDecimal = amount,
        currencyQuantityDeltaDecimal = null,
        paymentId = null,
        balanceTransactionId = null,
        date = "2026-01-01",
        note = "",
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
    )

    private fun valuation(id: String, value: String, date: String, createdAt: Long) = AssetValuation(
        id = id,
        operationId = "op-$id",
        assetId = "asset-1",
        valueDecimal = value,
        date = date,
        note = "",
        createdAt = createdAt,
        updatedAt = createdAt,
        deletedAt = null,
    )
}

private class FakeAssetGateway : AssetGateway {
    val assets = MutableStateFlow<List<Asset>>(emptyList())
    val transactions = MutableStateFlow<List<AssetTransaction>>(emptyList())
    val valuations = MutableStateFlow<List<AssetValuation>>(emptyList())
    val lots = MutableStateFlow<List<CurrencyAssetLot>>(emptyList())
    val allocations = MutableStateFlow<List<CurrencyAssetSaleAllocation>>(emptyList())
    var lastPurchase: PurchaseAssetRequest? = null

    override fun observeAssets() = assets
    override fun observeTransactions() = transactions
    override fun observeValuations() = valuations
    override fun observeCurrencyLots() = lots
    override fun observeCurrencySaleAllocations() = allocations

    override suspend fun addPreexistingAsset(request: PreexistingAssetRequest) = receipt(request.operationId)
    override suspend fun purchaseAsset(request: PurchaseAssetRequest): AssetCommandReceipt {
        lastPurchase = request
        return receipt(request.operationId)
    }
    override suspend fun purchaseCurrencyAsset(request: PurchaseCurrencyAssetRequest) = receipt(request.operationId)
    override suspend fun recordAssetPayment(request: AssetPaymentRequest) = receipt(request.operationId)
    override suspend fun valueAsset(request: AssetValuationRequest) = receipt(request.operationId)
    override suspend fun sellAsset(request: AssetSaleRequest) = receipt(request.operationId)
    override suspend fun addCurrencyLot(request: AddCurrencyLotRequest) = receipt(request.operationId)
    override suspend fun sellCurrencyAsset(request: CurrencyAssetSaleRequest) = receipt(request.operationId)
    override suspend fun updateAcquisition(assetId: String, name: String, type: String, amountDecimal: String) = receipt("update")
    override suspend fun updatePaymentEvent(operationId: String, amountDecimal: String, purpose: String, date: String, note: String) = receipt(operationId)
    override suspend fun updateValuation(operationId: String, valueDecimal: String, date: String, note: String) = receipt(operationId)
    override suspend fun updateSale(operationId: String, amountDecimal: String, date: String, note: String) = receipt(operationId)
    override suspend fun deleteOperation(operationId: String) = receipt(operationId)
    override suspend fun deleteValuation(operationId: String) = receipt(operationId)
    override suspend fun undoSale(operationId: String) = receipt(operationId)

    private fun receipt(operationId: String) = AssetCommandReceipt(operationId, syncRequested = true)
}

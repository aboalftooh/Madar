package com.shift.app.feature.assets.domain.usecase

import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetDetails
import com.shift.app.feature.assets.domain.model.AssetSummary
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.CurrencyAssetLot
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleAllocation
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.feature.assets.domain.repository.AssetGateway
import java.math.BigDecimal
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class ObserveAssetsUseCase @Inject constructor(
    private val gateway: AssetGateway,
) {
    operator fun invoke(): Flow<List<Asset>> = gateway.observeAssets()
}

class ObserveAssetSummariesUseCase @Inject constructor(
    private val gateway: AssetGateway,
) {
    operator fun invoke(): Flow<List<AssetSummary>> = combine(
        gateway.observeAssets(),
        gateway.observeTransactions(),
        gateway.observeValuations(),
        gateway.observeCurrencyLots(),
        gateway.observeCurrencySaleAllocations(),
    ) { assets, transactions, valuations, lots, allocations ->
        assets.map { asset -> AssetSummaryCalculator.summary(asset, transactions, valuations, lots, allocations) }
    }
}

class ObserveAssetDetailsUseCase @Inject constructor(
    private val gateway: AssetGateway,
) {
    operator fun invoke(selectedAssetId: Flow<String?>): Flow<AssetDetails> {
        val collections = combine(
            gateway.observeAssets(),
            gateway.observeTransactions(),
            gateway.observeValuations(),
            gateway.observeCurrencyLots(),
            gateway.observeCurrencySaleAllocations(),
        ) { assets, transactions, valuations, lots, allocations ->
            AssetCollections(assets, transactions, valuations, lots, allocations)
        }
        return combine(selectedAssetId, collections) { selectedId, data ->
            val asset = data.assets.firstOrNull { it.id == selectedId } ?: return@combine AssetDetails()
            val events = data.transactions.filter { it.assetId == asset.id }
            val values = data.valuations.filter { it.assetId == asset.id }
            val lots = data.lots.filter { it.assetId == asset.id }
            val allocations = data.allocations.filter { it.assetId == asset.id }
            val summary = AssetSummaryCalculator.summary(asset, events, values, lots, allocations)
            AssetDetails(
                asset = asset,
                transactions = events,
                valuations = values,
                currencyLots = lots,
                currencySaleAllocations = allocations,
                currentValueDecimal = summary.currentValueDecimal,
                totalInvestmentDecimal = summary.totalInvestmentDecimal,
                availableCurrencyQuantityDecimal = summary.availableCurrencyQuantityDecimal,
            )
        }
    }
}

private data class AssetCollections(
    val assets: List<Asset>,
    val transactions: List<AssetTransaction>,
    val valuations: List<AssetValuation>,
    val lots: List<CurrencyAssetLot>,
    val allocations: List<CurrencyAssetSaleAllocation>,
)

object AssetSummaryCalculator {
    fun summary(
        asset: Asset,
        events: List<AssetTransaction>,
        valuations: List<AssetValuation>,
        currencyLots: List<CurrencyAssetLot>,
        currencyAllocations: List<CurrencyAssetSaleAllocation>,
    ): AssetSummary {
        val latestValue = valuations
            .filter { it.assetId == asset.id && it.deletedAt == null }
            .maxWithOrNull(compareBy<AssetValuation> { it.date }.thenBy { it.createdAt })
            ?.valueDecimal
        val improvements = events
            .filter {
                it.assetId == asset.id && it.deletedAt == null &&
                    it.kind == AssetTransactionKind.Improvement.dbValue
            }
            .mapNotNull { it.amountDecimal?.let(::decimalOrNull) }
            .fold(BigDecimal.ZERO, BigDecimal::add)
        val activeLots = currencyLots.filter { it.assetId == asset.id && it.deletedAt == null }
        val activeAllocations = currencyAllocations.filter { it.assetId == asset.id && it.deletedAt == null }
        val currencyQuantity = if (asset.type == FOREIGN_CURRENCY_ASSET_TYPE) {
            CurrencyAssetCalculator.availableQuantity(
                activeLots.map { it.snapshot() },
                activeAllocations.map { it.snapshot() },
            )
        } else null
        val acquisition = if (asset.type == FOREIGN_CURRENCY_ASSET_TYPE) {
            activeLots.mapNotNull { decimalOrNull(it.localCostDecimal) }.fold(BigDecimal.ZERO, BigDecimal::add)
        } else {
            decimalOrNull(asset.acquisitionAmountDecimal) ?: BigDecimal.ZERO
        }
        return AssetSummary(
            asset = asset,
            currentValueDecimal = latestValue,
            totalInvestmentDecimal = acquisition.add(improvements).setScale(2).toPlainString(),
            availableCurrencyQuantityDecimal = currencyQuantity,
        )
    }

    private fun CurrencyAssetLot.snapshot() = CurrencyLotSnapshot(
        id = id,
        quantityPurchasedDecimal = quantityPurchasedDecimal,
        localCostDecimal = localCostDecimal,
        purchaseDate = purchaseDate,
        createdAt = createdAt,
        deletedAt = deletedAt,
    )

    private fun CurrencyAssetSaleAllocation.snapshot() = CurrencyAllocationSnapshot(
        lotId = lotId,
        quantitySoldDecimal = quantitySoldDecimal,
        allocatedLocalCostDecimal = allocatedLocalCostDecimal,
        deletedAt = deletedAt,
    )

    private fun decimalOrNull(value: String): BigDecimal? =
        runCatching { DecimalText.toBigDecimal(value) }.getOrNull()
}

package com.shift.app.feature.assets.domain.model

const val FOREIGN_CURRENCY_ASSET_TYPE: String = "foreign_currency"

data class Asset(
    val id: String,
    val operationId: String?,
    val type: String,
    val name: String,
    val status: String,
    val acquisitionMode: String,
    val acquisitionAmountDecimal: String,
    val currencyCode: String,
    val purchasePaymentId: String?,
    val purchaseBalanceTransactionId: String?,
    val currentValueCacheDecimal: String?,
    val currentValueCacheValuationId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class AssetTransaction(
    val id: String,
    val operationId: String,
    val assetId: String,
    val kind: String,
    val amountDecimal: String?,
    val currencyQuantityDeltaDecimal: String?,
    val paymentId: String?,
    val balanceTransactionId: String?,
    val date: String,
    val note: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class AssetValuation(
    val id: String,
    val operationId: String,
    val assetId: String,
    val valueDecimal: String,
    val date: String,
    val note: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class CurrencyAssetLot(
    val id: String,
    val operationId: String,
    val assetId: String,
    val purchaseAssetTransactionId: String,
    val foreignCurrencyCode: String,
    val quantityPurchasedDecimal: String,
    val purchaseExchangeRateDecimal: String,
    val localCostDecimal: String,
    val purchaseDate: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class CurrencyAssetSaleAllocation(
    val id: String,
    val operationId: String,
    val assetId: String,
    val saleAssetTransactionId: String,
    val lotId: String,
    val quantitySoldDecimal: String,
    val allocatedLocalCostDecimal: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
)

data class AssetSummary(
    val asset: Asset,
    val currentValueDecimal: String?,
    val totalInvestmentDecimal: String,
    val availableCurrencyQuantityDecimal: String? = null,
)

data class AssetDetails(
    val asset: Asset? = null,
    val transactions: List<AssetTransaction> = emptyList(),
    val valuations: List<AssetValuation> = emptyList(),
    val currencyLots: List<CurrencyAssetLot> = emptyList(),
    val currencySaleAllocations: List<CurrencyAssetSaleAllocation> = emptyList(),
    val currentValueDecimal: String? = null,
    val totalInvestmentDecimal: String = "0.00",
    val availableCurrencyQuantityDecimal: String? = null,
)

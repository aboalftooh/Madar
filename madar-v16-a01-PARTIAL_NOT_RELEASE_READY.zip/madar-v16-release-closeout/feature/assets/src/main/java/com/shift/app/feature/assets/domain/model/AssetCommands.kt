package com.shift.app.feature.assets.domain.model

import com.shift.app.domain.finance.PaymentKind
import java.util.UUID

data class PreexistingAssetRequest(
    val name: String,
    val type: String,
    val acquisitionAmountDecimal: String,
    val currentValueDecimal: String? = null,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class PurchaseAssetRequest(
    val name: String,
    val type: String,
    val amountDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class AssetPaymentRequest(
    val assetId: String,
    val kind: PaymentKind,
    val amountDecimal: String,
    val purpose: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class AssetValuationRequest(
    val assetId: String,
    val valueDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class AssetSaleRequest(
    val assetId: String,
    val amountDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class PurchaseCurrencyAssetRequest(
    val name: String,
    val foreignCurrencyCode: String,
    val quantityDecimal: String,
    val exchangeRateDecimal: String,
    val localCostDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class AddCurrencyLotRequest(
    val assetId: String,
    val quantityDecimal: String,
    val exchangeRateDecimal: String,
    val localCostDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class CurrencyAssetSaleRequest(
    val assetId: String,
    val quantityDecimal: String,
    val localProceedsDecimal: String,
    val date: String,
    val note: String = "",
    val operationId: String = UUID.randomUUID().toString(),
)

data class AssetCommandReceipt(
    val operationId: String,
    val syncRequested: Boolean,
)

class AssetSessionExpiredException : IllegalStateException("انتهت جلسة الحساب")

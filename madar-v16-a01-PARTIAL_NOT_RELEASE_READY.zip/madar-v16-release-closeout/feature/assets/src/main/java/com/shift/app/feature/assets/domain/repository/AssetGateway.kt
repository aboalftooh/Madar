package com.shift.app.feature.assets.domain.repository

import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetCommandReceipt
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetLot
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleAllocation
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import kotlinx.coroutines.flow.Flow

interface AssetGateway {
    fun observeAssets(): Flow<List<Asset>>
    fun observeTransactions(): Flow<List<AssetTransaction>>
    fun observeValuations(): Flow<List<AssetValuation>>
    fun observeCurrencyLots(): Flow<List<CurrencyAssetLot>>
    fun observeCurrencySaleAllocations(): Flow<List<CurrencyAssetSaleAllocation>>

    suspend fun addPreexistingAsset(request: PreexistingAssetRequest): AssetCommandReceipt
    suspend fun purchaseAsset(request: PurchaseAssetRequest): AssetCommandReceipt
    suspend fun purchaseCurrencyAsset(request: PurchaseCurrencyAssetRequest): AssetCommandReceipt
    suspend fun recordAssetPayment(request: AssetPaymentRequest): AssetCommandReceipt
    suspend fun valueAsset(request: AssetValuationRequest): AssetCommandReceipt
    suspend fun sellAsset(request: AssetSaleRequest): AssetCommandReceipt
    suspend fun addCurrencyLot(request: AddCurrencyLotRequest): AssetCommandReceipt
    suspend fun sellCurrencyAsset(request: CurrencyAssetSaleRequest): AssetCommandReceipt

    suspend fun updateAcquisition(assetId: String, name: String, type: String, amountDecimal: String): AssetCommandReceipt
    suspend fun updatePaymentEvent(operationId: String, amountDecimal: String, purpose: String, date: String, note: String): AssetCommandReceipt
    suspend fun updateValuation(operationId: String, valueDecimal: String, date: String, note: String): AssetCommandReceipt
    suspend fun updateSale(operationId: String, amountDecimal: String, date: String, note: String): AssetCommandReceipt
    suspend fun deleteOperation(operationId: String): AssetCommandReceipt
    suspend fun deleteValuation(operationId: String): AssetCommandReceipt
    suspend fun undoSale(operationId: String): AssetCommandReceipt
}

package com.shift.app.feature.assets.domain.usecase

import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.AssetCommandReceipt
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import com.shift.app.feature.assets.domain.repository.AssetGateway
import javax.inject.Inject

class CreateAssetUseCase @Inject constructor(private val gateway: AssetGateway) {
    suspend fun addPreexisting(request: PreexistingAssetRequest): AssetCommandReceipt = gateway.addPreexistingAsset(request)
    suspend fun purchase(request: PurchaseAssetRequest): AssetCommandReceipt = gateway.purchaseAsset(request)
    suspend fun purchaseCurrency(request: PurchaseCurrencyAssetRequest): AssetCommandReceipt = gateway.purchaseCurrencyAsset(request)
}

class ManageAssetLifecycleUseCase @Inject constructor(private val gateway: AssetGateway) {
    suspend fun recordPayment(request: AssetPaymentRequest): AssetCommandReceipt = gateway.recordAssetPayment(request)
    suspend fun value(request: AssetValuationRequest): AssetCommandReceipt = gateway.valueAsset(request)
    suspend fun sell(request: AssetSaleRequest): AssetCommandReceipt = gateway.sellAsset(request)
    suspend fun addCurrencyLot(request: AddCurrencyLotRequest): AssetCommandReceipt = gateway.addCurrencyLot(request)
    suspend fun sellCurrency(request: CurrencyAssetSaleRequest): AssetCommandReceipt = gateway.sellCurrencyAsset(request)
}

class EditAssetUseCase @Inject constructor(private val gateway: AssetGateway) {
    suspend fun acquisition(assetId: String, name: String, type: String, amount: String) =
        gateway.updateAcquisition(assetId, name, type, amount)

    suspend fun payment(operationId: String, amount: String, purpose: String, date: String, note: String) =
        gateway.updatePaymentEvent(operationId, amount, purpose, date, note)

    suspend fun valuation(operationId: String, value: String, date: String, note: String) =
        gateway.updateValuation(operationId, value, date, note)

    suspend fun sale(operationId: String, amount: String, date: String, note: String) =
        gateway.updateSale(operationId, amount, date, note)

    suspend fun deleteOperation(operationId: String) = gateway.deleteOperation(operationId)
    suspend fun deleteValuation(operationId: String) = gateway.deleteValuation(operationId)
    suspend fun undoSale(operationId: String) = gateway.undoSale(operationId)
}

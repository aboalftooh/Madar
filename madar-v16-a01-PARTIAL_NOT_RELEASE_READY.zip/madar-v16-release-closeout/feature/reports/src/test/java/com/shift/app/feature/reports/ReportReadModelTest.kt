package com.shift.app.feature.reports

import com.shift.app.feature.reports.domain.model.ReportAssetRow
import com.shift.app.feature.reports.domain.model.ReportAssetValuationRow
import com.shift.app.feature.reports.domain.model.ReportBalanceRow
import com.shift.app.feature.reports.domain.model.ReportDebtAccountRow
import com.shift.app.feature.reports.domain.model.ReportDebtTransactionRow
import com.shift.app.feature.reports.domain.model.ReportPaymentRow
import com.shift.app.feature.reports.domain.model.ReportTransactionRow
import com.shift.app.feature.reports.domain.model.ReportsDataset
import com.shift.app.feature.reports.domain.model.ReportsDateRange
import com.shift.app.feature.reports.domain.usecase.BuildReportsReadModelUseCase
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportReadModelTest {
    private val build = BuildReportsReadModelUseCase()
    private val range = ReportsDateRange(LocalDate.parse("2026-07-01"), LocalDate.parse("2026-07-31"))

    @Test
    fun `canonical ledger values override linked legacy projections`() {
        val model = build(sampleDataset(), range, YearMonth.of(2026, 7))
        assertEquals("150.00", model.period.income.toPlainString())
        assertEquals("20.00", model.period.actualExpenses.toPlainString())
        assertEquals("130.00", model.period.net.toPlainString())
        assertEquals(86, model.period.savingRatePercent)
    }

    @Test
    fun `wealth uses balance latest asset valuation and confirmed debt remainder`() {
        val model = build(sampleDataset(), range, YearMonth.of(2026, 7))
        assertEquals("130.00", model.wealth.balance.toPlainString())
        assertEquals("200.00", model.wealth.assetsValue.toPlainString())
        assertEquals("70.00", model.wealth.receivables.toPlainString())
        assertEquals("60.00", model.wealth.payables.toPlainString())
        assertEquals("340.00", model.wealth.netWorth.toPlainString())
    }

    @Test
    fun `breakdowns are sorted and carry precomputed shares`() {
        val model = build(sampleDataset(), range, YearMonth.of(2026, 7))
        assertEquals(listOf("راتب", "عمل حر"), model.incomeBySource.map { it.name })
        assertEquals("120.00", model.incomeBySource.first().amount.toPlainString())
        assertTrue(model.incomeBySource.first().shareFraction > model.incomeBySource.last().shareFraction)
        assertEquals(listOf("معيشة"), model.expensesByPurpose.map { it.name })
        assertEquals(1f, model.expensesByPurpose.single().shareFraction)
    }

    @Test
    fun `six month trend ends at requested anchor month`() {
        val model = build(sampleDataset(), range, YearMonth.of(2026, 7))
        assertEquals(6, model.monthlyTrend.size)
        assertEquals("فبر", model.monthlyTrend.first().label)
        assertEquals("يول", model.monthlyTrend.last().label)
        assertEquals(150f, model.monthlyTrend.last().income)
    }

    @Test
    fun `invalid date range returns empty period but keeps current wealth`() {
        val invalid = ReportsDateRange(LocalDate.parse("2026-08-01"), LocalDate.parse("2026-07-01"))
        val model = build(sampleDataset(), invalid, YearMonth.of(2026, 7))
        assertTrue(model.invalidRange)
        assertEquals("0.00", model.period.income.toPlainString())
        assertTrue(model.incomeBySource.isEmpty())
        assertEquals("340.00", model.wealth.netWorth.toPlainString())
    }

    @Test
    fun `duplicate payment operation uses newest logical row once`() {
        val data = sampleDataset().let { original ->
            original.copy(
                payments = original.payments + original.payments.single().copy(
                    id = "payment-new",
                    amountDecimal = "25.00",
                    updatedAt = 20,
                ),
            )
        }
        val model = build(data, range, YearMonth.of(2026, 7))
        assertEquals("25.00", model.period.actualExpenses.toPlainString())
    }

    private fun sampleDataset(): ReportsDataset = ReportsDataset(
        transactions = listOf(
            ReportTransactionRow("income-linked", "income", "100.00", "راتب", "2026-07-03", "راتب", "", "", false),
            ReportTransactionRow("income-legacy", "income", "30.00", "عمل حر", "2026-07-04", "عمل حر", "", "", false),
            ReportTransactionRow("expense-linked", "expense", "50.00", "قديم", "2026-07-05", "", "قديم", "متجر", false),
        ),
        balances = listOf(
            ReportBalanceRow("balance-income", "inflow", "income", "120.00", "2026-07-03", "transaction", "income-linked", "income-linked", 1, 1, false),
            ReportBalanceRow("balance-out", "outflow", "expense_payment", "20.00", "2026-07-05", "payment", "payment", null, 1, 1, false),
            ReportBalanceRow("balance-legacy", "inflow", "manual_add", "30.00", "2026-07-04", "", null, null, 1, 1, false),
        ),
        payments = listOf(
            ReportPaymentRow("payment", "expense-op", "ordinary_expense", "20.00", "2026-07-05", "معيشة", "متجر", "", "expense-linked", 1, 10, false),
        ),
        migratedLegacyExpenseIds = setOf("expense-linked"),
        assets = listOf(ReportAssetRow("asset", "active", false)),
        assetValuations = listOf(
            ReportAssetValuationRow("valuation-old", "asset", "150.00", "2026-06-01", 1, false),
            ReportAssetValuationRow("valuation-new", "asset", "200.00", "2026-07-01", 2, false),
        ),
        debtAccounts = listOf(
            ReportDebtAccountRow("receivable", "receivable", true, false),
            ReportDebtAccountRow("payable", "payable", true, false),
            ReportDebtAccountRow("draft", "receivable", false, false),
        ),
        debtTransactions = listOf(
            ReportDebtTransactionRow("r-open", "receivable", "opening", "100.00", false),
            ReportDebtTransactionRow("r-paid", "receivable", "collection", "30.00", false),
            ReportDebtTransactionRow("p-open", "payable", "opening", "80.00", false),
            ReportDebtTransactionRow("p-paid", "payable", "payment", "20.00", false),
            ReportDebtTransactionRow("d-open", "draft", "opening", "999.00", false),
        ),
    )
}

package com.shift.app.feature.reports.domain.usecase

import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.FinancialRules
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.feature.reports.domain.model.ReportAssetValuationRow
import com.shift.app.feature.reports.domain.model.ReportBalanceRow
import com.shift.app.feature.reports.domain.model.ReportCategoryReadModel
import com.shift.app.feature.reports.domain.model.ReportDebtAccountRow
import com.shift.app.feature.reports.domain.model.ReportDebtTransactionRow
import com.shift.app.feature.reports.domain.model.ReportPaymentRow
import com.shift.app.feature.reports.domain.model.ReportPeriodReadModel
import com.shift.app.feature.reports.domain.model.ReportTransactionRow
import com.shift.app.feature.reports.domain.model.ReportTrendPointReadModel
import com.shift.app.feature.reports.domain.model.ReportWealthReadModel
import com.shift.app.feature.reports.domain.model.ReportsDataset
import com.shift.app.feature.reports.domain.model.ReportsDateRange
import com.shift.app.feature.reports.domain.model.ReportsReadModel
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth
import javax.inject.Inject

class BuildReportsReadModelUseCase @Inject constructor() {
    operator fun invoke(
        dataset: ReportsDataset,
        range: ReportsDateRange,
        anchorMonth: YearMonth = YearMonth.now(),
    ): ReportsReadModel {
        val period = period(dataset, range)
        val wealth = wealth(dataset)
        val months = (5 downTo 0).map { anchorMonth.minusMonths(it.toLong()) }
        return ReportsReadModel(
            range = range,
            invalidRange = range.isInvalid,
            period = period,
            wealth = wealth,
            monthlyTrend = months.map { month ->
                val totals = period(dataset, ReportsDateRange(month.atDay(1), month.atEndOfMonth()))
                ReportTrendPointReadModel(
                    label = monthName(month.monthValue).take(3),
                    income = totals.income.toFloat(),
                    expense = totals.actualExpenses.toFloat(),
                )
            },
            incomeBySource = withShares(incomeBySource(dataset, range)),
            expensesByPurpose = withShares(expenseCategories(dataset, range, byBeneficiary = false).take(8)),
            expensesByBeneficiary = withShares(expenseCategories(dataset, range, byBeneficiary = true)),
        )
    }

    private fun period(dataset: ReportsDataset, range: ReportsDateRange): ReportPeriodReadModel {
        if (range.isInvalid) return zeroPeriod()
        val balances = activeBalances(dataset.balances).filter { it.date.inRange(range) }
        val payments = activePayments(dataset.payments).filter { it.date.inRange(range) }
        val linkedIds = buildSet {
            addAll(balances.mapNotNull { it.legacyTransactionId })
            addAll(balances.filter { it.sourceType == "transaction" }.mapNotNull { it.sourceId })
            addAll(payments.mapNotNull { it.legacyTransactionId })
        }
        val migratedExpenses = dataset.migratedLegacyExpenseIds + linkedIds
        val transactions = dataset.transactions.filter { !it.deleted && it.date.inRange(range) }
        val income = balances.asSequence()
            .filter { it.kind == BalanceTransactionKind.Income.dbValue }
            .sumMoney { it.amountDecimal.moneyOrZero() }
            .add(transactions.asSequence()
                .filter { it.type == "income" && it.id !in linkedIds }
                .sumMoney { it.amountDecimal.moneyOrZero() })
            .asMoney()
        val expenses = transactions.asSequence()
            .filter { it.type == "expense" && it.id !in migratedExpenses }
            .sumMoney { it.amountDecimal.moneyOrZero() }
            .add(payments.asSequence()
                .filter { it.kind.isReportablePayment() }
                .sumMoney { it.amountDecimal.moneyOrZero() })
            .asMoney()
        val net = income.subtract(expenses).asMoney()
        val savingRate = if (income.signum() > 0) {
            net.multiply(BigDecimal(100)).divide(income, 0, RoundingMode.DOWN).toInt()
        } else 0
        return ReportPeriodReadModel(income, expenses, net, savingRate)
    }

    private fun wealth(dataset: ReportsDataset): ReportWealthReadModel {
        val balance = activeBalances(dataset.balances).fold(ZERO_MONEY) { total, row ->
            when (row.direction) {
                BalanceDirection.Inflow.dbValue -> total.add(row.amountDecimal.moneyOrZero())
                BalanceDirection.Outflow.dbValue -> total.subtract(row.amountDecimal.moneyOrZero())
                else -> total
            }
        }.asMoney()
        val activeAssetIds = dataset.assets.asSequence()
            .filter { !it.deleted && it.status == AssetStatus.Active.dbValue }
            .map { it.id }
            .toSet()
        val assetsValue = activeAssetIds.asSequence().sumMoney { assetId ->
            latestValuation(assetId, dataset.assetValuations) ?: ZERO_MONEY
        }
        val remainingByAccount = dataset.debtTransactions.asSequence()
            .filter { !it.deleted }
            .groupBy { it.accountId }
            .mapValues { (_, rows) ->
                rows.fold(ZERO_MONEY) { total, row ->
                    val sign = runCatching { DebtTransactionType.fromDb(row.type).remainingSign }.getOrDefault(0)
                    total.add(row.amountDecimal.moneyOrZero().multiply(BigDecimal(sign)))
                }.max(BigDecimal.ZERO).asMoney()
            }
        fun debt(direction: String): BigDecimal = dataset.debtAccounts.asSequence()
            .filter { !it.deleted && it.confirmed && it.direction == direction }
            .sumMoney { remainingByAccount[it.id] ?: ZERO_MONEY }
        val receivables = debt("receivable")
        val payables = debt("payable")
        val netWorth = balance.add(assetsValue).add(receivables).subtract(payables).asMoney()
        return ReportWealthReadModel(balance, assetsValue, receivables, payables, netWorth)
    }

    private fun incomeBySource(dataset: ReportsDataset, range: ReportsDateRange): List<Pair<String, BigDecimal>> {
        if (range.isInvalid) return emptyList()
        val canonicalByTransaction = activeBalances(dataset.balances).asSequence()
            .filter { it.kind == BalanceTransactionKind.Income.dbValue }
            .mapNotNull { row ->
                val id = row.legacyTransactionId ?: row.sourceId?.takeIf { row.sourceType == "transaction" }
                id?.let { it to row.amountDecimal.moneyOrZero() }
            }.toMap()
        return dataset.transactions.asSequence()
            .filter { !it.deleted && it.type == "income" && it.date.inRange(range) }
            .groupBy { it.incomeSourceName.ifBlank { it.category.ifBlank { "أخرى" } } }
            .map { (name, rows) -> name to rows.asSequence().sumMoney { canonicalByTransaction[it.id] ?: it.amountDecimal.moneyOrZero() } }
            .sortedByDescending { it.second }
    }

    private fun expenseCategories(
        dataset: ReportsDataset,
        range: ReportsDateRange,
        byBeneficiary: Boolean,
    ): List<Pair<String, BigDecimal>> {
        if (range.isInvalid) return emptyList()
        val activePayments = activePayments(dataset.payments)
        val migratedIds = dataset.migratedLegacyExpenseIds + dataset.payments.mapNotNull { it.legacyTransactionId }
        val values = mutableListOf<Pair<String, BigDecimal>>()
        dataset.transactions.asSequence()
            .filter { !it.deleted && it.type == "expense" && it.id !in migratedIds && it.date.inRange(range) }
            .forEach { row ->
                val name = if (byBeneficiary) row.beneficiaryName.ifBlank { "غير محدد" }
                else row.purpose.ifBlank { row.category.ifBlank { "أخرى" } }
                values += name to row.amountDecimal.moneyOrZero()
            }
        activePayments.asSequence()
            .filter { it.date.inRange(range) && it.kind.isReportablePayment() }
            .forEach { row ->
                val name = if (byBeneficiary) row.beneficiaryName.ifBlank { row.assetName.ifBlank { "غير محدد" } }
                else row.purpose.ifBlank { "أخرى" }
                values += name to row.amountDecimal.moneyOrZero()
            }
        return values.groupBy { it.first }
            .map { (name, rows) -> name to rows.asSequence().sumMoney { it.second } }
            .sortedByDescending { it.second }
    }

    private fun withShares(values: List<Pair<String, BigDecimal>>): List<ReportCategoryReadModel> {
        val total = values.fold(ZERO_MONEY) { acc, item -> acc.add(item.second) }
        return values.map { (name, amount) ->
            val share = if (total.signum() > 0) amount.divide(total, 4, RoundingMode.HALF_UP).toFloat() else 0f
            ReportCategoryReadModel(name, amount.asMoney(), share.coerceIn(0f, 1f))
        }
    }

    private fun activeBalances(rows: List<ReportBalanceRow>): List<ReportBalanceRow> = rows.asSequence()
        .filter { !it.deleted }
        .groupBy { it.id }
        .values
        .map { duplicates -> duplicates.maxWith(compareBy<ReportBalanceRow> { it.updatedAt }.thenBy { it.createdAt }.thenBy { it.id }) }

    private fun activePayments(rows: List<ReportPaymentRow>): List<ReportPaymentRow> = rows.asSequence()
        .filter { !it.deleted }
        .groupBy { it.operationId.ifBlank { it.id } }
        .values
        .map { duplicates -> duplicates.maxWith(compareBy<ReportPaymentRow> { it.updatedAt }.thenBy { it.createdAt }.thenBy { it.id }) }

    private fun latestValuation(assetId: String, rows: List<ReportAssetValuationRow>): BigDecimal? = rows.asSequence()
        .filter { it.assetId == assetId && !it.deleted }
        .mapNotNull { row ->
            val date = runCatching { LocalDate.parse(row.date) }.getOrNull() ?: return@mapNotNull null
            val value = runCatching { DecimalText.toBigDecimal(row.valueDecimal) }.getOrNull()?.takeIf { it.signum() >= 0 }
                ?: return@mapNotNull null
            Triple(row, date, value)
        }
        .maxWithOrNull(compareBy<Triple<ReportAssetValuationRow, LocalDate, BigDecimal>> { it.second }
            .thenBy { it.first.createdAt }.thenBy { it.first.id })
        ?.third?.asMoney()

    private fun String.inRange(range: ReportsDateRange): Boolean {
        val date = runCatching { LocalDate.parse(this) }.getOrNull() ?: return false
        return !date.isBefore(range.from) && !date.isAfter(range.to)
    }

    private fun String.moneyOrZero(): BigDecimal =
        runCatching { DecimalText.toBigDecimal(this).asMoney() }.getOrDefault(ZERO_MONEY)

    private fun String.isReportablePayment(): Boolean = PaymentKind.entries
        .firstOrNull { it.dbValue == this }
        ?.let(FinancialRules::entersExpenseReports) == true

    private inline fun <T> Sequence<T>.sumMoney(value: (T) -> BigDecimal): BigDecimal =
        fold(ZERO_MONEY) { total, item -> total.add(value(item)) }.asMoney()

    private fun zeroPeriod() = ReportPeriodReadModel(ZERO_MONEY, ZERO_MONEY, ZERO_MONEY, 0)

    private fun monthName(month: Int): String = listOf(
        "", "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
    ).getOrElse(month) { "" }

    private fun BigDecimal.asMoney(): BigDecimal = setScale(2, RoundingMode.HALF_UP)
    private val ZERO_MONEY = BigDecimal.ZERO.setScale(2)
}

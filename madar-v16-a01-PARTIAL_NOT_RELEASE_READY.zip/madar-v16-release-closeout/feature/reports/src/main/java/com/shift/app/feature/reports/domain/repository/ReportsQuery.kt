package com.shift.app.feature.reports.domain.repository

import com.shift.app.feature.reports.domain.model.ReportsDataset
import kotlinx.coroutines.flow.Flow

/** Read-only reporting boundary. It exposes report-owned rows, never Room entities or DAOs. */
interface ReportsQuery {
    fun observeDataset(): Flow<ReportsDataset>
}

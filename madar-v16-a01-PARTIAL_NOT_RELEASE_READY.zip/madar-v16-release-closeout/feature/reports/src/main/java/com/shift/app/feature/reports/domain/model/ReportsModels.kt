package com.shift.app.feature.reports.domain.model

import java.math.BigDecimal
import java.time.LocalDate

data class ReportsDateRange(
    val from: LocalDate,
    val to: LocalDate,
) {
    val isInvalid: Boolean get() = from.isAfter(to)
}

data class ReportTransactionRow(
    val id: String,
    val type: String,
    val amountDecimal: String,
    val category: String,
    val date: String,
    val incomeSourceName: String,
    val purpose: String,
    val beneficiaryName: String,
    val deleted: Boolean,
)

data class ReportBalanceRow(
    val id: String,
    val direction: String,
    val kind: String,
    val amountDecimal: String,
    val date: String,
    val sourceType: String,
    val sourceId: String?,
    val legacyTransactionId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deleted: Boolean,
)

data class ReportPaymentRow(
    val id: String,
    val operationId: String,
    val kind: String,
    val amountDecimal: String,
    val date: String,
    val purpose: String,
    val beneficiaryName: String,
    val assetName: String,
    val legacyTransactionId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deleted: Boolean,
)

data class ReportAssetRow(
    val id: String,
    val status: String,
    val deleted: Boolean,
)

data class ReportAssetValuationRow(
    val id: String,
    val assetId: String,
    val valueDecimal: String,
    val date: String,
    val createdAt: Long,
    val deleted: Boolean,
)

data class ReportDebtAccountRow(
    val id: String,
    val direction: String,
    val confirmed: Boolean,
    val deleted: Boolean,
)

data class ReportDebtTransactionRow(
    val id: String,
    val accountId: String,
    val type: String,
    val amountDecimal: String,
    val deleted: Boolean,
)

data class ReportsDataset(
    val transactions: List<ReportTransactionRow> = emptyList(),
    val balances: List<ReportBalanceRow> = emptyList(),
    val payments: List<ReportPaymentRow> = emptyList(),
    val migratedLegacyExpenseIds: Set<String> = emptySet(),
    val assets: List<ReportAssetRow> = emptyList(),
    val assetValuations: List<ReportAssetValuationRow> = emptyList(),
    val debtAccounts: List<ReportDebtAccountRow> = emptyList(),
    val debtTransactions: List<ReportDebtTransactionRow> = emptyList(),
)

data class ReportPeriodReadModel(
    val income: BigDecimal,
    val actualExpenses: BigDecimal,
    val net: BigDecimal,
    val savingRatePercent: Int,
)

data class ReportWealthReadModel(
    val balance: BigDecimal,
    val assetsValue: BigDecimal,
    val receivables: BigDecimal,
    val payables: BigDecimal,
    val netWorth: BigDecimal,
)

data class ReportCategoryReadModel(
    val name: String,
    val amount: BigDecimal,
    val shareFraction: Float,
)

data class ReportTrendPointReadModel(
    val label: String,
    val income: Float,
    val expense: Float,
)

data class ReportsReadModel(
    val range: ReportsDateRange,
    val invalidRange: Boolean,
    val period: ReportPeriodReadModel,
    val wealth: ReportWealthReadModel,
    val monthlyTrend: List<ReportTrendPointReadModel>,
    val incomeBySource: List<ReportCategoryReadModel>,
    val expensesByPurpose: List<ReportCategoryReadModel>,
    val expensesByBeneficiary: List<ReportCategoryReadModel>,
) {
    companion object {
        fun empty(range: ReportsDateRange): ReportsReadModel {
            val zero = BigDecimal.ZERO.setScale(2)
            return ReportsReadModel(
                range = range,
                invalidRange = range.isInvalid,
                period = ReportPeriodReadModel(zero, zero, zero, 0),
                wealth = ReportWealthReadModel(zero, zero, zero, zero, zero),
                monthlyTrend = emptyList(),
                incomeBySource = emptyList(),
                expensesByPurpose = emptyList(),
                expensesByBeneficiary = emptyList(),
            )
        }
    }
}

package com.shift.app.feature.reports.domain.usecase

import com.shift.app.feature.reports.domain.model.ReportsDateRange
import com.shift.app.feature.reports.domain.model.ReportsReadModel
import com.shift.app.feature.reports.domain.repository.ReportsQuery
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class ObserveReportsUseCase @Inject constructor(
    private val query: ReportsQuery,
    private val buildReadModel: BuildReportsReadModelUseCase,
) {
    operator fun invoke(range: Flow<ReportsDateRange>): Flow<ReportsReadModel> =
        combine(query.observeDataset(), range) { dataset, selectedRange ->
            buildReadModel(dataset, selectedRange)
        }
}

import java.util.Properties

val localProps = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}

val keystoreProps = Properties().apply {
    rootProject.file("keystore.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}

fun String?.asBuildConfigString(): String =
    "\"" + orEmpty().replace("\\", "\\\\").replace("\"", "\\\"") + "\""

fun String.isConfiguredValue(): Boolean =
    isNotBlank() && !equals("null", ignoreCase = true) && !startsWith("YOUR_")

val supabaseUrl = localProps.getProperty("SUPABASE_URL").orEmpty().trim()
val supabaseKey = localProps.getProperty("SUPABASE_KEY").orEmpty().trim()
val sentryDsn = localProps.getProperty("SENTRY_DSN").orEmpty().trim()

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.shift.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shift.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 112
        versionName = "1.1.2"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
        buildConfigField("String", "SUPABASE_URL", supabaseUrl.asBuildConfigString())
        buildConfigField("String", "SUPABASE_KEY", supabaseKey.asBuildConfigString())
        buildConfigField("String", "SENTRY_DSN", sentryDsn.asBuildConfigString())
        buildConfigField("Boolean", "FINANCIAL_GOALS_PHASE_1", "true")
    }

    signingConfigs {
        create("release") {
            keystoreProps.getProperty("storeFile")?.let {
                storeFile = rootProject.file(it)
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.10" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
    arg("room.incremental", "true")
}

dependencies {
    implementation(project(":core:model"))
    implementation(project(":core:sync"))
    implementation(project(":feature:ledger"))
    implementation(project(":feature:auth"))
    implementation(project(":feature:assets"))
    implementation(project(":feature:debts"))
    implementation(project(":feature:goals"))
    implementation(project(":feature:reports"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.extended)
    implementation(libs.navigation.compose)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)
    implementation(libs.datastore.preferences)
    implementation(libs.kotlinx.coroutines)
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    // Google Fonts
    implementation("androidx.compose.ui:ui-text-google-fonts:1.6.1")
    implementation("io.sentry:sentry-android:7.18.0")
    debugImplementation(libs.compose.ui.tooling)
// ─── أضف ده في build.gradle (app) داخل dependencies {} ───────

// Supabase BOM — يتحكم في إصدارات كل المكتبات تلقائياً
    implementation(platform("io.github.jan-tennert.supabase:bom:2.6.1"))
    implementation("io.github.jan-tennert.supabase:postgrest-kt")
    implementation("io.github.jan-tennert.supabase:gotrue-kt")

// Ktor engine — مطلوب لـ Supabase
    implementation("io.ktor:ktor-client-android:2.3.12")

// Kotlin Serialization — لـ @Serializable على الـ Remote models
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")

// SQLCipher — تشفير قاعدة البيانات المحلية
    implementation("net.zetetic:sqlcipher-android:4.5.6")
    implementation("androidx.sqlite:sqlite-ktx:2.4.0")

// EncryptedSharedPreferences — تخزين مفتاح التشفير
    implementation("androidx.security:security-crypto:1.0.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    testImplementation(libs.room.testing)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.compose.ui.test.junit4)
    debugImplementation(libs.compose.ui.test.manifest)
}

val validateReleaseConfiguration = tasks.register("validateReleaseConfiguration") {
    group = "verification"
    description = "Fails release builds when signing or backend configuration is incomplete."
    doLast {
        require(supabaseUrl.isConfiguredValue() && supabaseUrl.startsWith("https://")) {
            "SUPABASE_URL must be a configured HTTPS URL in local.properties"
        }
        require(supabaseKey.isConfiguredValue()) {
            "SUPABASE_KEY must be configured in local.properties"
        }
        val storeFilePath = keystoreProps.getProperty("storeFile").orEmpty()
        require(storeFilePath.isNotBlank()) {
            "keystore.properties must define storeFile"
        }
        require(rootProject.file(storeFilePath).isFile) {
            "Release keystore does not exist: $storeFilePath"
        }
        listOf("storePassword", "keyAlias", "keyPassword").forEach { key ->
            require(keystoreProps.getProperty(key).orEmpty().trim().isConfiguredValue()) {
                "keystore.properties must define a real value for $key"
            }
        }
    }
}

tasks.matching {
    it.name in setOf("assembleRelease", "bundleRelease", "packageRelease")
}.configureEach {
    dependsOn(validateReleaseConfiguration)
}


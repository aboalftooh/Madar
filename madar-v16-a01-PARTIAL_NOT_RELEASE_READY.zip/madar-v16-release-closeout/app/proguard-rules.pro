# Runtime metadata used by Hilt, Room, Kotlin serialization and Supabase.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# SQLCipher loads native/database classes dynamically.
-keep class net.zetetic.database.** { *; }

# Supabase/PostgREST uses generated serializers and generic type metadata.
-keep class io.github.jan.supabase.** { *; }
-keep @kotlinx.serialization.Serializable class com.shift.app.data.remote.** { *; }
-keep @kotlinx.serialization.Serializable class com.shift.app.data.remote.goals.** { *; }

-dontwarn io.github.jan.supabase.**
-dontwarn com.google.errorprone.annotations.Immutable
-dontwarn org.slf4j.impl.StaticLoggerBinder

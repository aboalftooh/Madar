package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.screens.goals.FundingSection
import com.shift.app.ui.theme.MadarTheme
import com.shift.app.viewmodel.GoalFundingUiSummary
import org.junit.Rule
import org.junit.Test

class GoalFundingUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun fundingSectionShowsArabicFundingControlsAndAllocatedAmount() {
        composeRule.setContent {
            MadarTheme {
                FundingSection(
                    goal = goal(),
                    funding = GoalFundingUiSummary(allocatedDecimal = "125.00"),
                    onAllocate = { _, _ -> },
                    onRelease = { _, _ -> },
                    onReverse = {},
                )
            }
        }

        composeRule.onNodeWithText("المخصص الحالي").assertIsDisplayed()
        composeRule.onNodeWithText("125 SDG").assertIsDisplayed()
        composeRule.onNodeWithText("تخصيص").assertIsDisplayed()
        composeRule.onNodeWithText("سحب").assertIsDisplayed()
    }

    private fun goal() = FinancialGoalEntity(
        id = "goal-1",
        name = "صندوق الطوارئ",
        type = GoalType.EMERGENCY_FUND,
        lifecycleStatus = GoalLifecycleStatus.ACTIVE,
        healthStatus = GoalHealthStatus.UNAVAILABLE,
        currencyCode = "SDG",
        startDate = "2026-07-18",
        deadline = "2026-12-31",
        timezoneId = "Africa/Khartoum",
        targetDecimal = "1000.00",
        baselineDecimal = null,
        targetPercentDecimal = null,
        confirmationPeriods = 1,
        costThreshold = null,
        configJson = "{\"version\":1,\"settings\":{}}",
        revision = 0,
        readyAt = null,
        completedAt = null,
        cancelledAt = null,
        archivedAt = null,
        createdAt = 1,
        updatedAt = 1,
        deletedAt = null,
        syncState = "PENDING",
    )
}

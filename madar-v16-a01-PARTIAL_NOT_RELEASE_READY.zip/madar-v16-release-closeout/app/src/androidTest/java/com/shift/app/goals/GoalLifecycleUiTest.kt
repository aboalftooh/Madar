package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.ui.screens.goals.StatusBadge
import com.shift.app.ui.theme.MadarTheme
import org.junit.Rule
import org.junit.Test

class GoalLifecycleUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun lifecycleStatusBadgesRenderArabicLabels() {
        composeRule.setContent {
            MadarTheme {
                StatusBadge(GoalLifecycleStatus.ACTIVE)
                StatusBadge(GoalLifecycleStatus.CANCELLED)
            }
        }

        composeRule.onNodeWithText("نشط").assertIsDisplayed()
        composeRule.onNodeWithText("ملغي").assertIsDisplayed()
    }
}

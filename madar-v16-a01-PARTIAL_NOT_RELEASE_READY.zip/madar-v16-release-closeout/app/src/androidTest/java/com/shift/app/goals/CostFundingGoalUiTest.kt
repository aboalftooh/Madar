package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.ui.screens.goals.CostGoalCompletionScreen
import com.shift.app.ui.theme.MadarTheme
import org.junit.Rule
import org.junit.Test

class CostFundingGoalUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun completionScreenOffersConsumeOrKeepAllocated() {
        composeRule.setContent {
            MadarTheme {
                CostGoalCompletionScreen(summary = "رحلة آمنة", onKeepAllocated = {}, onConsume = {})
            }
        }

        composeRule.onNodeWithText("استهلاك التخصيص").assertIsDisplayed()
        composeRule.onNodeWithText("إبقاء المال مخصصًا").assertIsDisplayed()
    }
}

package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.theme.MadarTheme
import com.shift.app.viewmodel.arabicLabel
import org.junit.Rule
import org.junit.Test

class EmergencyFundGoalUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun emergencyFundArabicLabelIsAvailable() {
        composeRule.setContent {
            MadarTheme { androidx.compose.material3.Text(GoalType.EMERGENCY_FUND.arabicLabel()) }
        }

        composeRule.onNodeWithText("صندوق الطوارئ").assertIsDisplayed()
    }
}

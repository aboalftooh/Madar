package com.shift.app.goals

import androidx.compose.material3.Text
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class GoalSmokeTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun composeTestInfrastructureStarts() {
        composeRule.setContent {
            Text("goal-smoke")
        }

        composeRule.onNodeWithText("goal-smoke").assertIsDisplayed()
    }
}

package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.ui.screens.goals.AssetGoalCompletionScreen
import com.shift.app.ui.theme.MadarTheme
import org.junit.Rule
import org.junit.Test

class AssetPurchaseGoalUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun completionScreenShowsPreviewAndConfirmAction() {
        composeRule.setContent {
            MadarTheme {
                AssetGoalCompletionScreen(previewText = "أصل + حركة رصيد + استهلاك تخصيص", onConfirm = {})
            }
        }

        composeRule.onNodeWithText("إكمال شراء الأصل").assertIsDisplayed()
        composeRule.onNodeWithText("تأكيد الشراء").assertIsDisplayed()
    }
}

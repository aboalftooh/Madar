package com.shift.app.migration

import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.platform.app.InstrumentationRegistry
import com.shift.app.data.local.migration.Migration17To18Plan
import com.shift.app.data.local.migration.SqlMigrationExecutor
import com.shift.app.data.local.sync.SyncOutboxSqlPlan
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class Migration17To18InstrumentationTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val databaseName = "migration-17-18-test.db"

    @Before fun cleanBefore() { context.deleteDatabase(databaseName) }
    @After fun cleanAfter() { context.deleteDatabase(databaseName) }

    @Test
    fun migrationExecutesAgainstSQLiteAndTriggersQueuePendingWrites() {
        createVersion17Database().close()
        val helper = openVersion18Database()
        val db = helper.writableDatabase

        listOf("transactions", "income_sources", "expense_beneficiaries", "debts").forEach { table ->
            assertTrue(db.columns(table).contains("syncState"))
        }

        val triggerCount = db.query(
            "SELECT COUNT(*) FROM sqlite_master WHERE type = 'trigger' AND name LIKE 'sync_outbox_%'",
        ).use { cursor -> cursor.moveToFirst(); cursor.getInt(0) }
        assertEquals(SyncOutboxSqlPlan.owners.size * 2, triggerCount)

        db.execSQL(
            "INSERT INTO transactions(id, operationId, updatedAt, syncState) VALUES(?, ?, ?, ?)",
            arrayOf("tx-1", "op-1", 500L, "pending"),
        )
        val queued = db.query(
            "SELECT entityType, entityId, operationId, revision FROM sync_outbox WHERE eventId = ?",
            arrayOf("transactions:op-1"),
        ).use { cursor ->
            assertTrue(cursor.moveToFirst())
            listOf(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3).toString())
        }
        assertEquals(listOf("transactions", "tx-1", "op-1", "1"), queued)

        val migrationWakeUp = db.query(
            "SELECT COUNT(*) FROM sync_outbox WHERE eventId = 'migration:17:18'",
        ).use { cursor -> cursor.moveToFirst(); cursor.getInt(0) }
        assertEquals(1, migrationWakeUp)
        helper.close()
    }

    private fun createVersion17Database(): SupportSQLiteOpenHelper = helper(
        version = 17,
        onCreate = { db ->
            SyncOutboxSqlPlan.owners.forEach { owner ->
                val columns = buildList {
                    add(if (owner.table == "ledger_history_migrations") "migrationKey TEXT" else "id TEXT")
                    if (owner.operationExpression.contains("operationId")) add("operationId TEXT")
                    add("updatedAt INTEGER NOT NULL")
                    if (owner.table !in legacyPendingTables) add("syncState TEXT NOT NULL")
                }
                db.execSQL("CREATE TABLE ${owner.table} (${columns.joinToString()})")
            }
        },
    ).also { it.writableDatabase }

    private fun openVersion18Database(): SupportSQLiteOpenHelper = helper(
        version = 18,
        onUpgrade = { db, oldVersion, newVersion ->
            assertEquals(17, oldVersion)
            assertEquals(18, newVersion)
            Migration17To18Plan.migrate(
                SqlMigrationExecutor { sql, bindArgs ->
                    if (bindArgs.isEmpty()) db.execSQL(sql) else db.execSQL(sql, bindArgs)
                },
                now = 1000L,
            )
        },
    ).also { it.writableDatabase }

    private fun helper(
        version: Int,
        onCreate: (SupportSQLiteDatabase) -> Unit = {},
        onUpgrade: (SupportSQLiteDatabase, Int, Int) -> Unit = { _, _, _ -> },
    ): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = onCreate.invoke(db)
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) =
                onUpgrade.invoke(db, oldVersion, newVersion)
        }
        val configuration = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name(databaseName)
            .callback(callback)
            .build()
        return FrameworkSQLiteOpenHelperFactory().create(configuration)
    }

    private fun SupportSQLiteDatabase.columns(table: String): Set<String> =
        query("PRAGMA table_info($table)").use { cursor ->
            buildSet {
                val nameIndex = cursor.getColumnIndexOrThrow("name")
                while (cursor.moveToNext()) add(cursor.getString(nameIndex))
            }
        }

    private companion object {
        val legacyPendingTables = setOf("transactions", "income_sources", "expense_beneficiaries", "debts")
    }
}

package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.theme.MadarTheme
import com.shift.app.viewmodel.arabicLabel
import org.junit.Rule
import org.junit.Test

class GoalPhase1EndToEndUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun allGoalTypeLabelsRenderInUi() {
        composeRule.setContent {
            MadarTheme {
                androidx.compose.foundation.layout.Column {
                    GoalType.entries.forEach { androidx.compose.material3.Text(it.arabicLabel()) }
                }
            }
        }

        composeRule.onNodeWithText("شراء منزل").assertIsDisplayed()
        composeRule.onNodeWithText("نمو صافي الثروة").assertIsDisplayed()
    }
}

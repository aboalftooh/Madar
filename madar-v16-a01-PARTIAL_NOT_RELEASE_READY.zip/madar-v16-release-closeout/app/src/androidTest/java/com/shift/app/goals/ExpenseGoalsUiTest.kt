package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.theme.MadarTheme
import com.shift.app.viewmodel.arabicLabel
import org.junit.Rule
import org.junit.Test

class ExpenseGoalsUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun expenseGoalLabelsAreAvailable() {
        composeRule.setContent {
            MadarTheme {
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.Text(GoalType.EXPENSE_REDUCTION.arabicLabel())
                    androidx.compose.material3.Text(GoalType.EXPENSE_CEILING.arabicLabel())
                }
            }
        }

        composeRule.onNodeWithText("خفض المصروف").assertIsDisplayed()
        composeRule.onNodeWithText("سقف المصروف").assertIsDisplayed()
    }
}

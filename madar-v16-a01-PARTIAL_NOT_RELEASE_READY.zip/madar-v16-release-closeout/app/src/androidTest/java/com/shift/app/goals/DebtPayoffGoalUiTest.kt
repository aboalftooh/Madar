package com.shift.app.goals

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.theme.MadarTheme
import com.shift.app.viewmodel.arabicLabel
import org.junit.Rule
import org.junit.Test

class DebtPayoffGoalUiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun debtPayoffArabicLabelIsAvailable() {
        composeRule.setContent {
            MadarTheme { androidx.compose.material3.Text(GoalType.DEBT_PAYOFF.arabicLabel()) }
        }

        composeRule.onNodeWithText("سداد الديون").assertIsDisplayed()
    }
}

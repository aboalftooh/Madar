package com.shift.app.feature.assets

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetBoundaryArchitectureTest {
    @Test
    fun `asset presentation imports domain only`() {
        val presentation = sourceDir("feature/assets/presentation").walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf(
            "com.shift.app.data.",
            "androidx.room",
            "MadarDatabase",
            "AssetRepository",
            "SyncManager",
            "SyncQueueGateway",
        ).forEach { token -> assertFalse("Presentation must not contain $token", presentation.contains(token)) }
        assertTrue(presentation.contains("CreateAssetUseCase"))
        assertTrue(presentation.contains("ObserveAssetSummariesUseCase"))
    }

    @Test
    fun `asset domain is platform independent`() {
        val domain = assetDomainDir().walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf("android.", "androidx.", "com.shift.app.data.", "MadarDatabase", "AssetDao")
            .forEach { token -> assertFalse("Domain must not contain $token", domain.contains(token)) }
        assertTrue(domain.contains("interface AssetGateway"))
    }

    @Test
    fun `old asset presentation files are removed`() {
        assertFalse(sourceDir("viewmodel/AssetsViewModel.kt").exists())
        assertFalse(sourceDir("ui/screens/AssetsScreen.kt").exists())
        assertTrue(sourceDir("feature/assets/presentation/AssetsRoute.kt").exists())
        assertTrue(sourceDir("feature/assets/presentation/AssetOverviewContent.kt").exists())
        assertTrue(sourceDir("feature/assets/presentation/AssetDialogs.kt").exists())
    }

    @Test
    fun `repository factory is split from transactional store`() {
        val repository = sourceDir("data/repository/AssetRepository.kt")
        val factory = sourceDir("feature/assets/data/AssetOperationFactory.kt")
        assertTrue(repository.readLines().size < 700)
        assertTrue(factory.exists())
        assertFalse(repository.readText().contains("object AssetOperationFactory"))
    }

    private fun assetDomainDir(): File = sequenceOf(
        File("feature/assets/src/main/java/com/shift/app/feature/assets/domain"),
        File("../feature/assets/src/main/java/com/shift/app/feature/assets/domain"),
    ).first(File::isDirectory)

    private fun sourceDir(relativePath: String): File {
        val root = sequenceOf(
            File("../app/src/main/java/com/shift/app"),
            File("app/src/main/java/com/shift/app"),
        ).first(File::isDirectory)
        return root.resolve(relativePath)
    }
}

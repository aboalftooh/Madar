package com.shift.app.goals

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalSpecializedCompletionContractTest {
    @Test
    fun generalCompletionRejectsEveryAccountingSpecializedGoalType() {
        val lifecycle = source("feature/goals/src/main/java/com/shift/app/domain/goals/usecase/GoalLifecycleUseCases.kt")
        listOf(
            "HOUSE_PURCHASE",
            "CAR_PURCHASE",
            "PROJECT_FUNDING",
            "TRIP_FUNDING",
            "DEBT_PAYOFF",
        ).forEach { assertTrue(lifecycle.contains("GoalType.$it")) }
        assertTrue(lifecycle.contains("goal.type !in specializedCompletionTypes"))
    }

    @Test
    fun uiRoutesReadyGoalsToActualSpecializedFormsAndViewModelUseCases() {
        val list = source("app/src/main/java/com/shift/app/feature/goals/presentation/GoalsListScreen.kt")
        val details = source("app/src/main/java/com/shift/app/feature/goals/presentation/GoalDetailsScreen.kt")
        val viewModel = source("app/src/main/java/com/shift/app/feature/goals/presentation/GoalsViewModel.kt")
        listOf("AssetGoalCompletionScreen", "CostGoalCompletionScreen", "DebtGoalPaymentScreen").forEach {
            assertTrue(list.contains(it))
        }
        assertTrue(details.contains("فتح الإكمال المحاسبي"))
        assertTrue(details.contains("تسجيل دفعة ضمن هدف السداد"))
        assertTrue(viewModel.contains("completeAssetPurchaseGoal.complete"))
        assertTrue(viewModel.contains("completeCostGoal.complete"))
        assertTrue(viewModel.contains("recordGoalDebtPayment.record"))
    }

    @Test
    fun specializedCommandsAreAtomicAndTransitionOnlyAfterFinancialEffects() {
        val asset = source("app/src/main/java/com/shift/app/feature/goals/data/RoomAssetGoalCompletion.kt")
        val cost = source("app/src/main/java/com/shift/app/feature/goals/data/RoomCostGoalCompletion.kt")
        val debt = source("app/src/main/java/com/shift/app/feature/goals/data/RoomGoalDebtPayment.kt")
        listOf(asset, cost, debt).forEach { assertTrue(it.contains("database.withTransaction")) }
        assertTrue(asset.indexOf("recordFundingTransaction") < asset.indexOf("goalRepository.transition"))
        assertTrue(cost.indexOf("consume(request") < cost.indexOf("goalRepository.transition"))
        assertTrue(debt.indexOf("recordReduction") < debt.indexOf("GoalLifecycleStatus.COMPLETED"))
        assertTrue(debt.contains("measured.measuredDecimal == \"0.00\""))
    }

    private fun source(path: String): String =
        sequenceOf(File("../$path"), File(path)).first(File::isFile).readText()
}

package com.shift.app

import com.shift.app.domain.debt.reminders.DebtReminderAccount
import com.shift.app.domain.debt.reminders.DebtReminderEvent
import com.shift.app.domain.debt.reminders.DebtReminderSchedule
import com.shift.app.domain.debt.reminders.DebtReminderScheduler
import com.shift.app.domain.debt.reminders.DebtReminderSnapshot
import com.shift.app.domain.debt.reminders.DebtReminderWorker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class DebtReminderSchedulerTest {
    private val scheduler = DebtReminderScheduler()

    @Test
    fun schedulesBeforeDueDueTodayMissedAndWeeklyWithoutDuplicates() {
        val snapshot = DebtReminderSnapshot(
            accounts = listOf(DebtReminderAccount(id = "a1", partyName = "Ali", dueDate = "2026-07-15")),
            schedules = listOf(
                DebtReminderSchedule(id = "s1", accountId = "a1", installmentNo = 1, dueDate = "2026-07-15", amountDecimal = "20.00"),
                DebtReminderSchedule(id = "s1", accountId = "a1", installmentNo = 1, dueDate = "2026-07-15", amountDecimal = "20.00"),
                DebtReminderSchedule(id = "s2", accountId = "a1", installmentNo = 2, dueDate = "2026-07-13", amountDecimal = "10.00")
            )
        )

        val work = scheduler.plannedWork(snapshot, today = "2026-07-14")

        assertEquals(work.map { it.key }.distinct(), work.map { it.key })
        assertTrue(work.any { it.event == DebtReminderEvent.AccountBeforeDue && it.fireDate == "2026-07-14" })
        assertTrue(work.any { it.event == DebtReminderEvent.ScheduleBeforeDue && it.fireDate == "2026-07-14" })
        assertTrue(work.any { it.event == DebtReminderEvent.ScheduleMissed && it.fireDate == "2026-07-14" })
        assertTrue(work.any { it.event == DebtReminderEvent.WeeklySummary })
        assertFalse(work.any { it.key.contains(":due:2026-07-13") })
    }

    @Test
    fun skipsNoDateClosedArchivedUnconfirmedDeletedAndCompletedItems() {
        val snapshot = DebtReminderSnapshot(
            accounts = listOf(
                DebtReminderAccount(id = "no-date", partyName = "A", dueDate = null),
                DebtReminderAccount(id = "closed", partyName = "B", dueDate = "2026-07-15", closedAt = 1),
                DebtReminderAccount(id = "archived", partyName = "C", dueDate = "2026-07-15", archivedAt = 1),
                DebtReminderAccount(id = "draft", partyName = "D", dueDate = "2026-07-15", confirmed = false),
                DebtReminderAccount(id = "active", partyName = "E", dueDate = "2026-07-16")
            ),
            schedules = listOf(
                DebtReminderSchedule(id = "paid", accountId = "active", installmentNo = 1, dueDate = "2026-07-15", amountDecimal = "1.00", status = "paid"),
                DebtReminderSchedule(id = "deleted", accountId = "active", installmentNo = 2, dueDate = "2026-07-15", amountDecimal = "1.00", deletedAt = 1)
            )
        )

        val keys = scheduler.plannedWork(snapshot, today = "2026-07-14").map { it.key }

        assertTrue(keys.all { it.contains("active") || it == "debt:weekly:2026-07-14" })
        assertFalse(keys.any { it.contains("paid") || it.contains("deleted") })
    }

    @Test
    fun usesAfricaKhartoumBoundaryForToday() {
        val clockMillis = ZonedDateTime
            .of(2026, 7, 14, 0, 30, 0, 0, ZoneId.of("Africa/Khartoum"))
            .toInstant()
            .toEpochMilli()

        assertEquals("2026-07-14", scheduler.today(clockMillis))
    }

    @Test
    fun permissionDeniedDoesNotEmitNotificationsButKeepsPlannedKeys() {
        val snapshot = DebtReminderSnapshot(
            accounts = listOf(DebtReminderAccount(id = "a1", partyName = "Ali", dueDate = "2026-07-15")),
            schedules = emptyList()
        )

        val result = DebtReminderWorker(scheduler).run(snapshot, today = "2026-07-14", notificationPermissionGranted = false)

        assertTrue(result.permissionDenied)
        assertTrue(result.plannedKeys.isNotEmpty())
        assertTrue(result.notifications.isEmpty())
    }
}

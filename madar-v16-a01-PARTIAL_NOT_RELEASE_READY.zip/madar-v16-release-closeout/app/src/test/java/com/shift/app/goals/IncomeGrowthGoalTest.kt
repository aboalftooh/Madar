package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalIncomeRow
import com.shift.app.domain.goals.measurement.IncomeGoalMeasurementProvider
import com.shift.app.domain.goals.templates.IncomeGrowthGoalTemplate
import com.shift.app.domain.goals.templates.IncomeGrowthTemplateRequest
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IncomeGrowthGoalTest {
    @Test
    fun templateDefaultsToThreeMonthWindowAndThreeConfirmationPeriods() {
        val aggregate = template()

        assertEquals(3, aggregate.goal.confirmationPeriods)
        assertEquals(3, aggregate.metrics.single().windowSize)
        assertEquals("CLOSED_MONTH_AVERAGE", aggregate.metrics.single().windowType)
    }

    @Test
    fun missingClosedHistoryIsUnavailableAndCurrentMonthIsProvisional() {
        val aggregate = template()

        val measurement = IncomeGoalMeasurementProvider.measureTransactions(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(income("2026-07-01", 9999.0)),
        )

        assertFalse(measurement.available)
        assertEquals("missing-closed-income-history", measurement.unavailableReason)
    }

    @Test
    fun closedThreeMonthAverageIsMeasuredWithoutDoubleCountingLedgerLink() {
        val aggregate = template()

        val measurement = IncomeGoalMeasurementProvider.measureTransactions(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(income("2026-04-02", 90.0), income("2026-05-02", 120.0), income("2026-06-02", 150.0)),
        )

        assertTrue(measurement.available)
        assertEquals("120.00", measurement.measuredDecimal)
        assertEquals(2, measurement.confirmationStreak)
        assertTrue(measurement.sourceFingerprint.contains("streak=2"))
    }

    @Test
    fun successfulAverageReportsCompleteConfirmationStreak() {
        val aggregate = template()

        val measurement = IncomeGoalMeasurementProvider.measureTransactions(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(income("2026-04-02", 100.0), income("2026-05-02", 110.0), income("2026-06-02", 120.0)),
        )

        assertEquals("110.00", measurement.measuredDecimal)
        assertEquals(3, measurement.confirmationStreak)
    }

    @Test
    fun interruptedSequenceReportsOnlyLatestConsecutiveSuccesses() {
        val aggregate = template()

        val measurement = IncomeGoalMeasurementProvider.measureTransactions(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(income("2026-04-02", 200.0), income("2026-05-02", 50.0), income("2026-06-02", 100.0)),
        )

        assertEquals("116.67", measurement.measuredDecimal)
        assertEquals(1, measurement.confirmationStreak)
    }

    private fun template() = IncomeGrowthGoalTemplate.build(
        IncomeGrowthTemplateRequest(
            id = "income",
            name = "زيادة الدخل",
            targetDecimal = "100.00",
            baselineDecimal = "80.00",
            startDate = "2026-07-01",
            deadline = "2026-12-31",
            timezoneId = "UTC",
            now = 1L,
        ),
    )

    private fun income(date: String, amount: Double) = GoalIncomeRow(id = "income-$date-$amount", date = date, amountDecimal = java.math.BigDecimal.valueOf(amount).setScale(2).toPlainString(), deletedAt = null)
}

package com.shift.app

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.domain.finance.BalanceCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class BalanceCalculatorTest {
    @Test
    fun currentBalance_sumsInflowsMinusOutflows() {
        val result = BalanceCalculator.currentBalance(
            listOf(
                balanceTransaction(direction = "inflow", amount = "100.00"),
                balanceTransaction(direction = "outflow", amount = "40.25")
            )
        )

        assertEquals("59.75", result.toPlainString())
    }

    @Test
    fun currentBalance_canBeNegativeOrZero() {
        val negative = BalanceCalculator.currentBalance(
            listOf(balanceTransaction(direction = "outflow", amount = "10.00"))
        )
        val zero = BalanceCalculator.currentBalance(
            listOf(
                balanceTransaction(direction = "inflow", amount = "10.00"),
                balanceTransaction(direction = "outflow", amount = "10.00")
            )
        )

        assertEquals("-10.00", negative.toPlainString())
        assertEquals("0.00", zero.toPlainString())
    }

    @Test
    fun currentBalance_ignoresSoftDeletedRows() {
        val result = BalanceCalculator.currentBalance(
            listOf(
                balanceTransaction(direction = "inflow", amount = "20.00"),
                balanceTransaction(direction = "inflow", amount = "50.00", deletedAt = 1L)
            )
        )

        assertEquals("20.00", result.toPlainString())
    }

    private fun balanceTransaction(
        direction: String,
        amount: String,
        deletedAt: Long? = null
    ) = BalanceTransaction(
        operationId = "op-$direction-$amount",
        direction = direction,
        kind = "opening_balance",
        amountDecimal = amount,
        date = "2026-07-12",
        deletedAt = deletedAt
    )
}

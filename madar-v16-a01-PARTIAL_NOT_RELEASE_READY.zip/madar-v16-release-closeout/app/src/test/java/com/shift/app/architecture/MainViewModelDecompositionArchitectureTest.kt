package com.shift.app.architecture

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MainViewModelDecompositionArchitectureTest {
    @Test
    fun `god main view model is removed`() {
        assertFalse(sourceFile("viewmodel/MainViewModel.kt").exists())
        val production = productionSources()
        assertFalse(production.contains("MainViewModel"))
    }

    @Test
    fun `app shell owns session and transaction entry points only`() {
        val source = source("ui/screens/MainScreen.kt")
        assertTrue(source.contains("AppSessionViewModel"))
        assertTrue(source.contains("TransactionsViewModel"))
        assertTrue(source.contains("sessionVm.initialSync()"))
        assertFalse(source.contains("MadarDatabase"))
        assertFalse(source.contains("TransactionRepository"))
    }

    @Test
    fun `session presentation depends on session gateway only`() {
        val source = source("feature/session/presentation/AppSessionViewModel.kt")
        assertTrue(source.contains("AppSessionGateway"))
        assertFalse(source.contains("PreferencesManager"))
        assertFalse(source.contains("SyncManager"))
        assertFalse(source.contains("Repository"))
        assertFalse(source.contains("MadarDatabase"))
    }

    @Test
    fun `feature screens use feature view models`() {
        assertTrue(source("ui/screens/DashboardScreen.kt").contains("TransactionsViewModel"))
        assertTrue(source("feature/reports/presentation/ReportsRoute.kt").contains("ReportsViewModel"))
        val settings = source("ui/screens/SettingsScreen.kt")
        assertTrue(settings.contains("SettingsViewModel"))
        assertTrue(settings.contains("BackupViewModel"))
        assertTrue(settings.contains("AppSessionViewModel"))
    }

    private fun productionSources(): String =
        sourceFile("").walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }

    private fun source(relativePath: String): String = sourceFile(relativePath).readText()

    private fun sourceFile(relativePath: String): File {
        val roots = sequenceOf(
            File("../app/src/main/java/com/shift/app"),
            File("app/src/main/java/com/shift/app"),
        )
        val root = roots.first(File::isDirectory)
        return if (relativePath.isBlank()) root else File(root, relativePath)
    }
}

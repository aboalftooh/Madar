package com.shift.app

import com.shift.app.domain.debt.DebtAccountSnapshot
import com.shift.app.domain.debt.DebtAccountStatus
import com.shift.app.domain.debt.DebtCalculator
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtFamily
import com.shift.app.domain.debt.DebtMoney
import com.shift.app.domain.debt.DebtOperationFactory
import com.shift.app.domain.debt.DebtTransactionInput
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.debt.DebtUserFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtDomainTest {
    private val now = 1_789_347_600_000L

    @Test
    fun debtScenariosCoverS01ToS40WithFamilyFlowAndCanonicalAmounts() {
        val scenarios = (1..40).map { index ->
            val family = DebtFamily.entries[(index - 1) % DebtFamily.entries.size]
            val flow = DebtUserFlow.entries[(index - 1) % DebtUserFlow.entries.size]
            Scenario("S%02d".format(index), family, flow, DebtMoney.of(index.toString()).decimalText)
        }

        assertEquals(40, scenarios.size)
        assertEquals((1..40).map { "S%02d".format(it) }, scenarios.map { it.id })
        assertEquals(DebtFamily.entries.toSet(), scenarios.map { it.family }.toSet())
        assertEquals(DebtUserFlow.entries.toSet(), scenarios.map { it.flow }.toSet())
        assertTrue(scenarios.all { it.expectedAmount.matches(Regex("""\d+\.\d{2}""")) })
    }

    @Test
    fun familyImpactRulesCoverF01ToF10() {
        val payable = account(DebtDirection.Payable, tx(DebtTransactionType.Opening, "100.00"))
        val receivable = account(DebtDirection.Receivable, tx(DebtTransactionType.Opening, "100.00"))

        val drafts = listOf(
            DebtOperationFactory.opening("op01", "a1", DebtDirection.Payable, "Ali", "100", now),
            DebtOperationFactory.cashPrincipal("op02", "a2", DebtDirection.Receivable, "Ali", "100", DebtCashSource.MadarBalance, now),
            DebtOperationFactory.deferredExpense("op03", "a3", "Store", "100", now),
            DebtOperationFactory.accruedIncome("op04", "a4", "Client", "100", now),
            DebtOperationFactory.financedAsset("op05", "a5", "Seller", "80", "100", "20", now),
            DebtOperationFactory.assetSettlement("op06", "a6", DebtDirection.Payable, "Seller", "50", "55", now),
            DebtOperationFactory.cashReduction("op07", payable, "10", DebtCashSource.External, now),
            DebtOperationFactory.adjustment("op08", receivable, DebtTransactionType.WriteOff, "10", "uncollectable", now),
            DebtOperationFactory.reversal("op09", payable, "original-tx", "10", "mistake", now),
            DebtOperationFactory.organization("op10", payable, DebtTransactionType.SplitOut, "10", now)
        )

        assertEquals(DebtFamily.entries.toSet(), drafts.map { it.impact.family }.toSet())
        assertFalse(drafts.any { it.impact.entersOrdinaryIncome && it.impact.entersOrdinaryExpense })
    }

    @Test
    fun remainingIsDerivedNonNegativeAndStatusHasNoSettlementBoolean() {
        val account = account(
            DebtDirection.Payable,
            tx(DebtTransactionType.Opening, "100.00"),
            tx(DebtTransactionType.Payment, "40.00"),
            tx(DebtTransactionType.Waiver, "100.00")
        )

        val result = DebtCalculator.calculate(account)

        assertEquals("0.00", result.remainingDecimal)
        assertEquals(DebtAccountStatus.Settled, result.status)
        assertEquals("0.00", result.confirmedPayableDecimal)
    }

    @Test
    fun unconfirmedLegacyDebtIsExcludedFromWealthAndNeedsReview() {
        val account = account(DebtDirection.Receivable, tx(DebtTransactionType.Opening, "125.00")).copy(confirmed = false)

        val result = DebtCalculator.calculate(account)

        assertEquals(DebtAccountStatus.NeedsReview, result.status)
        assertEquals("0.00", result.confirmedReceivableDecimal)
    }

    @Test
    fun overpaymentIsRejected() {
        val account = account(DebtDirection.Payable, tx(DebtTransactionType.Opening, "25.00"))

        assertThrows(IllegalArgumentException::class.java) {
            DebtOperationFactory.cashReduction("op", account, "25.01", DebtCashSource.MadarBalance, now)
        }
    }

    @Test
    fun partyIsRequiredForNewDebt() {
        assertThrows(IllegalArgumentException::class.java) {
            DebtOperationFactory.opening("op", "a", DebtDirection.Payable, " ", "10", now)
        }
    }

    @Test
    fun reasonIsRequiredForAdjustments() {
        val account = account(DebtDirection.Receivable, tx(DebtTransactionType.Opening, "50.00"))

        assertThrows(IllegalArgumentException::class.java) {
            DebtOperationFactory.adjustment("op", account, DebtTransactionType.WriteOff, "10", " ", now)
        }
    }

    @Test
    fun madarBalanceOperationsDeclareBalanceRequirementAndExternalWarning() {
        val madar = DebtOperationFactory.cashPrincipal("op1", "a", DebtDirection.Payable, "Ali", "100", DebtCashSource.MadarBalance, now)
        val external = DebtOperationFactory.cashPrincipal("op2", "b", DebtDirection.Payable, "Ali", "100", DebtCashSource.External, now)

        assertTrue(madar.impact.requiresBalanceEnabled)
        assertFalse(madar.impact.externalCashWarning)
        assertEquals("100.00", madar.impact.balanceDeltaDecimal)
        assertFalse(external.impact.requiresBalanceEnabled)
        assertTrue(external.impact.externalCashWarning)
        assertEquals("0.00", external.impact.balanceDeltaDecimal)
    }

    @Test
    fun organizationRequiresMatchingDirectionAndCurrency() {
        val payable = account(DebtDirection.Payable, tx(DebtTransactionType.Opening, "10.00"))
        val receivable = account(DebtDirection.Receivable, tx(DebtTransactionType.Opening, "10.00"))

        assertThrows(IllegalArgumentException::class.java) {
            DebtCalculator.assertSameDirection(listOf(payable, receivable))
        }
        assertThrows(IllegalArgumentException::class.java) {
            DebtCalculator.assertSingleCurrency(listOf(payable, payable.copy(accountId = "b", currencyCode = "USD")))
        }
    }

    @Test
    fun reversalRestoresOriginalRemainingEffect() {
        val original = tx(DebtTransactionType.Payment, "25.00").copy(id = "p1")
        val account = account(
            DebtDirection.Payable,
            tx(DebtTransactionType.Opening, "100.00"),
            original,
            tx(DebtTransactionType.Reversal, "0.00").copy(originalTransactionId = "p1")
        )

        assertEquals("100.00", DebtCalculator.calculate(account).remainingDecimal)
    }

    private fun account(direction: DebtDirection, vararg txs: DebtTransactionInput) = DebtAccountSnapshot(
        accountId = "account-${direction.name}",
        direction = direction,
        partyName = "Party",
        currencyCode = "SDG",
        confirmed = true,
        archived = false,
        transactions = txs.toList()
    )

    private fun tx(type: DebtTransactionType, amount: String) = DebtTransactionInput(
        id = "tx-$type-$amount-${Math.random()}",
        accountId = "account",
        operationId = "op",
        type = type,
        amount = DebtMoney.of(amount),
        occurredAtEpochMillis = now
    )

    private data class Scenario(
        val id: String,
        val family: DebtFamily,
        val flow: DebtUserFlow,
        val expectedAmount: String
    )
}

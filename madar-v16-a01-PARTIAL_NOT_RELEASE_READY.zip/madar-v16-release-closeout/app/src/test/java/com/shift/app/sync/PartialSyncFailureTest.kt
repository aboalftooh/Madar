package com.shift.app.sync

import com.shift.app.sync.SyncRunResult
import com.shift.app.sync.SyncStepFailure
import com.shift.app.sync.runIsolatedSyncStep
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PartialSyncFailureTest {
    @Test
    fun independentFailureProducesRetryablePartialResult() = runBlocking {
        val failures = mutableListOf<SyncStepFailure>()
        var secondRan = false

        runIsolatedSyncStep("assets", failures) { error("offline") }
        runIsolatedSyncStep("debts", failures) { secondRan = true }

        val result = SyncRunResult.PartialFailure(failures.map { it.step })
        assertTrue(secondRan)
        assertEquals(listOf("assets"), result.failedSteps)
    }
}

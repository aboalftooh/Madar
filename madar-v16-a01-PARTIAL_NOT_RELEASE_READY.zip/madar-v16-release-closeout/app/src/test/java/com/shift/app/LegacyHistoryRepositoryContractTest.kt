package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class LegacyHistoryRepositoryContractTest {
    @Test
    fun migratedLegacyEditAndDeleteTouchTransactionBalanceAndPaymentAtomically() {
        val source = sequenceOf(
            File("../app/src/main/java/com/shift/app/data/repository/TransactionRepository.kt"),
            File("app/src/main/java/com/shift/app/data/repository/TransactionRepository.kt")
        ).first(File::isFile).readText()

        assertTrue(source.contains("updateWithLinkedIncome(transaction: Transaction): LinkedIncomeRecords = db.withTransaction"))
        assertTrue(source.contains("paymentDao.getByLegacyTransactionId(transaction.id)"))
        assertTrue(source.contains("paymentDao.update(it)"))
        assertTrue(source.contains("softDeleteWithLinkedIncome(id: String, deletedAt: Long)"))
        assertTrue(source.contains("deletedPayment"))
        assertTrue(source.contains("legacyTransactionId = transaction.id"))
        assertTrue(source.contains("historyCompleted && transaction.type == \"expense\""))
        assertTrue(source.contains("(!linkIncomeToBalance && !historyCompleted)"))
    }

    @Test
    fun roomSchemaKeepsV14LegacyLinksAndAddsDebtMigration() {
        val source = sequenceOf(
            File("../app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt"),
            File("app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt")
        ).first(File::isFile).readText()

        assertTrue(source.contains("version = 18"))
        assertTrue(source.contains("MIGRATION_13_14"))
        assertTrue(source.contains("MIGRATION_14_15"))
        assertTrue(source.contains("index_balance_transactions_legacyTransactionId"))
        assertTrue(source.contains("index_payments_legacyTransactionId"))
        assertTrue(source.contains("ledger_history_migrations"))
        assertTrue(source.contains("opening_balance_adjustment"))
    }

    @Test
    fun paymentEditorRoutesMigratedExpensesThroughTheLinkedTransactionRepository() {
        val source = sequenceOf(
            File("../app/src/main/java/com/shift/app/viewmodel/PaymentsViewModel.kt"),
            File("app/src/main/java/com/shift/app/viewmodel/PaymentsViewModel.kt")
        ).first(File::isFile).readText()

        assertTrue(source.contains("original.legacyTransactionId"))
        assertTrue(source.contains("transactionRepo.updateWithLinkedIncome(updated)"))
        assertTrue(source.contains("transactionRepo.softDeleteWithLinkedIncome"))
        assertTrue(source.contains("operationId = records.transaction.operationId ?: records.transaction.id"))
    }
}

package com.shift.app.feature.reports

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportsBoundaryArchitectureTest {
    private val root = sequenceOf(
        File("app/src/main/java/com/shift/app"),
        File("../app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
    private val domainRoot = sequenceOf(
        File("feature/reports/src/main/java/com/shift/app/feature/reports/domain"),
        File("../feature/reports/src/main/java/com/shift/app/feature/reports/domain"),
    ).first(File::isDirectory)

    @Test
    fun `reports presentation imports no room repositories or calculators`() {
        val source = File(root, "feature/reports/presentation").walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf(
            "com.shift.app.data.",
            "androidx.room",
            "MadarDatabase",
            "Dao",
            "Repository",
            "FinancialReportCalculator",
            "AssetRepository",
        ).forEach { token -> assertFalse("Presentation must not contain $token", source.contains(token)) }
        assertTrue(source.contains("ReportsReadModel"))
        assertTrue(source.contains("ObserveReportsUseCase"))
    }

    @Test
    fun `reports domain is independent from data and android`() {
        val source = domainRoot.walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf("com.shift.app.data.", "android.", "androidx.", "MadarDatabase", "Dao", "Entity")
            .forEach { token -> assertFalse("Domain must not contain $token", source.contains(token)) }
        assertTrue(source.contains("interface ReportsQuery"))
        assertTrue(source.contains("BuildReportsReadModelUseCase"))
    }

    @Test
    fun `legacy reports files are removed and navigation uses feature screen`() {
        assertFalse(File(root, "viewmodel/ReportsViewModel.kt").exists())
        assertFalse(File(root, "ui/screens/ReportsScreen.kt").exists())
        assertTrue(File(root, "feature/reports/presentation/ReportsViewModel.kt").isFile)
        assertTrue(File(root, "feature/reports/presentation/ReportsScreen.kt").isFile)
        assertTrue(File(root, "feature/reports/presentation/ReportsRoute.kt").isFile)
        val main = File(root, "ui/screens/MainScreen.kt").readText()
        assertTrue(main.contains("feature.reports.presentation.ReportsRoute"))
    }

    @Test
    fun `reports cache is owned by viewmodel state only`() {
        val vm = File(root, "feature/reports/presentation/ReportsViewModel.kt").readText()
        val adapter = File(root, "feature/reports/data/ReportsQueryAdapter.kt").readText()
        assertTrue(vm.contains("stateIn("))
        assertFalse(adapter.contains("stateIn("))
        assertFalse(adapter.contains("shareIn("))
        assertFalse(adapter.contains("MutableStateFlow"))
    }
}

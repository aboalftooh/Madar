package com.shift.app

import com.shift.app.utils.ExpenseTextNormalizer
import org.junit.Assert.assertEquals
import org.junit.Test

class ExpenseTextNormalizerTest {
    @Test
    fun displayText_trimsAndCollapsesSpaces() {
        assertEquals("ايجار البيت", ExpenseTextNormalizer.displayText("  ايجار   البيت  "))
    }

    @Test
    fun key_normalizesHamzaForms() {
        assertEquals(ExpenseTextNormalizer.key("ايجار"), ExpenseTextNormalizer.key("إيجار"))
    }

    @Test
    fun key_normalizesAlefMaqsuraToYaa() {
        assertEquals(ExpenseTextNormalizer.key("اجري"), ExpenseTextNormalizer.key("أجرى"))
    }
}

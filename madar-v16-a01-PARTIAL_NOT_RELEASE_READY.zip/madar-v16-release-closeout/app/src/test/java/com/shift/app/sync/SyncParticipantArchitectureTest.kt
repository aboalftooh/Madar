package com.shift.app.sync

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncParticipantArchitectureTest {
    @Test
    fun facadeAndOrchestratorAreInfrastructureAgnostic() {
        val manager = source("app/src/main/java/com/shift/app/data/remote/SyncManager.kt")
        val orchestrator = source("app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt")
        val forbidden = listOf("data.local", "MadarDatabase", "Dao", "SupabaseClient", "androidx.room")

        forbidden.forEach {
            assertFalse("SyncManager imports $it", manager.contains("import $it") || manager.contains("com.shift.app.$it"))
            assertFalse("SyncOrchestrator imports $it", orchestrator.contains("import $it") || orchestrator.contains("com.shift.app.$it"))
        }
        assertTrue(manager.lineSequence().count() < 100)
    }

    @Test
    fun sixFeatureParticipantsAreRegisteredThroughMultibinding() {
        val module = source("app/src/main/java/com/shift/app/sync/di/SyncParticipantModule.kt")
        val bindings = Regex("@Binds @IntoSet").findAll(module).count()
        assertEquals(6, bindings)
        listOf("ReferenceData", "Ledger", "Assets", "Debts", "Goals", "Settings").forEach {
            assertTrue(module.contains("bind$it"))
        }
    }

    @Test
    fun remoteSynchronizationIsSplitByFeaturePort() {
        val root = sequenceOf(File("../app/src/main/java"), File("app/src/main/java"))
            .first(File::isDirectory)
        assertFalse(File(root, "com/shift/app/data/remote/RemoteSyncDataSource.kt").exists())

        val slices = listOf(
            "ReferenceDataRemoteSyncDataSource.kt",
            "LedgerRemoteSyncDataSource.kt",
            "AssetRemoteSyncDataSource.kt",
            "DebtRemoteSyncDataSource.kt",
            "GoalRemoteSyncDataSource.kt",
            "SettingsRemoteSyncDataSource.kt",
        ).map { File(root, "com/shift/app/data/remote/$it") }
        assertTrue(slices.all(File::isFile))
        assertTrue(slices.all { it.readLines().size < 750 })

        val participants = File(root, "com/shift/app/sync/participant")
            .walkTopDown().filter { it.extension == "kt" }.joinToString("\n") { it.readText() }
        assertTrue(participants.contains("com.shift.app.sync.remote"))
        assertFalse(participants.contains("com.shift.app.data.remote.RemoteSync"))
    }

    private fun source(path: String): String = sequenceOf(
        File("../$path"),
        File(path),
    ).first(File::isFile).readText()
}

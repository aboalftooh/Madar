package com.shift.app

import com.shift.app.utils.SyncMergePolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncMergePolicyTest {
    @Test
    fun shouldApplyRemote_acceptsRemoteWhenLocalMissingOrNotNewer() {
        assertTrue(SyncMergePolicy.shouldApplyRemote(localUpdatedAt = null, remoteUpdatedAt = 100L))
        assertTrue(SyncMergePolicy.shouldApplyRemote(localUpdatedAt = 100L, remoteUpdatedAt = 100L))
        assertTrue(SyncMergePolicy.shouldApplyRemote(localUpdatedAt = 100L, remoteUpdatedAt = 101L))
    }

    @Test
    fun shouldApplyRemote_rejectsRemoteWhenLocalIsNewer() {
        assertFalse(SyncMergePolicy.shouldApplyRemote(localUpdatedAt = 101L, remoteUpdatedAt = 100L))
    }

    @Test
    fun shouldApplyRemote_rejectsKnownDirtyLocalRows() {
        assertFalse(
            SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = 1L,
                remoteUpdatedAt = 999L,
                lastSuccessfulSync = 100L,
                localSyncState = "pending",
            ),
        )
    }

}

package com.shift.app.feature.debts

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtGatewayAdapterTest {
    @Test
    fun `adapter maps owned debt DAOs and uses cross feature ports`() {
        val source = source("feature/debts/data/DebtGatewayAdapter.kt")
        assertTrue(source.contains(": DebtGateway"))
        assertTrue(source.contains("DebtEntityMapper"))
        assertTrue(source.contains("DebtSettlementAssetQuery"))
        assertTrue(source.contains("DebtGoalScopePort"))
        assertFalse(source.contains("AssetDao"))
        assertFalse(source.contains("FinancialGoalRepository"))
        assertFalse(source.contains("BalanceTransactionDao"))
        assertFalse(source.contains("PaymentDao"))
    }

    @Test
    fun `commands are session guarded and queued after local commit`() {
        val source = source("feature/debts/data/DebtGatewayAdapter.kt")
        assertTrue(source.contains("syncManager.executeSessionOperation"))
        assertTrue(source.contains("syncQueue.requestSync"))
        assertTrue(source.contains("runCatching"))
        assertTrue(source.contains("DebtSessionExpiredException"))
    }

    private fun source(relativePath: String): String = root().resolve(relativePath).readText()
    private fun root(): File = sequenceOf(
        File("../app/src/main/java/com/shift/app"),
        File("app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
}

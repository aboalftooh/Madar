package com.shift.app

import com.shift.app.feature.debts.presentation.DebtAccountUiModel
import com.shift.app.feature.debts.presentation.DebtCenterState
import com.shift.app.feature.debts.presentation.DebtCenterTab
import org.junit.Assert.assertEquals
import org.junit.Test

class DebtCenterUiContractTest {
    @Test
    fun filtersPayablesReceivablesAndNoDateWithoutSettlementBoolean() {
        val state = DebtCenterState(
            accounts = listOf(
                DebtAccountUiModel("p", "Ali", "payable", "10.00", null, "no_date", "pending", false),
                DebtAccountUiModel("r", "Omar", "receivable", "5.00", "2026-07-14", "due_today", "synced", false)
            )
        )
        assertEquals(listOf("p"), state.copy(selectedTab = DebtCenterTab.Payables).visibleAccounts.map { it.id })
        assertEquals(listOf("r"), state.copy(selectedTab = DebtCenterTab.Receivables).visibleAccounts.map { it.id })
        assertEquals(listOf("p"), state.copy(selectedTab = DebtCenterTab.NoDate).visibleAccounts.map { it.id })
    }
}

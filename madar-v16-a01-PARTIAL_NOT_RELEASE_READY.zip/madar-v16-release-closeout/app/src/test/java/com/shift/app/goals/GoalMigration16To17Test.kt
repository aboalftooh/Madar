package com.shift.app.goals

import androidx.sqlite.db.SupportSQLiteDatabase
import com.shift.app.data.local.MadarDatabase
import java.io.File
import java.lang.reflect.Proxy
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalMigration16To17Test {

    @Test
    fun `migration drops legacy goals without reading or copying rows`() {
        val statements = executeMigration()

        assertEquals("DROP TABLE goals", statements.first())
        assertFalse(statements.any { it.startsWith("SELECT", ignoreCase = true) })
        assertFalse(statements.any { it.startsWith("INSERT", ignoreCase = true) })
        assertFalse(statements.any { "goals_new" in it })
    }

    @Test
    fun `migration creates the nine phase one tables and required indexes`() {
        val statements = executeMigration()
        val expectedTables = setOf(
            "financial_goals",
            "goal_metrics",
            "goal_conditions",
            "goal_scopes",
            "goal_funding_transactions",
            "goal_cost_estimates",
            "goal_evaluations",
            "goal_activities",
            "financial_change_outbox",
        )
        val createdTables = statements.mapNotNull { statement ->
            Regex("CREATE TABLE IF NOT EXISTS ([a-z_]+)").find(statement)?.groupValues?.get(1)
        }.toSet()

        assertEquals(expectedTables, createdTables)
        assertEquals(16, MadarDatabase.MIGRATION_16_17.startVersion)
        assertEquals(17, MadarDatabase.MIGRATION_16_17.endVersion)
        assertTrue(statements.any { "UNIQUE INDEX IF NOT EXISTS index_goal_funding_transactions_operationId" in it })
        assertTrue(statements.any { "UNIQUE INDEX IF NOT EXISTS index_goal_evaluations_goalId_inputFingerprint_engineVersion" in it })
        assertTrue(statements.any { "UNIQUE INDEX IF NOT EXISTS index_goal_scopes_goalId_dimension_referenceId_effectiveFrom" in it })
        assertTrue(statements.any { "index_financial_change_outbox_processedAt_createdAt" in it })
    }

    @Test
    fun `v16 fixture table manifest migrates to the generated v17 identity`() {
        val v16 = schema(16)
        val v17 = schema(17)
        val fixtureTables = entityTables(v16).toMutableSet()
        assertTrue(fixtureTables.remove("goals"))

        val createdTables = executeMigration().mapNotNull { statement ->
            Regex("CREATE TABLE IF NOT EXISTS ([a-z_]+)").find(statement)?.groupValues?.get(1)
        }
        fixtureTables += createdTables

        assertEquals(entityTables(v17), fixtureTables)
        assertFalse("goals" in fixtureTables)
        assertEquals(17, v17.getJSONObject("database").getInt("version"))
        assertTrue(v17.getJSONObject("database").getString("identityHash").isNotBlank())
    }

    @Test
    fun `all goal foreign keys use no action`() {
        val foreignKeyLines = executeMigration()
            .flatMap(String::lines)
            .filter { "FOREIGN KEY" in it }

        assertTrue(foreignKeyLines.isNotEmpty())
        assertTrue(foreignKeyLines.all { "ON UPDATE NO ACTION ON DELETE NO ACTION" in it })
    }

    private fun executeMigration(): List<String> {
        val statements = mutableListOf<String>()
        val database = Proxy.newProxyInstance(
            SupportSQLiteDatabase::class.java.classLoader,
            arrayOf(SupportSQLiteDatabase::class.java),
        ) { _, method, args ->
            if (method.name == "execSQL") statements += args.orEmpty().first() as String
            defaultValue(method.returnType)
        } as SupportSQLiteDatabase

        MadarDatabase.MIGRATION_16_17.migrate(database)
        return statements
    }

    private fun schema(version: Int): JSONObject {
        val relative = "schemas/com.shift.app.data.local.MadarDatabase/$version.json"
        val file = sequenceOf(File(relative), File("app/$relative"), File("../app/$relative"))
            .first(File::isFile)
        return JSONObject(file.readText())
    }

    private fun entityTables(schema: JSONObject): Set<String> {
        val entities = schema.getJSONObject("database").getJSONArray("entities")
        return buildSet {
            repeat(entities.length()) { index -> add(entities.getJSONObject(index).getString("tableName")) }
        }
    }

    private fun defaultValue(type: Class<*>): Any? = when (type) {
        java.lang.Boolean.TYPE -> false
        java.lang.Byte.TYPE -> 0.toByte()
        java.lang.Short.TYPE -> 0.toShort()
        java.lang.Integer.TYPE -> 0
        java.lang.Long.TYPE -> 0L
        java.lang.Float.TYPE -> 0f
        java.lang.Double.TYPE -> 0.0
        java.lang.Character.TYPE -> '\u0000'
        else -> null
    }
}

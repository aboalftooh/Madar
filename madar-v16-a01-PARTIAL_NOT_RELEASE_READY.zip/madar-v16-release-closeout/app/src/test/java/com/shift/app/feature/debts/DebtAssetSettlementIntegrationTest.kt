package com.shift.app.feature.debts

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtAssetSettlementIntegrationTest {
    @Test
    fun `asset settlement remains one Room transaction`() {
        val source = source("data/repository/DebtLedgerRepository.kt")
        val start = source.indexOf("suspend fun recordAssetSettlement")
        val end = source.indexOf("suspend fun recordAssetSaleOnCredit", start)
        val method = source.substring(start, end)
        assertTrue(method.contains("db.withTransaction"))
        assertTrue(method.contains("transactionDao.upsert"))
        assertTrue(method.contains("assetTransactionDao.insert"))
        assertTrue(method.contains("assetDao.update"))
        assertTrue(method.contains("writeLink"))
    }

    @Test
    fun `available settlement assets are queried through AssetGateway contract`() {
        val source = source("feature/debts/data/AssetDebtSettlementQueryAdapter.kt")
        assertTrue(source.contains("AssetGateway"))
        assertTrue(source.contains("observeAssets"))
        assertTrue(source.contains("AssetStatus.Active"))
    }

    private fun source(relativePath: String): String = root().resolve(relativePath).readText()
    private fun root(): File = sequenceOf(
        File("../app/src/main/java/com/shift/app"),
        File("app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
}

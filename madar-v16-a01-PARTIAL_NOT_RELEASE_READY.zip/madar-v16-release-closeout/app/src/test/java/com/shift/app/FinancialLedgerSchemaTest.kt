package com.shift.app

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.repository.toBalanceTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.domain.finance.SyncState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import kotlin.reflect.full.memberProperties

class FinancialLedgerSchemaTest {
    @Test
    fun databaseValues_matchSourceOfTruthNames() {
        assertEquals("inflow", BalanceDirection.Inflow.dbValue)
        assertEquals("outflow", BalanceDirection.Outflow.dbValue)
        assertEquals("opening_balance", BalanceTransactionKind.OpeningBalance.dbValue)
        assertEquals("opening_balance_adjustment", BalanceTransactionKind.OpeningBalanceAdjustment.dbValue)
        assertEquals("manual_withdrawal", BalanceTransactionKind.ManualWithdrawal.dbValue)
        assertEquals("ordinary_expense", PaymentKind.OrdinaryExpense.dbValue)
        assertEquals("asset_maintenance", PaymentKind.AssetMaintenance.dbValue)
        assertEquals("incomplete_remote", SyncState.IncompleteRemote.dbValue)
    }

    @Test
    fun paymentKinds_mapToExpectedBalanceTransactionKinds() {
        assertEquals(BalanceTransactionKind.ExpensePayment, PaymentKind.OrdinaryExpense.toBalanceTransactionKind())
        assertEquals(BalanceTransactionKind.AssetPurchase, PaymentKind.AssetPurchase.toBalanceTransactionKind())
        assertEquals(BalanceTransactionKind.AssetImprovement, PaymentKind.AssetImprovement.toBalanceTransactionKind())
        assertEquals(BalanceTransactionKind.AssetMaintenance, PaymentKind.AssetMaintenance.toBalanceTransactionKind())
        assertEquals(BalanceTransactionKind.ManualWithdrawal, PaymentKind.BalanceWithdrawal.toBalanceTransactionKind())
    }

    @Test
    fun newFinancialEntities_doNotUseFloatingPointFields() {
        val forbidden = setOf(Double::class, Float::class)

        val balanceHasFloatingPoint = BalanceTransaction::class.memberProperties.any { it.returnType.classifier in forbidden }
        val paymentHasFloatingPoint = Payment::class.memberProperties.any { it.returnType.classifier in forbidden }

        assertFalse(balanceHasFloatingPoint)
        assertFalse(paymentHasFloatingPoint)
        assertFalse(LedgerHistoryMigration::class.memberProperties.any { it.returnType.classifier in forbidden })
    }

    @Test
    fun incomeTransaction_hasStableLedgerLinkFields() {
        val names = Transaction::class.memberProperties.map { it.name }.toSet()

        assertEquals(true, "operationId" in names)
        assertEquals(true, "balanceTransactionId" in names)
    }
}

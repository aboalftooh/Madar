package com.shift.app.feature.debts

import com.shift.app.domain.debt.DebtDirection
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.usecase.DebtCommandUseCases
import com.shift.app.feature.debts.domain.usecase.ObserveDebtCenterUseCase
import com.shift.app.feature.debts.domain.usecase.ObservePayableDebtAccountsUseCase
import com.shift.app.feature.debts.presentation.DebtsViewModel
import com.shift.app.testing.debts.FakeDebtGateway
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DebtsViewModelTest {
    @Test
    fun openingCommandIsNormalizedAndDelegatedThroughUseCases() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        Dispatchers.setMain(dispatcher)
        try {
            val gateway = FakeDebtGateway()
            val viewModel = DebtsViewModel(
                observeDebtCenter = ObserveDebtCenterUseCase(gateway),
                commands = DebtCommandUseCases(gateway),
            )
            val collection = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
                viewModel.state.collect { }
            }

            viewModel.createOpening(
                direction = DebtDirection.Payable,
                partyName = "المورد",
                amountDecimal = "1200",
                includeInActivePayoffGoal = false,
            )
            advanceUntilIdle()

            assertEquals("1200.00", gateway.lastOpenRequest?.amountDecimal)
            assertFalse(viewModel.state.value.isSubmitting)
            assertEquals(null, viewModel.state.value.errorMessage)
            collection.cancel()
        } finally {
            Dispatchers.resetMain()
        }
    }

    @Test
    fun gatewayFailureBecomesUiErrorWithoutLeavingSubmittingState() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        Dispatchers.setMain(dispatcher)
        try {
            val gateway = FakeDebtGateway().apply { failure = IllegalStateException("network down") }
            val viewModel = DebtsViewModel(
                ObserveDebtCenterUseCase(gateway),
                DebtCommandUseCases(gateway),
            )
            val collection = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
                viewModel.state.collect { }
            }

            viewModel.createOpening(
                DebtDirection.Receivable,
                "عميل",
                "50",
                includeInActivePayoffGoal = false,
            )
            advanceUntilIdle()

            assertEquals("network down", viewModel.state.value.errorMessage)
            assertFalse(viewModel.state.value.isSubmitting)
            collection.cancel()
        } finally {
            Dispatchers.resetMain()
        }
    }

    @Test
    fun payableDebtQueryReturnsOnlyConfirmedActivePayables() = runTest {
        val gateway = FakeDebtGateway()
        gateway.accounts.value = listOf(
            account("payable", DebtDirection.Payable, confirmed = true),
            account("receivable", DebtDirection.Receivable, confirmed = true),
            account("draft", DebtDirection.Payable, confirmed = false),
            account("archived", DebtDirection.Payable, confirmed = true, archivedAt = 1L),
        )

        val result = ObservePayableDebtAccountsUseCase(gateway)().first()

        assertEquals(listOf("payable"), result.map { it.id })
        assertTrue(result.all { it.direction == DebtDirection.Payable.dbValue })
    }

    private fun account(
        id: String,
        direction: DebtDirection,
        confirmed: Boolean,
        archivedAt: Long? = null,
    ) = DebtAccount(
        id = id,
        operationId = "op-$id",
        direction = direction.dbValue,
        partyName = id,
        currencyCode = "SDG",
        dueDate = null,
        confirmed = confirmed,
        archivedAt = archivedAt,
        closedAt = null,
        legacyDebtId = null,
        syncState = "synced",
        deletedAt = null,
    )
}

package com.shift.app.feature.goals

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalDomainIndependenceTest {
    @Test fun goalDomainHasNoAndroidRoomOrDataImports() {
        val root = sequenceOf(
            File("feature/goals/src/main/java/com/shift/app"),
            File("../feature/goals/src/main/java/com/shift/app"),
        ).first(File::isDirectory)
        val files = (File(root, "domain/goals").walkTopDown() + File(root, "feature/goals/domain").walkTopDown())
            .filter { it.isFile && it.extension == "kt" }.toList()
        assertTrue(files.isNotEmpty())
        val forbidden = listOf("import android.", "import androidx.", "import com.shift.app.data.")
        files.forEach { file -> forbidden.forEach { token -> assertTrue("${file.path} imports $token", token !in file.readText()) } }
    }
}

package com.shift.app

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.remote.ASSET_OPERATION_RPC_FUNCTION
import com.shift.app.data.remote.AssetOperationRpcParams
import com.shift.app.data.remote.isSingleCurrencySalePayloadForRollback
import com.shift.app.feature.assets.data.AssetOperationFactory
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.FinancialRules
import com.shift.app.domain.finance.CurrencySalePlan
import com.shift.app.domain.finance.FifoAllocationDraft
import com.shift.app.domain.finance.PaymentKind
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetOperationsTest {
    private val activeAsset = Asset(
        id = "asset-1",
        operationId = "asset-created",
        type = "car",
        name = "السيارة",
        acquisitionMode = "preexisting",
        acquisitionAmountDecimal = "100.00",
        createdAt = 1L,
        updatedAt = 1L
    )

    @Test
    fun preexistingAsset_createsInitialValuationFromAcquisitionAmount() {
        val operation = AssetOperationFactory.preexisting(
            PreexistingAssetRequest(
                name = "منزل",
                type = "real_estate",
                acquisitionAmountDecimal = "1000",
                currentValueDecimal = "1250",
                date = "2026-07-12",
                operationId = "op-preexisting"
            ),
            now = 10L
        )

        val asset = operation.assets.single()
        val event = operation.assetTransactions.single()
        val valuation = operation.assetValuations.single()
        assertEquals("op-preexisting", asset.operationId)
        assertEquals("op-preexisting", event.operationId)
        assertEquals("op-preexisting", valuation.operationId)
        assertEquals(asset.id, event.assetId)
        assertEquals(asset.id, valuation.assetId)
        assertEquals("1000.00", valuation.valueDecimal)
        assertTrue(operation.payments.isEmpty())
        assertTrue(operation.balanceTransactions.isEmpty())
    }

    @Test
    fun purchase_createsLinkedRowsAndInitialValuationWithOneOperationId_andIsNotExpense() {
        val operation = AssetOperationFactory.purchase(
            PurchaseAssetRequest(
                name = "حاسوب",
                type = "laptop",
                amountDecimal = "500",
                date = "2026-07-12",
                operationId = "op-purchase"
            ),
            now = 20L
        )

        val asset = operation.assets.single()
        val event = operation.assetTransactions.single()
        val payment = operation.payments.single()
        val balance = operation.balanceTransactions.single()
        val valuation = operation.assetValuations.single()
        assertEquals(setOf("op-purchase"), listOfNotNull(asset.operationId, event.operationId, valuation.operationId, payment.operationId, balance.operationId).toSet())
        assertEquals(asset.id, valuation.assetId)
        assertEquals("500.00", valuation.valueDecimal)
        assertEquals(PaymentKind.AssetPurchase.dbValue, payment.kind)
        assertEquals(BalanceTransactionKind.AssetPurchase.dbValue, balance.kind)
        assertEquals(BalanceDirection.Outflow.dbValue, balance.direction)
        assertEquals(payment.id, asset.purchasePaymentId)
        assertEquals(balance.id, payment.balanceTransactionId)
        assertEquals(payment.id, event.paymentId)
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetPurchase))
    }

    @Test
    fun improvement_isLinkedPaymentAndOutflow_butNotExpense() {
        val operation = AssetOperationFactory.paymentEvent(
            activeAsset,
            AssetPaymentRequest(
                assetId = activeAsset.id,
                kind = PaymentKind.AssetImprovement,
                amountDecimal = "75",
                purpose = "ترقية المحرك",
                date = "2026-07-12",
                operationId = "op-improvement"
            ),
            now = 30L
        )

        assertEquals(AssetTransactionKind.Improvement.dbValue, operation.assetTransactions.single().kind)
        assertEquals(PaymentKind.AssetImprovement.dbValue, operation.payments.single().kind)
        assertEquals(BalanceTransactionKind.AssetImprovement.dbValue, operation.balanceTransactions.single().kind)
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetImprovement))
    }

    @Test
    fun maintenance_isExpense_andUsesAssetAsAutomaticBeneficiaryReference() {
        val operation = AssetOperationFactory.paymentEvent(
            activeAsset,
            AssetPaymentRequest(
                assetId = activeAsset.id,
                kind = PaymentKind.AssetMaintenance,
                amountDecimal = "25",
                purpose = "تغيير الزيت",
                date = "2026-07-12",
                operationId = "op-maintenance"
            ),
            now = 40L
        )

        val payment = operation.payments.single()
        assertEquals(activeAsset.id, payment.assetId)
        assertEquals(activeAsset.name, payment.assetNameSnapshot)
        assertEquals(activeAsset.id, payment.beneficiaryId)
        assertEquals(activeAsset.name, payment.beneficiaryNameSnapshot)
        assertTrue(FinancialRules.entersExpenseReports(PaymentKind.AssetMaintenance))
    }

    @Test
    fun valuation_createsNoFakeAssetEventAndNoFinancialRows() {
        val operation = AssetOperationFactory.valuation(
            activeAsset,
            AssetValuationRequest(
                assetId = activeAsset.id,
                valueDecimal = "130",
                date = "2026-07-12",
                operationId = "op-value"
            ),
            now = 50L
        )

        assertEquals("130.00", operation.assetValuations.single().valueDecimal)
        assertTrue(operation.assetTransactions.isEmpty())
        assertTrue(operation.payments.isEmpty())
        assertTrue(operation.balanceTransactions.isEmpty())
    }

    @Test
    fun fullSale_createsInflowWithoutPayment_andMarksAssetSold() {
        val operation = AssetOperationFactory.sale(
            activeAsset,
            AssetSaleRequest(
                assetId = activeAsset.id,
                amountDecimal = "150",
                date = "2026-07-12",
                operationId = "op-sale"
            ),
            now = 60L
        )

        assertEquals(AssetStatus.Sold.dbValue, operation.assets.single().status)
        assertEquals(AssetTransactionKind.SaleFull.dbValue, operation.assetTransactions.single().kind)
        assertEquals(BalanceDirection.Inflow.dbValue, operation.balanceTransactions.single().direction)
        assertEquals(BalanceTransactionKind.AssetSale.dbValue, operation.balanceTransactions.single().kind)
        assertTrue(operation.payments.isEmpty())
    }

    @Test
    fun currencyPurchase_createsLotAndInitialValuation() {
        val operation = AssetOperationFactory.purchaseCurrency(
            PurchaseCurrencyAssetRequest(
                name = "دولار",
                foreignCurrencyCode = "usd",
                quantityDecimal = "500",
                exchangeRateDecimal = "350",
                localCostDecimal = "175000",
                date = "2026-07-12",
                operationId = "op-currency-purchase"
            ),
            now = 65L
        )

        val asset = operation.assets.single()
        val event = operation.assetTransactions.single()
        val lot = operation.currencyLots.single()
        val valuation = operation.assetValuations.single()
        assertEquals("foreign_currency", asset.type)
        assertEquals("USD", asset.currencyCode)
        assertEquals("500.00000000", event.currencyQuantityDeltaDecimal)
        assertEquals(event.id, lot.purchaseAssetTransactionId)
        assertEquals("350.00000000", lot.purchaseExchangeRateDecimal)
        assertEquals(asset.id, valuation.assetId)
        assertEquals("175000.00", valuation.valueDecimal)
        assertEquals(setOf("op-currency-purchase"), listOf(
            asset.operationId,
            event.operationId,
            valuation.operationId,
            lot.operationId,
            operation.payments.single().operationId,
            operation.balanceTransactions.single().operationId
        ).toSet())
    }

    @Test
    fun currencyPurchase_rejectsLocalOrMalformedCurrencyCode() {
        fun request(code: String) = PurchaseCurrencyAssetRequest(
            name = "عملة",
            foreignCurrencyCode = code,
            quantityDecimal = "1",
            exchangeRateDecimal = "1",
            localCostDecimal = "1",
            date = "2026-07-12",
            operationId = "op-$code"
        )

        assertThrows(IllegalArgumentException::class.java) {
            AssetOperationFactory.purchaseCurrency(request("SDG"), now = 65L)
        }
        assertThrows(IllegalArgumentException::class.java) {
            AssetOperationFactory.purchaseCurrency(request("US"), now = 65L)
        }
        assertThrows(java.time.format.DateTimeParseException::class.java) {
            AssetOperationFactory.purchaseCurrency(
                request("USD").copy(date = "12/07/2026"),
                now = 65L
            )
        }
    }

    @Test
    fun partialCurrencySale_createsInflowAndAllocationsWithoutPaymentOrIncome() {
        val currencyAsset = activeAsset.copy(type = "foreign_currency", currencyCode = "USD")
        val plan = CurrencySalePlan(
            requestedQuantityDecimal = "200.00000000",
            availableBeforeDecimal = "500.00000000",
            availableAfterDecimal = "300.00000000",
            allocatedLocalCostDecimal = "70000.00",
            allocations = listOf(FifoAllocationDraft("lot-1", "200.00000000", "70000.00"))
        )
        val operation = AssetOperationFactory.currencySale(
            currencyAsset,
            CurrencyAssetSaleRequest(
                assetId = currencyAsset.id,
                quantityDecimal = "200",
                localProceedsDecimal = "80000",
                date = "2026-07-12",
                operationId = "op-partial-sale"
            ),
            plan,
            now = 66L
        )

        assertEquals(AssetStatus.Active.dbValue, operation.assets.single().status)
        assertEquals(AssetTransactionKind.SalePartial.dbValue, operation.assetTransactions.single().kind)
        assertEquals("-200.00000000", operation.assetTransactions.single().currencyQuantityDeltaDecimal)
        assertEquals(BalanceDirection.Inflow.dbValue, operation.balanceTransactions.single().direction)
        assertTrue(operation.payments.isEmpty())
        assertEquals("lot-1", operation.currencySaleAllocations.single().lotId)
    }

    @Test
    fun rpcPayloadContract_containsAllNineCompositeTables() {
        val encoded = Json.encodeToString(
            AssetOperationRpcParams.serializer(),
            AssetOperationRpcParams(
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList()
            )
        )

        assertEquals("upsert_asset_operation", ASSET_OPERATION_RPC_FUNCTION)
        assertTrue(encoded.contains("p_balance_transactions"))
        assertTrue(encoded.contains("p_payments"))
        assertTrue(encoded.contains("p_assets"))
        assertTrue(encoded.contains("p_asset_transactions"))
        assertTrue(encoded.contains("p_asset_valuations"))
        assertTrue(encoded.contains("p_currency_asset_lots"))
        assertTrue(encoded.contains("p_currency_asset_sale_allocations"))
        assertTrue(encoded.contains("p_transactions"))
        assertTrue(encoded.contains("p_ledger_history_migrations"))
    }

    @Test
    fun oversellCompensation_isLimitedToOneCurrencySaleOperation() {
        val sale = AssetTransaction(
            operationId = "sale-1",
            assetId = "asset-1",
            kind = AssetTransactionKind.SalePartial.dbValue,
            date = "2026-07-12"
        )
        val balance = BalanceTransaction(
            operationId = "sale-1",
            direction = BalanceDirection.Inflow.dbValue,
            kind = BalanceTransactionKind.AssetSale.dbValue,
            amountDecimal = "1.00",
            date = "2026-07-12"
        )
        val allocation = CurrencyAssetSaleAllocation(
            operationId = "sale-1",
            assetId = "asset-1",
            saleAssetTransactionId = sale.id,
            lotId = "lot-1",
            quantitySoldDecimal = "1.00000000",
            allocatedLocalCostDecimal = "1.00"
        )

        assertTrue(isSingleCurrencySalePayloadForRollback(listOf(sale), listOf(balance), listOf(allocation)))
        assertFalse(
            isSingleCurrencySalePayloadForRollback(
                listOf(sale, sale.copy(operationId = "other")),
                listOf(balance),
                listOf(allocation)
            )
        )
        assertFalse(isSingleCurrencySalePayloadForRollback(emptyList(), listOf(balance), listOf(allocation)))
        assertFalse(
            isSingleCurrencySalePayloadForRollback(
                listOf(sale.copy(kind = AssetTransactionKind.Purchase.dbValue)),
                listOf(balance),
                listOf(allocation)
            )
        )
    }
}

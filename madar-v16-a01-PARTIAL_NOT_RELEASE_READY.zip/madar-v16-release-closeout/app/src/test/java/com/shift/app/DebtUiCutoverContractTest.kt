package com.shift.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class DebtUiCutoverContractTest {
    @Test
    fun mainScreenRoutesDebtPageToNewCenterWithoutLegacyAddSheet() {
        val source = sourceFile("ui/screens/MainScreen.kt").readText()

        assertFalse(source.contains("import com.shift.app.ui.components.AddDebtSheet"))
        assertFalse(source.contains("DebtsScreen(vm = vm)"))
        assertFalse(source.contains("DebtsViewModel"))
        assertFalse(source.contains("showAddDebt"))
        assertTrue(source.contains("openDebtCreateSignal"))
        assertTrue(source.contains("DebtsRoute("))
    }

    @Test
    fun debtScreenDoesNotUseLegacyDebtRowsOrSettlementBoolean() {
        val source = sourceFile("feature/debts/presentation/DebtsScreen.kt").readText()

        assertFalse(source.contains("com.shift.app.data.local.entities.Debt"))
        assertFalse(source.contains("AddDebtSheet"))
        assertFalse(source.contains("MainViewModel"))
        assertFalse(source.contains("markDebtSettled"))
        assertFalse(source.contains("unmarkDebtSettled"))
        assertFalse(source.contains("isSettled"))
        assertFalse(source.contains("DebtsViewModel"))
        assertTrue(source.contains("DebtsUiEvent"))
        assertTrue(source.contains("DebtAccountUiModel"))
    }

    private fun sourceFile(relativePath: String): File =
        sequenceOf(
            File("../app/src/main/java/com/shift/app/$relativePath"),
            File("app/src/main/java/com/shift/app/$relativePath")
        ).first(File::isFile)
}

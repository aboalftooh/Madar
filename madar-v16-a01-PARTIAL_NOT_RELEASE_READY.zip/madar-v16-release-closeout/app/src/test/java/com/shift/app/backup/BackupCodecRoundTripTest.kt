package com.shift.app.backup

import com.shift.app.feature.backup.data.BackupDocumentCodec
import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.domain.model.BackupImportMode
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupCodecRoundTripTest {
    @Test fun documentAndFeatureSectionRoundTrip() = runSuspend {
        val codec = SampleCodec("value-from-storage")
        val document = BackupDocumentCodec(listOf(codec))

        val encoded = document.encode(now = 123L)
        val decoded = document.decode(encoded, now = 456L)
        val section = decoded.sections.getValue("sample") as SampleSnapshot

        assertEquals("value-from-storage", section.value)
        assertEquals(1, section.rowCount)
        assertEquals(2, decoded.manifest.formatVersion)
        assertEquals(16, decoded.fingerprint.length)
        assertTrue(document.sectionIds() == listOf("sample"))
    }

    private data class SampleSnapshot(val value: String) : BackupSectionSnapshot {
        override val rowCount: Int = 1
    }
    private data class SamplePlan(override val importedRowCount: Int = 1) : BackupSectionPlan {
        override val affectedRowCount: Int = 1
        override val deleteCount: Int = 0
    }
    private class SampleCodec(private val stored: String) : BackupSectionCodec {
        override val id: String = "sample"
        override suspend fun writeExport(root: JSONObject) {
            root.put(id, JSONObject().put("value", stored))
        }
        override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot =
            SampleSnapshot(requireNotNull(root.optJSONObject(id)).optString("value"))
        override suspend fun plan(imported: BackupSectionSnapshot, mode: BackupImportMode, now: Long): BackupSectionPlan = SamplePlan()
        override suspend fun apply(plan: BackupSectionPlan) = Unit
    }
}

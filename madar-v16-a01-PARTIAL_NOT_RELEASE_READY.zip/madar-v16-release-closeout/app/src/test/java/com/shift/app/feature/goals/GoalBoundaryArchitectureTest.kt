package com.shift.app.feature.goals

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalBoundaryArchitectureTest {
    private val root = sequenceOf(File("app/src/main/java/com/shift/app"), File("../app/src/main/java/com/shift/app")).first(File::isDirectory)

    @Test fun presentationDependsOnGoalContractsOnly() {
        val source = File(root, "feature/goals/presentation").walkTopDown().filter { it.extension == "kt" }.joinToString("\n") { it.readText() }
        listOf("com.shift.app.data.", "androidx.room", "FinancialGoalDao", "MadarDatabase", "SyncManager").forEach { assertFalse(source.contains(it)) }
        assertTrue(source.contains("GoalGateway"))
    }

    @Test fun goalFeatureOwnsGoalBindings() {
        assertFalse(File(root, "di/AppModule.kt").exists())
        val source = File(root, "feature/goals/di/GoalFeatureModule.kt").readText()
        assertTrue(source.contains("provideFinancialGoalDao"))
        assertTrue(source.contains("provideGoalMeasurementRegistry"))
    }
}

package com.shift.app.architecture

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialCanonicalArchitectureTest {
    @Test
    fun productionReportsUseCanonicalLedgerReadModel() {
        val dashboard = source("ui/screens/DashboardScreen.kt")
        val budget = source("ui/screens/BudgetGoalsScreen.kt")
        val reports = source("feature/reports/presentation/ReportsScreen.kt")
        val calculator = source("feature/reports/domain/usecase/ReportsReadModelCalculator.kt")
        val adapter = source("feature/reports/data/ReportsQueryAdapter.kt")
        val vm = source("viewmodel/TransactionsViewModel.kt")

        assertTrue(vm.contains("val balanceTransactions"))
        assertTrue(dashboard.contains("balanceTransactions,"))
        assertTrue(budget.contains("balanceTransactions,"))
        assertFalse(reports.contains("FinancialReportCalculator"))
        assertTrue(reports.contains("val readModel = state.readModel"))
        assertTrue(source("feature/reports/presentation/ReportsViewModel.kt").contains("ReportsReadModel"))
        assertTrue(calculator.contains("BalanceTransactionKind.Income"))
        assertTrue(calculator.contains("migratedLegacyExpenseIds"))
        assertTrue(adapter.contains("financialLedgerRepository.balanceTransactions()"))
        assertTrue(adapter.contains("financialLedgerRepository.payments()"))
    }

    @Test
    fun cutoverCoordinatorOwnsParityFingerprintAndRollback() {
        val coordinator = source("data/migration/LegacyFinancialCutoverCoordinator.kt")
        val planner = source("domain/finance/LegacyFinancialCutover.kt")
        assertTrue(coordinator.contains("plan.parity.requireExact()"))
        assertTrue(coordinator.contains("expectedCutoverFingerprint"))
        assertTrue(coordinator.contains("rollbackPending"))
        assertTrue(planner.contains("SHA-256"))
        assertFalse(planner.contains("androidx."))
        assertFalse(planner.contains("com.shift.app.data"))
    }


    @Test
    fun migrationWizardUsesUnifiedFinancialCutoverCoordinator() {
        val vm = source("viewmodel/LegacyHistoryMigrationViewModel.kt")
        val wizard = source("ui/components/LegacyHistoryMigrationWizard.kt")

        assertTrue(vm.contains("LegacyFinancialCutoverCoordinator"))
        assertTrue(vm.contains("cutoverCoordinator.preview"))
        assertTrue(vm.contains("cutoverCoordinator.commit"))
        assertTrue(vm.contains("legacy-financial-cutover"))
        assertFalse(vm.contains("migrationRepository.prepareCommit"))
        assertFalse(vm.contains("migrationRepository.applyLocally"))
        assertTrue(wizard.contains("تنفيذ التحويل المالي الكامل"))
    }

    private fun source(relative: String): String = sequenceOf(
        File("../app/src/main/java/com/shift/app/$relative"),
        File("app/src/main/java/com/shift/app/$relative"),
        File("../feature/reports/src/main/java/com/shift/app/$relative"),
        File("feature/reports/src/main/java/com/shift/app/$relative"),
        File("../feature/ledger/src/main/java/com/shift/app/$relative"),
        File("feature/ledger/src/main/java/com/shift/app/$relative"),
    ).first(File::isFile).readText()
}

package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtAdjustmentOperationsTest {
    private val repoSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt")
    ).first(File::isFile).readText()

    @Test
    fun adjustmentRequiresReasonAndReducesRemainingAppendOnly() {
        assertTrue(repoSource.contains("recordAdjustment("))
        assertTrue(repoSource.contains("DebtOperationFactory.adjustment"))
        assertTrue(repoSource.contains("reason = reason"))
        assertTrue(repoSource.contains("transactionDao.upsert(tx)"))
    }

    @Test
    fun offsetWritesTwoLinkedCounterpartyTransactionsWithoutCash() {
        assertTrue(repoSource.contains("recordOffset("))
        assertTrue(repoSource.contains("Offset requires one payable and one receivable"))
        assertTrue(repoSource.contains("offset_counterparty"))
        assertTrue(!repoSource.substringAfter("recordOffset(").substringBefore("reverseDebtTransaction(").contains("writeBalanceLeg"))
    }

    @Test
    fun reversalIsLinkedAndDuplicateReversalIsRejected() {
        assertTrue(repoSource.contains("reverseDebtTransaction("))
        assertTrue(repoSource.contains("Debt transaction is already reversed"))
        assertTrue(repoSource.contains("originalTransactionId = originalTransactionId"))
        assertTrue(repoSource.contains("reversal_of"))
    }
}

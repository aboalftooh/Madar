package com.shift.app

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import org.junit.Assert.assertFalse
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.reflect.full.memberProperties

class AssetSchemaTest {
    @Test
    fun assetEntities_doNotUseFloatingPointFields() {
        val forbidden = setOf(Double::class, Float::class)
        assertFalse(Asset::class.memberProperties.any { it.returnType.classifier in forbidden })
        assertFalse(AssetTransaction::class.memberProperties.any { it.returnType.classifier in forbidden })
        assertFalse(AssetValuation::class.memberProperties.any { it.returnType.classifier in forbidden })
        assertFalse(CurrencyAssetLot::class.memberProperties.any { it.returnType.classifier in forbidden })
        assertFalse(CurrencyAssetSaleAllocation::class.memberProperties.any { it.returnType.classifier in forbidden })
    }

    @Test
    fun currencyLotRemainingQuantity_isDerivedNotStoredAsCache() {
        assertEquals(
            false,
            CurrencyAssetLot::class.memberProperties.any { it.name == "quantityRemainingDecimal" }
        )
    }
}

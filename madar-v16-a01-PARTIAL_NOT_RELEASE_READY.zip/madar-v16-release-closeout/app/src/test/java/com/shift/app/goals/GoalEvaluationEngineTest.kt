package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.goals.evaluation.GOAL_ENGINE_VERSION
import com.shift.app.domain.goals.evaluation.GoalEvaluationEngine
import com.shift.app.domain.goals.evaluation.GoalMeasurement
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class GoalEvaluationEngineTest {
    private val engine = GoalEvaluationEngine()
    private val asOf = Instant.parse("2026-07-18T12:00:00Z")

    @Test
    fun `required conditions move active goal to ready`() {
        val decision = engine.evaluate(goalAggregate(), listOf(measurement("100")), asOf)

        assertEquals(GOAL_ENGINE_VERSION, decision.engineVersion)
        assertEquals(GoalLifecycleStatus.READY, decision.lifecycleStatus)
        assertEquals(GoalHealthStatus.ON_TRACK, decision.healthStatus)
        assertEquals(0, decision.progressPercent!!.compareTo(java.math.BigDecimal("100")))
        assertEquals(true, decision.conditionResults.single().satisfied)
    }

    @Test
    fun `missing source is unavailable and cannot make goal ready`() {
        val missing = GoalMeasurement(
            metricId = "metric-1",
            metricType = MetricType.NET_WORTH,
            measuredDecimal = null,
            sourceFingerprint = "missing-history",
            available = false,
            unavailableReason = "history is incomplete",
        )

        val decision = engine.evaluate(goalAggregate(), listOf(missing), asOf)

        assertEquals(GoalLifecycleStatus.ACTIVE, decision.lifecycleStatus)
        assertEquals(GoalHealthStatus.UNAVAILABLE, decision.healthStatus)
    }

    @Test
    fun `ready goal returns active when a required condition is lost`() {
        val aggregate = goalAggregate().let {
            it.copy(goal = it.goal.copy(lifecycleStatus = GoalLifecycleStatus.READY, readyAt = 1L))
        }
        val decision = engine.evaluate(aggregate, listOf(measurement("99")), asOf)

        assertEquals(GoalLifecycleStatus.ACTIVE, decision.lifecycleStatus)
    }

    @Test
    fun `completed goal is never reopened by correction`() {
        val aggregate = goalAggregate().let {
            it.copy(goal = it.goal.copy(lifecycleStatus = GoalLifecycleStatus.COMPLETED, completedAt = 1L))
        }

        assertEquals(
            GoalLifecycleStatus.COMPLETED,
            engine.evaluate(aggregate, listOf(measurement("1")), asOf).lifecycleStatus,
        )
    }

    @Test
    fun `maximum condition treats lower measurement as better`() {
        val original = goalAggregate()
        val aggregate = original.copy(
            goal = original.goal.copy(targetDecimal = money("80"), baselineDecimal = money("120")),
            conditions = listOf(
                original.conditions.single().copy(operator = "<=", valueDecimal = money("80")),
            ),
        )

        val decision = engine.evaluate(aggregate, listOf(measurement("80")), asOf)

        assertEquals(GoalLifecycleStatus.READY, decision.lifecycleStatus)
        assertEquals(GoalHealthStatus.ON_TRACK, decision.healthStatus)
        assertEquals(0, decision.progressPercent!!.compareTo(java.math.BigDecimal("100")))
    }

    @Test
    fun `successful average cannot satisfy incomplete confirmation streak`() {
        val aggregate = confirmationAggregate(periods = 3)

        val decision = engine.evaluate(aggregate, listOf(incomeMeasurement("120", streak = 2)), asOf)

        assertEquals(GoalLifecycleStatus.ACTIVE, decision.lifecycleStatus)
        assertEquals(false, decision.conditionResults.single().satisfied)
        assertEquals(true, decision.conditionResults.single().available)
    }

    @Test
    fun `successful average and complete confirmation streak make goal ready`() {
        val aggregate = confirmationAggregate(periods = 3)

        val decision = engine.evaluate(aggregate, listOf(incomeMeasurement("120", streak = 3)), asOf)

        assertEquals(GoalLifecycleStatus.READY, decision.lifecycleStatus)
        assertEquals(true, decision.conditionResults.single().satisfied)
    }

    @Test
    fun `interrupted confirmation streak keeps goal active`() {
        val aggregate = confirmationAggregate(periods = 3)

        val decision = engine.evaluate(aggregate, listOf(incomeMeasurement("120", streak = 0)), asOf)

        assertEquals(GoalLifecycleStatus.ACTIVE, decision.lifecycleStatus)
        assertEquals(false, decision.conditionResults.single().satisfied)
    }

    @Test
    fun `confirmation condition without streak measurement is unavailable`() {
        val aggregate = confirmationAggregate(periods = 3)

        val decision = engine.evaluate(aggregate, listOf(incomeMeasurement("120", streak = null)), asOf)

        assertEquals(GoalLifecycleStatus.ACTIVE, decision.lifecycleStatus)
        assertEquals(false, decision.conditionResults.single().available)
    }

    @Test
    fun `missing best rate uses deadline rule only`() {
        val decision = engine.evaluate(goalAggregate(), listOf(measurement("20")), asOf)

        assertEquals(GoalHealthStatus.NEEDS_ATTENTION, decision.healthStatus)
    }

    @Test
    fun `fingerprint is deterministic and excludes evaluation derived state`() {
        val original = goalAggregate()
        val persistedDerivedState = original.copy(
            goal = original.goal.copy(
                lifecycleStatus = GoalLifecycleStatus.READY,
                healthStatus = GoalHealthStatus.ON_TRACK,
                revision = 8,
                readyAt = 100,
                updatedAt = 200,
                syncState = "PENDING",
            ),
        )
        val source = listOf(measurement("100"))

        assertEquals(engine.fingerprint(original, source), engine.fingerprint(persistedDerivedState, source))
        assertNotEquals(engine.fingerprint(original, source), engine.fingerprint(original, listOf(measurement("101"))))
    }
}

internal fun goalAggregate(): GoalAggregate {
    val now = 1L
    val goal = FinancialGoal(
        id = "goal-1",
        name = "Net worth",
        type = GoalType.NET_WORTH_GROWTH,
        lifecycleStatus = GoalLifecycleStatus.ACTIVE,
        healthStatus = GoalHealthStatus.UNAVAILABLE,
        currencyCode = "SDG",
        startDate = "2026-01-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        targetDecimal = money("100"),
        baselineDecimal = money("0"),
        targetPercentDecimal = null,
        confirmationPeriods = 1,
        costThreshold = null,
        configJson = "{\"version\":1,\"settings\":{}}",
        revision = 0,
        readyAt = null,
        completedAt = null,
        cancelledAt = null,
        archivedAt = null,
        createdAt = now,
        updatedAt = now,
        deletedAt = null,
        syncState = "SYNCED",
    )
    val metric = GoalMetric(
        id = "metric-1",
        goalId = goal.id,
        metricType = MetricType.NET_WORTH,
        windowType = "CURRENT",
        windowSize = 1,
        baselineDecimal = money("0"),
        configJson = "{\"version\":1,\"settings\":{}}",
        ordinal = 0,
        createdAt = now,
        updatedAt = now,
        deletedAt = null,
        syncState = "SYNCED",
    )
    val condition = GoalCondition(
        id = "condition-1",
        goalId = goal.id,
        metricId = metric.id,
        kind = ConditionKind.TARGET,
        operator = ">=",
        valueDecimal = money("100"),
        required = true,
        configJson = "{\"version\":1,\"settings\":{}}",
        ordinal = 0,
        createdAt = now,
        updatedAt = now,
        deletedAt = null,
        syncState = "SYNCED",
    )
    return GoalAggregate(goal = goal, metrics = listOf(metric), conditions = listOf(condition))
}

internal fun measurement(value: String) = GoalMeasurement(
    metricId = "metric-1",
    metricType = MetricType.NET_WORTH,
    measuredDecimal = money(value),
    sourceFingerprint = "ledger:$value",
)

private fun confirmationAggregate(periods: Int): GoalAggregate = goalAggregate().let { aggregate ->
    aggregate.copy(
        goal = aggregate.goal.copy(
            name = "Income growth",
            type = GoalType.INCOME_GROWTH,
            confirmationPeriods = periods,
        ),
        metrics = listOf(aggregate.metrics.single().copy(metricType = MetricType.INCOME)),
        conditions = listOf(aggregate.conditions.single().copy(kind = ConditionKind.CONFIRMATION_STREAK)),
    )
}

private fun incomeMeasurement(value: String, streak: Int?) = GoalMeasurement(
    metricId = "metric-1",
    metricType = MetricType.INCOME,
    measuredDecimal = money(value),
    sourceFingerprint = "income:$value:streak=$streak",
    confirmationStreak = streak,
)

internal fun money(value: String): String = requireNotNull(
    DecimalText.canonicalNonNegative(value, DecimalTextScale.Money),
)

package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.FinancialChangeEvent
import com.shift.app.feature.goals.domain.model.GoalActivity
import com.shift.app.feature.goals.domain.model.GoalEvaluation
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.repository.GoalInvalidationGateway
import com.shift.app.domain.goals.evaluation.GoalEvaluationEngine
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.domain.goals.evaluation.GoalMeasurementRegistry
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class GoalOutboxTest {
    @Test
    fun `retry with identical input creates no duplicate evaluation or activity`() = runTest {
        val gateway = InMemoryInvalidationGateway(goalAggregate())
        val registry = GoalMeasurementRegistry().apply {
            register(com.shift.app.domain.goals.model.MetricType.NET_WORTH) { metric, _, _ ->
                measurement("100").copy(metricId = metric.id)
            }
        }
        val processor = GoalInvalidationProcessor(gateway, registry, GoalEvaluationEngine())

        val first = processor.processPending()
        val retry = processor.processPending()

        assertEquals(1, first.insertedEvaluations)
        assertEquals(0, retry.insertedEvaluations)
        assertEquals(1, gateway.evaluations.size)
        assertEquals(1, gateway.activities.size)
        assertEquals(2, gateway.processedCalls)
    }

    @Test
    fun `failed event remains retryable and increments attempt`() = runTest {
        val gateway = InMemoryInvalidationGateway(goalAggregate(), failNextSave = true)
        val registry = GoalMeasurementRegistry().apply {
            register(com.shift.app.domain.goals.model.MetricType.NET_WORTH) { metric, _, _ ->
                measurement("100").copy(metricId = metric.id)
            }
        }
        val processor = GoalInvalidationProcessor(gateway, registry, GoalEvaluationEngine())

        assertEquals(1, processor.processPending().failures)
        assertEquals(1, gateway.failedAttempts)
        assertEquals(1, processor.processPending().insertedEvaluations)
    }
}

private class InMemoryInvalidationGateway(
    aggregate: GoalAggregate,
    var failNextSave: Boolean = false,
) : GoalInvalidationGateway {
    private var current = aggregate
    val evaluations = linkedMapOf<String, GoalEvaluation>()
    val activities = linkedMapOf<String, GoalActivity>()
    var processedCalls = 0
    var failedAttempts = 0
    private val event = FinancialChangeEvent(
        eventId = "event-1",
        sourceType = "transactions",
        sourceId = "source-1",
        operationId = "operation-1",
        effectiveDate = "2026-07-18",
        changedFields = "amountDecimal",
        createdAt = 1,
        processedAt = null,
        attemptCount = 0,
        lastError = null,
    )

    override suspend fun getLiveAggregates(): List<GoalAggregate> = listOf(current)

    // Deliberately returns the event after markProcessed to simulate a crash before its marker persists.
    override suspend fun pendingChanges(limit: Int): List<FinancialChangeEvent> = listOf(event)

    override suspend fun saveEvaluation(
        evaluation: GoalEvaluation,
        activity: GoalActivity,
        expectedRevision: Long,
    ): Boolean {
        if (failNextSave) {
            failNextSave = false
            error("temporary database failure")
        }
        val key = "${evaluation.goalId}:${evaluation.inputFingerprint}:${evaluation.engineVersion}"
        if (key in evaluations) return false
        evaluations[key] = evaluation
        activities["${activity.goalId}:${activity.operationId}:${activity.type}"] = activity
        current = current.copy(
            goal = current.goal.copy(
                lifecycleStatus = evaluation.lifecycleStatus,
                healthStatus = evaluation.healthStatus,
                revision = current.goal.revision + 1,
                updatedAt = evaluation.updatedAt,
                syncState = "PENDING",
            ),
            evaluations = evaluations.values.toList(),
            activities = activities.values.toList(),
        )
        return true
    }

    override suspend fun markChangeProcessed(eventId: String, processedAt: Long) {
        processedCalls++
    }

    override suspend fun markChangeFailed(event: FinancialChangeEvent, error: String) {
        failedAttempts++
    }
}

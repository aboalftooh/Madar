package com.shift.app

import com.shift.app.utils.ErrorMessages
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ErrorMessagesTest {
    @Test
    fun networkErrorsUseArabicConnectionMessage() {
        assertEquals(
            "لا يوجد اتصال بالإنترنت (NET)",
            ErrorMessages.userMessage(UnknownHostException("Unable to resolve host"))
        )
        assertEquals(
            "لا يوجد اتصال بالإنترنت (NET)",
            ErrorMessages.userMessage(SocketTimeoutException("timeout"))
        )
        assertEquals(
            "لا يوجد اتصال بالإنترنت (NET)",
            ErrorMessages.userMessage(IOException("network failure"))
        )
    }

    @Test
    fun authErrorsUseArabicCredentialsMessage() {
        assertEquals(
            "بيانات الدخول غير صحيحة أو البريد غير مؤكد (AUTH)",
            ErrorMessages.userMessage(IllegalArgumentException("Invalid login credentials"))
        )
    }

    @Test
    fun serverErrorsUseArabicServerMessage() {
        assertEquals(
            "خطأ من الخادم. حاول لاحقاً (SRV)",
            ErrorMessages.userMessage(IllegalStateException("HTTP 503 Service Unavailable"))
        )
    }

    @Test
    fun unknownErrorsUseShortUnknownCode() {
        assertEquals(
            "حدث خطأ غير معروف (UNK)",
            ErrorMessages.userMessage(IllegalStateException("unexpected"))
        )
    }
}

package com.shift.app

import com.shift.app.domain.finance.LegacyFinancialCutoverPlanner
import com.shift.app.domain.finance.LegacyFinancialRollbackDecision
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LegacyCutoverRollbackTest {
    @Test
    fun rollbackDecisionBlocksSyncedAndChangedRows() {
        val fingerprint = "a".repeat(64)
        assertEquals(
            LegacyFinancialRollbackDecision.Allowed,
            LegacyFinancialCutoverPlanner.rollbackDecision(true, true, fingerprint, fingerprint),
        )
        assertEquals(
            LegacyFinancialRollbackDecision.BlockedBySyncedRows,
            LegacyFinancialCutoverPlanner.rollbackDecision(true, false, fingerprint, fingerprint),
        )
        assertEquals(
            LegacyFinancialRollbackDecision.BlockedByChangedSource,
            LegacyFinancialCutoverPlanner.rollbackDecision(true, true, "b".repeat(64), fingerprint),
        )
    }

    @Test
    fun repositoriesRequirePendingStateAndCleanOutbox() {
        val history = source("data/repository/LegacyHistoryMigrationRepository.kt")
        val debts = source("data/migration/LegacyDebtMigrator.kt")

        assertTrue(history.contains("Cannot rollback a synchronized history migration"))
        assertTrue(history.contains("Cannot rollback history after a migrated transaction was edited"))
        assertTrue(history.contains("deleteForEntity"))
        assertTrue(debts.contains("Cannot rollback legacy debt rows that were already synchronized"))
        assertTrue(debts.contains("deleteForOperation"))
    }

    private fun source(relative: String): String = sequenceOf(
        File("../app/src/main/java/com/shift/app/$relative"),
        File("app/src/main/java/com/shift/app/$relative"),
    ).first(File::isFile).readText()
}

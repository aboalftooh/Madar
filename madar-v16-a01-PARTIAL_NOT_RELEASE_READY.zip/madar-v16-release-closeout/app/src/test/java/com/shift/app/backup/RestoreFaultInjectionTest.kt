package com.shift.app.backup

import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.data.RestoreAtomicityGuard
import com.shift.app.feature.backup.data.RestoreFaultInjector
import com.shift.app.feature.backup.data.RestoreFaultPoint
import com.shift.app.feature.backup.data.RestoreTransactionBoundary
import com.shift.app.feature.backup.domain.model.BackupImportMode
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RestoreFaultInjectionTest {
    @Test
    fun everyDatabaseAndExternalFaultRollsBackCapturedSectionsInReverseOrder() = runSuspend {
        val faultPoints = listOf(
            RestoreFaultPoint.BEFORE_DATABASE_APPLY,
            RestoreFaultPoint.AFTER_DATABASE_APPLY,
            RestoreFaultPoint.BEFORE_EXTERNAL_APPLY,
            RestoreFaultPoint.AFTER_EXTERNAL_APPLY,
        )

        faultPoints.forEach { point ->
            val events = mutableListOf<String>()
            val boundary = RestoreTransactionBoundary { block ->
                events += "transaction:start"
                try {
                    block()
                    events += "transaction:commit"
                } catch (error: Throwable) {
                    events += "transaction:rollback"
                    throw error
                }
            }
            val injector = RestoreFaultInjector { current, sectionId ->
                if (current == point && sectionId == "second") error("fault:$point")
            }
            val guard = RestoreAtomicityGuard(boundary, injector)

            val result = runCatching {
                guard.apply(
                    listOf(
                        FakeCodec("first", events) to FakePlan,
                        FakeCodec("second", events) to FakePlan,
                    ),
                )
            }

            assertTrue("Expected failure at $point", result.isFailure)
            assertTrue(events.contains("transaction:rollback"))
            assertEquals(
                listOf("second:rollbackExternal", "first:rollbackExternal"),
                events.filter { it.endsWith(":rollbackExternal") },
            )
        }
    }


    @Test
    fun rollbackFaultInOneSectionDoesNotBlockRemainingRollback() = runSuspend {
        val events = mutableListOf<String>()
        val boundary = RestoreTransactionBoundary { block ->
            try { block() } catch (error: Throwable) { throw error }
        }
        val injector = RestoreFaultInjector { point, sectionId ->
            if (point == RestoreFaultPoint.BEFORE_DATABASE_APPLY && sectionId == "second") error("apply fault")
            if (point == RestoreFaultPoint.BEFORE_ROLLBACK && sectionId == "second") error("rollback fault")
        }
        val guard = RestoreAtomicityGuard(boundary, injector)

        val result = runCatching {
            guard.apply(listOf(FakeCodec("first", events) to FakePlan, FakeCodec("second", events) to FakePlan))
        }

        assertTrue(result.isFailure)
        assertTrue(events.none { it == "second:rollbackExternal" })
        assertTrue(events.contains("first:rollbackExternal"))
    }

    @Test
    fun captureFaultDoesNotEnterDatabaseTransaction() = runSuspend {
        val events = mutableListOf<String>()
        val guard = RestoreAtomicityGuard(
            boundary = RestoreTransactionBoundary { block ->
                events += "transaction:start"
                block()
            },
            faultInjector = RestoreFaultInjector { point, sectionId ->
                if (point == RestoreFaultPoint.AFTER_CAPTURE && sectionId == "first") error("capture fault")
            },
        )

        val result = runCatching { guard.apply(listOf(FakeCodec("first", events) to FakePlan)) }

        assertTrue(result.isFailure)
        assertTrue(events.none { it == "transaction:start" })
        assertTrue(events.none { it.endsWith(":apply") })
    }

    private object FakePlan : BackupSectionPlan {
        override val importedRowCount = 1
        override val affectedRowCount = 1
        override val deleteCount = 0
    }

    private class FakeCodec(
        override val id: String,
        private val events: MutableList<String>,
    ) : BackupSectionCodec {
        override suspend fun writeExport(root: JSONObject) = Unit
        override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot = error("unused")
        override suspend fun plan(imported: BackupSectionSnapshot, mode: BackupImportMode, now: Long): BackupSectionPlan = FakePlan
        override suspend fun captureExternalState(): Any = id.also { events += "$id:capture" }
        override suspend fun apply(plan: BackupSectionPlan) { events += "$id:apply" }
        override suspend fun applyExternal(plan: BackupSectionPlan) { events += "$id:applyExternal" }
        override suspend fun rollbackExternal(snapshot: Any?) { events += "$id:rollbackExternal" }
    }
}

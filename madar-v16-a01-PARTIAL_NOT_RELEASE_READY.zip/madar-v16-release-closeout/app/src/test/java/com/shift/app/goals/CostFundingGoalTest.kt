package com.shift.app.goals

import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.templates.CostFundingGoalTemplate
import com.shift.app.domain.goals.templates.CostFundingTemplateRequest
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CostFundingGoalTest {
    private val repositorySource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt"),
    ).first(File::isFile).readText()

    private val completionSource = sequenceOf(
        File("../feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteCostGoal.kt"),
        File("feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteCostGoal.kt"),
    ).first(File::isFile).readText()

    @Test
    fun tripDefaultsToSafeThresholdAndProjectDefaultsToExpected() {
        val trip = CostFundingGoalTemplate.build(request(GoalType.TRIP_FUNDING))
        val project = CostFundingGoalTemplate.build(request(GoalType.PROJECT_FUNDING))

        assertEquals(CostThreshold.SAFE, trip.goal.costThreshold)
        assertEquals("120.00", trip.goal.targetDecimal)
        assertEquals(CostThreshold.EXPECTED, project.goal.costThreshold)
        assertEquals("100.00", project.goal.targetDecimal)
    }

    @Test
    fun initialCostHistoryIsStoredAsAppendOnlyEstimate() {
        val aggregate = CostFundingGoalTemplate.build(request(GoalType.PROJECT_FUNDING))

        assertEquals(1, aggregate.costEstimates.size)
        assertEquals("100.00", aggregate.costEstimates.single().expectedDecimal)
        assertEquals("120.00", aggregate.costEstimates.single().safeDecimal)
        assertTrue(repositorySource.contains("recordCostEstimate("))
        assertTrue(repositorySource.contains("costDao.insert(entity)"))
        assertTrue(!repositorySource.contains("DELETE FROM goal_cost_estimates WHERE goalId"))
    }

    @Test
    fun completionSupportsKeepConsumeTripExpenseAndProjectAsset() {
        assertTrue(completionSource.contains("KEEP_ALLOCATED"))
        assertTrue(completionSource.contains("PaymentKind.OrdinaryExpense"))
        assertTrue(completionSource.contains("assetRepository.purchaseAsset"))
        assertTrue(completionSource.contains("kind = FundingKind.CONSUME"))
        assertTrue(completionSource.contains("GoalLifecycleStatus.COMPLETED"))
    }

    private fun request(type: GoalType) = CostFundingTemplateRequest(
        id = type.name.lowercase(),
        name = type.name,
        type = type,
        expectedDecimal = "100.00",
        safeDecimal = "120.00",
        startDate = "2026-07-18",
        deadline = "2026-12-18",
        timezoneId = "Africa/Khartoum",
        now = 1L,
    )
}

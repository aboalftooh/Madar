package com.shift.app

import com.shift.app.data.backup.DebtAccountBackup
import com.shift.app.data.backup.DebtBackupPayload
import com.shift.app.data.backup.DebtBackupMapper
import com.shift.app.data.backup.DebtTransactionBackup
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtReportCalculator
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.SyncState
import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

class DebtEndToEndTest {
    @Test
    fun roomReportBackupIdentityKeepsDebtTablesConsistent() {
        val balance = listOf(
            BalanceTransaction(
                operationId = "op-balance",
                kind = BalanceTransactionKind.OpeningBalance,
                amountDecimal = "100.00",
                date = "2026-07-14"
            )
        )
        val asset = Asset(
            id = "asset-1",
            operationId = "op-asset",
            type = "device",
            name = "Laptop",
            acquisitionMode = "cash",
            acquisitionAmountDecimal = "300.00",
            currentValueCacheDecimal = "300.00"
        )
        val receivable = DebtAccount(
            id = "debt-receivable",
            operationId = "op-r",
            direction = DebtDirection.Receivable.dbValue,
            partyName = "Customer",
            partyKey = "customer"
        )
        val payable = DebtAccount(
            id = "debt-payable",
            operationId = "op-p",
            direction = DebtDirection.Payable.dbValue,
            partyName = "Supplier",
            partyKey = "supplier"
        )
        val debtTransactions = listOf(
            DebtTransaction(
                id = "tx-r-open",
                accountId = receivable.id,
                operationId = "op-r",
                type = DebtTransactionType.Opening.dbValue,
                amountDecimal = "50.00",
                occurredAt = 1
            ),
            DebtTransaction(
                id = "tx-p-open",
                accountId = payable.id,
                operationId = "op-p",
                type = DebtTransactionType.Opening.dbValue,
                amountDecimal = "30.00",
                occurredAt = 1
            ),
            DebtTransaction(
                id = "tx-r-collect",
                accountId = receivable.id,
                operationId = "op-r2",
                type = DebtTransactionType.Collection.dbValue,
                amountDecimal = "10.00",
                occurredAt = 1
            )
        )

        val wealth = DebtReportCalculator.wealth(
            balanceTransactions = balance,
            assets = listOf(asset),
            valuations = emptyList(),
            accounts = listOf(receivable, payable),
            transactions = debtTransactions
        )

        assertEquals(BigDecimal("440.00"), wealth.totalAssetsDecimal)
        assertEquals(BigDecimal("410.00"), wealth.netWorthDecimal)
        assertEquals(BigDecimal("40.00"), wealth.receivablesDecimal)
        assertEquals(BigDecimal("30.00"), wealth.payablesDecimal)

        val backup = DebtBackupPayload(
            accounts = listOf(
                DebtAccountBackup(receivable.id, receivable.operationId, receivable.direction, receivable.partyName, receivable.partyKey, receivable.currencyCode, receivable.confirmed, SyncState.Pending.dbValue, 1),
                DebtAccountBackup(payable.id, payable.operationId, payable.direction, payable.partyName, payable.partyKey, payable.currencyCode, payable.confirmed, SyncState.Pending.dbValue, 1)
            ),
            transactions = debtTransactions.map {
                DebtTransactionBackup(it.id, it.accountId, it.operationId, it.type, it.amountDecimal, it.currencyCode, it.occurredAt, SyncState.Pending.dbValue, 1)
            }
        )
        backup.validateForRestore()

        assertEquals(
            listOf("debt_accounts", "debt_transactions", "debt_links", "debt_schedules", "debt_migration_reviews"),
            DebtBackupMapper.restoreOrder
        )
    }

    @Test(expected = IllegalArgumentException::class)
    fun backupRestoreRejectsOrphanDebtTransactions() {
        DebtBackupPayload(
            transactions = listOf(
                DebtTransactionBackup(
                    id = "orphan",
                    accountId = "missing",
                    operationId = "op",
                    type = DebtTransactionType.Opening.dbValue,
                    amountDecimal = "1.00",
                    currencyCode = "SDG",
                    occurredAt = 1,
                    syncState = SyncState.Pending.dbValue,
                    updatedAt = 1
                )
            )
        ).validateForRestore()
    }
}

package com.shift.app.architecture

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PresentationConventionArchitectureTest {
    private val root = sequenceOf(
        File("app/src/main/java/com/shift/app"),
        File("../app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)

    @Test
    fun `debts and reports expose route screen viewmodel state and events`() {
        assertFeatureConvention("debts", "Debts", "DebtCenterState")
        assertFeatureConvention("reports", "Reports", "ReportsUiState")
    }

    @Test
    fun `pure screens do not collect flows or inject viewmodels`() {
        listOf(
            "feature/debts/presentation/DebtsScreen.kt",
            "feature/reports/presentation/ReportsScreen.kt",
        ).forEach { relative ->
            val source = File(root, relative).readText()
            assertFalse("$relative must not inject ViewModels", source.contains("hiltViewModel"))
            assertFalse("$relative must not collect flows", source.contains("collectAsState"))
            assertFalse("$relative must not receive ViewModel types", Regex("\\w+ViewModel").containsMatchIn(source))
            assertFalse("$relative must not import Data", source.contains("com.shift.app.data."))
        }
    }

    @Test
    fun `routes own state collection and event dispatch`() {
        val debts = File(root, "feature/debts/presentation/DebtsRoute.kt").readText()
        val reports = File(root, "feature/reports/presentation/ReportsRoute.kt").readText()
        listOf(debts, reports).forEach { source ->
            assertTrue(source.contains("hiltViewModel"))
            assertTrue(source.contains("collectAsState"))
            assertTrue(source.contains("viewModel::onEvent"))
        }
    }

    @Test
    fun `modified feature screens stay below five hundred lines`() {
        listOf(
            "feature/debts/presentation/DebtsScreen.kt",
            "feature/reports/presentation/ReportsScreen.kt",
        ).forEach { relative ->
            val lineCount = File(root, relative).readLines().size
            assertTrue("$relative has $lineCount lines", lineCount <= 500)
        }
    }

    @Test
    fun `app shell navigates to routes not injectable screens`() {
        val main = File(root, "ui/screens/MainScreen.kt").readText()
        assertTrue(main.contains("DebtsRoute("))
        assertTrue(main.contains("ReportsRoute("))
        assertFalse(main.contains("DebtsScreen("))
        assertFalse(main.contains("ReportsScreen("))
    }

    private fun assertFeatureConvention(feature: String, prefix: String, stateName: String) {
        val presentation = File(root, "feature/$feature/presentation")
        assertTrue(File(presentation, "${prefix}Route.kt").isFile)
        assertTrue(File(presentation, "${prefix}Screen.kt").isFile)
        assertTrue(File(presentation, "${prefix}ViewModel.kt").isFile)
        val joined = presentation.walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        assertTrue(joined.contains(stateName))
        assertTrue(joined.contains("${prefix}UiEvent"))
    }
}

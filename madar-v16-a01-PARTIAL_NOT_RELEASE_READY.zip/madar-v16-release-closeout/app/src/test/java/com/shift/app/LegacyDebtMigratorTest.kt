package com.shift.app

import com.shift.app.data.local.entities.Debt
import com.shift.app.data.migration.LegacyDebtMigrationPlan
import com.shift.app.data.migration.LegacyDebtMigrationPlanner
import com.shift.app.domain.debt.DebtDirection
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtLegacyMigratorTest {
    @Test
    fun plannerConvertsValidLegacyDebtToOpeningWithoutCashRows() {
        val plan = LegacyDebtMigrationPlanner.plan(Debt(id = "1", name = "Ali", amount = 10.0, type = "borrow"))
        require(plan is LegacyDebtMigrationPlan.Opening)
        assertEquals(DebtDirection.Payable, plan.direction)
        assertEquals("10.00", plan.amountDecimal)
    }

    @Test
    fun plannerSendsInvalidOrAmbiguousLegacyDebtToReview() {
        assertTrue(LegacyDebtMigrationPlanner.plan(Debt(id = "1", name = "", amount = 10.0, type = "borrow")) is LegacyDebtMigrationPlan.Review)
        assertTrue(LegacyDebtMigrationPlanner.plan(Debt(id = "2", name = "Ali", amount = 0.0, type = "borrow")) is LegacyDebtMigrationPlan.Review)
        assertTrue(LegacyDebtMigrationPlanner.plan(Debt(id = "3", name = "Ali", amount = 10.0, type = "x")) is LegacyDebtMigrationPlan.Review)
    }

    @Test
    fun migratorIsIdempotentAndDoesNotCreateBalanceRows() {
        val source = sequenceOf(
            File("../app/src/main/java/com/shift/app/data/migration/LegacyDebtMigrator.kt"),
            File("app/src/main/java/com/shift/app/data/migration/LegacyDebtMigrator.kt")
        ).first(File::isFile).readText()
        assertTrue(source.contains("getByLegacyDebtId"))
        assertTrue(source.contains("skipped += 1"))
        assertTrue(!source.contains("BalanceTransaction"))
    }
}

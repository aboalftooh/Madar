package com.shift.app.goals

import org.junit.Assert.assertEquals
import org.junit.Test

class GoalPhase1ManifestTest {

    @Test
    fun `phase one contains exactly the ten approved goal types`() {
        val goalTypeManifest = listOf(
            "HOUSE_PURCHASE",
            "CAR_PURCHASE",
            "PROJECT_FUNDING",
            "TRIP_FUNDING",
            "INCOME_GROWTH",
            "EXPENSE_REDUCTION",
            "EXPENSE_CEILING",
            "EMERGENCY_FUND",
            "DEBT_PAYOFF",
            "NET_WORTH_GROWTH",
        )

        assertEquals(10, goalTypeManifest.size)
        assertEquals(10, goalTypeManifest.toSet().size)
        assertEquals(
            setOf(
                "HOUSE_PURCHASE",
                "CAR_PURCHASE",
                "PROJECT_FUNDING",
                "TRIP_FUNDING",
                "INCOME_GROWTH",
                "EXPENSE_REDUCTION",
                "EXPENSE_CEILING",
                "EMERGENCY_FUND",
                "DEBT_PAYOFF",
                "NET_WORTH_GROWTH",
            ),
            goalTypeManifest.toSet(),
        )
    }
}

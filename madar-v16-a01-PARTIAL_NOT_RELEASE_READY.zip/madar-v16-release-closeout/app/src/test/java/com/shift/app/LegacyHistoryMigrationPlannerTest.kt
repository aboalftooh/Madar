package com.shift.app

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.LegacyHistoryExecutionDecision
import com.shift.app.domain.finance.LegacyHistoryMigrationPlanner
import com.shift.app.domain.finance.legacyHistoryExecutionDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class LegacyHistoryMigrationPlannerTest {
    private val opening = BalanceTransaction(
        id = "opening",
        operationId = "opening-op",
        direction = BalanceDirection.Inflow.dbValue,
        kind = BalanceTransactionKind.OpeningBalance.dbValue,
        amountDecimal = "1000.00",
        date = "2026-01-01",
        sourceType = "balance_activation",
        createdAt = 1,
        updatedAt = 1
    )

    private val income = Transaction(
        id = "legacy-income",
        type = "income",
        amount = 500.0,
        category = "راتب",
        date = "2025-01-01",
        updatedAt = 10
    )
    private val expense = Transaction(
        id = "legacy-expense",
        type = "expense",
        amount = 200.0,
        category = "طعام",
        purpose = "طعام",
        date = "2025-01-02",
        updatedAt = 11
    )

    @Test
    fun preview_isDeterministicAndCreatesExpectedLinkedRows() {
        val first = preview(listOf(expense, income), "1300")
        val second = preview(listOf(income, expense), "1300")

        assertEquals(first.sourceFingerprint, second.sourceFingerprint)
        assertEquals(first.commitFingerprint, second.commitFingerprint)
        assertEquals(64, first.sourceFingerprint.length)
        assertEquals(64, first.commitFingerprint.length)
        assertEquals(first.operations.map { it.balanceTransaction.id }, second.operations.map { it.balanceTransaction.id })
        assertEquals("500.00", first.historicalIncomeDecimal)
        assertEquals("200.00", first.historicalExpenseDecimal)
        assertEquals("1300.00", first.projectedBalanceDecimal)
        assertEquals("0.00", first.adjustmentDecimal)
        assertNull(first.adjustmentBalanceTransaction)

        val migratedExpense = first.operations.single { it.transaction.id == expense.id }
        assertEquals(expense.id, migratedExpense.balanceTransaction.legacyTransactionId)
        assertEquals(expense.id, migratedExpense.payment?.legacyTransactionId)
        assertEquals(migratedExpense.transaction.operationId, migratedExpense.payment?.operationId)
    }

    @Test
    fun adjustmentSupportsPositiveAndNegativeAndChangesFingerprint() {
        val positive = preview(listOf(income, expense), "1400")
        val negative = preview(listOf(income, expense), "1200")

        assertEquals("100.00", positive.adjustmentDecimal)
        assertEquals("-100.00", negative.adjustmentDecimal)
        assertEquals(BalanceDirection.Inflow.dbValue, positive.adjustmentBalanceTransaction?.direction)
        assertEquals(BalanceDirection.Outflow.dbValue, negative.adjustmentBalanceTransaction?.direction)
        assertEquals(BalanceTransactionKind.OpeningBalanceAdjustment.dbValue, negative.adjustmentBalanceTransaction?.kind)
        assertNotEquals(positive.commitFingerprint, negative.commitFingerprint)
    }

    @Test
    fun linkedSessionNineIncomeIsSkippedButOrphanLinkIsRejected() {
        val linkedBalance = BalanceTransaction(
            id = "linked-balance",
            operationId = "linked-op",
            direction = BalanceDirection.Inflow.dbValue,
            kind = BalanceTransactionKind.Income.dbValue,
            amountDecimal = "25.00",
            date = "2026-01-02",
            sourceType = "transaction",
            sourceId = "new-income",
            createdAt = 2,
            updatedAt = 2
        )
        val linkedIncome = income.copy(
            id = "new-income",
            operationId = "linked-op",
            balanceTransactionId = "linked-balance"
        )
        val skipped = LegacyHistoryMigrationPlanner.preview(
            listOf(linkedIncome),
            listOf(opening, linkedBalance),
            emptyList(),
            "SDG",
            "1025"
        )
        assertEquals(0, skipped.candidateCount)

        assertThrows(IllegalArgumentException::class.java) {
            LegacyHistoryMigrationPlanner.preview(
                listOf(linkedIncome.copy(balanceTransactionId = "missing")),
                listOf(opening, linkedBalance),
                emptyList(),
                "SDG",
                "1025"
            )
        }
    }

    @Test
    fun repeatedExecutionDecisionIsNoOpAndDifferentFingerprintConflicts() {
        val fingerprint = preview(listOf(income), "1500").commitFingerprint
        assertEquals(LegacyHistoryExecutionDecision.Execute, legacyHistoryExecutionDecision(null, fingerprint))
        assertEquals(
            LegacyHistoryExecutionDecision.AlreadyCompleted,
            legacyHistoryExecutionDecision(fingerprint, fingerprint)
        )
        assertEquals(
            LegacyHistoryExecutionDecision.Conflict,
            legacyHistoryExecutionDecision("0".repeat(64), fingerprint)
        )
        assertTrue(fingerprint.matches(Regex("[0-9a-f]{64}")))
    }

    private fun preview(transactions: List<Transaction>, target: String) =
        LegacyHistoryMigrationPlanner.preview(
            transactions = transactions,
            balanceTransactions = listOf(opening),
            payments = emptyList(),
            localCurrencyCode = "SDG",
            targetBalanceInput = target
        )
}

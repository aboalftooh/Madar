package com.shift.app.feature.auth

import com.shift.app.feature.auth.domain.AccountLocalDataCleaner
import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionSyncGateway
import com.shift.app.feature.auth.domain.SessionSyncResult
import com.shift.app.feature.auth.domain.SessionWorkController
import com.shift.app.feature.auth.domain.SessionWriter
import com.shift.app.feature.auth.session.SessionCleanupCoordinator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionCleanupCoordinatorTest {
    @Test
    fun successfulLogoutSyncsThenCleansInsideExclusiveSession() = runBlocking {
        val events = mutableListOf<String>()
        val coordinator = coordinator(events = events)

        val result = coordinator.logout(discardUnsyncedChanges = false)

        assertEquals(LogoutResult.Completed, result)
        assertEquals(
            listOf("sync", "lock:start", "work:cancel", "local:clear", "session:clear", "auth:signout", "lock:end"),
            events,
        )
    }

    @Test
    fun forceLogoutSkipsSyncButStillUsesExclusiveCleanup() = runBlocking {
        val events = mutableListOf<String>()
        val coordinator = coordinator(events = events)

        val result = coordinator.logout(discardUnsyncedChanges = true)

        assertEquals(LogoutResult.Completed, result)
        assertTrue("safe sync must be skipped", "sync" !in events)
        assertEquals("lock:start", events.first())
        assertEquals("lock:end", events.last())
    }

    @Test
    fun remoteSignOutFailureFallsBackToLocalSessionClear() = runBlocking {
        val events = mutableListOf<String>()
        val coordinator = coordinator(events = events, signOutFails = true)

        val result = coordinator.logout(discardUnsyncedChanges = true)

        assertEquals(LogoutResult.Completed, result)
        assertTrue(events.contains("auth:clear-local"))
    }

    private fun coordinator(
        events: MutableList<String>,
        syncResult: SessionSyncResult = SessionSyncResult.Success,
        signOutFails: Boolean = false,
    ) = SessionCleanupCoordinator(
        authGateway = FakeAuthGateway(events, signOutFails),
        sessionWriter = FakeSessionWriter(events),
        sessionSyncGateway = FakeSessionSyncGateway(events, syncResult),
        localDataCleaner = AccountLocalDataCleaner { events += "local:clear" },
        sessionWorkController = SessionWorkController { events += "work:cancel" },
    )

    private class FakeAuthGateway(
        private val events: MutableList<String>,
        private val signOutFails: Boolean,
    ) : AuthGateway {
        override suspend fun signIn(email: String, password: String) = Unit
        override suspend fun signUp(email: String, password: String) = Unit
        override suspend fun requestPasswordReset(email: String) = Unit
        override suspend fun updatePassword(newPassword: String) = Unit
        override suspend fun verifyRecoveryOtp(email: String, code: String) = Unit
        override suspend fun signOut() {
            events += "auth:signout"
            if (signOutFails) error("remote sign-out failed")
        }
        override suspend fun clearLocalAuthSession() {
            events += "auth:clear-local"
        }
    }

    private class FakeSessionWriter(
        private val events: MutableList<String>,
    ) : SessionWriter {
        override suspend fun rememberEmail(email: String) = Unit
        override suspend fun initializeRegisteredAccount(name: String, jobTitle: String) = Unit
        override suspend fun clearAccountScopedState() {
            events += "session:clear"
        }
    }

    private class FakeSessionSyncGateway(
        private val events: MutableList<String>,
        private val syncResult: SessionSyncResult,
    ) : SessionSyncGateway {
        override suspend fun synchronizePendingChanges(): SessionSyncResult {
            events += "sync"
            return syncResult
        }

        override suspend fun <T> withExclusiveSession(block: suspend () -> T): T {
            events += "lock:start"
            return try {
                block()
            } finally {
                events += "lock:end"
            }
        }
    }
}

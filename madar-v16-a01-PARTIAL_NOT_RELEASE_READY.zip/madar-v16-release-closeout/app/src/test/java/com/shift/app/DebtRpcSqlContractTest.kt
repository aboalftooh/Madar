package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtRpcSqlContractTest {
    private val sql = sequenceOf(
        File("../docs/supabase_debt_rpc.sql"),
        File("docs/supabase_debt_rpc.sql")
    ).first(File::isFile).readText()

    @Test
    fun sqlDefinesFiveDebtTablesAndRpc() {
        listOf("debt_accounts", "debt_transactions", "debt_links", "debt_schedules", "debt_migration_reviews").forEach {
            assertTrue(sql.contains("create table if not exists public.$it"))
            assertTrue(sql.contains("alter table public.$it enable row level security"))
        }
        assertTrue(sql.contains("function public.upsert_debt_operation"))
        assertTrue(sql.contains("jsonb_populate_recordset"))
        assertTrue(sql.contains("on conflict (id) do update"))
    }

    @Test
    fun sqlProtectsOwnershipAndLegacyDebtsWritePath() {
        assertTrue(sql.contains("auth.uid() = user_id"))
        assertTrue(sql.contains("revoke insert, update, delete on table public.debts from authenticated"))
        assertTrue(sql.contains("set search_path = public"))
        assertTrue(sql.contains("operation ownership mismatch"))
        assertTrue(sql.contains("grant execute on function public.upsert_debt_operation(jsonb) to authenticated"))
    }

    @Test
    fun sqlHasOperationIdempotencyIndexes() {
        assertTrue(sql.contains("unique(user_id, operation_id, id)"))
        assertTrue(sql.contains("unique(user_id, legacy_debt_id)"))
    }

    @Test
    fun rpcWritesParentsBeforeChildrenAndReliesOnTransactionRollback() {
        val accountInsert = sql.indexOf("insert into public.debt_accounts")
        val transactionInsert = sql.indexOf("insert into public.debt_transactions")
        val linkInsert = sql.indexOf("insert into public.debt_links")
        val scheduleInsert = sql.indexOf("insert into public.debt_schedules")
        val reviewInsert = sql.indexOf("insert into public.debt_migration_reviews")

        assertTrue(accountInsert in 0 until transactionInsert)
        assertTrue(transactionInsert in 0 until linkInsert)
        assertTrue(linkInsert in 0 until scheduleInsert)
        assertTrue(scheduleInsert in 0 until reviewInsert)
        assertTrue(sql.contains("on delete no action"))
    }
}

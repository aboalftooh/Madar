package com.shift.app

import com.shift.app.domain.finance.LegacyFinancialAmountRow
import com.shift.app.domain.finance.LegacyFinancialCutoverPlanner
import com.shift.app.domain.finance.LegacyFinancialRowKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialBalanceParityTest {
    @Test
    fun exactLegacyAndCanonicalTotalsPass() {
        val source = listOf(
            row("income", LegacyFinancialRowKind.Income, "100.10"),
            row("expense", LegacyFinancialRowKind.Expense, "40.05"),
            row("receivable", LegacyFinancialRowKind.Receivable, "25.00"),
            row("payable", LegacyFinancialRowKind.Payable, "15.00"),
        )
        val plan = LegacyFinancialCutoverPlanner.plan(
            historyCommitFingerprint = "1".repeat(64),
            debtSourceFingerprint = "2".repeat(64),
            transactionCandidateCount = 2,
            debtCandidateCount = 2,
            debtReviewCount = 0,
            sourceRows = source,
            canonicalRows = source.reversed(),
        )

        assertTrue(plan.parity.exact)
        assertEquals(64, plan.fingerprint.length)
        plan.parity.requireExact()
    }

    @Test
    fun oneCentMismatchBlocksCommit() {
        val source = listOf(row("income", LegacyFinancialRowKind.Income, "100.10"))
        val canonical = listOf(row("income", LegacyFinancialRowKind.Income, "100.09"))
        val report = LegacyFinancialCutoverPlanner.parity(source, canonical)

        assertFalse(report.exact)
        assertEquals(
            "-0.01",
            report.differences.first { it.kind == LegacyFinancialRowKind.Income }.differenceDecimal,
        )
        assertThrows(IllegalArgumentException::class.java) { report.requireExact() }
    }

    private fun row(id: String, kind: LegacyFinancialRowKind, amount: String) =
        LegacyFinancialAmountRow(id, kind, amount)
}

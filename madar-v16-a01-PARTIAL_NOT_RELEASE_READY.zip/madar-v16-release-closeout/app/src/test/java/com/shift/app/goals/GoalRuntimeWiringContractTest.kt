package com.shift.app.goals

import com.shift.app.domain.goals.model.MetricType
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalRuntimeWiringContractTest {
    @Test
    fun registryWiresEveryMetricUsedByTheTenTemplates() {
        val module = source("app/src/main/java/com/shift/app/feature/goals/di/GoalFeatureModule.kt")
        MetricType.entries.forEach { metric ->
            assertTrue("Missing provider for $metric", module.contains("register(MetricType.${metric.name}"))
        }
    }

    @Test
    fun syncProcessesPullEventsPushesEvaluationsAndUsesExpectedRevision() {
        val context = source("app/src/main/java/com/shift/app/data/remote/RemoteSyncContext.kt")
        val goals = source("app/src/main/java/com/shift/app/data/remote/GoalRemoteSyncDataSource.kt")
        assertTrue(context.contains("invalidatePulledChanges"))
        assertTrue(context.contains("goalInvalidationProcessor.processPending()"))
        assertTrue(goals.contains("evaluations = with(GoalSyncMapper)"))
        assertTrue(goals.contains("expectedRevision = (goal.revision - 1L)"))
    }

    @Test
    fun bootstrapRetriesPendingOutboxAndLogoutClearsItBeforeAnotherAccount() {
        val application = source("app/src/main/java/com/shift/app/ShiftApplication.kt")
        val cleaner = source("app/src/main/java/com/shift/app/feature/auth/data/RoomAccountLocalDataCleaner.kt")
        assertTrue(application.contains("goalInvalidationProcessor.processPending()"))
        assertTrue(cleaner.contains("financialChangeOutboxDao().deleteAll()"))
    }

    private fun source(path: String): String =
        sequenceOf(File("../$path"), File(path)).first(File::isFile).readText()
}

package com.shift.app

import com.shift.app.utils.FinancialInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialInputTest {
    @Test
    fun englishDigitsOnly_rejectsLettersArabicDigitsAndSymbols() {
        assertEquals("13", FinancialInput.englishDigitsOnly("1a٢3-+"))
    }

    @Test
    fun positiveAmount_rejectsBlankZeroAndNonEnglishInput() {
        assertFalse(FinancialInput.isPositiveEnglishAmount(""))
        assertFalse(FinancialInput.isPositiveEnglishAmount("000"))
        assertFalse(FinancialInput.isPositiveEnglishAmount("١٢"))
        assertFalse(FinancialInput.isPositiveEnglishAmount("12.5"))
        assertTrue(FinancialInput.isPositiveEnglishAmount("1205"))
    }
}

package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalAssetRow
import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.goals.measurement.NetWorthMeasurementProvider
import com.shift.app.domain.goals.templates.NetWorthGrowthGoalTemplate
import com.shift.app.domain.goals.templates.NetWorthGrowthTemplateRequest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class NetWorthGrowthGoalTest {
    @Test
    fun templateKeepsImmutableBaselineAndSupportsPercentTarget() {
        val aggregate = template(percent = "10.00")

        assertEquals("1000.00", aggregate.goal.baselineDecimal)
        assertEquals("1100.00", aggregate.goal.targetDecimal)
    }

    @Test
    fun netWorthUsesDebtAwareFormulaAndAssetAcquisitionFallback() {
        val aggregate = template(fixed = "1400.00")
        val measurement = NetWorthMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(GoalBalanceRow("bal", BalanceDirection.Inflow.dbValue, "1000.00", "2026-07-01", null)),
            listOf(GoalAssetRow("asset", AssetStatus.Active.dbValue, "500.00", 1L, null)),
            emptyList(),
            listOf(account("payable", DebtDirection.Payable), account("receivable", DebtDirection.Receivable)),
            listOf(tx("payable", "200.00"), tx("receivable", "50.00")),
        )

        assertEquals("1350.00", measurement.measuredDecimal)
        assertTrue(measurement.estimated)
    }

    @Test
    fun netWorthMeasurementExcludesRowsAfterAsOf() {
        val aggregate = template(fixed = "1400.00")
        val measurement = NetWorthMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            Instant.parse("2026-07-10T00:00:00Z"),
            listOf(
                GoalBalanceRow("before", BalanceDirection.Inflow.dbValue, "1000.00", "2026-07-10", null),
                GoalBalanceRow("after", BalanceDirection.Inflow.dbValue, "999.00", "2026-07-11", null),
            ),
            listOf(GoalAssetRow("asset", AssetStatus.Active.dbValue, "500.00", 1L, null)),
            listOf(
                com.shift.app.feature.goals.domain.model.GoalAssetValuationRow("old-value", "asset", "600.00", "2026-07-10", 1L, null),
                com.shift.app.feature.goals.domain.model.GoalAssetValuationRow("future-value", "asset", "900.00", "2026-07-11", 2L, null),
            ),
            listOf(account("payable", DebtDirection.Payable)),
            listOf(
                tx("payable", "200.00", occurredAt = Instant.parse("2026-07-10T00:00:00Z").toEpochMilli()),
                tx("payable", "300.00", occurredAt = Instant.parse("2026-07-11T00:00:00Z").toEpochMilli()),
            ),
        )

        assertEquals("1400.00", measurement.measuredDecimal)
        assertFalse(measurement.estimated)
    }

    private fun template(percent: String? = null, fixed: String? = null) = NetWorthGrowthGoalTemplate.build(
        NetWorthGrowthTemplateRequest(
            id = "wealth",
            baselineDecimal = "1000.00",
            fixedTargetDecimal = fixed,
            growthPercentDecimal = percent,
            startDate = "2026-07-01",
            deadline = "2026-12-31",
            timezoneId = "UTC",
            now = 1L,
        ),
    )

    private fun account(id: String, direction: DebtDirection) = GoalDebtAccountRow(
        id = id, direction = direction.dbValue, confirmed = true, createdAt = 1L, deletedAt = null,
    )

    private fun tx(accountId: String, amount: String, occurredAt: Long = 1L) = GoalDebtTransactionRow(
        accountId = accountId, type = DebtTransactionType.Opening.dbValue, amountDecimal = amount, occurredAt = occurredAt, deletedAt = null,
    )
}

package com.shift.app.goals

import java.io.File
import java.math.BigDecimal
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalRpcSqlContractTest {
    private val sql = sequenceOf(
        File("../docs/supabase_financial_goals.sql"),
        File("docs/supabase_financial_goals.sql")
    ).first(File::isFile).readText()

    @Test
    fun sqlDefinesEightGoalSyncTablesAndRls() {
        goalTables.forEach {
            assertTrue(sql.contains("create table if not exists public.$it"))
            assertTrue(sql.contains("alter table public.$it enable row level security"))
            assertTrue(sql.contains("auth.uid() = user_id"))
        }
    }

    @Test
    fun sqlDropsOnlyLegacyGoalsTableAndDefinesRpc() {
        assertTrue(sql.contains("drop table public.goals"))
        assertTrue(sql.contains("function public.apply_financial_goal_operation"))
        assertTrue(sql.contains("set search_path = public"))
        assertTrue(sql.contains("operation ownership mismatch"))
        assertTrue(sql.contains("grant execute on function public.apply_financial_goal_operation(jsonb) to authenticated"))
    }

    @Test
    fun rpcWritesParentsBeforeChildrenAndUsesAppendOnlyConflictKeys() {
        val goalInsert = sql.indexOf("insert into public.financial_goals")
        val metricInsert = sql.indexOf("insert into public.goal_metrics")
        val conditionInsert = sql.indexOf("insert into public.goal_conditions")
        val scopeInsert = sql.indexOf("insert into public.goal_scopes")
        val fundingInsert = sql.indexOf("insert into public.goal_funding_transactions")
        val costInsert = sql.indexOf("insert into public.goal_cost_estimates")
        val evaluationInsert = sql.indexOf("insert into public.goal_evaluations")
        val activityInsert = sql.indexOf("insert into public.goal_activities")

        assertTrue(goalInsert in 0 until metricInsert)
        assertTrue(metricInsert in 0 until conditionInsert)
        assertTrue(conditionInsert in 0 until scopeInsert)
        assertTrue(scopeInsert in 0 until fundingInsert)
        assertTrue(fundingInsert in 0 until costInsert)
        assertTrue(costInsert in 0 until evaluationInsert)
        assertTrue(evaluationInsert in 0 until activityInsert)
        assertTrue(sql.contains("unique(user_id, operation_id)"))
        assertTrue(sql.contains("unique(user_id, goal_id, input_fingerprint, engine_version)"))
        assertTrue(sql.contains("on delete no action"))
    }

    @Test
    fun rpcPreventsAllocatingMoreThanRealBalanceAtomically() {
        assertTrue(sql.contains("pg_advisory_xact_lock(hashtextextended(v_user_id::text || ':financial_goal_allocation', 0))"))
        assertTrue(sql.contains("from public.balance_transactions"))
        assertTrue(sql.contains("v_real_balance"))
        assertTrue(sql.contains("v_active_allocated"))
        assertTrue(sql.contains("v_available_balance"))
        assertTrue(sql.contains("if v_active_allocated > v_real_balance then"))
        assertTrue(sql.contains("goal allocation exceeds available balance"))
        assertTrue(sql.indexOf("if v_active_allocated > v_real_balance then") < sql.indexOf("insert into public.goal_funding_transactions"))

        assertTrue(allocationAllowed(realBalance = "100.00", currentAllocated = "40.00", incomingAllocate = "60.00"))
        assertTrue(!allocationAllowed(realBalance = "100.00", currentAllocated = "40.00", incomingAllocate = "60.01"))
    }

    @Test
    fun rpcRejectsExpectedRevisionConflictInsteadOfSilentlyOverwriting() {
        assertTrue(sql.contains("v_expected_revision"))
        assertTrue(sql.contains("existing.revision <> v_expected_revision"))
        assertTrue(sql.contains("financial goal revision conflict"))
        assertTrue(sql.contains("errcode = '40001'"))
    }

    private val goalTables = listOf(
        "financial_goals",
        "goal_metrics",
        "goal_conditions",
        "goal_scopes",
        "goal_funding_transactions",
        "goal_cost_estimates",
        "goal_evaluations",
        "goal_activities"
    )

    private fun allocationAllowed(
        realBalance: String,
        currentAllocated: String,
        incomingAllocate: String
    ): Boolean {
        val activeAllocatedAfterOperation = BigDecimal(currentAllocated) + BigDecimal(incomingAllocate)
        return activeAllocatedAfterOperation <= BigDecimal(realBalance)
    }
}

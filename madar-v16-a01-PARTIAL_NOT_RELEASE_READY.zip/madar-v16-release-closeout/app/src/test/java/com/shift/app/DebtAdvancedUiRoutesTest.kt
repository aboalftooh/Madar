package com.shift.app

import com.shift.app.feature.debts.presentation.DebtReasonedActionState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DebtAdvancedUiRoutesTest {
    @Test
    fun reasonedActionsRequireReasonAndAmount() {
        assertEquals("المبلغ مطلوب", DebtReasonedActionState(reason = "x").error())
        assertEquals("السبب مطلوب", DebtReasonedActionState(amountDecimal = "10.00").error())
        assertNull(DebtReasonedActionState(amountDecimal = "10.00", reason = "mistake").error())
    }
}

package com.shift.app.sync

import com.shift.app.utils.SyncMergePolicy
import org.junit.Assert.assertFalse
import org.junit.Test

class PendingLocalChangeSurvivesPullTest {
    @Test
    fun explicitPendingStateWinsEvenWhenRemoteTimestampIsNewer() {
        assertFalse(
            SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = 10L,
                remoteUpdatedAt = 1_000L,
                lastSuccessfulSync = 100L,
                localSyncState = "pending",
            ),
        )
    }

    @Test
    fun legacyLocalWriteAfterLastSuccessfulSyncIsNotOverwritten() {
        assertFalse(
            SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = 101L,
                remoteUpdatedAt = 1_000L,
                lastSuccessfulSync = 100L,
            ),
        )
    }
}

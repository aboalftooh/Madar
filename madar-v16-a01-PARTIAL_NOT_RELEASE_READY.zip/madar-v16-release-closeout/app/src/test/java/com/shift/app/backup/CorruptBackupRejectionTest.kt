package com.shift.app.backup

import com.shift.app.feature.backup.data.BackupDocumentCodec
import com.shift.app.feature.backup.data.BackupRedactor
import com.shift.app.feature.backup.domain.model.CorruptBackupException
import com.shift.app.feature.backup.domain.model.IncompatibleBackupException
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CorruptBackupRejectionTest {
    @Test fun malformedJsonIsRejectedBeforeRestorePlanning() {
        val result = runCatching { BackupDocumentCodec(emptyList()).decode("{not-json", 1L) }
        assertTrue(result.exceptionOrNull() is CorruptBackupException)
    }

    @Test fun backupForAnotherApplicationIsRejected() {
        val json = """{"manifest":{"applicationId":"other","formatVersion":2,"minimumReaderVersion":2,"maximumReaderVersion":2,"databaseSchemaVersion":18,"createdAt":1}}"""
        val result = runCatching { BackupDocumentCodec(emptyList()).decode(json, 1L) }
        assertTrue(result.exceptionOrNull() is IncompatibleBackupException)
    }

    @Test fun diagnosticMessageRedactsSensitiveValues() {
        val raw = "Bearer abc123 user@example.com +249 912 345 678 {\"password\":\"secret\"}"
        val safe = BackupRedactor.safeMessage(IllegalStateException(raw))
        assertFalse(safe.contains("abc123"))
        assertFalse(safe.contains("user@example.com"))
        assertFalse(safe.contains("912 345 678"))
        assertFalse(safe.contains("\"secret\""))
    }
}

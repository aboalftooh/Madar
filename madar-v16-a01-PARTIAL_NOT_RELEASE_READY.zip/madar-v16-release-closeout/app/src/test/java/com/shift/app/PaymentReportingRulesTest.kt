package com.shift.app

import com.shift.app.domain.finance.FinancialRules
import com.shift.app.domain.finance.PaymentKind
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaymentReportingRulesTest {
    @Test
    fun onlyOrdinaryExpenseAndAssetMaintenanceEnterExpenseReports() {
        assertTrue(FinancialRules.entersExpenseReports(PaymentKind.OrdinaryExpense))
        assertTrue(FinancialRules.entersExpenseReports(PaymentKind.AssetMaintenance))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.BalanceWithdrawal))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetPurchase))
        assertFalse(FinancialRules.entersExpenseReports(PaymentKind.AssetImprovement))
    }
}

package com.shift.app.sync.outbox

import com.shift.app.data.local.migration.Migration17To18Plan
import com.shift.app.data.local.migration.SqlMigrationExecutor
import com.shift.app.data.local.sync.SyncOutboxSqlPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncOutboxTransactionTest {
    @Test
    fun migrationAddsPendingStateAndBuildsDurableQueuePlan() {
        val database = RecordingSchemaDatabase()

        Migration17To18Plan.migrate(database, now = 1234L)

        assertEquals(setOf("syncState"), database.addedColumns["transactions"])
        assertEquals(setOf("syncState"), database.addedColumns["income_sources"])
        assertEquals(setOf("syncState"), database.addedColumns["expense_beneficiaries"])
        assertEquals(setOf("syncState"), database.addedColumns["debts"])
        assertTrue("sync_outbox" in database.createdTables)
        assertEquals(SyncOutboxSqlPlan.owners.size * 2, database.createdTriggers.size)
        assertEquals(3, database.lastBindArgs.toList().count { it == 1234L })
    }

    @Test
    fun everyOwnerGetsInsertAndUpdateTriggerWithRevisionProtection() {
        val database = RecordingSchemaDatabase()
        SyncOutboxSqlPlan.install(database)

        SyncOutboxSqlPlan.owners.forEach { owner ->
            val insert = database.createdTriggers.getValue("sync_outbox_${owner.table}_insert")
            val update = database.createdTriggers.getValue("sync_outbox_${owner.table}_update")
            assertTrue(insert.contains("AFTER INSERT ON ${owner.table}"))
            assertTrue(update.contains("AFTER UPDATE ON ${owner.table}"))
            assertTrue(update.contains("revision = revision + 1"))
        }

        val history = database.createdTriggers.getValue("sync_outbox_ledger_history_migrations_insert")
        assertTrue(history.contains("NEW.migrationKey"))
    }

    private class RecordingSchemaDatabase : SqlMigrationExecutor {
        val addedColumns = linkedMapOf<String, MutableSet<String>>()
        val createdTables = linkedSetOf<String>()
        val createdTriggers = linkedMapOf<String, String>()
        var lastBindArgs: Array<out Any?> = emptyArray()

        override fun execute(sql: String, bindArgs: Array<out Any?>) {
            val normalized = sql.trim().replace(Regex("\\s+"), " ")
            when {
                normalized.startsWith("ALTER TABLE") -> {
                    val tokens = normalized.split(" ")
                    val table = tokens[2]
                    val column = tokens[tokens.indexOf("COLUMN") + 1]
                    addedColumns.getOrPut(table) { linkedSetOf() } += column
                }
                normalized.startsWith("CREATE TABLE") -> {
                    val match = Regex("CREATE TABLE IF NOT EXISTS ([a-zA-Z0-9_]+)").find(normalized)
                    createdTables += requireNotNull(match).groupValues[1]
                }
                normalized.startsWith("CREATE TRIGGER") -> {
                    val match = Regex("CREATE TRIGGER IF NOT EXISTS ([a-zA-Z0-9_]+)").find(normalized)
                    createdTriggers[requireNotNull(match).groupValues[1]] = normalized
                }
            }
            if (bindArgs.isNotEmpty()) lastBindArgs = bindArgs
        }
    }
}

package com.shift.app.feature.auth

import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionBootstrapper
import com.shift.app.feature.auth.domain.SessionCleanup
import com.shift.app.feature.auth.domain.SessionReader
import com.shift.app.feature.auth.presentation.AuthState
import com.shift.app.feature.auth.presentation.AuthViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModelTest {
    @Test
    fun loginDelegatesAuthenticationAndSessionBootstrap() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        Dispatchers.setMain(dispatcher)
        try {
            val auth = FakeAuthGateway()
            val bootstrap = FakeBootstrapper()
            val viewModel = AuthViewModel(
                authGateway = auth,
                sessionReader = FakeSessionReader(),
                sessionBootstrapper = bootstrap,
                sessionCleanup = FakeSessionCleanup(),
            )

            viewModel.login("user@example.com", "secret", rememberMe = true)
            advanceUntilIdle()

            assertEquals("user@example.com" to "secret", auth.login)
            assertEquals("user@example.com" to true, bootstrap.login)
            assertEquals(AuthState.Success, viewModel.authState.value)
        } finally {
            Dispatchers.resetMain()
        }
    }

    @Test
    fun blockedLogoutUsesBlockedCallbackOnly() = runTest {
        val dispatcher = StandardTestDispatcher(testScheduler)
        Dispatchers.setMain(dispatcher)
        try {
            var success = false
            var blocked = false
            val viewModel = AuthViewModel(
                authGateway = FakeAuthGateway(),
                sessionReader = FakeSessionReader(),
                sessionBootstrapper = FakeBootstrapper(),
                sessionCleanup = FakeSessionCleanup(
                    LogoutResult.Blocked(listOf("push_assets")),
                ),
            )

            viewModel.logout(onSuccess = { success = true }, onBlocked = { blocked = true })
            advanceUntilIdle()

            assertTrue(blocked)
            assertEquals(false, success)
        } finally {
            Dispatchers.resetMain()
        }
    }

    private class FakeAuthGateway : AuthGateway {
        var login: Pair<String, String>? = null
        override suspend fun signIn(email: String, password: String) {
            login = email to password
        }
        override suspend fun signUp(email: String, password: String) = Unit
        override suspend fun requestPasswordReset(email: String) = Unit
        override suspend fun updatePassword(newPassword: String) = Unit
        override suspend fun verifyRecoveryOtp(email: String, code: String) = Unit
        override suspend fun signOut() = Unit
        override suspend fun clearLocalAuthSession() = Unit
    }

    private class FakeSessionReader : SessionReader {
        override val rememberedEmail = MutableStateFlow("")
        override fun isLoggedIn(): Boolean = true
    }

    private class FakeBootstrapper : SessionBootstrapper {
        var login: Pair<String, Boolean>? = null
        override suspend fun onLogin(email: String, rememberMe: Boolean) {
            login = email to rememberMe
        }
        override suspend fun onRegistration(name: String, jobTitle: String) = Unit
    }

    private class FakeSessionCleanup(
        private val result: LogoutResult = LogoutResult.Completed,
    ) : SessionCleanup {
        override suspend fun logout(discardUnsyncedChanges: Boolean): LogoutResult = result
    }
}

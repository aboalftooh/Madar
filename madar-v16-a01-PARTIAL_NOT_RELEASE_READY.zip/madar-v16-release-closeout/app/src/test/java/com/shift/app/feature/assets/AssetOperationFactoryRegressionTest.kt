package com.shift.app.feature.assets

import com.shift.app.data.local.entities.Asset
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.feature.assets.data.AssetOperationFactory
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetOperationFactoryRegressionTest {
    @Test
    fun `purchase keeps one operation id across asset payment balance event and valuation`() {
        val result = AssetOperationFactory.purchase(
            PurchaseAssetRequest(
                name = "حاسوب",
                type = "laptop",
                amountDecimal = "500",
                date = "2026-07-25",
                operationId = "purchase-1",
            ),
            now = 10L,
        )
        val ids = buildSet {
            addAll(result.assets.mapNotNull { it.operationId })
            addAll(result.assetTransactions.map { it.operationId })
            addAll(result.assetValuations.map { it.operationId })
            addAll(result.payments.map { it.operationId })
            addAll(result.balanceTransactions.map { it.operationId })
        }
        assertEquals(setOf("purchase-1"), ids)
        assertEquals("500.00", result.assetValuations.single().valueDecimal)
    }

    @Test
    fun `preexisting asset does not create cash movement`() {
        val result = AssetOperationFactory.preexisting(
            PreexistingAssetRequest(
                name = "منزل",
                type = "real_estate",
                acquisitionAmountDecimal = "1000",
                currentValueDecimal = "1200",
                date = "2026-07-25",
                operationId = "opening-1",
            ),
            now = 20L,
        )
        assertTrue(result.payments.isEmpty())
        assertTrue(result.balanceTransactions.isEmpty())
        assertEquals("1000.00", result.assetValuations.single().valueDecimal)
    }

    @Test
    fun `sale marks asset sold and creates inflow`() {
        val asset = Asset(
            id = "asset-1",
            operationId = "create-1",
            type = "car",
            name = "سيارة",
            status = AssetStatus.Active.dbValue,
            acquisitionMode = "preexisting",
            acquisitionAmountDecimal = "100.00",
            createdAt = 1L,
            updatedAt = 1L,
        )
        val result = AssetOperationFactory.sale(
            asset,
            AssetSaleRequest(
                assetId = asset.id,
                amountDecimal = "150",
                date = "2026-07-25",
                operationId = "sale-1",
            ),
            now = 30L,
        )
        assertEquals(AssetStatus.Sold.dbValue, result.assets.single().status)
        assertEquals(AssetTransactionKind.SaleFull.dbValue, result.assetTransactions.single().kind)
        assertEquals(BalanceDirection.Inflow.dbValue, result.balanceTransactions.single().direction)
    }
}

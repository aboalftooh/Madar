package com.shift.app.feature.debts

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtBoundaryArchitectureTest {
    @Test
    fun `debt presentation imports no data or Room types`() {
        val source = dir("feature/debts/presentation").walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf("com.shift.app.data.", "androidx.room", "DebtAccountDao", "AssetDao", "DebtLedgerRepository", "SyncManager")
            .forEach { token -> assertFalse("Presentation must not contain $token", source.contains(token)) }
        assertTrue(source.contains("DebtCommandUseCases"))
    }

    @Test
    fun `debt domain is platform independent`() {
        val source = debtDomainDir().walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        listOf("android.", "androidx.", "com.shift.app.data.", "Dao", "MadarDatabase")
            .forEach { token -> assertFalse("Domain must not contain $token", source.contains(token)) }
        assertTrue(source.contains("interface DebtGateway"))
        assertTrue(source.contains("interface DebtSettlementAssetQuery"))
    }

    @Test
    fun `legacy debt presentation paths are removed`() {
        assertFalse(dir("ui/debt").exists())
        assertFalse(dir("ui/screens/DebtsScreen.kt").exists())
        assertTrue(dir("feature/debts/presentation/DebtsScreen.kt").exists())
        assertTrue(dir("feature/debts/presentation/DebtsViewModel.kt").exists())
    }

    @Test
    fun `cross feature reads use ports not foreign DAOs`() {
        val feature = dir("feature/debts").walkTopDown()
            .filter { it.isFile && it.extension == "kt" }
            .joinToString("\n") { it.readText() }
        assertFalse(feature.contains("import com.shift.app.data.local.dao.AssetDao"))
        assertFalse(feature.contains("import com.shift.app.data.local.dao.BalanceTransactionDao"))
        assertFalse(feature.contains("import com.shift.app.data.local.dao.PaymentDao"))
        assertTrue(feature.contains("AssetDebtSettlementQueryAdapter"))
        assertTrue(feature.contains("DebtGoalScopePort"))
    }

    private fun dir(relativePath: String): File = root().resolve(relativePath)
    private fun debtDomainDir(): File = sequenceOf(
        File("feature/debts/src/main/java/com/shift/app/feature/debts/domain"),
        File("../feature/debts/src/main/java/com/shift/app/feature/debts/domain"),
    ).first(File::isDirectory)
    private fun root(): File = sequenceOf(
        File("../app/src/main/java/com/shift/app"),
        File("app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
}

package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalExpenseRow
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.goals.measurement.EmergencyFundMeasurementProvider
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.templates.EmergencyFundGoalTemplate
import com.shift.app.domain.goals.templates.EmergencyFundTemplateRequest
import java.io.File
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EmergencyFundGoalTest {
    @Test
    fun templateDefaultsToSixMonthsAndThreeClosedMonthAverage() {
        val aggregate = template()

        assertEquals("6.00", aggregate.goal.targetDecimal)
        assertEquals(3, aggregate.metrics.single().windowSize)
        assertEquals("essential", aggregate.scopes.single().referenceId)
    }

    @Test
    fun templateRejectsMissingEssentialScopes() {
        val error = runCatching {
            EmergencyFundGoalTemplate.build(
                EmergencyFundTemplateRequest(
                    id = "emergency",
                    startDate = "2026-07-01",
                    deadline = "2026-12-31",
                    timezoneId = "UTC",
                    now = 1L,
                ),
            )
        }.exceptionOrNull()

        assertTrue(error is IllegalArgumentException)
    }

    @Test
    fun coverageUsesAllocatedDividedByEssentialAverage() {
        val aggregate = template().let {
            it.copy(fundingTransactions = listOf(funding("600.00")))
        }
        val measurement = EmergencyFundMeasurementProvider.measurePayments(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(payment("2026-04-01", "100.00"), payment("2026-05-01", "100.00"), payment("2026-06-01", "100.00")),
        )

        assertEquals("6.00", measurement.measuredDecimal)
    }

    @Test
    fun denominatorZeroOrMissingHistoryIsUnavailableAndWithdrawalReasonIsEnforced() {
        val aggregate = template()
        val measurement = EmergencyFundMeasurementProvider.measurePayments(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            emptyList(),
        )
        val fundingUseCaseSource = sequenceOf(
            File("../app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt"),
            File("app/src/main/java/com/shift/app/data/repository/FinancialGoalRepository.kt"),
        ).first(File::isFile).readText()

        assertFalse(measurement.available)
        assertTrue(fundingUseCaseSource.contains("سحب صندوق الطوارئ يتطلب سبب"))
    }

    private fun template() = EmergencyFundGoalTemplate.build(
        EmergencyFundTemplateRequest(
            id = "emergency",
            startDate = "2026-07-01",
            deadline = "2026-12-31",
            timezoneId = "UTC",
            essentialPurposeKeys = listOf("essential"),
            now = 1L,
        ),
    )

    private fun payment(date: String, amount: String) = GoalExpenseRow(
        id = "payment-$date",
        date = date,
        amountDecimal = amount,
        kind = "ordinary_expense",
        purpose = "أساسي",
        purposeKey = "essential",
        deletedAt = null,
    )

    private fun funding(amount: String) = GoalFundingTransaction(
        id = "funding-$amount",
        goalId = "emergency",
        operationId = "op-funding-$amount",
        kind = FundingKind.ALLOCATE,
        amountDecimal = amount,
        currencyCode = "SDG",
        balanceTransactionId = null,
        relatedFundingTransactionId = null,
        note = "",
        occurredAt = 1L,
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
        syncState = "PENDING",
    )
}

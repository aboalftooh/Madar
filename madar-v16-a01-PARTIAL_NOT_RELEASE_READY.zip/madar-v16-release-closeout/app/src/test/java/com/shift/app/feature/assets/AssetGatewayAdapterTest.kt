package com.shift.app.feature.assets

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetGatewayAdapterTest {
    @Test
    fun `adapter owns Room mapping and session safe command execution`() {
        val source = source("feature/assets/data/AssetGatewayAdapter.kt")
        assertTrue(source.contains(": AssetGateway"))
        assertTrue(source.contains("AssetEntityMapper"))
        assertTrue(source.contains("syncManager.executeSessionOperation"))
        assertTrue(source.contains("syncQueue.requestSync"))
        assertFalse(source.contains("androidx.lifecycle"))
        assertFalse(source.contains("androidx.compose"))
    }

    @Test
    fun `queue failure cannot roll back committed local asset command`() {
        val source = source("feature/assets/data/AssetGatewayAdapter.kt")
        assertTrue(source.contains("runCatching"))
        assertTrue(source.contains("syncRequested"))
    }

    private fun source(relativePath: String): String = sourceRoot().resolve(relativePath).readText()
    private fun sourceRoot(): File = sequenceOf(
        File("../app/src/main/java/com/shift/app"),
        File("app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
}

package com.shift.app.testing.debts

import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.model.DebtCommandReceipt
import com.shift.app.feature.debts.domain.model.DebtMigrationReview
import com.shift.app.feature.debts.domain.model.DebtSettlementAsset
import com.shift.app.feature.debts.domain.model.DebtTransaction
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import com.shift.app.feature.debts.domain.repository.DebtGateway
import kotlinx.coroutines.flow.MutableStateFlow

class FakeDebtGateway : DebtGateway {
    val accounts = MutableStateFlow<List<DebtAccount>>(emptyList())
    val transactions = MutableStateFlow<List<DebtTransaction>>(emptyList())
    val reviews = MutableStateFlow<List<DebtMigrationReview>>(emptyList())
    val assets = MutableStateFlow<List<DebtSettlementAsset>>(emptyList())

    var lastOpenRequest: OpenDebtRequest? = null
    var failure: Throwable? = null

    override fun observeAccounts() = accounts
    override fun observeTransactions() = transactions
    override fun observeMigrationReviews() = reviews
    override fun observeSettlementAssets() = assets

    override suspend fun open(request: OpenDebtRequest): DebtCommandReceipt {
        failure?.let { throw it }
        lastOpenRequest = request
        return receipt()
    }

    override suspend fun recordCashPrincipal(request: CashPrincipalRequest) = receipt()
    override suspend fun recordDeferredExpense(request: DeferredExpenseRequest) = receipt()
    override suspend fun recordAccruedIncome(request: AccruedIncomeRequest) = receipt()
    override suspend fun recordFinancedAssetPurchase(request: FinancedAssetPurchaseRequest) = receipt()
    override suspend fun recordAssetSaleOnCredit(request: AssetSaleOnCreditRequest) = receipt()
    override suspend fun reduce(request: ReduceDebtRequest) = receipt()
    override suspend fun adjust(request: AdjustDebtRequest) = receipt()
    override suspend fun settleWithAsset(request: AssetSettlementRequest) = receipt()
    override suspend fun offset(request: OffsetDebtRequest) = receipt()
    override suspend fun reverse(request: ReverseDebtTransactionRequest) = receipt()
    override suspend fun transfer(request: TransferDebtRequest) = receipt()
    override suspend fun writeSchedule(request: WriteDebtScheduleRequest) = receipt()
    override suspend fun archive(request: ArchiveDebtRequest) = receipt()

    private fun receipt() = DebtCommandReceipt(
        operationId = "test-operation",
        accountId = "test-account",
        syncRequested = true,
    )
}

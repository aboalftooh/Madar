package com.shift.app.goals

import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.usecase.GoalLifecycleStateMachine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalLifecycleTest {
    private val allowed = setOf(
        GoalLifecycleStatus.DRAFT to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.PAUSED,
        GoalLifecycleStatus.PAUSED to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.READY,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.COMPLETED,
        GoalLifecycleStatus.ACTIVE to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.PAUSED to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.READY to GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.COMPLETED to GoalLifecycleStatus.ARCHIVED,
        GoalLifecycleStatus.CANCELLED to GoalLifecycleStatus.ARCHIVED,
    )

    @Test
    fun `state machine allows exactly the specified transitions`() {
        GoalLifecycleStatus.entries.forEach { from ->
            GoalLifecycleStatus.entries.forEach { to ->
                val expected = from to to in allowed
                assertTrue("Unexpected result for $from -> $to", expected == GoalLifecycleStateMachine.isAllowed(from, to))
            }
        }
    }

    @Test
    fun `state machine rejects every unspecified transition`() {
        GoalLifecycleStatus.entries.forEach { from ->
            GoalLifecycleStatus.entries.forEach { to ->
                if (from to to !in allowed) {
                    assertFalse(GoalLifecycleStateMachine.isAllowed(from, to))
                    val rejected = runCatching { GoalLifecycleStateMachine.requireAllowed(from, to) }.isFailure
                    assertTrue("Expected $from -> $to to be rejected", rejected)
                }
            }
        }
    }
}

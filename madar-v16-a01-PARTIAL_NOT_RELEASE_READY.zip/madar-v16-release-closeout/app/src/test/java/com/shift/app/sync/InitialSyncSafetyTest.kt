package com.shift.app.sync

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InitialSyncSafetyTest {
    @Test
    fun initialSyncRunsCompleteTwoWayCycle() {
        val source = syncManagerSource()
        val initialBlock = source.substringAfter("suspend fun initialSyncOnce")
            .substringBefore("suspend fun runSessionCleanup")

        assertTrue(initialBlock.contains("runSyncSafely(afterPull)"))
        assertTrue(initialBlock.contains("result is SyncRunResult.Success"))
        assertFalse(initialBlock.contains("prefs.setLastSync(System.currentTimeMillis())"))
    }

    private fun syncManagerSource(): String = sequenceOf(
        File("app/src/main/java/com/shift/app/data/remote/SyncManager.kt"),
        File("src/main/java/com/shift/app/data/remote/SyncManager.kt"),
    ).first(File::isFile).readText()
}

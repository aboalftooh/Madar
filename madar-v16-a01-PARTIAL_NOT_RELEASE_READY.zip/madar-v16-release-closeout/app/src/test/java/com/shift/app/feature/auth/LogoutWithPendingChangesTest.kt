package com.shift.app.feature.auth

import com.shift.app.feature.auth.domain.AccountLocalDataCleaner
import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionSyncGateway
import com.shift.app.feature.auth.domain.SessionSyncResult
import com.shift.app.feature.auth.domain.SessionWorkController
import com.shift.app.feature.auth.domain.SessionWriter
import com.shift.app.feature.auth.session.SessionCleanupCoordinator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogoutWithPendingChangesTest {
    @Test
    fun failedPendingSyncBlocksLogoutWithoutDeletingAnything() = runBlocking {
        var localCleared = false
        var preferencesCleared = false
        var signedOut = false
        var workCancelled = false
        val coordinator = SessionCleanupCoordinator(
            authGateway = authGateway(onSignOut = { signedOut = true }),
            sessionWriter = sessionWriter(onClear = { preferencesCleared = true }),
            sessionSyncGateway = syncGateway(SessionSyncResult.PartialFailure(listOf("push_ledger"))),
            localDataCleaner = AccountLocalDataCleaner { localCleared = true },
            sessionWorkController = SessionWorkController { workCancelled = true },
        )

        val result = coordinator.logout(discardUnsyncedChanges = false)

        assertTrue(result is LogoutResult.Blocked)
        assertEquals(listOf("push_ledger"), (result as LogoutResult.Blocked).failedSteps)
        assertFalse(localCleared)
        assertFalse(preferencesCleared)
        assertFalse(signedOut)
        assertFalse(workCancelled)
    }

    @Test
    fun authenticationChangeAlsoBlocksDestructiveCleanup() = runBlocking {
        var localCleared = false
        val coordinator = SessionCleanupCoordinator(
            authGateway = authGateway(),
            sessionWriter = sessionWriter(),
            sessionSyncGateway = syncGateway(SessionSyncResult.AuthenticationRequired),
            localDataCleaner = AccountLocalDataCleaner { localCleared = true },
            sessionWorkController = SessionWorkController { Unit },
        )

        val result = coordinator.logout(discardUnsyncedChanges = false)

        assertTrue(result is LogoutResult.Blocked)
        assertTrue((result as LogoutResult.Blocked).authenticationRequired)
        assertFalse(localCleared)
    }

    private fun syncGateway(result: SessionSyncResult) = object : SessionSyncGateway {
        override suspend fun synchronizePendingChanges(): SessionSyncResult = result
        override suspend fun <T> withExclusiveSession(block: suspend () -> T): T = block()
    }

    private fun sessionWriter(onClear: () -> Unit = {}) = object : SessionWriter {
        override suspend fun rememberEmail(email: String) = Unit
        override suspend fun initializeRegisteredAccount(name: String, jobTitle: String) = Unit
        override suspend fun clearAccountScopedState() = onClear()
    }

    private fun authGateway(onSignOut: () -> Unit = {}) = object : AuthGateway {
        override suspend fun signIn(email: String, password: String) = Unit
        override suspend fun signUp(email: String, password: String) = Unit
        override suspend fun requestPasswordReset(email: String) = Unit
        override suspend fun updatePassword(newPassword: String) = Unit
        override suspend fun verifyRecoveryOtp(email: String, code: String) = Unit
        override suspend fun signOut() = onSignOut()
        override suspend fun clearLocalAuthSession() = Unit
    }
}

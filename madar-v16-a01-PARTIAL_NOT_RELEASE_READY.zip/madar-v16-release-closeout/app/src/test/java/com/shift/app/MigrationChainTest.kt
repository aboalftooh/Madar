package com.shift.app

import com.shift.app.data.local.MadarDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MigrationChainTest {
    @Test
    fun migrationsAreContiguousFromOldestSupportedVersionToCurrentSchema() {
        val migrations = MadarDatabase.ALL_MIGRATIONS.toList()

        assertEquals(2, migrations.first().startVersion)
        assertEquals(18, migrations.last().endVersion)
        migrations.zipWithNext().forEach { (current, next) ->
            assertEquals(current.endVersion, next.startVersion)
        }
        assertTrue(migrations.all { it.endVersion == it.startVersion + 1 })
        assertEquals(migrations.size, migrations.map { it.startVersion to it.endVersion }.toSet().size)
    }
}

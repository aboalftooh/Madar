package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.feature.goals.domain.model.GoalScope
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.goals.measurement.DebtPayoffMeasurementProvider
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.templates.DebtPayoffGoalTemplate
import com.shift.app.domain.goals.templates.DebtPayoffTemplateRequest
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtPayoffGoalTest {
    @Test
    fun templateCapturesBaselineAndSelectedDebtScopes() {
        val aggregate = template(selected = listOf("debt-1"))

        assertEquals("500.00", aggregate.goal.baselineDecimal)
        assertEquals("0.00", aggregate.goal.targetDecimal)
        assertEquals("debt-1", aggregate.scopes.single().referenceId)
    }

    @Test
    fun measurementUsesPrincipalRemainingForConfirmedPayablesOnly() {
        val aggregate = template()
        val measurement = DebtPayoffMeasurementProvider.measureDebt(
            aggregate.metrics.single(),
            aggregate,
            listOf(account("debt-1", true), account("debt-2", false)),
            listOf(
                tx("debt-1", DebtTransactionType.Opening, "500.00"),
                tx("debt-1", DebtTransactionType.Payment, "125.00"),
                tx("debt-2", DebtTransactionType.Opening, "999.00"),
            ),
        )

        assertEquals("375.00", measurement.measuredDecimal)
    }

    @Test
    fun measurementHonorsExplicitExcludedDebtScopeWhenGoalUsesAllPayables() {
        val aggregate = template().let {
            it.copy(scopes = listOf(excludedScope("debt-2")))
        }
        val measurement = DebtPayoffMeasurementProvider.measureDebt(
            aggregate.metrics.single(),
            aggregate,
            listOf(account("debt-1", true), account("debt-2", true)),
            listOf(
                tx("debt-1", DebtTransactionType.Opening, "500.00"),
                tx("debt-2", DebtTransactionType.Opening, "999.00"),
            ),
        )

        assertEquals("500.00", measurement.measuredDecimal)
    }

    @Test
    fun recordUseCaseUsesNewDebtLedgerAndNotLegacyDebtPath() {
        val source = sequenceOf(
            File("../feature/goals/src/main/java/com/shift/app/domain/goals/usecase/RecordGoalDebtPayment.kt"),
            File("feature/goals/src/main/java/com/shift/app/domain/goals/usecase/RecordGoalDebtPayment.kt"),
        ).first(File::isFile).readText()

        assertTrue(source.contains("recordReduction"))
        assertTrue(source.contains("DEBT_PAYOFF_COMPLETED"))
        assertTrue(!source.contains("DebtRepository"))
        assertTrue(!source.contains("debts"))
    }

    private fun template(selected: List<String> = emptyList()) = DebtPayoffGoalTemplate.build(
        DebtPayoffTemplateRequest(
            id = "payoff",
            baselineDebtDecimal = "500.00",
            selectedAccountIds = selected,
            startDate = "2026-07-01",
            deadline = "2026-12-31",
            timezoneId = "UTC",
            now = 1L,
        ),
    )

    private fun account(id: String, confirmed: Boolean) = GoalDebtAccountRow(
        id = id,
        direction = DebtDirection.Payable.dbValue,
        confirmed = confirmed,
        createdAt = 1L,
        deletedAt = null,
    )

    private fun tx(accountId: String, type: DebtTransactionType, amount: String) = GoalDebtTransactionRow(
        accountId = accountId,
        type = type.dbValue,
        amountDecimal = amount,
        occurredAt = 1L,
        deletedAt = null,
    )

    private fun excludedScope(accountId: String) = GoalScope(
        id = "payoff:scope:debt:$accountId",
        goalId = "payoff",
        dimension = ScopeDimension.DEBT_ACCOUNT,
        referenceId = accountId,
        mode = "EXCLUDE",
        reason = "test",
        effectiveFrom = "2026-07-01",
        effectiveTo = null,
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
        syncState = "PENDING",
    )
}

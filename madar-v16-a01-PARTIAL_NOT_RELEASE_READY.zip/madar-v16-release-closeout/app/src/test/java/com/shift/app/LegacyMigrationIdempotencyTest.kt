package com.shift.app

import com.shift.app.data.local.entities.Debt
import com.shift.app.data.migration.LegacyDebtMigrationPlanner
import com.shift.app.domain.finance.LegacyFinancialCutoverDecision
import com.shift.app.domain.finance.LegacyFinancialCutoverPlanner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class LegacyMigrationIdempotencyTest {
    @Test
    fun debtFingerprintIsOrderIndependentAndSensitiveToSourceChanges() {
        val first = Debt(id = "a", name = "Ali", amount = 10.0, type = "borrow", updatedAt = 1)
        val second = Debt(id = "b", name = "Sara", amount = 20.0, type = "lend", updatedAt = 2)

        val a = LegacyDebtMigrationPlanner.preview(listOf(first, second), "SDG")
        val b = LegacyDebtMigrationPlanner.preview(listOf(second, first), "sdg")
        val changed = LegacyDebtMigrationPlanner.preview(listOf(first.copy(amount = 11.0), second), "SDG")

        assertEquals(a.sourceFingerprint, b.sourceFingerprint)
        assertEquals(64, a.sourceFingerprint.length)
        assertNotEquals(a.sourceFingerprint, changed.sourceFingerprint)
    }

    @Test
    fun repeatedCutoverFingerprintIsNoOpAndDifferentFingerprintConflicts() {
        val fingerprint = "a".repeat(64)
        assertEquals(
            LegacyFinancialCutoverDecision.Execute,
            LegacyFinancialCutoverPlanner.executionDecision(null, fingerprint),
        )
        assertEquals(
            LegacyFinancialCutoverDecision.AlreadyCompleted,
            LegacyFinancialCutoverPlanner.executionDecision(fingerprint, fingerprint),
        )
        assertEquals(
            LegacyFinancialCutoverDecision.Conflict,
            LegacyFinancialCutoverPlanner.executionDecision("b".repeat(64), fingerprint),
        )
    }
}

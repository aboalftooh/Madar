package com.shift.app.goals

import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import org.junit.Assert.assertFalse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalSyncContractTest {
    @Test
    fun bundleCarriesExpectedRevisionForRemoteConflictDetection() {
        val bundle = FinancialGoalSyncBundle(
            operationId = "goal:g:4",
            expectedRevision = 3,
            goals = listOf(remoteGoal("g", "u").copy(revision = 4)),
        )

        assertEquals(3L, bundle.expectedRevision)
        assertTrue(bundle.isComplete)
    }

    @Test
    fun completeBundleRequiresParentGoalForAppendOnlyRows() {
        val goal = remoteGoal("g", "u")
        val funding = RemoteGoalFundingTransaction(
            id = "f",
            userId = "u",
            goalId = "g",
            operationId = "op",
            kind = FundingKind.ALLOCATE,
            amountDecimal = "10.00",
            currencyCode = "SDG",
            note = "",
            occurredAt = "2026-07-18T00:00:00Z",
            syncState = "synced",
            createdAt = "2026-07-18T00:00:00Z",
            updatedAt = "2026-07-18T00:00:00Z"
        )

        val complete = FinancialGoalSyncBundle("op", goals = listOf(goal), fundingTransactions = listOf(funding))
        val incomplete = FinancialGoalSyncBundle("op", fundingTransactions = listOf(funding))

        assertTrue(complete.isComplete)
        assertNull(complete.incompleteReason)
        assertFalse(incomplete.isComplete)
        assertTrue(incomplete.incompleteReason!!.contains("IncompleteRemote"))
    }

    @Test
    fun bundleRejectsCrossUserRows() {
        val goal = remoteGoal("g", "u1")
        val funding = RemoteGoalFundingTransaction(
            id = "f",
            userId = "u2",
            goalId = "g",
            operationId = "op",
            kind = FundingKind.ALLOCATE,
            amountDecimal = "10.00",
            currencyCode = "SDG",
            note = "",
            occurredAt = "2026-07-18T00:00:00Z",
            syncState = "synced",
            createdAt = "2026-07-18T00:00:00Z",
            updatedAt = "2026-07-18T00:00:00Z"
        )

        assertFalse(FinancialGoalSyncBundle("op", goals = listOf(goal), fundingTransactions = listOf(funding)).isComplete)
    }

    private fun remoteGoal(id: String, userId: String) = RemoteFinancialGoal(
        id = id,
        userId = userId,
        name = "Emergency",
        type = GoalType.EMERGENCY_FUND,
        lifecycleStatus = GoalLifecycleStatus.ACTIVE,
        healthStatus = GoalHealthStatus.ON_TRACK,
        currencyCode = "SDG",
        startDate = "2026-07-18",
        deadline = "2026-12-31",
        timezoneId = "Africa/Khartoum",
        targetDecimal = "100.00",
        confirmationPeriods = 1,
        configJson = "{\"version\":1,\"template\":\"test\"}",
        revision = 1,
        syncState = "synced",
        createdAt = "2026-07-18T00:00:00Z",
        updatedAt = "2026-07-18T00:00:00Z"
    )
}

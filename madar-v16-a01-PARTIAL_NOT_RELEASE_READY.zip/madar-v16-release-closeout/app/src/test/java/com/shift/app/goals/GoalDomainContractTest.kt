package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalDecimal
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.model.VersionedGoalConfig
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class GoalDomainContractTest {

    @Test
    fun `all approved enums are exact`() {
        assertEquals(
            listOf(
                "HOUSE_PURCHASE", "CAR_PURCHASE", "PROJECT_FUNDING", "TRIP_FUNDING",
                "INCOME_GROWTH", "EXPENSE_REDUCTION", "EXPENSE_CEILING", "EMERGENCY_FUND",
                "DEBT_PAYOFF", "NET_WORTH_GROWTH",
            ),
            GoalType.entries.map(Enum<*>::name),
        )
        assertEquals(
            listOf(
                "ALLOCATED_BALANCE", "INCOME", "EXPENSE", "EMERGENCY_COVERAGE",
                "DEBT_BALANCE", "NET_WORTH", "HOUSE_TO_NET_WORTH_RATIO",
                "POST_PURCHASE_AVAILABLE_BALANCE", "INSTALLMENT_AMOUNT",
            ),
            MetricType.entries.map(Enum<*>::name),
        )
        assertEquals(
            listOf(
                "TARGET", "FUNDING", "MAX_RATIO", "MIN_VALUE", "MAX_VALUE",
                "CONFIRMATION_STREAK", "EXTERNAL_CONFIRMATION",
            ),
            ConditionKind.entries.map(Enum<*>::name),
        )
        assertEquals(listOf("ALLOCATE", "RELEASE", "CONSUME", "REVERSAL"), FundingKind.entries.map(Enum<*>::name))
        assertEquals(listOf("EXPECTED", "SAFE"), CostThreshold.entries.map(Enum<*>::name))
        assertEquals(
            listOf("EXPENSE_TRANSACTION", "EXPENSE_PURPOSE", "DEBT_ACCOUNT", "ESSENTIAL_PURPOSE"),
            ScopeDimension.entries.map(Enum<*>::name),
        )
        assertEquals(
            listOf("DRAFT", "ACTIVE", "PAUSED", "READY", "COMPLETED", "CANCELLED", "ARCHIVED"),
            GoalLifecycleStatus.entries.map(Enum<*>::name),
        )
        assertEquals(
            listOf("ON_TRACK", "NEEDS_ATTENTION", "BEHIND", "UNAVAILABLE"),
            GoalHealthStatus.entries.map(Enum<*>::name),
        )
    }

    @Test
    fun `goal decimals stay canonical and use BigDecimal`() {
        val amount = GoalDecimal.nonNegative("1200.00")

        assertEquals(BigDecimal("1200.00"), amount.value)
        listOf("1200", "1200.0", "01200.00", "-1.00", "NaN").forEach { invalid ->
            assertThrows(IllegalArgumentException::class.java) {
                GoalDecimal.nonNegative(invalid)
            }
        }
        assertThrows(IllegalArgumentException::class.java) { GoalDecimal.positive("0.00") }
    }

    @Test
    fun `entity constructors reject non canonical or negative financial values`() {
        assertThrows(IllegalArgumentException::class.java) { goal(targetDecimal = "100") }
        assertThrows(IllegalArgumentException::class.java) { goal(targetDecimal = "-100.00") }
        assertThrows(IllegalArgumentException::class.java) {
            GoalFundingTransaction(
                id = "funding-1",
                goalId = "goal-1",
                operationId = "operation-1",
                kind = FundingKind.ALLOCATE,
                amountDecimal = "-1.00",
                currencyCode = "SDG",
                balanceTransactionId = null,
                relatedFundingTransactionId = null,
                note = "",
                occurredAt = 1,
                createdAt = 1,
                updatedAt = 1,
                deletedAt = null,
                syncState = "pending",
            )
        }
    }

    @Test
    fun `versioned config round trips and starts with version`() {
        val config = VersionedGoalConfig(settings = linkedMapOf("window" to "3", "mode" to "closed"))
        val encoded = GoalConfigJson.encode(config)

        assertEquals(true, encoded.startsWith("{\"version\":1,"))
        assertEquals(config, GoalConfigJson.decode(encoded))
        assertThrows(IllegalArgumentException::class.java) { VersionedGoalConfig(version = 2) }
        assertThrows(IllegalArgumentException::class.java) {
            VersionedGoalConfig(settings = mapOf("targetDecimal" to "10.00"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            VersionedGoalConfig(settings = mapOf("scopeReferenceId" to "transaction-1"))
        }
    }

    private fun goal(targetDecimal: String) = FinancialGoal(
        id = "goal-1",
        name = "Goal",
        type = GoalType.HOUSE_PURCHASE,
        lifecycleStatus = GoalLifecycleStatus.DRAFT,
        healthStatus = GoalHealthStatus.UNAVAILABLE,
        currencyCode = "SDG",
        startDate = "2026-07-18",
        deadline = "2027-07-18",
        timezoneId = "Africa/Khartoum",
        targetDecimal = targetDecimal,
        baselineDecimal = null,
        targetPercentDecimal = null,
        confirmationPeriods = 1,
        costThreshold = null,
        configJson = "{\"version\":1,\"settings\":{}}",
        revision = 0,
        readyAt = null,
        completedAt = null,
        cancelledAt = null,
        archivedAt = null,
        createdAt = 1,
        updatedAt = 1,
        deletedAt = null,
        syncState = "pending",
    )
}

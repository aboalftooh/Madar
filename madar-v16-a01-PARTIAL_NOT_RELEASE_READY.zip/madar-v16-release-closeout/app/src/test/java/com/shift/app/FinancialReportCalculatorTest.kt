package com.shift.app

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.FinancialReportCalculator
import com.shift.app.domain.finance.PaymentKind
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class FinancialReportCalculatorTest {
    @Test
    fun actualExpenses_includeOnlyLegacyOrdinaryAndMaintenance() {
        val report = FinancialReportCalculator.period(
            transactions = listOf(tx("legacy", "expense", 10.0)),
            payments = listOf(
                payment("ordinary", PaymentKind.OrdinaryExpense, "20.00"),
                payment("maintenance", PaymentKind.AssetMaintenance, "30.00"),
                payment("purchase", PaymentKind.AssetPurchase, "40.00"),
                payment("improvement", PaymentKind.AssetImprovement, "50.00"),
                payment("withdrawal", PaymentKind.BalanceWithdrawal, "60.00")
            ),
            from = LocalDate.parse("2026-07-01"),
            to = LocalDate.parse("2026-07-31")
        )

        assertEquals("60.00", report.actualExpenses.toPlainString())
        assertEquals("200.00", report.payments.toPlainString())
    }

    @Test
    fun migratedLegacyExpense_isNotCountedTwice() {
        val report = FinancialReportCalculator.month(
            transactions = listOf(tx("migrated", "expense", 25.0), tx("legacy-only", "expense", 5.0)),
            payments = listOf(payment("migrated-payment", PaymentKind.OrdinaryExpense, "25.00")),
            month = YearMonth.of(2026, 7),
            migratedLegacyExpenseIds = setOf("migrated")
        )

        assertEquals("30.00", report.actualExpenses.toPlainString())
    }

    @Test
    fun migratedLegacyExpenseTombstoneStillPreventsLegacyRowFromReappearing() {
        val report = FinancialReportCalculator.month(
            transactions = listOf(tx("migrated", "expense", 25.0)),
            payments = listOf(
                payment(
                    "migrated-payment",
                    PaymentKind.OrdinaryExpense,
                    "25.00",
                    legacyTransactionId = "migrated",
                    deletedAt = 99
                )
            ),
            month = YearMonth.of(2026, 7)
        )

        assertEquals("0.00", report.actualExpenses.toPlainString())
    }

    @Test
    fun duplicatePaymentOperation_countsLatestRowOnce() {
        val report = FinancialReportCalculator.month(
            transactions = emptyList(),
            payments = listOf(
                payment("old", PaymentKind.OrdinaryExpense, "10.00", operationId = "same", updatedAt = 1),
                payment("new", PaymentKind.OrdinaryExpense, "12.00", operationId = "same", updatedAt = 2)
            ),
            month = YearMonth.of(2026, 7)
        )

        assertEquals("12.00", report.payments.toPlainString())
        assertEquals("12.00", report.actualExpenses.toPlainString())
    }

    @Test
    fun invalidDatesDeletedRowsAndRangeAreExcluded() {
        val report = FinancialReportCalculator.period(
            transactions = listOf(
                tx("start", "income", 10.0, "2026-07-01"),
                tx("end", "income", 20.0, "2026-07-31"),
                tx("invalid", "income", 100.0, "bad-date"),
                tx("deleted", "income", 100.0, deletedAt = 1)
            ),
            payments = listOf(payment("outside", PaymentKind.OrdinaryExpense, "99.00", date = "2026-08-01")),
            from = LocalDate.parse("2026-07-01"),
            to = LocalDate.parse("2026-07-31")
        )

        assertEquals("30.00", report.income.toPlainString())
        assertEquals("0.00", report.actualExpenses.toPlainString())
    }

    @Test
    fun latestValidValuation_ignoresDeletedInvalidCacheAndInactiveAssets() {
        val active = asset("active", AssetStatus.Active, cache = "9999.00")
        val transferred = asset("transferred", AssetStatus.Transferred)
        val sold = asset("sold", AssetStatus.Sold)
        val values = listOf(
            valuation("old", active.id, "100.00", "2026-06-01", createdAt = 1),
            valuation("bad-date", active.id, "900.00", "not-a-date", createdAt = 9),
            valuation("bad-value", active.id, "broken", "2026-07-03", createdAt = 9),
            valuation("deleted-new", active.id, "800.00", "2026-07-04", createdAt = 9, deletedAt = 10),
            valuation("new", active.id, "120.00", "2026-07-02", createdAt = 2),
            valuation("transferred-value", transferred.id, "30.00", "2026-07-01"),
            valuation("sold-value", sold.id, "500.00", "2026-07-01")
        )

        val total = FinancialReportCalculator.currentAssetsValue(listOf(active, transferred, sold), values)

        assertEquals("120.00", total.toPlainString())
    }

    @Test
    fun valuationTie_isResolvedByCreatedAtThenId() {
        val asset = asset("asset", AssetStatus.Active)
        val values = listOf(
            valuation("a", asset.id, "10.00", "2026-07-01", createdAt = 1),
            valuation("b", asset.id, "20.00", "2026-07-01", createdAt = 2),
            valuation("c", asset.id, "30.00", "2026-07-01", createdAt = 2)
        )

        assertEquals(
            "30.00",
            FinancialReportCalculator.currentAssetsValue(listOf(asset), values).toPlainString()
        )
    }

    @Test
    fun wealth_isCashBalancePlusCurrentAssetValuesEvenWhenBalanceIsNegative() {
        val active = asset("asset", AssetStatus.Active)
        val wealth = FinancialReportCalculator.wealth(
            balanceTransactions = listOf(
                balance("in", "inflow", "20.00"),
                balance("out", "outflow", "50.00")
            ),
            assets = listOf(active),
            valuations = listOf(valuation("value", active.id, "100.00", "2026-07-01"))
        )

        assertEquals("-30.00", wealth.balance.toPlainString())
        assertEquals("100.00", wealth.assetsValue.toPlainString())
        assertEquals("70.00", wealth.netWorth.toPlainString())
    }

    @Test
    fun wealth_inProductionReportDefinitionIncludesDebts() {
        val wealth = FinancialReportCalculator.wealth(
            balanceTransactions = listOf(balance("cash", "inflow", "100.00")),
            assets = listOf(asset("asset", AssetStatus.Active)),
            valuations = listOf(valuation("asset-value", "asset", "50.00", "2026-07-01")),
            debtAccounts = listOf(debtAccount("receivable", DebtDirection.Receivable), debtAccount("payable", DebtDirection.Payable)),
            debtTransactions = listOf(debtTx("receivable", "40.00"), debtTx("payable", "30.00")),
        )

        assertEquals("40.00", wealth.receivables.toPlainString())
        assertEquals("30.00", wealth.payables.toPlainString())
        assertEquals("160.00", wealth.netWorth.toPlainString())
    }

    private fun tx(
        id: String,
        type: String,
        amount: Double,
        date: String = "2026-07-12",
        deletedAt: Long? = null
    ) = Transaction(id = id, type = type, amount = amount, category = "اختبار", date = date, deletedAt = deletedAt)

    private fun payment(
        id: String,
        kind: PaymentKind,
        amount: String,
        operationId: String = "op-$id",
        date: String = "2026-07-12",
        updatedAt: Long = 1,
        legacyTransactionId: String? = null,
        deletedAt: Long? = null
    ) = Payment(
        id = id,
        operationId = operationId,
        kind = kind.dbValue,
        amountDecimal = amount,
        date = date,
        balanceTransactionId = "balance-$id",
        legacyTransactionId = legacyTransactionId,
        updatedAt = updatedAt,
        deletedAt = deletedAt
    )

    private fun asset(id: String, status: AssetStatus, cache: String? = null) = Asset(
        id = id,
        type = "other",
        name = id,
        status = status.dbValue,
        acquisitionMode = "preexisting",
        acquisitionAmountDecimal = "0.00",
        currentValueCacheDecimal = cache
    )

    private fun valuation(
        id: String,
        assetId: String,
        value: String,
        date: String,
        createdAt: Long = 1,
        deletedAt: Long? = null
    ) = AssetValuation(
        id = id,
        operationId = "op-$id",
        assetId = assetId,
        valueDecimal = value,
        date = date,
        createdAt = createdAt,
        updatedAt = createdAt,
        deletedAt = deletedAt
    )

    private fun balance(id: String, direction: String, amount: String) = BalanceTransaction(
        id = id,
        operationId = "op-$id",
        direction = direction,
        kind = "test",
        amountDecimal = amount,
        date = "2026-07-12"
    )

    private fun debtAccount(id: String, direction: DebtDirection) = DebtAccount(
        id = id,
        operationId = "op-$id",
        direction = direction.dbValue,
        partyName = id,
        partyKey = id,
        confirmed = true,
    )

    private fun debtTx(accountId: String, amount: String) = DebtTransaction(
        accountId = accountId,
        operationId = "op-$accountId",
        type = DebtTransactionType.Opening,
        amountDecimal = amount,
        occurredAt = 1L,
    )
}

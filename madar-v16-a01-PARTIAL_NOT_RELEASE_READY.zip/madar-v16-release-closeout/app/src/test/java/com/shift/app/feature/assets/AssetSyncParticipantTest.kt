package com.shift.app.feature.assets

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetSyncParticipantTest {
    @Test
    fun `asset sync remains an infrastructure participant with composite operations`() {
        val source = source("sync/participant/AssetSyncParticipant.kt")
        assertTrue(source.contains("override val key: String = \"assets\""))
        assertTrue(source.contains("push_asset_operation:"))
        assertTrue(source.contains("remote.pushAssetOperation"))
        assertFalse(source.contains("feature.assets.presentation"))
        assertFalse(source.contains("AssetsViewModel"))
    }

    @Test
    fun `asset participant is registered once`() {
        val source = source("sync/di/SyncParticipantModule.kt")
        assertTrue(source.contains("bindAssets"))
        assertTrue(source.contains("AssetSyncParticipant"))
    }

    private fun source(relativePath: String): String = sequenceOf(
        File("../app/src/main/java/com/shift/app/$relativePath"),
        File("app/src/main/java/com/shift/app/$relativePath"),
    ).first(File::isFile).readText()
}

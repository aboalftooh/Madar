package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtAccrualOperationsTest {
    private val paymentSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/local/entities/Payment.kt"),
        File("app/src/main/java/com/shift/app/data/local/entities/Payment.kt")
    ).first(File::isFile).readText()

    private val dbSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt"),
        File("app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt")
    ).first(File::isFile).readText()

    private val repoSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt")
    ).first(File::isFile).readText()

    @Test
    fun migration15To16MakesPaymentBalanceLinkNullable() {
        assertTrue(paymentSource.contains("val balanceTransactionId: String?"))
        assertTrue(dbSource.contains("MIGRATION_15_16"))
        assertTrue(dbSource.contains("balanceTransactionId TEXT,"))
        assertTrue(dbSource.contains("'debt_gift'"))
    }

    @Test
    fun deferredExpenseCreatesPaymentWithoutCashLeg() {
        assertTrue(repoSource.contains("recordDeferredExpense("))
        assertTrue(repoSource.contains("Payment("))
        assertTrue(repoSource.contains("balanceTransactionId = null"))
        assertTrue(repoSource.contains("\"deferred_expense\""))
    }

    @Test
    fun accruedIncomeCreatesIncomeTransactionWithoutBalanceCollection() {
        assertTrue(repoSource.contains("recordAccruedIncome("))
        assertTrue(repoSource.contains("type = \"income\""))
        assertTrue(repoSource.contains("balanceTransactionId = null"))
        assertTrue(repoSource.contains("\"accrued_income\""))
    }
}

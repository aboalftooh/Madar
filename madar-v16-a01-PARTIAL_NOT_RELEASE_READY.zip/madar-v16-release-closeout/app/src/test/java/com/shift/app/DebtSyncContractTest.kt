package com.shift.app

import com.shift.app.data.remote.DebtSyncBundle
import com.shift.app.data.remote.RemoteDebtAccount
import com.shift.app.data.remote.RemoteDebtLink
import com.shift.app.data.remote.RemoteDebtTransaction
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtSyncContractTest {
    @Test
    fun completeBundleRequiresAccountTransactionAndLinkDependencies() {
        val account = RemoteDebtAccount("a", "u", "op", "payable", "Ali", "ali", "SDG", syncState = "pending", createdAt = 1)
        val tx = RemoteDebtTransaction("t", "u", "a", "op", "opening", "10.00", "SDG", 1, syncState = "pending", createdAt = 1)
        val link = RemoteDebtLink("l", "u", "op", "a", "t", "balance_transaction", "b", "cash", syncState = "pending", createdAt = 1)

        val complete = DebtSyncBundle("op", listOf(account), listOf(tx), listOf(link))
        val incomplete = DebtSyncBundle("op", emptyList(), listOf(tx), listOf(link))

        assertTrue(complete.isComplete)
        assertNull(complete.incompleteReason)
        assertFalse(incomplete.isComplete)
        assertTrue(incomplete.incompleteReason!!.contains("IncompleteRemote"))
    }

    @Test
    fun bundleRejectsCrossUserRows() {
        val account = RemoteDebtAccount("a", "u1", "op", "payable", "Ali", "ali", "SDG", syncState = "pending", createdAt = 1)
        val tx = RemoteDebtTransaction("t", "u2", "a", "op", "opening", "10.00", "SDG", 1, syncState = "pending", createdAt = 1)

        assertFalse(DebtSyncBundle("op", listOf(account), listOf(tx)).isComplete)
    }
}

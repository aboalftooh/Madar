package com.shift.app.backup

import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.data.RestoreAtomicityGuard
import com.shift.app.feature.backup.data.RestoreTransactionBoundary
import com.shift.app.feature.backup.domain.model.BackupImportMode
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RestoreAtomicityTest {
    @Test fun failureRollsBackTransactionAndExternalState() = runSuspend {
        val events = mutableListOf<String>()
        val boundary = RestoreTransactionBoundary { block ->
            events += "transaction:start"
            try { block() } catch (error: Throwable) {
                events += "transaction:rollback"
                throw error
            }
        }
        val first = FakeCodec("first", events)
        val second = FakeCodec("second", events, failOnApply = true)
        val guard = RestoreAtomicityGuard(boundary)

        val result = runCatching {
            guard.apply(listOf(first to FakePlan, second to FakePlan))
        }

        assertTrue(result.isFailure)
        assertTrue(events.contains("transaction:rollback"))
        assertEquals("first:rollbackExternal", events.last())
        assertTrue(events.none { it == "first:applyExternal" })
    }

    @Test fun successAppliesAllSectionsInsideOneBoundary() = runSuspend {
        val events = mutableListOf<String>()
        val boundary = RestoreTransactionBoundary { block ->
            events += "transaction:start"; block(); events += "transaction:commit"
        }
        val guard = RestoreAtomicityGuard(boundary)
        guard.apply(listOf(FakeCodec("one", events) to FakePlan, FakeCodec("two", events) to FakePlan))
        assertEquals(1, events.count { it == "transaction:start" })
        assertEquals(1, events.count { it == "transaction:commit" })
        assertTrue(events.indexOf("one:apply") < events.indexOf("one:applyExternal"))
    }

    private object FakePlan : BackupSectionPlan {
        override val importedRowCount = 1
        override val affectedRowCount = 1
        override val deleteCount = 0
    }
    private class FakeCodec(
        override val id: String,
        private val events: MutableList<String>,
        private val failOnApply: Boolean = false,
    ) : BackupSectionCodec {
        override suspend fun writeExport(root: JSONObject) = Unit
        override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot = error("unused")
        override suspend fun plan(imported: BackupSectionSnapshot, mode: BackupImportMode, now: Long): BackupSectionPlan = FakePlan
        override suspend fun captureExternalState(): Any = id
        override suspend fun apply(plan: BackupSectionPlan) {
            events += "$id:apply"
            if (failOnApply) error("boom")
        }
        override suspend fun applyExternal(plan: BackupSectionPlan) { events += "$id:applyExternal" }
        override suspend fun rollbackExternal(snapshot: Any?) { events += "$id:rollbackExternal" }
    }
}

package com.shift.app.goals

import com.shift.app.feature.goals.domain.model.GoalExpenseRow
import com.shift.app.feature.goals.domain.model.GoalScope
import com.shift.app.domain.goals.measurement.ExpenseGoalMeasurementProvider
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.templates.ExpenseGoalTemplateRequest
import com.shift.app.domain.goals.templates.ExpenseGoalTemplates
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExpenseGoalsTest {
    @Test
    fun reductionDefaultIsThreePeriodsAndCeilingDefaultIsFour() {
        val reduction = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_REDUCTION, reductionPercentDecimal = "10.00"))
        val ceiling = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_CEILING, fixedTargetDecimal = "900.00"))

        assertEquals(3, reduction.goal.confirmationPeriods)
        assertEquals("900.00", reduction.goal.targetDecimal)
        assertEquals(4, ceiling.goal.confirmationPeriods)
        assertEquals(4, ceiling.metrics.single().windowSize)
    }

    @Test
    fun exactBoundarySucceedsAndExceededLatestMonthResetsStreak() {
        val aggregate = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_REDUCTION, fixedTargetDecimal = "100.00"))
        val measurement = ExpenseGoalMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(payment("2026-04-01", "100.00"), payment("2026-05-01", "100.00"), payment("2026-06-01", "101.00")),
            emptyList(),
        )

        assertEquals("100.33", measurement.measuredDecimal)
        assertEquals(0, measurement.confirmationStreak)
        assertTrue(measurement.sourceFingerprint.contains("streak=0"))
    }

    @Test
    fun successfulAverageDoesNotHideInterruptedExpenseStreak() {
        val aggregate = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_REDUCTION, fixedTargetDecimal = "100.00"))
        val measurement = ExpenseGoalMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(payment("2026-04-01", "50.00"), payment("2026-05-01", "150.00"), payment("2026-06-01", "50.00")),
            emptyList(),
        )

        assertEquals("83.33", measurement.measuredDecimal)
        assertEquals(1, measurement.confirmationStreak)
    }

    @Test
    fun allRequiredExpensePeriodsProduceCompleteStreak() {
        val aggregate = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_CEILING, fixedTargetDecimal = "100.00"))
        val measurement = ExpenseGoalMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(
                payment("2026-03-01", "100.00"),
                payment("2026-04-01", "90.00"),
                payment("2026-05-01", "80.00"),
                payment("2026-06-01", "70.00"),
            ),
            emptyList(),
        )

        assertEquals("85.00", measurement.measuredDecimal)
        assertEquals(4, measurement.confirmationStreak)
    }

    @Test
    fun transactionSpecificExclusionRequiresGoalScopeAndDoesNotDeletePayment() {
        val aggregate = ExpenseGoalTemplates.build(request(GoalType.EXPENSE_CEILING, fixedTargetDecimal = "100.00")).let {
            it.copy(scopes = listOf(scope(goalId = it.goal.id, referenceId = "payment-2")))
        }
        val measurement = ExpenseGoalMeasurementProvider.measureRows(
            aggregate.metrics.single(),
            aggregate,
            Instant.parse("2026-07-18T00:00:00Z"),
            listOf(
                payment("2026-03-01", "50.00", "payment-1"),
                payment("2026-04-01", "50.00", "payment-2"),
                payment("2026-05-01", "50.00", "payment-3"),
                payment("2026-06-01", "50.00", "payment-4"),
            ),
            emptyList(),
        )

        assertEquals("missing-closed-expense-history", measurement.unavailableReason)
        assertEquals("payment-2", aggregate.scopes.single().referenceId)
    }

    private fun request(type: GoalType, fixedTargetDecimal: String? = null, reductionPercentDecimal: String? = null) =
        ExpenseGoalTemplateRequest(
            id = type.name.lowercase(),
            name = type.name,
            type = type,
            baselineDecimal = "1000.00",
            fixedTargetDecimal = fixedTargetDecimal,
            reductionPercentDecimal = reductionPercentDecimal,
            startDate = "2026-07-01",
            deadline = "2026-12-31",
            timezoneId = "UTC",
            now = 1L,
        )

    private fun payment(date: String, amount: String, id: String = java.util.UUID.randomUUID().toString()) = GoalExpenseRow(
        id = id,
        date = date,
        amountDecimal = amount,
        kind = "ordinary_expense",
        purpose = "عام",
        purposeKey = "عام",
        deletedAt = null,
    )

    private fun scope(goalId: String, referenceId: String) = GoalScope(
        id = "scope-$referenceId",
        goalId = goalId,
        dimension = ScopeDimension.EXPENSE_TRANSACTION,
        referenceId = referenceId,
        mode = "EXCLUDE",
        reason = "استثناء موثق",
        effectiveFrom = "2026-07-01",
        effectiveTo = null,
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
        syncState = "PENDING",
    )
}

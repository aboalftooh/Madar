package com.shift.app.sync

import com.shift.app.utils.SyncMergePolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClockSkewConflictTest {
    @Test
    fun pendingStateProtectsLocalWriteDespiteClockSkew() {
        assertFalse(
            SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = 50L,
                remoteUpdatedAt = 500L,
                lastSuccessfulSync = 100L,
                localSyncState = "FAILED",
            ),
        )
    }

    @Test
    fun cleanSyncedRowStillAcceptsNewerRemoteVersion() {
        assertTrue(
            SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = 50L,
                remoteUpdatedAt = 500L,
                lastSuccessfulSync = 100L,
                localSyncState = "synced",
            ),
        )
    }
}

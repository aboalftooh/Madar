package com.shift.app

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.feature.debts.presentation.DebtOperationWizardState
import com.shift.app.feature.debts.presentation.debtAsciiDecimalOnly
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtOperationWizardTest {
    @Test
    fun moneyFieldKeepsAsciiDecimalOnly() {
        assertEquals("23.45", debtAsciiDecimalOnly("١2a3.4.5"))
    }

    @Test
    fun wizardRequiresPartyAndPreviewsImpactBeforeSubmit() {
        val invalid = DebtOperationWizardState("op", "a", DebtDirection.Payable, "", "10.00")
        assertTrue(invalid.validate().isNotEmpty())
        val valid = invalid.copy(partyName = "Ali", cashSource = DebtCashSource.MadarBalance)
        assertEquals("10.00", valid.preview(1).payableDeltaDecimal)
        assertTrue(valid.preview(1).requiresBalanceEnabled)
    }
}

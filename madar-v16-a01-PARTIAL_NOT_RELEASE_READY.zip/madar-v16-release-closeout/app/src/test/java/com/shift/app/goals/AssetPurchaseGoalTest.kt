package com.shift.app.goals

import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.evaluation.GoalEvaluationEngine
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.measurement.AssetPurchaseMeasurementProvider
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.templates.AssetPurchaseGoalTemplate
import com.shift.app.domain.goals.templates.AssetPurchaseTemplateRequest
import com.shift.app.domain.goals.templates.CarPurchaseMode
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import java.io.File
import java.math.BigDecimal
import java.time.Instant
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetPurchaseGoalTest {
    private val useCaseSource = sequenceOf(
        File("../feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteAssetPurchaseGoal.kt"),
        File("feature/goals/src/main/java/com/shift/app/domain/goals/usecase/CompleteAssetPurchaseGoal.kt"),
    ).first(File::isFile).readText()

    @Test
    fun houseTemplateRequiresFundingAndDefaultThirtyPercentNetWorthRatio() {
        val aggregate = AssetPurchaseGoalTemplate.build(
            AssetPurchaseTemplateRequest(
                id = "house-goal",
                name = "شراء منزل",
                type = GoalType.HOUSE_PURCHASE,
                targetDecimal = "300000.00",
                startDate = "2026-07-18",
                deadline = "2027-07-18",
                timezoneId = "Africa/Khartoum",
                now = 1L,
            ),
        )

        assertEquals(listOf(MetricType.ALLOCATED_BALANCE, MetricType.HOUSE_TO_NET_WORTH_RATIO), aggregate.metrics.map { it.metricType })
        assertEquals("30.00", aggregate.goal.targetPercentDecimal)
        assertTrue(aggregate.conditions.any { it.kind == ConditionKind.FUNDING && it.valueDecimal == "300000.00" })
        assertTrue(aggregate.conditions.any { it.kind == ConditionKind.MAX_RATIO && it.valueDecimal == "30.00" })
    }

    @Test
    fun financedCarTemplateAddsInstallmentAndPostBalanceConditions() {
        val aggregate = AssetPurchaseGoalTemplate.build(
            AssetPurchaseTemplateRequest(
                id = "car-goal",
                name = "شراء سيارة",
                type = GoalType.CAR_PURCHASE,
                targetDecimal = "120000.00",
                startDate = "2026-07-18",
                deadline = "2027-01-18",
                timezoneId = "Africa/Khartoum",
                carMode = CarPurchaseMode.FINANCED,
                financedAmountDecimal = "80000.00",
                installmentAmountDecimal = "4500.00",
                maxInstallmentDecimal = "5000.00",
                minimumPostPurchaseBalanceDecimal = "1000.00",
                now = 1L,
            ),
        )

        assertEquals(
            listOf(MetricType.ALLOCATED_BALANCE, MetricType.POST_PURCHASE_AVAILABLE_BALANCE, MetricType.INSTALLMENT_AMOUNT),
            aggregate.metrics.map { it.metricType },
        )
        assertTrue(aggregate.conditions.any { it.kind == ConditionKind.MIN_VALUE && it.valueDecimal == "1000.00" })
        assertTrue(aggregate.conditions.any { it.kind == ConditionKind.MAX_VALUE && it.valueDecimal == "5000.00" })
        assertTrue(aggregate.conditions.any { it.kind == ConditionKind.FUNDING && it.valueDecimal == "40000.00" })
        assertEquals("80000.00", GoalConfigJson.decode(aggregate.goal.configJson).settings["financed"])
        assertEquals("4500.00", GoalConfigJson.decode(aggregate.goal.configJson).settings["installment"])
    }

    @Test
    fun financedCarRequiresItsCashPortionWhileCashCarRequiresFullPrice() = runTest {
        val financed = carAggregate(installment = "4500.00")
        val cash = AssetPurchaseGoalTemplate.build(
            carRequest(
                id = "cash-car",
                carMode = CarPurchaseMode.CASH,
                financedAmount = null,
                installment = null,
                maxInstallment = null,
            ),
        )

        assertEquals("40000.00", financed.conditions.single { it.kind == ConditionKind.FUNDING }.valueDecimal)
        assertEquals("120000.00", cash.conditions.single { it.kind == ConditionKind.FUNDING }.valueDecimal)
        assertFalse(GoalConfigJson.decode(cash.goal.configJson).settings.containsKey("financed"))

        val activeCash = cash.copy(
            goal = cash.goal.copy(lifecycleStatus = GoalLifecycleStatus.ACTIVE),
            fundingTransactions = listOf(funding("cash-allocation", "120000.00", goalId = "cash-car")),
        )
        val provider = AssetPurchaseMeasurementProvider(realBalanceDecimal = { "200000.00" })
        val measurements = activeCash.metrics.map { provider.measure(it, activeCash, asOf) }

        assertEquals("80000.00", measurements.single { it.metricType == MetricType.POST_PURCHASE_AVAILABLE_BALANCE }.measuredDecimal)
        assertEquals(GoalLifecycleStatus.READY, GoalEvaluationEngine().evaluate(activeCash, measurements, asOf).lifecycleStatus)
    }

    @Test
    fun postPurchaseBalanceDoesNotDoubleSubtractFullPartialOrMissingAllocation() = runTest {
        val aggregate = carAggregate(installment = "4500.00")
        val provider = AssetPurchaseMeasurementProvider(realBalanceDecimal = { "100000.00" })
        val metric = aggregate.metrics.single { it.metricType == MetricType.POST_PURCHASE_AVAILABLE_BALANCE }

        val balances = listOf("40000.00", "15000.00", null).mapIndexed { index, allocation ->
            val withFunding = aggregate.copy(
                fundingTransactions = allocation?.let { listOf(funding("allocation-$index", it)) }.orEmpty(),
            )
            provider.measure(metric, withFunding, asOf).measuredDecimal
        }

        assertEquals(listOf("60000.00", "60000.00", "60000.00"), balances)
        assertEquals(
            BigDecimal("60000.00"),
            GoalFundingCalculator.postPurchaseAvailableBalance(BigDecimal("100000.00"), BigDecimal("40000.00")),
        )
    }

    @Test
    fun financedCarInstallmentBoundaryControlsFinalReadiness() = runTest {
        assertEquals(GoalLifecycleStatus.READY, evaluateFinancedCar("4999.99"))
        assertEquals(GoalLifecycleStatus.READY, evaluateFinancedCar("5000.00"))
        assertEquals(GoalLifecycleStatus.ACTIVE, evaluateFinancedCar("5000.01"))
    }

    @Test
    fun financedCarCannotLoseDecisionAmounts() {
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            AssetPurchaseGoalTemplate.build(carRequest(installment = null))
        }
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            AssetPurchaseGoalTemplate.build(carRequest(financedAmount = null))
        }
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            AssetPurchaseGoalTemplate.build(carRequest(financedAmount = "120000.01"))
        }
    }

    @Test
    fun completionUseCaseConsumesAllocationAndCompletesInsideOneTransaction() {
        assertTrue(useCaseSource.contains("database.withTransaction"))
        assertTrue(useCaseSource.contains("assetRepository.purchaseAsset"))
        assertTrue(useCaseSource.contains("debtLedgerRepository.recordFinancedAssetPurchase"))
        assertTrue(useCaseSource.contains("kind = FundingKind.CONSUME"))
        assertTrue(useCaseSource.contains("GoalLifecycleStatus.COMPLETED"))
    }

    private suspend fun evaluateFinancedCar(installment: String): GoalLifecycleStatus {
        val aggregate = carAggregate(installment).let {
            it.copy(
                goal = it.goal.copy(lifecycleStatus = GoalLifecycleStatus.ACTIVE),
                fundingTransactions = listOf(funding("ready-allocation", "40000.00")),
            )
        }
        val provider = AssetPurchaseMeasurementProvider(realBalanceDecimal = { "100000.00" })
        val measurements = aggregate.metrics.map { provider.measure(it, aggregate, asOf) }
        return GoalEvaluationEngine().evaluate(aggregate, measurements, asOf).lifecycleStatus
    }

    private fun carAggregate(installment: String) =
        AssetPurchaseGoalTemplate.build(carRequest(installment = installment))

    private fun carRequest(
        id: String = "financed-car",
        carMode: CarPurchaseMode = CarPurchaseMode.FINANCED,
        financedAmount: String? = "80000.00",
        installment: String? = "4500.00",
        maxInstallment: String? = "5000.00",
    ) = AssetPurchaseTemplateRequest(
        id = id,
        name = "شراء سيارة",
        type = GoalType.CAR_PURCHASE,
        targetDecimal = "120000.00",
        startDate = "2026-07-18",
        deadline = "2027-01-18",
        timezoneId = "Africa/Khartoum",
        carMode = carMode,
        financedAmountDecimal = financedAmount,
        installmentAmountDecimal = installment,
        maxInstallmentDecimal = maxInstallment,
        minimumPostPurchaseBalanceDecimal = "1000.00",
        now = 1L,
    )

    private fun funding(id: String, amount: String, goalId: String = "financed-car") = GoalFundingTransaction(
        id = id,
        goalId = goalId,
        operationId = "op-$id",
        kind = FundingKind.ALLOCATE,
        amountDecimal = amount,
        currencyCode = "SDG",
        balanceTransactionId = null,
        relatedFundingTransactionId = null,
        note = "",
        occurredAt = 1L,
        createdAt = 1L,
        updatedAt = 1L,
        deletedAt = null,
        syncState = "PENDING",
    )

    private companion object {
        val asOf: Instant = Instant.parse("2026-08-18T12:00:00Z")
    }
}

package com.shift.app.feature.reports

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportsQueryTest {
    private val root = sequenceOf(
        File("app/src/main/java/com/shift/app"),
        File("../app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)
    private val reportsModuleRoot = sequenceOf(
        File("feature/reports/src/main/java/com/shift/app"),
        File("../feature/reports/src/main/java/com/shift/app"),
    ).first(File::isDirectory)

    @Test
    fun `query contract is read only and returns report owned dataset`() {
        val source = File(reportsModuleRoot, "feature/reports/domain/repository/ReportsQuery.kt").readText()
        assertTrue(source.contains("fun observeDataset(): Flow<ReportsDataset>"))
        listOf("insert", "update", "delete", "upsert", "MadarDatabase", "Dao", "Entity").forEach {
            assertFalse("ReportsQuery must stay read-only: $it", source.contains(it))
        }
    }

    @Test
    fun `adapter owns cross feature reads and maps them to report rows`() {
        val source = File(root, "feature/reports/data/ReportsQueryAdapter.kt").readText()
        assertTrue(source.contains(": ReportsQuery"))
        assertTrue(source.contains("ReportsDataset("))
        assertTrue(source.contains("ReportTransactionRow("))
        assertTrue(source.contains("ReportDebtAccountRow("))
        assertFalse(source.contains("suspend fun insert"))
        assertFalse(source.contains("suspend fun update"))
    }
}

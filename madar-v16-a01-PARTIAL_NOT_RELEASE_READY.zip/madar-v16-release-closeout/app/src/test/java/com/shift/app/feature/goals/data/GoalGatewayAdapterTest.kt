package com.shift.app.feature.goals.data

import com.shift.app.domain.goals.model.*
import com.shift.app.feature.goals.domain.model.*
import org.junit.Assert.assertEquals
import org.junit.Test

class GoalGatewayAdapterTest {
    @Test fun aggregateMappingRoundTripsWithoutLosingDomainValues() {
        val goal = FinancialGoal("g","Goal",GoalType.INCOME_GROWTH,GoalLifecycleStatus.DRAFT,GoalHealthStatus.UNAVAILABLE,"SDG","2026-01-01","2026-12-31","UTC","100.00","80.00",null,1,null,"{\"version\":1,\"settings\":{}}",0,null,null,null,null,1,1,null,"PENDING")
        val aggregate = GoalAggregate(goal=goal, metrics=listOf(GoalMetric("m","g",MetricType.INCOME,"CLOSED_MONTH_AVERAGE",3,"80.00","{\"version\":1,\"settings\":{}}",0,1,1,null,"PENDING")))
        val restored = aggregate.toEntityAggregate().toDomain()
        assertEquals(aggregate, restored)
    }
}

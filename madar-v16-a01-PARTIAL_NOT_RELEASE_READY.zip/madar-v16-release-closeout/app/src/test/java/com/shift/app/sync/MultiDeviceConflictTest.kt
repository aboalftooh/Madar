package com.shift.app.sync

import com.shift.app.utils.SyncMergeDecision
import com.shift.app.utils.SyncMergePolicy
import org.junit.Assert.assertEquals
import org.junit.Test

class MultiDeviceConflictTest {
    @Test
    fun deviceWithPendingWriteKeepsItEvenWhenItsClockIsBehindRemote() {
        val deviceA = Replica(updatedAt = 50L, syncState = "pending", value = "local-A")
        val server = Replica(updatedAt = 500L, syncState = "synced", value = "server-old")

        assertEquals(
            SyncMergeDecision.KEEP_LOCAL_DIRTY,
            deviceA.decisionAgainst(server, lastSuccessfulSync = 100L),
        )
    }

    @Test
    fun secondDeviceAcceptsFirstDeviceWriteAfterServerAcknowledgesIt() {
        val deviceB = Replica(updatedAt = 100L, syncState = "synced", value = "old")
        val serverAfterA = Replica(updatedAt = 600L, syncState = "synced", value = "from-A")

        assertEquals(
            SyncMergeDecision.APPLY_REMOTE,
            deviceB.decisionAgainst(serverAfterA, lastSuccessfulSync = 100L),
        )
    }

    @Test
    fun legacyLocalWriteAfterCheckpointIsProtectedWithoutExplicitSyncState() {
        val legacyDevice = Replica(updatedAt = 150L, syncState = null, value = "offline-change")
        val staleServer = Replica(updatedAt = 140L, syncState = "synced", value = "server")

        assertEquals(
            SyncMergeDecision.KEEP_LOCAL_DIRTY,
            legacyDevice.decisionAgainst(staleServer, lastSuccessfulSync = 100L),
        )
    }

    @Test
    fun cleanLocalRowWithNewerClockDoesNotMoveBackward() {
        val local = Replica(updatedAt = 900L, syncState = "synced", value = "newer")
        val remote = Replica(updatedAt = 800L, syncState = "synced", value = "older")

        assertEquals(
            SyncMergeDecision.KEEP_LOCAL_NEWER,
            local.decisionAgainst(remote, lastSuccessfulSync = 700L),
        )
    }

    private data class Replica(
        val updatedAt: Long,
        val syncState: String?,
        val value: String,
    ) {
        fun decisionAgainst(remote: Replica, lastSuccessfulSync: Long): SyncMergeDecision =
            SyncMergePolicy.decideRemote(
                localUpdatedAt = updatedAt,
                remoteUpdatedAt = remote.updatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = syncState,
            )
    }
}

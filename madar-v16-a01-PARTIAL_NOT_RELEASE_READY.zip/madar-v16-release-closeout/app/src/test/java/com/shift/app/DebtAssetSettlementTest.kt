package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtAssetSettlementTest {
    private val repoSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt")
    ).first(File::isFile).readText()

    @Test
    fun assetSettlementReducesDebtAndWritesAssetEventInOneTransaction() {
        assertTrue(repoSource.contains("recordAssetSettlement("))
        assertTrue(repoSource.contains("DebtCalculator.assertCanReduce"))
        assertTrue(repoSource.contains("AssetTransactionKind.Transferred"))
        assertTrue(repoSource.contains("\"asset_settlement\""))
        assertTrue(repoSource.contains("db.withTransaction"))
    }

    @Test
    fun creditSaleIsFullAssetSaleAndCreatesReceivable() {
        assertTrue(repoSource.contains("recordAssetSaleOnCredit("))
        assertTrue(repoSource.contains("Only active assets can be sold on credit"))
        assertTrue(repoSource.contains("AssetTransactionKind.SaleFull"))
        assertTrue(repoSource.contains("DebtDirection.Receivable"))
        assertTrue(repoSource.contains("credit_sale_asset"))
    }

    @Test
    fun optionalCashLegUsesSameOperationAndDebtLink() {
        assertTrue(repoSource.contains("credit_sale_cash"))
        assertTrue(repoSource.contains("writeBalanceLeg(cashDraft, debtTransaction, currencyCode)"))
        assertTrue(repoSource.contains("operationId = draft.operationId"))
    }
}

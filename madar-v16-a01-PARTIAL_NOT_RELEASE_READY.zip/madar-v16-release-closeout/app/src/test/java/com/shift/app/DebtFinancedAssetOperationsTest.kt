package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtFinancedAssetOperationsTest {
    private val recordsSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtOperationRecords.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtOperationRecords.kt")
    ).first(File::isFile).readText()

    private val repoSource = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt")
    ).first(File::isFile).readText()

    @Test
    fun financedAssetBundleWritesAssetDebtValuationAndLinksAtomically() {
        assertTrue(repoSource.contains("recordFinancedAssetPurchase("))
        assertTrue(repoSource.contains("db.withTransaction"))
        assertTrue(repoSource.contains("assetDao.insert(asset)"))
        assertTrue(repoSource.contains("assetTransactionDao.insert(assetTransaction)"))
        assertTrue(repoSource.contains("assetValuationDao.insert(valuation)"))
        assertTrue(repoSource.contains("transactionDao.upsert(debtTransaction)"))
    }

    @Test
    fun financedAssetRecordsPreserveCostAndInitialValuationWithoutExpense() {
        assertTrue(repoSource.contains("acquisitionAmountDecimal = assetValueDecimal"))
        assertTrue(repoSource.contains("currentValueCacheDecimal = assetValueDecimal"))
        assertTrue(repoSource.contains("Initial debt-financed valuation"))
        val financedBlock = repoSource.substringAfter("recordFinancedAssetPurchase(").substringBefore("suspend fun recordCashPrincipal(")
        assertTrue(!financedBlock.contains("Payment("))
    }

    @Test
    fun operationRecordsExposeAssetLegsForRollbackAndSync() {
        assertTrue(recordsSource.contains("val asset: Asset?"))
        assertTrue(recordsSource.contains("val assetTransaction: AssetTransaction?"))
        assertTrue(recordsSource.contains("val assetValuation: AssetValuation?"))
    }
}

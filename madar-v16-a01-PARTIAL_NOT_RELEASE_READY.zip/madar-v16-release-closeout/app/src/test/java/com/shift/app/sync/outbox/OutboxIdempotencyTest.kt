package com.shift.app.sync.outbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class OutboxIdempotencyTest {
    @Test
    fun sameOperationCoalescesToSameEventId() {
        assertEquals(
            outboxEventId("payments", "operation-1"),
            outboxEventId("payments", "operation-1"),
        )
    }

    @Test
    fun differentOperationsDoNotCollide() {
        assertNotEquals(
            outboxEventId("payments", "operation-1"),
            outboxEventId("payments", "operation-2"),
        )
    }
}

package com.shift.app

import com.shift.app.domain.debt.DebtScheduleCalculator
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtOrganizationRepositoryTest {
    @Test
    fun scheduleCalculatorDistributesRoundingToLastInstallment() {
        val items = DebtScheduleCalculator.equalInstallments("100.00", "2026-07-15", 3)
        assertEquals(listOf("33.33", "33.33", "33.34"), items.map { it.amountDecimal })
        assertEquals(listOf("2026-07-15", "2026-08-15", "2026-09-15"), items.map { it.dueDate })
    }

    @Test
    fun dueStateSupportsNoDateAndOverdueSections() {
        assertEquals("no_date", DebtScheduleCalculator.statusFor(null, "2026-07-14", "10.00"))
        assertEquals("overdue", DebtScheduleCalculator.statusFor("2026-07-13", "2026-07-14", "10.00"))
        assertEquals("due_today", DebtScheduleCalculator.statusFor("2026-07-14", "2026-07-14", "10.00"))
    }

    @Test
    fun organizationRepositoryWritesNoCashOrPaymentLegs() {
        val source = sequenceOf(
            File("../app/src/main/java/com/shift/app/data/repository/DebtOrganizationRepository.kt"),
            File("app/src/main/java/com/shift/app/data/repository/DebtOrganizationRepository.kt")
        ).first(File::isFile).readText()
        assertTrue(source.contains("DebtTransactionType.TransferOut"))
        assertTrue(source.contains("DebtTransactionType.TransferIn"))
        assertTrue(source.contains("scheduleDao.upsertAll"))
        assertTrue(!source.contains("BalanceTransaction"))
        assertTrue(!source.contains("Payment("))
    }
}

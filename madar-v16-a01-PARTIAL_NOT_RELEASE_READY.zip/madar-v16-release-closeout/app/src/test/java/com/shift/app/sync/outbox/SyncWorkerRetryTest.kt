package com.shift.app.sync.outbox

import com.shift.app.data.local.entities.SyncOutboxEntity
import com.shift.app.sync.SyncRunResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncWorkerRetryTest {
    @Test
    fun partialFailureIsRetryable() {
        val decision = decideOutboxRun(SyncRunResult.PartialFailure(listOf("push_assets")))
        assertTrue(decision is SyncOutboxRunDecision.Retry)
        assertEquals(listOf("push_assets"), (decision as SyncOutboxRunDecision.Retry).failedSteps)
    }

    @Test
    fun authenticationFailureDoesNotSpin() {
        assertEquals(
            SyncOutboxRunDecision.WaitForAuthentication,
            decideOutboxRun(SyncRunResult.AuthenticationRequired),
        )
    }

    @Test
    fun successfulRunCompletesSnapshot() {
        assertEquals(
            SyncOutboxRunDecision.Complete,
            decideOutboxRun(SyncRunResult.Success(100L)),
        )
    }

    @Test
    fun exponentialBackoffIsBounded() {
        assertEquals(10_000L, SyncOutboxBackoff.delayMillis(0))
        assertEquals(20_000L, SyncOutboxBackoff.delayMillis(1))
        assertEquals(40_000L, SyncOutboxBackoff.delayMillis(2))
        assertEquals(6 * 60 * 60 * 1_000L, SyncOutboxBackoff.delayMillis(20))
    }
    @Test
    fun eachEventKeepsItsOwnRetryLevel() {
        val now = 1_000_000L
        val fresh = event("fresh", attemptCount = 0)
        val retried = event("retried", attemptCount = 3)

        val freshFailure = retryOutboxEvent(fresh, now, listOf("push"))
        val retriedFailure = retryOutboxEvent(retried, now, listOf("push"))

        assertEquals(1, freshFailure.attemptCount)
        assertEquals(now + 10_000L, freshFailure.nextAttemptAt)
        assertEquals(4, retriedFailure.attemptCount)
        assertEquals(now + 80_000L, retriedFailure.nextAttemptAt)
    }

    private fun event(id: String, attemptCount: Int) = SyncOutboxEntity(
        eventId = id,
        entityType = "payments",
        entityId = id,
        operationId = id,
        createdAt = 1L,
        updatedAt = 1L,
        attemptCount = attemptCount,
    )

}

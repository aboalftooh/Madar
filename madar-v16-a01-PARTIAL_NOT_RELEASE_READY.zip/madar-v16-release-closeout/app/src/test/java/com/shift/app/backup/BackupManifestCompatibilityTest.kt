package com.shift.app.backup

import com.shift.app.feature.backup.domain.model.BackupCompatibility
import com.shift.app.feature.backup.domain.model.BackupManifest
import com.shift.app.feature.backup.domain.model.compatibility
import org.junit.Assert.assertEquals
import org.junit.Test

class BackupManifestCompatibilityTest {
    @Test fun currentManifestIsCompatible() {
        assertEquals(BackupCompatibility.COMPATIBLE, BackupManifest.current(10L).compatibility())
    }

    @Test fun wrongApplicationIsRejected() {
        val manifest = BackupManifest.current(10L).copy(applicationId = "other")
        assertEquals(BackupCompatibility.WRONG_APPLICATION, manifest.compatibility())
    }

    @Test fun newerFormatIsRejected() {
        val manifest = BackupManifest.current(10L).copy(formatVersion = 3, minimumReaderVersion = 3, maximumReaderVersion = 3)
        assertEquals(BackupCompatibility.FORMAT_TOO_NEW, manifest.compatibility())
    }

    @Test fun readerRangeIsEnforced() {
        val manifest = BackupManifest.current(10L).copy(minimumReaderVersion = 3, maximumReaderVersion = 4)
        assertEquals(BackupCompatibility.READER_TOO_OLD, manifest.compatibility())
    }
}

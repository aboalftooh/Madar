package com.shift.app.sync

import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.sync.SyncRunResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncOrchestratorTest {
    @Test
    fun participantsRunByOrderWithPullBeforePush() = runBlocking {
        val events = mutableListOf<String>()
        val checkpoints = FakeCheckpointStore()
        val later = fakeParticipant("later", 20, SyncCheckpointKey.Assets, events)
        val earlier = fakeParticipant("earlier", 10, SyncCheckpointKey.Transactions, events)

        val result = SyncOrchestrator(setOf(later, earlier), checkpoints).synchronize(
            expectedUserId = "user-1",
            isSessionCurrent = { true },
        )

        assertTrue(result is SyncRunResult.Success)
        assertEquals(
            listOf("pull:earlier", "pull:later", "push:earlier", "push:later"),
            events,
        )
        assertEquals(
            setOf(SyncCheckpointKey.Transactions.key, SyncCheckpointKey.Assets.key),
            checkpoints.participantCheckpoints.keys,
        )
        assertTrue(checkpoints.lastSync != null)
    }

    @Test
    fun failedPullDoesNotAdvanceItsCheckpointOrGlobalCheckpoint() = runBlocking {
        val events = mutableListOf<String>()
        val checkpoints = FakeCheckpointStore()
        var afterPullRan = false
        val failing = object : SyncParticipant {
            override val key = "failing"
            override val order = 10
            override suspend fun pullOperations() = listOf(
                SyncOperation("pull_failing", SyncCheckpointKey.Transactions) {
                    events += "pull:failing"
                    error("network")
                },
            )
            override suspend fun pushOperations(lastSuccessfulSync: Long) = listOf(
                SyncOperation("push_failing") { events += "push:failing" },
            )
        }
        val healthy = fakeParticipant("healthy", 20, SyncCheckpointKey.Assets, events)

        val result = SyncOrchestrator(setOf(failing, healthy), checkpoints).synchronize(
            expectedUserId = "user-1",
            isSessionCurrent = { true },
            afterPull = { afterPullRan = true },
        )

        assertTrue(result is SyncRunResult.PartialFailure)
        assertTrue((result as SyncRunResult.PartialFailure).failedSteps.contains("pull_failing"))
        assertFalse(afterPullRan)
        assertFalse(checkpoints.participantCheckpoints.containsKey(SyncCheckpointKey.Transactions.key))
        assertTrue(checkpoints.participantCheckpoints.containsKey(SyncCheckpointKey.Assets.key))
        assertNull(checkpoints.lastSync)
        assertTrue(events.contains("push:healthy"))
    }


    @Test
    fun checkpointWriteFailureIsIsolatedAndBlocksGlobalCheckpoint() = runBlocking {
        val events = mutableListOf<String>()
        val checkpoints = FakeCheckpointStore(failCheckpointKey = SyncCheckpointKey.Transactions.key)
        val failingCheckpoint = fakeParticipant("first", 10, SyncCheckpointKey.Transactions, events)
        val healthy = fakeParticipant("second", 20, SyncCheckpointKey.Assets, events)

        val result = SyncOrchestrator(setOf(failingCheckpoint, healthy), checkpoints).synchronize(
            expectedUserId = "user-1",
            isSessionCurrent = { true },
        )

        assertTrue(result is SyncRunResult.PartialFailure)
        assertTrue(checkpoints.participantCheckpoints.containsKey(SyncCheckpointKey.Assets.key))
        assertFalse(checkpoints.participantCheckpoints.containsKey(SyncCheckpointKey.Transactions.key))
        assertNull(checkpoints.lastSync)
        assertTrue(events.contains("push:second"))
    }

    @Test
    fun changedAuthenticationStopsRunWithoutAdvancingGlobalCheckpoint() = runBlocking {
        val checkpoints = FakeCheckpointStore()
        var current = true
        val participant = object : SyncParticipant {
            override val key = "session"
            override val order = 10
            override suspend fun pullOperations() = listOf(
                SyncOperation("pull_session", SyncCheckpointKey.Settings) { current = false },
            )
            override suspend fun pushOperations(lastSuccessfulSync: Long) = emptyList<SyncOperation>()
        }

        val result = SyncOrchestrator(setOf(participant), checkpoints).synchronize(
            expectedUserId = "user-1",
            isSessionCurrent = { current },
        )

        assertEquals(SyncRunResult.AuthenticationRequired, result)
        assertNull(checkpoints.lastSync)
        assertFalse(checkpoints.participantCheckpoints.containsKey(SyncCheckpointKey.Settings.key))
    }

    private fun fakeParticipant(
        name: String,
        participantOrder: Int,
        checkpointKey: SyncCheckpointKey,
        events: MutableList<String>,
    ): SyncParticipant = object : SyncParticipant {
        override val key = name
        override val order = participantOrder
        override suspend fun pullOperations() = listOf(
            SyncOperation("pull_$name", checkpointKey) { events += "pull:$name" },
        )
        override suspend fun pushOperations(lastSuccessfulSync: Long) = listOf(
            SyncOperation("push_$name") { events += "push:$name" },
        )
    }

    private class FakeCheckpointStore(
        private val failCheckpointKey: String? = null,
    ) : SyncCheckpointStore {
        var lastSync: Long? = null
        val participantCheckpoints = linkedMapOf<String, Long>()

        override suspend fun lastSuccessfulSync(): Long = lastSync ?: 0L
        override suspend fun setLastSuccessfulSync(value: Long) {
            lastSync = value
        }
        override suspend fun setParticipantCheckpoint(key: String, value: Long) {
            if (key == failCheckpointKey) error("checkpoint storage failed")
            participantCheckpoints[key] = value
        }
    }
}

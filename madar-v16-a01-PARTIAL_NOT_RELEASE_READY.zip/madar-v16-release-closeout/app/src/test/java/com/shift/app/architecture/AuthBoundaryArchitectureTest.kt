package com.shift.app.architecture

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthBoundaryArchitectureTest {
    @Test
    fun authViewModelDependsOnlyOnAuthSessionContracts() {
        val source = source("app/src/main/java/com/shift/app/feature/auth/presentation/AuthViewModel.kt")
        val forbidden = listOf(
            "com.shift.app.data.",
            "com.shift.app.sync.",
            "PreferencesManager",
            "MadarDatabase",
            "SyncManager",
            "io.github.jan.supabase",
            "androidx.room",
            "WorkManager",
        )
        forbidden.forEach { token ->
            assertFalse("AuthViewModel must not contain $token", source.contains(token))
        }
        listOf("AuthGateway", "SessionReader", "SessionBootstrapper", "SessionCleanup").forEach {
            assertTrue("AuthViewModel must depend on $it", source.contains(it))
        }
    }

    @Test
    fun destructiveCleanupIsOwnedByRoomAdapterNotPresentation() {
        val viewModel = source("app/src/main/java/com/shift/app/feature/auth/presentation/AuthViewModel.kt")
        val cleaner = source("app/src/main/java/com/shift/app/feature/auth/data/RoomAccountLocalDataCleaner.kt")
        assertFalse(viewModel.contains("deleteAll"))
        assertFalse(viewModel.contains("clearAllTables"))
        assertTrue(cleaner.contains("database.withTransaction"))
        assertTrue(cleaner.contains("database.syncOutboxDao().deleteAll()"))
    }

    @Test
    fun sessionCoordinatorOwnsSafeLogoutOrder() {
        val coordinator = source("app/src/main/java/com/shift/app/feature/auth/session/SessionCleanupCoordinator.kt")
        val syncIndex = coordinator.indexOf("synchronizePendingChanges()")
        val lockIndex = coordinator.indexOf("withExclusiveSession")
        val workIndex = coordinator.indexOf("cancelAndAwaitSessionWork()")
        val localIndex = coordinator.indexOf("clearAccountData()")
        val sessionIndex = coordinator.indexOf("clearAccountScopedState()")
        val authIndex = coordinator.indexOf("authGateway.signOut()")
        assertTrue(syncIndex in 0 until lockIndex)
        assertTrue(lockIndex < workIndex)
        assertTrue(workIndex < localIndex)
        assertTrue(localIndex < sessionIndex)
        assertTrue(sessionIndex < authIndex)
    }

    private fun source(path: String): String = sequenceOf(
        File("../$path"),
        File(path),
    ).first(File::isFile).readText()
}

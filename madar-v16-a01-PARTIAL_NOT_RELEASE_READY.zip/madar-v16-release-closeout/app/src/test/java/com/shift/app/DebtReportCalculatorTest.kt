package com.shift.app

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtReportCalculator
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import org.junit.Assert.assertEquals
import org.junit.Test

class DebtReportCalculatorTest {
    @Test
    fun netWorthIncludesBalanceAssetsReceivablesAndPayables() {
        val snapshot = DebtReportCalculator.wealth(
            balanceTransactions = listOf(balance("100.00")),
            assets = listOf(Asset(id = "asset", type = "device", name = "Phone", acquisitionMode = "preexisting", acquisitionAmountDecimal = "50.00")),
            valuations = emptyList(),
            accounts = listOf(account("r", DebtDirection.Receivable), account("p", DebtDirection.Payable)),
            transactions = listOf(tx("r", DebtTransactionType.Opening, "40.00"), tx("p", DebtTransactionType.Opening, "30.00"))
        )

        assertEquals("190.00", snapshot.totalAssetsDecimal.toPlainString())
        assertEquals("160.00", snapshot.netWorthDecimal.toPlainString())
    }

    @Test
    fun unconfirmedLegacyDebtIsExcludedFromWealth() {
        val snapshot = DebtReportCalculator.wealth(
            balanceTransactions = emptyList(),
            assets = emptyList(),
            valuations = emptyList(),
            accounts = listOf(account("p", DebtDirection.Payable).copy(confirmed = false)),
            transactions = listOf(tx("p", DebtTransactionType.Opening, "999.00"))
        )

        assertEquals("0.00", snapshot.payablesDecimal.toPlainString())
        assertEquals("0.00", snapshot.netWorthDecimal.toPlainString())
    }

    private fun account(id: String, direction: DebtDirection) = DebtAccount(
        id = id,
        operationId = "op-$id",
        direction = direction.dbValue,
        partyName = "Party",
        partyKey = "party",
        currencyCode = "SDG"
    )

    private fun tx(accountId: String, type: DebtTransactionType, amount: String) = DebtTransaction(
        accountId = accountId,
        operationId = "op-$accountId-$type",
        type = type.dbValue,
        amountDecimal = amount,
        occurredAt = 1_789_347_600_000L
    )

    private fun balance(amount: String) = BalanceTransaction(
        operationId = "balance",
        direction = BalanceDirection.Inflow.dbValue,
        kind = BalanceTransactionKind.ManualAdd.dbValue,
        amountDecimal = amount,
        date = "2026-07-14"
    )
}

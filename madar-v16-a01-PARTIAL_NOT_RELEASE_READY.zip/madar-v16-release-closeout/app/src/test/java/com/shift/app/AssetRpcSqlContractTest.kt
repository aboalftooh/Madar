package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetRpcSqlContractTest {
    @Test
    fun rpcSql_coversCurrencyTablesRlsLockingAndServerOversellValidation() {
        val sqlFile = sequenceOf(
            File("../docs/supabase_assets_rpc.sql"),
            File("docs/supabase_assets_rpc.sql")
        ).firstOrNull(File::isFile) ?: error("supabase_assets_rpc.sql not found")
        val sql = sqlFile.readText()

        assertTrue(sql.contains("currency_asset_lots"))
        assertTrue(sql.contains("currency_asset_sale_allocations"))
        assertTrue(sql.contains("enable row level security"))
        assertTrue(sql.contains("for update"))
        assertTrue(sql.contains("quantitySoldDecimal"))
        assertTrue(sql.contains("quantityPurchasedDecimal"))
        assertTrue(sql.contains("Currency sale exceeds available lot quantity"))
        assertTrue(sql.contains("p_transactions jsonb"))
        assertTrue(sql.contains("insert into public.transactions"))
        assertTrue(sql.contains("p_ledger_history_migrations jsonb"))
        assertTrue(sql.contains("ledger_history_migrations"))
        assertTrue(sql.contains("legacyTransactionId"))
        assertTrue(sql.contains("pg_advisory_xact_lock"))
        assertTrue(sql.contains("different fingerprint"))
        assertTrue(sql.contains("Invalid ledger history migration marker metadata"))
        assertTrue(sql.contains("candidate count is invalid"))
        assertTrue(sql.contains("marker counts are lower bounds"))
        assertTrue(sql.contains("jsonb, jsonb, jsonb, jsonb, jsonb, jsonb, jsonb, jsonb, jsonb"))
    }
}

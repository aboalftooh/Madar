package com.shift.app

import com.shift.app.utils.NumberDisplayFormatter
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Test

class NumberDisplayFormatterTest {
    @Test
    fun removesFractionWhenItContainsOnlyZeroes() {
        assertEquals("95000", NumberDisplayFormatter.format(BigDecimal("95000.00")))
        assertEquals("0", NumberDisplayFormatter.format(BigDecimal("0.00000000")))
    }

    @Test
    fun preservesRealFractionWithoutRounding() {
        assertEquals("95000.25", NumberDisplayFormatter.format(BigDecimal("95000.2500")))
        assertEquals("0.12345678", NumberDisplayFormatter.formatDecimalText("0.12345678"))
    }

    @Test
    fun supportsNegativeAndUngroupedValues() {
        assertEquals("-1,234.5", NumberDisplayFormatter.format(BigDecimal("-1234.500"), useGrouping = true))
        assertEquals("1234.5", NumberDisplayFormatter.format(BigDecimal("1234.500")))
    }
}

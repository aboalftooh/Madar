package com.shift.app

import com.shift.app.data.remote.AssetPayload
import com.shift.app.data.remote.AssetTransactionPayload
import com.shift.app.data.remote.AssetValuationPayload
import com.shift.app.data.remote.BalanceTransactionPayload
import com.shift.app.data.remote.CurrencyAssetLotPayload
import com.shift.app.data.remote.CurrencyAssetSaleAllocationPayload
import com.shift.app.data.remote.LedgerHistoryMigrationPayload
import com.shift.app.data.remote.PaymentPayload
import com.shift.app.data.remote.SYNC_ORCHESTRATED_REMOTE_TABLES
import com.shift.app.sync.runIsolatedSyncStep
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SyncOrchestrationContractTest {
    private val json = Json { ignoreUnknownKeys = true }

    @Test
    fun orchestratorRegistersEveryRemoteDataType() {
        assertEquals(
            setOf(
                "income_sources",
                "expense_beneficiaries",
                "transactions",
                "balance_transactions",
                "payments",
                "ledger_history_migrations",
                "assets",
                "asset_transactions",
                "asset_valuations",
                "currency_asset_lots",
                "currency_asset_sale_allocations",
                "debts",
                "financial_goals",
                "goal_metrics",
                "goal_conditions",
                "goal_scopes",
                "goal_funding_transactions",
                "goal_cost_estimates",
                "goal_evaluations",
                "goal_activities",
                "user_settings"
            ),
            SYNC_ORCHESTRATED_REMOTE_TABLES.toSet()
        )
    }

    @Test
    fun orchestrationIsOwnedByFeatureParticipants() {
        val manager = source("app/src/main/java/com/shift/app/data/remote/SyncManager.kt")
        val orchestrator = source("app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt")
        val participants = participantSources()

        assertTrue(manager.contains("SyncOrchestrator"))
        assertTrue(manager.contains("SyncSessionRemote"))
        assertTrue(orchestrator.contains("Set<@JvmSuppressWildcards SyncParticipant>"))
        assertTrue(orchestrator.contains("participants.sortedBy"))
        assertTrue(orchestrator.contains("pullOperations()"))
        assertTrue(orchestrator.contains("pushOperations(lastSync)"))

        listOf(
            "pullTransactions",
            "pullBalanceTransactions",
            "pullPayments",
            "pullLedgerHistoryMigrations",
            "pullAssets",
            "pullAssetTransactions",
            "pullAssetValuations",
            "pullCurrencyAssetLots",
            "pullCurrencyAssetSaleAllocations",
            "pullDebts",
            "pullFinancialGoals",
            "push_transactions",
            "push_ledger_history_migrations",
            "push_asset_operation",
            "push_debts",
            "push_financial_goals",
            "push_settings",
        ).forEach { expected ->
            assertTrue("Participants must own $expected", participants.contains(expected))
        }
    }

    @Test
    fun syncFacadeAndOrchestratorDoNotKnowRoomOrSupabaseDetails() {
        val manager = source("app/src/main/java/com/shift/app/data/remote/SyncManager.kt")
        val orchestrator = source("app/src/main/java/com/shift/app/sync/SyncOrchestrator.kt")
        val forbidden = listOf("MadarDatabase", "Dao", "androidx.room", "SupabaseClient", ".from(", ".rpc(")

        forbidden.forEach { dependency ->
            assertTrue("SyncManager must not depend on $dependency", !manager.contains(dependency))
            assertTrue("SyncOrchestrator must not depend on $dependency", !orchestrator.contains(dependency))
        }
    }

    @Test
    fun isolatedSyncStepContinuesAfterIndependentFailure() = runBlocking {
        val failures = mutableListOf<com.shift.app.sync.SyncStepFailure>()
        var secondStepRan = false

        runIsolatedSyncStep("first", failures) { error("network failed") }
        runIsolatedSyncStep("second", failures) { secondStepRan = true }

        assertTrue(secondStepRan)
        assertEquals(listOf("first"), failures.map { it.step })
        assertEquals(IllegalStateException::class.java.name, failures.single().causeType)
    }

    @Test
    fun newFinancialAndAssetPayloadsRoundTripThroughSerialization() {
        roundTrip(
            BalanceTransactionPayload.serializer(),
            BalanceTransactionPayload(
                operationId = "op-1",
                direction = "inflow",
                kind = "income",
                amountDecimal = "10.00",
                currencyCode = "SDG",
                date = "2026-07-13",
                note = "",
                sourceType = "transaction",
                sourceId = "tx-1",
                legacyTransactionId = null,
                syncState = "pending",
                createdAt = 1L
            )
        )
        roundTrip(
            PaymentPayload.serializer(),
            PaymentPayload(
                operationId = "op-2",
                kind = "asset_maintenance",
                amountDecimal = "5.00",
                currencyCode = "SDG",
                date = "2026-07-13",
                purpose = "maintenance",
                purposeKey = "maintenance",
                beneficiaryId = "asset-1",
                beneficiaryNameSnapshot = "Asset",
                assetId = "asset-1",
                assetNameSnapshot = "Asset",
                balanceTransactionId = "bt-1",
                legacyTransactionId = null,
                note = "",
                syncState = "pending",
                createdAt = 2L
            )
        )
        roundTrip(
            AssetPayload.serializer(),
            AssetPayload(
                operationId = "op-3",
                type = "foreign_currency",
                name = "USD",
                status = "active",
                acquisitionMode = "purchase",
                acquisitionAmountDecimal = "100.00",
                currencyCode = "USD",
                purchasePaymentId = "pay-1",
                purchaseBalanceTransactionId = "bt-2",
                currentValueCacheDecimal = "110.00",
                currentValueCacheValuationId = "val-1",
                syncState = "pending",
                createdAt = 3L
            )
        )
        roundTrip(
            AssetTransactionPayload.serializer(),
            AssetTransactionPayload(
                operationId = "op-4",
                assetId = "asset-1",
                kind = "sale_partial",
                amountDecimal = "30.00",
                currencyQuantityDeltaDecimal = "-1.00000000",
                paymentId = null,
                balanceTransactionId = "bt-3",
                date = "2026-07-13",
                note = "",
                syncState = "pending",
                createdAt = 4L
            )
        )
        roundTrip(
            AssetValuationPayload.serializer(),
            AssetValuationPayload(
                operationId = "op-5",
                assetId = "asset-1",
                valueDecimal = "120.00",
                date = "2026-07-13",
                note = "",
                syncState = "pending",
                createdAt = 5L
            )
        )
        roundTrip(
            CurrencyAssetLotPayload.serializer(),
            CurrencyAssetLotPayload(
                operationId = "op-6",
                assetId = "asset-1",
                purchaseAssetTransactionId = "event-1",
                foreignCurrencyCode = "USD",
                quantityPurchasedDecimal = "1.00000000",
                purchaseExchangeRateDecimal = "600.00000000",
                localCostDecimal = "600.00",
                purchaseDate = "2026-07-13",
                syncState = "pending",
                createdAt = 6L
            )
        )
        roundTrip(
            CurrencyAssetSaleAllocationPayload.serializer(),
            CurrencyAssetSaleAllocationPayload(
                operationId = "op-7",
                assetId = "asset-1",
                saleAssetTransactionId = "event-2",
                lotId = "lot-1",
                quantitySoldDecimal = "0.50000000",
                allocatedLocalCostDecimal = "300.00",
                syncState = "pending",
                createdAt = 7L
            )
        )
        roundTrip(
            LedgerHistoryMigrationPayload.serializer(),
            LedgerHistoryMigrationPayload(
                plannerVersion = 1,
                status = "completed",
                sourceFingerprint = "a".repeat(64),
                commitFingerprint = "b".repeat(64),
                candidateCount = 1,
                incomeCount = 1,
                expenseCount = 0,
                historicalIncomeDecimal = "10.00",
                historicalExpenseDecimal = "0.00",
                targetBalanceDecimal = "10.00",
                adjustmentDecimal = "0.00",
                adjustmentBalanceTransactionId = null,
                confirmedAt = 8L,
                completedAt = 9L,
                syncState = "pending",
                createdAt = 8L
            )
        )
    }

    @Test
    fun legacyAssetPayloadWithMissingNullableFieldsUsesDefaults() {
        val decoded = json.decodeFromString(
            AssetPayload.serializer(),
            """
            {
              "type":"car",
              "name":"Asset",
              "status":"active",
              "acquisitionMode":"preexisting",
              "acquisitionAmountDecimal":"0.00",
              "currencyCode":"SDG",
              "syncState":"synced",
              "createdAt":1
            }
            """.trimIndent()
        )

        assertNull(decoded.operationId)
        assertNull(decoded.currentValueCacheDecimal)
        assertNull(decoded.currentValueCacheValuationId)
    }

    private fun <T> roundTrip(serializer: KSerializer<T>, value: T) {
        val encoded = json.encodeToString(serializer, value)
        assertEquals(value, json.decodeFromString(serializer, encoded))
    }

    private fun source(path: String): String =
        sequenceOf(File("../$path"), File(path)).first(File::isFile).readText()

    private fun participantSources(): String {
        val directory = sequenceOf(
            File("../app/src/main/java/com/shift/app/sync/participant"),
            File("app/src/main/java/com/shift/app/sync/participant"),
        ).first(File::isDirectory)
        return directory.listFiles().orEmpty()
            .filter { it.extension == "kt" }
            .sortedBy { it.name }
            .joinToString("\n") { it.readText() }
    }
}

package com.shift.app

import com.shift.app.domain.debt.DebtFamily
import com.shift.app.domain.debt.DebtUserFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtScenarioCoverageTest {
    private val scenarios = (1..40).map { "S%02d".format(it) }.toSet()
    private val implementedScenarioMatrix = mapOf(
        "domain" to setOf("S01", "S02", "S03", "S04", "S09", "S12", "S13", "S14", "S19", "S22", "S24", "S25", "S26"),
        "cash-ledger" to setOf("S05", "S06", "S10", "S17", "S20", "S22", "S23", "S28"),
        "accrual-asset" to setOf("S07", "S08", "S11", "S18", "S21"),
        "organization" to setOf("S15", "S16", "S17", "S18", "S27", "S28", "S29", "S30", "S31", "S32", "S33"),
        "migration-ui-reminders" to setOf("S34", "S35", "S36", "S37", "S38", "S39", "S40")
    )

    @Test
    fun coversAllFortyScenariosTenFamiliesAndEightFlows() {
        assertEquals(scenarios, implementedScenarioMatrix.values.flatten().toSet())
        assertEquals(10, DebtFamily.entries.size)
        assertEquals(8, DebtUserFlow.entries.size)
    }

    @Test
    fun everyScenarioIsAssignedToAtLeastOneExecutionArea() {
        scenarios.forEach { scenario ->
            assertTrue("$scenario has no owner", implementedScenarioMatrix.any { scenario in it.value })
        }
    }
}

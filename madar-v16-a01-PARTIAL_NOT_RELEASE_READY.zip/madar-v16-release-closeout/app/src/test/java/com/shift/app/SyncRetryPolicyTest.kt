package com.shift.app

import com.shift.app.data.remote.shouldPushFinancialRecord
import com.shift.app.domain.finance.SyncState
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncRetryPolicyTest {
    @Test
    fun syncedRecord_isSelectedOnlyWhenNewerThanLastSync() {
        assertFalse(
            shouldPushFinancialRecord(
                updatedAt = 99L,
                syncState = SyncState.Synced.dbValue,
                lastSync = 100L
            )
        )
        assertTrue(
            shouldPushFinancialRecord(
                updatedAt = 101L,
                syncState = SyncState.Synced.dbValue,
                lastSync = 100L
            )
        )
    }

    @Test
    fun oldNonSyncedRecords_areAlwaysSelectedForRetry() {
        listOf(
            SyncState.Pending,
            SyncState.Failed,
            SyncState.Conflict,
            SyncState.IncompleteRemote
        ).forEach { state ->
            assertTrue(
                "Expected ${state.dbValue} record to be retried",
                shouldPushFinancialRecord(
                    updatedAt = 1L,
                    syncState = state.dbValue,
                    lastSync = 100L
                )
            )
        }
    }
}

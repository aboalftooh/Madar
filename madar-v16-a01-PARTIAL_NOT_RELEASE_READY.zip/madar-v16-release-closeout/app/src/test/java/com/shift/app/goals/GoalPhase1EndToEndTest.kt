package com.shift.app.goals

import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.templates.AssetPurchaseGoalTemplate
import com.shift.app.domain.goals.templates.AssetPurchaseTemplateRequest
import com.shift.app.domain.goals.templates.CostFundingGoalTemplate
import com.shift.app.domain.goals.templates.CostFundingTemplateRequest
import com.shift.app.domain.goals.templates.DebtPayoffGoalTemplate
import com.shift.app.domain.goals.templates.DebtPayoffTemplateRequest
import com.shift.app.domain.goals.templates.EmergencyFundGoalTemplate
import com.shift.app.domain.goals.templates.EmergencyFundTemplateRequest
import com.shift.app.domain.goals.templates.ExpenseGoalTemplateRequest
import com.shift.app.domain.goals.templates.ExpenseGoalTemplates
import com.shift.app.domain.goals.templates.IncomeGrowthGoalTemplate
import com.shift.app.domain.goals.templates.IncomeGrowthTemplateRequest
import com.shift.app.domain.goals.templates.NetWorthGrowthGoalTemplate
import com.shift.app.domain.goals.templates.NetWorthGrowthTemplateRequest
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalPhase1EndToEndTest {
    @Test
    fun allTenGoalTypesHaveExecutablePhaseOneTemplates() {
        val aggregates = listOf(
            AssetPurchaseGoalTemplate.build(assetRequest("house", GoalType.HOUSE_PURCHASE)),
            AssetPurchaseGoalTemplate.build(assetRequest("car", GoalType.CAR_PURCHASE)),
            CostFundingGoalTemplate.build(costRequest("project", GoalType.PROJECT_FUNDING)),
            CostFundingGoalTemplate.build(costRequest("trip", GoalType.TRIP_FUNDING)),
            IncomeGrowthGoalTemplate.build(incomeRequest()),
            ExpenseGoalTemplates.build(expenseRequest("reduction", GoalType.EXPENSE_REDUCTION, fixed = "900.00")),
            ExpenseGoalTemplates.build(expenseRequest("ceiling", GoalType.EXPENSE_CEILING, fixed = "900.00")),
            EmergencyFundGoalTemplate.build(emergencyRequest()),
            DebtPayoffGoalTemplate.build(debtRequest()),
            NetWorthGrowthGoalTemplate.build(netWorthRequest()),
        )

        assertEquals(GoalType.entries.toSet(), aggregates.map { it.goal.type }.toSet())
        aggregates.forEach { aggregate ->
            assertTrue(aggregate.goal.configJson.startsWith("{\"version\":1,"))
            assertTrue(aggregate.metrics.isNotEmpty())
            assertTrue(aggregate.conditions.isNotEmpty())
        }
    }

    @Test
    fun finalCutoverHasFeatureEnabledAndNoLegacyGoalClasses() {
        val buildFile = source("app/build.gradle.kts")
        assertTrue(buildFile.contains("FINANCIAL_GOALS_PHASE_1\", \"true\""))
        assertFalse(File("app/src/main/java/com/shift/app/data/remote/RemoteGoal.kt").exists())
        assertFalse(File("app/src/main/java/com/shift/app/data/repository/GoalRepository.kt").exists())
        assertFalse(File("app/src/main/java/com/shift/app/data/local/dao/GoalDao.kt").exists())
        assertFalse(File("app/src/main/java/com/shift/app/data/local/entities/Goal.kt").exists())
    }

    @Test
    fun goalEditorCreatesTypedTemplateAggregatesInsteadOfGenericDefinitions() {
        val source = source("app/src/main/java/com/shift/app/viewmodel/GoalEditorViewModel.kt")

        assertFalse(source.contains("\"template\" to \"generic\""))
        listOf(
            "AssetPurchaseGoalTemplate.build",
            "CostFundingGoalTemplate.build",
            "IncomeGrowthGoalTemplate.build",
            "ExpenseGoalTemplates.build",
            "EmergencyFundGoalTemplate.build",
            "DebtPayoffGoalTemplate.build",
            "NetWorthGrowthGoalTemplate.build",
        ).forEach { assertTrue(source.contains(it)) }
    }

    private fun assetRequest(id: String, type: GoalType) = AssetPurchaseTemplateRequest(
        id = id,
        name = id,
        type = type,
        targetDecimal = "100.00",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun costRequest(id: String, type: GoalType) = CostFundingTemplateRequest(
        id = id,
        name = id,
        type = type,
        expectedDecimal = "100.00",
        safeDecimal = "120.00",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun incomeRequest() = IncomeGrowthTemplateRequest(
        id = "income",
        name = "income",
        targetDecimal = "100.00",
        baselineDecimal = "80.00",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun expenseRequest(id: String, type: GoalType, fixed: String) = ExpenseGoalTemplateRequest(
        id = id,
        name = id,
        type = type,
        baselineDecimal = "1000.00",
        fixedTargetDecimal = fixed,
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun emergencyRequest() = EmergencyFundTemplateRequest(
        id = "emergency",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        essentialPurposeKeys = listOf("essential"),
        now = 1L,
    )

    private fun debtRequest() = DebtPayoffTemplateRequest(
        id = "debt",
        baselineDebtDecimal = "100.00",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun netWorthRequest() = NetWorthGrowthTemplateRequest(
        id = "wealth",
        baselineDecimal = "100.00",
        fixedTargetDecimal = "120.00",
        startDate = "2026-07-01",
        deadline = "2026-12-31",
        timezoneId = "UTC",
        now = 1L,
    )

    private fun source(path: String): String = sequenceOf(File("../$path"), File(path)).first(File::isFile).readText()
}

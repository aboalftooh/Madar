package com.shift.app

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.feature.debts.presentation.DebtReductionSheetState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DebtReductionSheetTest {
    @Test
    fun reductionValidationRejectsOverPayment() {
        val state = DebtReductionSheetState("a", "10.00", "10.01", DebtCashSource.MadarBalance)
        assertEquals("المبلغ أكبر من المتبقي", state.validationError())
    }

    @Test
    fun reductionValidationAllowsPartialAndFull() {
        assertNull(DebtReductionSheetState("a", "10.00", "4.00", DebtCashSource.External).validationError())
        assertNull(DebtReductionSheetState("a", "10.00", "10.00", DebtCashSource.MadarBalance).validationError())
    }
}

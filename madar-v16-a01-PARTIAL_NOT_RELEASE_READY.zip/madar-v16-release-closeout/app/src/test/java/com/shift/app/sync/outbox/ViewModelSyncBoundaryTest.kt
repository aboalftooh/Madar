package com.shift.app.sync.outbox

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewModelSyncBoundaryTest {
    @Test
    fun viewModelsQueueWorkInsteadOfCallingPushMethods() {
        val roots = listOf(
            File("app/src/main/java/com/shift/app/viewmodel"),
            File("app/src/main/java/com/shift/app/ui"),
            File("src/main/java/com/shift/app/viewmodel"),
            File("src/main/java/com/shift/app/ui"),
        ).filter(File::isDirectory)

        val sources = roots.flatMap { root -> root.walkTopDown().filter { it.extension == "kt" }.toList() }
        assertTrue(sources.isNotEmpty())
        sources.forEach { file ->
            val source = file.readText()
            assertFalse("Direct push in ${'$'}{file.path}", Regex("\\bsync\\.push[A-Z]").containsMatchIn(source))
        }
    }
}

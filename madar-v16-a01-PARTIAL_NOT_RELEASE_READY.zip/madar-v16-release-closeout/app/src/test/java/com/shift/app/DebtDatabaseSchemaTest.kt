package com.shift.app

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtDatabaseSchemaTest {
    @Test
    fun roomVersionHasDebtMigrationsRegistered() {
        assertEquals(14, MadarDatabase.MIGRATION_14_15.startVersion)
        assertEquals(15, MadarDatabase.MIGRATION_14_15.endVersion)
        assertEquals(15, MadarDatabase.MIGRATION_15_16.startVersion)
        assertEquals(16, MadarDatabase.MIGRATION_15_16.endVersion)
    }

    @Test
    fun debtEntitiesExposeStableLocalDefaults() {
        assertEquals("Ali", DebtAccount(operationId = "op", direction = com.shift.app.domain.debt.DebtDirection.Payable, partyName = " Ali ").partyName)
        assertEquals("ali", DebtAccount(operationId = "op", direction = com.shift.app.domain.debt.DebtDirection.Payable, partyName = " Ali ").partyKey)
        assertEquals("opening", DebtTransaction(
            accountId = "a",
            operationId = "op",
            type = com.shift.app.domain.debt.DebtTransactionType.Opening,
            amountDecimal = "10.00",
            occurredAt = 1L
        ).type)
    }

    @Test
    fun defaultDebtRowsCarrySyncStateAndTombstoneFields() {
        val account = DebtAccount(operationId = "op", direction = com.shift.app.domain.debt.DebtDirection.Payable, partyName = "Ali")
        val tx = DebtTransaction(
            accountId = account.id,
            operationId = "op",
            type = com.shift.app.domain.debt.DebtTransactionType.Opening,
            amountDecimal = "10.00",
            occurredAt = 1L
        )
        val link = DebtLink(
            operationId = "op",
            accountId = account.id,
            debtTransactionId = tx.id,
            targetType = "balance_transaction",
            targetId = "bt",
            role = "cash_leg"
        )
        val schedule = DebtSchedule(
            operationId = "op",
            accountId = account.id,
            installmentNo = 1,
            dueDate = "2026-07-15",
            amountDecimal = "10.00"
        )
        val review = DebtMigrationReview(
            legacyDebtId = "legacy",
            reason = "missing party",
            legacyPayloadJson = "{}"
        )

        listOf(account.syncState, tx.syncState, link.syncState, schedule.syncState, review.syncState).forEach {
            assertEquals("pending", it)
        }
        assertTrue(listOf(account.deletedAt, tx.deletedAt, link.deletedAt, schedule.deletedAt, review.deletedAt).all { it == null })
        assertFalse(account.confirmed.not())
    }
}

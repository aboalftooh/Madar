package com.shift.app

import com.shift.app.data.local.entities.Transaction
import com.shift.app.utils.FinanceCalculations
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class FinanceCalculationsTest {
    @Test
    fun monthlyTotals_sumIncomeAndExpenseForSelectedMonthOnly() {
        val transactions = listOf(
            tx(type = "income", amount = 1000.0, date = "2026-07-01"),
            tx(type = "income", amount = 250.0, date = "2026-07-20"),
            tx(type = "expense", amount = 300.0, date = "2026-07-03"),
            tx(type = "expense", amount = 99.0, date = "2026-06-30"),
            tx(type = "income", amount = 5000.0, date = "bad-date"),
            tx(type = "expense", amount = 10.0, date = "2026-07-04", deletedAt = 123L)
        )

        val totals = FinanceCalculations.monthlyTotals(transactions, YearMonth.of(2026, 7))

        assertEquals(1250.0, totals.income, 0.0)
        assertEquals(300.0, totals.expense, 0.0)
    }

    @Test
    fun totals_countsIncomeAmountDirectly() {
        val totals = FinanceCalculations.totals(
            listOf(
                tx(type = "income", amount = 900.0, date = "2026-07-01"),
                tx(type = "expense", amount = 120.0, date = "2026-07-02")
            )
        )

        assertEquals(900.0, totals.income, 0.0)
        assertEquals(120.0, totals.expense, 0.0)
    }

    @Test
    fun budgetProgress_clampsBetweenZeroAndOne() {
        assertEquals(0.25, FinanceCalculations.budgetProgress(250.0, 1000.0), 0.0)
        assertEquals(1.0, FinanceCalculations.budgetProgress(1500.0, 1000.0), 0.0)
        assertEquals(1.0, FinanceCalculations.budgetProgress(2.0, 0.0), 0.0)
    }

    @Test
    fun filterByDateRange_keepsOnlyValidVisibleTransactionsInsideRange() {
        val transactions = listOf(
            tx(id = "before", date = "2026-06-30"),
            tx(id = "start", date = "2026-07-01"),
            tx(id = "middle", date = "2026-07-15"),
            tx(id = "end", date = "2026-07-31"),
            tx(id = "after", date = "2026-08-01"),
            tx(id = "invalid", date = "not-a-date"),
            tx(id = "deleted", date = "2026-07-10", deletedAt = 1L)
        )

        val filtered = FinanceCalculations.filterByDateRange(
            transactions,
            LocalDate.of(2026, 7, 1),
            LocalDate.of(2026, 7, 31)
        )

        assertEquals(listOf("start", "middle", "end"), filtered.map { it.id })
    }

    private fun tx(
        id: String = java.util.UUID.randomUUID().toString(),
        type: String = "income",
        amount: Double = 1.0,
        date: String,
        deletedAt: Long? = null
    ) = Transaction(
        id = id,
        type = type,
        amount = amount,
        category = "اختبار",
        date = date,
        deletedAt = deletedAt
    )
}

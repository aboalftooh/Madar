package com.shift.app.sync.outbox

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkerConfigurationTest {
    @Test
    fun schedulerRequiresNetworkAndUsesUniqueExponentialWork() {
        val scheduler = source("app/src/main/java/com/shift/app/sync/outbox/SyncWorkScheduler.kt")
        assertTrue(scheduler.contains("setRequiredNetworkType(NetworkType.CONNECTED)"))
        assertTrue(scheduler.contains("BackoffPolicy.EXPONENTIAL"))
        assertTrue(scheduler.contains("enqueueUniqueWork"))
        assertTrue(scheduler.contains("enqueueUniquePeriodicWork"))
        assertTrue(scheduler.contains("ExistingWorkPolicy.APPEND_OR_REPLACE"))
        assertTrue(scheduler.contains("ExistingPeriodicWorkPolicy.KEEP"))
    }

    @Test
    fun authenticationKeepsRowsWithoutCreatingRetryLoop() {
        val worker = source("app/src/main/java/com/shift/app/sync/outbox/SyncOutboxWorker.kt")
        assertTrue(worker.contains("SyncOutboxProcessResult.AuthenticationRequired -> Result.success()"))
        assertFalse(worker.contains("SyncOutboxProcessResult.AuthenticationRequired -> Result.retry()"))
    }

    @Test
    fun loginWakesPreviouslyBlockedOutbox() {
        val bootstrap = source("app/src/main/java/com/shift/app/feature/auth/session/SessionBootstrapCoordinator.kt")
        assertTrue(bootstrap.contains("syncQueue.enqueueRecovery()"))
    }

    private fun source(path: String): String = sequenceOf(
        File(path),
        File(path.removePrefix("app/")),
    ).first(File::isFile).readText()
}

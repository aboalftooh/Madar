package com.shift.app

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReleaseCloseoutArchitectureTest {
    @Test
    fun releaseBuildRejectsMissingBackendAndSigningConfiguration() {
        val build = source("app/build.gradle.kts")
        assertTrue(build.contains("validateReleaseConfiguration"))
        assertTrue(build.contains("supabaseUrl.isConfiguredValue() && supabaseUrl.startsWith(\"https://\")"))
        assertTrue(build.contains("supabaseKey.isConfiguredValue()"))
        assertTrue(build.contains("Release keystore does not exist"))
        assertTrue(build.contains("dependsOn(validateReleaseConfiguration)"))
        assertTrue(build.contains("!equals(\"null\", ignoreCase = true)"))
    }

    @Test
    fun releaseWorkflowBuildsOnlyFromExplicitSecrets() {
        val workflow = source(".github/workflows/android-release.yml")
        assertTrue(workflow.contains("ANDROID_KEYSTORE_BASE64"))
        assertTrue(workflow.contains("Validate required secrets"))
        assertTrue(workflow.contains("bundleRelease"))
        assertTrue(workflow.contains("Remove materialized secrets"))
        assertFalse(workflow.contains("storePassword=changeme"))
    }

    @Test
    fun secretsAndSigningFilesAreExcludedFromVersionControl() {
        val ignore = source(".gitignore")
        listOf("local.properties", "keystore.properties", "*.jks", "*.keystore").forEach {
            assertTrue("Missing ignore rule for $it", ignore.lineSequence().any { line -> line.trim() == it })
        }
        assertTrue(file("local.properties.example").isFile)
        assertTrue(file("keystore.properties.example").isFile)
    }

    @Test
    fun syncHasFeaturePortsInsteadOfCentralRemoteGodObject() {
        assertFalse(file("app/src/main/java/com/shift/app/data/remote/RemoteSyncDataSource.kt").exists())
        val port = source("app/src/main/java/com/shift/app/sync/remote/RemoteSyncPorts.kt")
        listOf(
            "ReferenceDataRemoteSync",
            "LedgerRemoteSync",
            "AssetRemoteSync",
            "DebtRemoteSync",
            "GoalRemoteSync",
            "SettingsRemoteSync",
        ).forEach { assertTrue(port.contains("interface $it")) }

        val slices = file("app/src/main/java/com/shift/app/data/remote")
            .listFiles().orEmpty()
            .filter { it.name.endsWith("RemoteSyncDataSource.kt") }
        assertEquals(6, slices.size)
        assertTrue(slices.all { it.readLines().size < 750 })
    }

    @Test
    fun roomVersionAndSchemaStayAtEighteen() {
        val database = source("app/src/main/java/com/shift/app/data/local/ShiftDatabase.kt")
        assertTrue(database.contains("version = 18"))
        assertTrue(database.contains("MIGRATION_17_18"))
        assertTrue(file("app/src/androidTest/java/com/shift/app/migration/Migration17To18InstrumentationTest.kt").isFile)
    }

    @Test
    fun obsoleteServerCommitCompatibilityMethodWasRemoved() {
        val migration = source("app/src/main/java/com/shift/app/data/repository/LegacyHistoryMigrationRepository.kt")
        assertFalse(migration.contains("applyServerCommitted"))
    }

    private fun source(path: String): String = file(path).readText()

    private val projectRoot: File by lazy {
        sequenceOf(File(".."), File("."))
            .first { File(it, "settings.gradle.kts").isFile }
    }

    private fun file(path: String): File = File(projectRoot, path)
}

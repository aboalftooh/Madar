package com.shift.app.feature.session

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppSessionGatewayContractTest {
    @Test
    fun `adapter owns sync manager preferences queue and migration`() {
        val adapter = source("feature/session/data/AppSessionGatewayAdapter.kt")
        assertTrue(adapter.contains("SyncManager"))
        assertTrue(adapter.contains("PreferencesManager"))
        assertTrue(adapter.contains("SyncQueueGateway"))
        assertTrue(adapter.contains("LegacyIncomeSourceMigrator"))
    }

    @Test
    fun `view model does not own legacy migration`() {
        val viewModel = source("feature/session/presentation/AppSessionViewModel.kt")
        assertFalse(viewModel.contains("IncomeSourceRepository"))
        assertFalse(viewModel.contains("TransactionRepository"))
        assertFalse(viewModel.contains("LegacyIncomeSourceMigrator"))
    }

    @Test
    fun `session result preserves partial failure`() {
        val adapter = source("feature/session/data/AppSessionGatewayAdapter.kt")
        val viewModel = source("feature/session/presentation/AppSessionViewModel.kt")
        assertTrue(adapter.contains("AppSessionSyncStatus.PARTIAL_FAILURE"))
        assertTrue(viewModel.contains("AppSessionSyncStatus.PARTIAL_FAILURE"))
        assertTrue(viewModel.contains("تعذرت مزامنة بعض البيانات"))
    }

    private fun source(relativePath: String): String {
        val roots = sequenceOf(
            File("../app/src/main/java/com/shift/app"),
            File("app/src/main/java/com/shift/app"),
        )
        return File(roots.first(File::isDirectory), relativePath).readText()
    }
}

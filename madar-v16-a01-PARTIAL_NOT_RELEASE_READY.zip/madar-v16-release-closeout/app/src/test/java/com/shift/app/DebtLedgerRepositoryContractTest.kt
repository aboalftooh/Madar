package com.shift.app

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DebtLedgerRepositoryContractTest {
    private val source = sequenceOf(
        File("../app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt"),
        File("app/src/main/java/com/shift/app/data/repository/DebtLedgerRepository.kt")
    ).first(File::isFile).readText()

    @Test
    fun cashOperationsAreRoomTransactionsAndIdempotentByOperationId() {
        assertTrue(source.contains("openAccount("))
        assertTrue(source.contains("recordCashPrincipal("))
        assertTrue(source.contains("recordReduction("))
        assertTrue(source.contains("db.withTransaction"))
        assertTrue(source.contains("existing(operationId)?.let { return@withTransaction it }"))
    }

    @Test
    fun madarCashLegsUseExplicitDebtSourceAndSharedOperationId() {
        assertTrue(source.contains("sourceType = \"debt_transaction\""))
        assertTrue(source.contains("sourceId = debtTransaction.id"))
        assertTrue(source.contains("operationId = draft.operationId"))
        assertTrue(source.contains("writeLink(operationId, account.id, debtTransaction.id, \"balance_transaction\""))
    }

    @Test
    fun repositoryRejectsMissingBalanceActivationAndOverReduction() {
        assertTrue(source.contains("requireBalanceActivated()"))
        assertTrue(source.contains("Madar balance must be activated"))
        assertTrue(source.contains("DebtCalculator.assertCanReduce"))
    }
}

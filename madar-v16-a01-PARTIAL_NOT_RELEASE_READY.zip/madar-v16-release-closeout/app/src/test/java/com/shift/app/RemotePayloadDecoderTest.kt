package com.shift.app

import com.shift.app.data.remote.RemotePayloadDecoder
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class RemotePayloadDecoderTest {
    private val json = Json { ignoreUnknownKeys = true }
    private val decoder = RemotePayloadDecoder(json)

    @Serializable
    private data class TestPayload(val name: String, val amount: Double)

    @Test
    fun decodesPlainJsonPayload() {
        val payload = """{"name":"salary","amount":1200.5}"""

        val decoded = decoder.decodePayload(payload, "user-1", TestPayload.serializer())

        assertEquals(TestPayload("salary", 1200.5), decoded)
        assertTrue(decoder.isPlainJsonPayload(payload))
    }

    @Test
    fun decodesLegacyEncryptedPayload() {
        val userId = "user-1"
        val plain = """{"name":"rent","amount":350.0}"""
        val encrypted = legacyEncrypt(plain, userId)

        val decoded = decoder.decodePayload(encrypted, userId, TestPayload.serializer())

        assertEquals(TestPayload("rent", 350.0), decoded)
    }

    @Test
    fun corruptedPayloadCanBeSkippedPerRow() {
        val rows = listOf(
            """{"name":"ok","amount":1.0}""",
            "not-valid-base64"
        )

        val decoded = rows.mapNotNull { row ->
            runCatching {
                decoder.decodePayload(row, "user-1", TestPayload.serializer())
            }.getOrNull()
        }

        assertEquals(listOf(TestPayload("ok", 1.0)), decoded)
    }

    private fun legacyEncrypt(plain: String, userId: String): String {
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest("madar-app-v1:$userId".toByteArray(Charsets.UTF_8))
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        return Base64.getEncoder().encodeToString(iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8)))
    }
}

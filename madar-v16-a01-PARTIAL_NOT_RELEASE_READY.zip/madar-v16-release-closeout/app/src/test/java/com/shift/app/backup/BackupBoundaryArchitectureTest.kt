package com.shift.app.backup

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupBoundaryArchitectureTest {
    private val root = sequenceOf(
        File("app/src/main/java/com/shift/app"),
        File("../app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)

    @Test fun legacyManagerAndViewModelAreRemoved() {
        assertFalse(File(root, "utils/BackupManager.kt").exists())
        assertFalse(File(root, "viewmodel/BackupViewModel.kt").exists())
    }

    @Test fun presentationDependsOnBackupContractOnly() {
        val source = File(root, "feature/backup/presentation/BackupViewModel.kt").readText()
        listOf("com.shift.app.data.", "androidx.room", "MadarDatabase", "BackupSectionCodec", "JSONObject").forEach {
            assertFalse(source.contains(it))
        }
        assertTrue(source.contains("BackupGateway"))
    }

    @Test fun settingsDoesNotBuildRestorePlansOrReadRoomEntities() {
        val source = File(root, "ui/screens/SettingsScreen.kt").readText()
        assertTrue(source.contains("feature.backup.presentation.BackupViewModel"))
        listOf("BackupManager", "DebtBackupPayload", "GoalBackupPayload", "buildImportPlan", "MadarDatabase").forEach {
            assertFalse(source.contains(it))
        }
    }

    @Test fun documentCodecKnowsNoFeatureEntities() {
        val source = File(root, "feature/backup/data/BackupDocumentCodec.kt").readText()
        assertFalse(source.contains("data.local.entities"))
        assertFalse(source.contains("data.backup"))
        assertTrue(source.contains("BackupSectionCodec"))
    }

    @Test fun eachFeatureOwnsASectionCodec() {
        listOf("FinanceBackupCodec.kt", "AssetBackupCodec.kt", "DebtBackupCodec.kt", "GoalBackupCodec.kt").forEach {
            assertTrue(File(root, "feature/backup/data/codec/$it").isFile)
        }
        assertTrue(File(root, "feature/backup/di/BackupFeatureModule.kt").isFile)
    }
}

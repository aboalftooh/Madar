package com.shift.app.sync.outbox

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class ProcessDeathRecoveryTest {
    @Test
    fun applicationSchedulesRecoveryAfterProcessRestart() {
        val app = source("app/src/main/java/com/shift/app/ShiftApplication.kt")
        assertTrue(app.contains("syncWorkScheduler.startRecovery(applicationScope)"))
        val scheduler = source("app/src/main/java/com/shift/app/sync/outbox/SyncWorkScheduler.kt")
        assertTrue(scheduler.contains("ensurePeriodicRecovery()"))
        assertTrue(scheduler.contains("pendingCount"))
    }

    @Test
    fun workerDeletesOnlyCapturedSnapshotAfterSuccess() {
        val processor = source("app/src/main/java/com/shift/app/sync/outbox/SyncOutboxProcessor.kt")
        assertTrue(processor.contains("val snapshot = outboxDao.getReady"))
        assertTrue(processor.contains("deleteIfUnchanged(event.eventId, event.revision)"))
        assertTrue(processor.contains("Revision-checked deletion preserves a newer write"))
    }

    private fun source(path: String): String = sequenceOf(
        File(path),
        File(path.removePrefix("app/")),
    ).first(File::isFile).readText()
}

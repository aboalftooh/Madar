package com.shift.app.feature.goals

import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.goals.measurement.DebtPayoffMeasurementProvider
import com.shift.app.domain.goals.measurement.IncomeGoalMeasurementProvider
import com.shift.app.domain.goals.templates.DebtPayoffGoalTemplate
import com.shift.app.domain.goals.templates.DebtPayoffTemplateRequest
import com.shift.app.domain.goals.templates.IncomeGrowthGoalTemplate
import com.shift.app.domain.goals.templates.IncomeGrowthTemplateRequest
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.feature.goals.domain.model.GoalIncomeRow
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Test

class GoalMeasurementProviderTest {
    @Test fun incomeProviderUsesDomainRows() {
        val aggregate = IncomeGrowthGoalTemplate.build(IncomeGrowthTemplateRequest(id="income", name="Income", targetDecimal="100.00", baselineDecimal="80.00", startDate="2026-01-01", deadline="2026-12-31", timezoneId="UTC", now=1L))
        val rows = listOf("2026-04-01","2026-05-01","2026-06-01").mapIndexed { i,date -> GoalIncomeRow("i$i",date,"100.00",null) }
        val result = IncomeGoalMeasurementProvider.measureTransactions(aggregate.metrics.single(), aggregate, Instant.parse("2026-07-18T00:00:00Z"), rows)
        assertEquals("100.00", result.measuredDecimal)
    }
    @Test fun debtProviderUsesDomainRows() {
        val aggregate = DebtPayoffGoalTemplate.build(DebtPayoffTemplateRequest(id="debt", baselineDebtDecimal="500.00", startDate="2026-01-01", deadline="2026-12-31", timezoneId="UTC", now=1L))
        val account = GoalDebtAccountRow("d1", DebtDirection.Payable.dbValue, true, 1L, null)
        val rows = listOf(GoalDebtTransactionRow("d1", DebtTransactionType.Opening.dbValue, "500.00", 1L, null), GoalDebtTransactionRow("d1", DebtTransactionType.Payment.dbValue, "125.00", 2L, null))
        val result = DebtPayoffMeasurementProvider.measureDebt(aggregate.metrics.single(), aggregate, listOf(account), rows)
        assertEquals("375.00", result.measuredDecimal)
    }
}

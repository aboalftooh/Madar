package com.shift.app.goals

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalFinancialChangeContractTest {
    @Test
    fun `financial source repositories publish durable invalidation events`() {
        val files = listOf(
            "TransactionRepository.kt" to "sourceType = \"transactions\"",
            "FinancialLedgerRepository.kt" to "sourceType = \"payments\"",
            "AssetRepository.kt" to "sourceType = \"assets\"",
            "DebtLedgerRepository.kt" to "sourceType = \"debts\"",
        )
        files.forEach { (name, marker) ->
            assertTrue(source("app/src/main/java/com/shift/app/data/repository/$name").contains(marker))
        }
    }

    @Test
    fun `expense UI requires an explicit allocation decision above available`() {
        val viewModel = source("app/src/main/java/com/shift/app/viewmodel/TransactionsViewModel.kt")
        val sheet = source("app/src/main/java/com/shift/app/ui/components/AddTransactionSheet.kt")

        assertTrue(viewModel.contains("impact.requiresAllocationDecision"))
        assertTrue(viewModel.contains("confirmExpenseAllocationDecision"))
        assertTrue(viewModel.contains("cancelExpenseAllocationDecision"))
        assertTrue(sheet.contains("المصروف يتجاوز الرصيد المتاح"))
        assertTrue(sheet.contains("تسجيل دون تحرير"))
    }

    private fun source(path: String): String =
        sequenceOf(File("../$path"), File(path)).first(File::isFile).readText()
}

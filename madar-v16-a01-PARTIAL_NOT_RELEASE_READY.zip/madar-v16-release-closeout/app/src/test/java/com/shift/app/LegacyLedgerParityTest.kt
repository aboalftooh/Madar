package com.shift.app

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.FinancialReportCalculator
import com.shift.app.domain.finance.PaymentKind
import java.math.BigDecimal
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class LegacyLedgerParityTest {
    @Test
    fun linkedRowsUseCanonicalLedgerAmountsInsteadOfLegacyDoubleProjection() {
        val income = Transaction(
            id = "income-1",
            type = "income",
            amount = 999999.99,
            category = "salary",
            date = "2026-07-01",
            operationId = "income-op",
            balanceTransactionId = "income-balance",
        )
        val expense = Transaction(
            id = "expense-1",
            type = "expense",
            amount = 888888.88,
            category = "food",
            date = "2026-07-02",
            operationId = "expense-op",
            balanceTransactionId = "expense-balance",
        )
        val balances = listOf(
            BalanceTransaction(
                id = "income-balance",
                operationId = "income-op",
                direction = BalanceDirection.Inflow.dbValue,
                kind = BalanceTransactionKind.Income.dbValue,
                amountDecimal = "100.10",
                date = income.date,
                sourceType = "transaction",
                sourceId = income.id,
                legacyTransactionId = income.id,
            ),
            BalanceTransaction(
                id = "expense-balance",
                operationId = "expense-op",
                direction = BalanceDirection.Outflow.dbValue,
                kind = BalanceTransactionKind.ExpensePayment.dbValue,
                amountDecimal = "40.05",
                date = expense.date,
                sourceType = "transaction",
                sourceId = expense.id,
                legacyTransactionId = expense.id,
            ),
        )
        val payments = listOf(
            Payment(
                id = "expense-payment",
                operationId = "expense-op",
                kind = PaymentKind.OrdinaryExpense.dbValue,
                amountDecimal = "40.05",
                date = expense.date,
                balanceTransactionId = "expense-balance",
                legacyTransactionId = expense.id,
            ),
        )

        val report = FinancialReportCalculator.period(
            transactions = listOf(income, expense),
            balanceTransactions = balances,
            payments = payments,
            from = LocalDate.parse("2026-07-01"),
            to = LocalDate.parse("2026-07-31"),
        )

        assertEquals(BigDecimal("100.10"), report.income)
        assertEquals(BigDecimal("40.05"), report.payments)
        assertEquals(BigDecimal("40.05"), report.actualExpenses)
    }

    @Test
    fun unlinkedLegacyRowsRemainVisibleUntilCutover() {
        val income = Transaction(
            id = "legacy-income",
            type = "income",
            amount = 25.5,
            category = "legacy",
            date = "2026-07-01",
        )
        val expense = Transaction(
            id = "legacy-expense",
            type = "expense",
            amount = 10.25,
            category = "legacy",
            date = "2026-07-02",
        )

        val report = FinancialReportCalculator.period(
            transactions = listOf(income, expense),
            balanceTransactions = emptyList(),
            payments = emptyList(),
            from = LocalDate.parse("2026-07-01"),
            to = LocalDate.parse("2026-07-31"),
        )

        assertEquals(BigDecimal("25.50"), report.income)
        assertEquals(BigDecimal("10.25"), report.actualExpenses)
    }
}

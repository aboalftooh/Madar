package com.shift.app.architecture

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiPackageByFeatureArchitectureTest {
    private val root = sequenceOf(
        File("app/src/main/java/com/shift/app"),
        File("../app/src/main/java/com/shift/app"),
    ).first(File::isDirectory)

    @Test
    fun `central app module is removed and responsibilities are split`() {
        assertFalse(File(root, "di/AppModule.kt").exists())
        listOf(
            "di/DatabaseModule.kt",
            "di/NetworkModule.kt",
            "di/PreferencesModule.kt",
            "feature/ledger/di/LedgerDataModule.kt",
            "feature/assets/di/AssetDataModule.kt",
            "feature/debts/di/DebtDataModule.kt",
            "feature/goals/di/GoalFeatureModule.kt",
            "sync/di/SyncInfrastructureModule.kt",
        ).forEach { relative ->
            assertTrue("Missing DI owner: $relative", File(root, relative).isFile)
        }
    }

    @Test
    fun `database module owns construction but no feature DAOs`() {
        val database = source("di/DatabaseModule.kt")
        assertTrue(database.contains("Room.databaseBuilder"))
        assertTrue(database.contains("MIGRATION_17_18"))
        assertTrue(database.contains("SyncOutboxSchema.callback"))
        assertFalse(database.contains("TransactionDao"))
        assertFalse(database.contains("AssetDao"))
        assertFalse(database.contains("DebtAccountDao"))
        assertFalse(database.contains("FinancialGoalDao"))
    }

    @Test
    fun `dao providers are owned by responsible feature modules`() {
        val ledger = source("feature/ledger/di/LedgerDataModule.kt")
        val assets = source("feature/assets/di/AssetDataModule.kt")
        val debts = source("feature/debts/di/DebtDataModule.kt")
        val goals = source("feature/goals/di/GoalFeatureModule.kt")
        val sync = source("sync/di/SyncInfrastructureModule.kt")

        listOf("TransactionDao", "BalanceTransactionDao", "PaymentDao").forEach { assertTrue(ledger.contains(it)) }
        listOf("AssetDao", "AssetTransactionDao", "AssetValuationDao").forEach { assertTrue(assets.contains(it)) }
        listOf("DebtDao", "DebtAccountDao", "DebtTransactionDao").forEach { assertTrue(debts.contains(it)) }
        listOf("FinancialGoalDao", "GoalMetricDao", "GoalEvaluationDao").forEach { assertTrue(goals.contains(it)) }
        assertTrue(sync.contains("SyncOutboxDao"))
        assertTrue(sync.contains("SyncQueueGateway"))
    }

    @Test
    fun `provider function names are unique across DI modules`() {
        val providerPattern = Regex("fun\\s+(provide[A-Za-z0-9_]+)\\s*\\(")
        val providers = root.walkTopDown()
            .filter { it.isFile && it.extension == "kt" && it.path.contains("/di/") }
            .flatMap { file -> providerPattern.findAll(file.readText()).map { it.groupValues[1] } }
            .toList()
        assertEquals(providers.toSet().size, providers.size)
    }

    @Test
    fun `auth and session presentation live inside their features`() {
        assertFalse(File(root, "ui/auth").exists())
        assertFalse(File(root, "viewmodel/AppSessionViewModel.kt").exists())
        listOf(
            "feature/auth/presentation/AuthViewModel.kt",
            "feature/auth/presentation/LoginScreen.kt",
            "feature/auth/presentation/RegisterScreen.kt",
            "feature/auth/presentation/ResetPasswordScreen.kt",
            "feature/session/presentation/AppSessionViewModel.kt",
        ).forEach { relative -> assertTrue("Missing feature presentation: $relative", File(root, relative).isFile) }
    }

    @Test
    fun `navigation and app shell import feature entry points`() {
        val nav = source("navigation/NavGraph.kt")
        val main = source("ui/screens/MainScreen.kt")
        val settings = source("ui/screens/SettingsScreen.kt")
        assertTrue(nav.contains("com.shift.app.feature.auth.presentation"))
        assertFalse(nav.contains("com.shift.app.ui.auth"))
        assertTrue(main.contains("com.shift.app.feature.session.presentation.AppSessionViewModel"))
        assertTrue(settings.contains("com.shift.app.feature.session.presentation.AppSessionViewModel"))
    }

    @Test
    fun `moved presentation keeps data implementations behind contracts`() {
        val auth = source("feature/auth/presentation/AuthViewModel.kt")
        val session = source("feature/session/presentation/AppSessionViewModel.kt")
        listOf("com.shift.app.data.", "MadarDatabase", "PreferencesManager", "SyncManager", "WorkManager").forEach {
            assertFalse("Auth presentation contains $it", auth.contains(it))
            assertFalse("Session presentation contains $it", session.contains(it))
        }
        assertTrue(auth.contains("AuthGateway"))
        assertTrue(session.contains("AppSessionGateway"))
    }

    private fun source(relativePath: String): String = File(root, relativePath).readText()
}

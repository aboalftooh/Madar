package com.shift.app

import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.repository.IncomeLedgerFactory
import com.shift.app.domain.finance.BalanceTransactionKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class IncomeLedgerFactoryTest {
    @Test
    fun newIncome_usesOneOperationAndStableCrossLinks() {
        val records = IncomeLedgerFactory.create(
            transaction = income(amount = 125.555),
            operationId = "income-op",
            balanceTransactionId = "balance-row"
        )
        val balance = requireNotNull(records.balanceTransaction)

        assertEquals("income-op", records.transaction.operationId)
        assertEquals("balance-row", records.transaction.balanceTransactionId)
        assertEquals("income-op", balance.operationId)
        assertEquals(records.transaction.id, balance.sourceId)
        assertEquals("transaction", balance.sourceType)
        assertEquals(BalanceTransactionKind.Income.dbValue, balance.kind)
        assertEquals("125.56", balance.amountDecimal)
    }

    @Test
    fun nonIncomeOrNonPositiveAmount_isRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            IncomeLedgerFactory.create(income(amount = 0.0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            IncomeLedgerFactory.create(income(amount = 10.0).copy(type = "expense"))
        }
    }

    private fun income(amount: Double) = Transaction(
        id = "income-row",
        type = "income",
        amount = amount,
        category = "راتب",
        date = "2026-07-12",
        note = "اختبار",
        updatedAt = 100L
    )
}

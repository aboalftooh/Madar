package com.shift.app.data.migration

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtMigrationReviewDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.local.dao.SyncOutboxDao
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.SyncState
import java.math.BigDecimal
import java.math.RoundingMode
import javax.inject.Inject

data class LegacyDebtMigrationResult(
    val sourceFingerprint: String,
    val migratedAccounts: Int,
    val reviews: Int,
    val skippedExisting: Int,
    val verified: Boolean,
)

data class LegacyDebtMigrationVerification(
    val expectedReceivableDecimal: String,
    val actualReceivableDecimal: String,
    val expectedPayableDecimal: String,
    val actualPayableDecimal: String,
    val expectedReviews: Int,
    val actualReviews: Int,
) {
    val exact: Boolean =
        expectedReceivableDecimal == actualReceivableDecimal &&
            expectedPayableDecimal == actualPayableDecimal &&
            expectedReviews == actualReviews

    fun requireExact() {
        require(exact) {
            "Legacy debt migration parity mismatch: " +
                "receivable=$actualReceivableDecimal/$expectedReceivableDecimal, " +
                "payable=$actualPayableDecimal/$expectedPayableDecimal, " +
                "reviews=$actualReviews/$expectedReviews"
        }
    }
}

data class LegacyDebtRollbackResult(
    val deletedAccounts: Int,
    val deletedTransactions: Int,
    val deletedReviews: Int,
)

class LegacyDebtMigrator @Inject constructor(
    private val db: MadarDatabase,
    private val accountDao: DebtAccountDao,
    private val transactionDao: DebtTransactionDao,
    private val reviewDao: DebtMigrationReviewDao,
    private val outboxDao: SyncOutboxDao,
) {
    suspend fun preview(
        debts: List<Debt>,
        localCurrencyCode: String = "SDG",
    ): LegacyDebtMigrationPreview = LegacyDebtMigrationPlanner.preview(debts, localCurrencyCode)

    suspend fun migrate(
        debts: List<Debt>,
        localCurrencyCode: String = "SDG",
    ): LegacyDebtMigrationResult {
        val preview = preview(debts, localCurrencyCode)
        return migrate(debts, preview.sourceFingerprint, localCurrencyCode)
    }

    suspend fun migrate(
        debts: List<Debt>,
        expectedSourceFingerprint: String,
        localCurrencyCode: String = "SDG",
    ): LegacyDebtMigrationResult {
        val preview = preview(debts, localCurrencyCode)
        require(preview.sourceFingerprint == expectedSourceFingerprint) {
            "Legacy debts changed since preview"
        }
        val counts = db.withTransaction {
            var migrated = 0
            var reviews = 0
            var skipped = 0
            preview.plans.forEach { plan ->
                val legacy = when (plan) {
                    is LegacyDebtMigrationPlan.Opening -> plan.legacyDebt
                    is LegacyDebtMigrationPlan.Review -> plan.legacyDebt
                }
                if (accountDao.getByLegacyDebtId(legacy.id) != null || reviewDao.getByLegacyDebtId(legacy.id) != null) {
                    skipped += 1
                    return@forEach
                }
                when (plan) {
                    is LegacyDebtMigrationPlan.Opening -> {
                        val operationId = "legacy-debt:${legacy.id}"
                        val accountId = "legacy-account:${legacy.id}"
                        val account = DebtAccount(
                            id = accountId,
                            operationId = operationId,
                            direction = plan.direction.dbValue,
                            partyName = legacy.name.trim(),
                            partyKey = legacy.name.trim().lowercase(),
                            currencyCode = preview.currencyCode,
                            description = legacy.note,
                            dueDate = legacy.dueDate.ifBlank { null },
                            confirmed = !plan.archived,
                            archivedAt = if (plan.archived) legacy.updatedAt else null,
                            closedAt = if (plan.archived) legacy.updatedAt else null,
                            closeReason = if (plan.archived) "legacy settled" else null,
                            legacyDebtId = legacy.id,
                            createdAt = legacy.createdAt,
                            updatedAt = legacy.updatedAt,
                        )
                        accountDao.upsert(account)
                        if (!plan.archived) {
                            transactionDao.upsert(
                                DebtTransaction(
                                    id = "legacy-opening:${legacy.id}",
                                    accountId = accountId,
                                    operationId = operationId,
                                    type = DebtTransactionType.Opening.dbValue,
                                    amountDecimal = plan.amountDecimal,
                                    currencyCode = preview.currencyCode,
                                    occurredAt = legacy.createdAt,
                                    note = "Migrated from legacy debts",
                                    sourceType = "legacy_debt",
                                    sourceId = legacy.id,
                                    createdAt = legacy.createdAt,
                                    updatedAt = legacy.updatedAt,
                                ),
                            )
                        }
                        migrated += 1
                    }

                    is LegacyDebtMigrationPlan.Review -> {
                        reviewDao.upsert(
                            DebtMigrationReview(
                                id = "legacy-review:${legacy.id}",
                                legacyDebtId = legacy.id,
                                reason = plan.reason,
                                legacyPayloadJson = LegacyDebtMigrationPlanner.legacyPayload(legacy),
                                createdAt = legacy.createdAt,
                                updatedAt = legacy.updatedAt,
                            ),
                        )
                        reviews += 1
                    }
                }
            }
            Triple(migrated, reviews, skipped)
        }
        val verification = verify(preview)
        verification.requireExact()
        return LegacyDebtMigrationResult(
            sourceFingerprint = preview.sourceFingerprint,
            migratedAccounts = counts.first,
            reviews = counts.second,
            skippedExisting = counts.third,
            verified = verification.exact,
        )
    }

    suspend fun verify(preview: LegacyDebtMigrationPreview): LegacyDebtMigrationVerification {
        val accounts = accountDao.getLegacyMigrationAccounts()
        val openingRows = transactionDao.getLegacyMigrationTransactions()
        val reviews = reviewDao.getAllOnce()
        val openingByAccount = openingRows.groupBy { it.accountId }
        var receivable = BigDecimal.ZERO
        var payable = BigDecimal.ZERO
        accounts.asSequence()
            .filter { it.deletedAt == null && it.confirmed }
            .forEach { account ->
                val remaining = openingByAccount[account.id].orEmpty().asSequence()
                    .filter { it.deletedAt == null }
                    .fold(BigDecimal.ZERO) { total, row ->
                        total.add(DecimalText.toBigDecimal(row.amountDecimal))
                    }
                when (account.direction) {
                    DebtDirection.Receivable.dbValue -> receivable = receivable.add(remaining)
                    DebtDirection.Payable.dbValue -> payable = payable.add(remaining)
                }
            }
        return LegacyDebtMigrationVerification(
            expectedReceivableDecimal = preview.receivableDecimal,
            actualReceivableDecimal = receivable.moneyText(),
            expectedPayableDecimal = preview.payableDecimal,
            actualPayableDecimal = payable.moneyText(),
            expectedReviews = preview.reviewCount,
            actualReviews = reviews.count { it.deletedAt == null },
        )
    }

    /**
     * Rollback is deliberately restricted to rows that never left the local pending state.
     * Legacy source rows are never deleted, so a safe retry can rebuild the same deterministic ids.
     */
    suspend fun rollbackPending(
        debts: List<Debt>,
        expectedSourceFingerprint: String,
        localCurrencyCode: String = "SDG",
    ): LegacyDebtRollbackResult {
        val preview = preview(debts, localCurrencyCode)
        require(preview.sourceFingerprint == expectedSourceFingerprint) {
            "Legacy debts changed since preview"
        }
        return db.withTransaction {
            val accounts = accountDao.getLegacyMigrationAccounts()
            val transactions = transactionDao.getLegacyMigrationTransactions()
            val reviews = reviewDao.getAllOnce()
            val allPending = accounts.all { it.syncState == SyncState.Pending.dbValue } &&
                transactions.all { it.syncState == SyncState.Pending.dbValue } &&
                reviews.all { it.syncState == SyncState.Pending.dbValue }
            require(allPending) { "Cannot rollback legacy debt rows that were already synchronized" }

            transactions.forEach { row ->
                transactionDao.hardDeleteById(row.id)
                outboxDao.deleteForEntity("debt_transactions", row.id)
                outboxDao.deleteForOperation(row.operationId)
            }
            accounts.forEach { account ->
                accountDao.hardDeleteById(account.id)
                outboxDao.deleteForEntity("debt_accounts", account.id)
                outboxDao.deleteForOperation(account.operationId)
            }
            reviews.forEach { review ->
                reviewDao.hardDeleteById(review.id)
                outboxDao.deleteForEntity("debt_migration_reviews", review.id)
            }
            LegacyDebtRollbackResult(
                deletedAccounts = accounts.size,
                deletedTransactions = transactions.size,
                deletedReviews = reviews.size,
            )
        }
    }

    private fun BigDecimal.moneyText(): String =
        setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()
}

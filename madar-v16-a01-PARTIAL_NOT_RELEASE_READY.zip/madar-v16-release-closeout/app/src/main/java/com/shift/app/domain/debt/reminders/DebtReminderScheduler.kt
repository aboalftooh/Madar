package com.shift.app.domain.debt.reminders

import java.time.LocalDate
import java.time.ZoneId

data class DebtReminderAccount(
    val id: String,
    val partyName: String,
    val dueDate: String?,
    val confirmed: Boolean = true,
    val archivedAt: Long? = null,
    val closedAt: Long? = null,
    val deletedAt: Long? = null
)

data class DebtReminderSchedule(
    val id: String,
    val accountId: String,
    val installmentNo: Int,
    val dueDate: String,
    val amountDecimal: String,
    val status: String = "planned",
    val reminderBeforeDue: Boolean = true,
    val reminderOnDue: Boolean = true,
    val deletedAt: Long? = null
)

enum class DebtReminderEvent {
    AccountBeforeDue,
    AccountDueToday,
    ScheduleBeforeDue,
    ScheduleDueToday,
    ScheduleMissed,
    WeeklySummary
}

data class DebtReminderWork(
    val key: String,
    val event: DebtReminderEvent,
    val fireDate: String,
    val accountId: String? = null,
    val scheduleId: String? = null,
    val titleRef: String,
    val amountDecimal: String? = null
)

data class DebtReminderSnapshot(
    val accounts: List<DebtReminderAccount>,
    val schedules: List<DebtReminderSchedule>
)

class DebtReminderScheduler(
    private val zoneId: ZoneId = ZoneId.of("Africa/Khartoum")
) {
    fun today(clockMillis: Long): String =
        java.time.Instant.ofEpochMilli(clockMillis).atZone(zoneId).toLocalDate().toString()

    fun plannedWork(snapshot: DebtReminderSnapshot, today: String): List<DebtReminderWork> {
        val currentDate = LocalDate.parse(today)
        val activeAccounts = snapshot.accounts.filter { it.isReminderEligible() }.associateBy { it.id }
        val accountWork = activeAccounts.values.flatMap { account ->
            account.dueDate?.let { dueDate ->
                listOf(
                    DebtReminderWork(
                        key = "debt:account:${account.id}:before:$dueDate",
                        event = DebtReminderEvent.AccountBeforeDue,
                        fireDate = LocalDate.parse(dueDate).minusDays(1).toString(),
                        accountId = account.id,
                        titleRef = account.partyName
                    ),
                    DebtReminderWork(
                        key = "debt:account:${account.id}:due:$dueDate",
                        event = DebtReminderEvent.AccountDueToday,
                        fireDate = dueDate,
                        accountId = account.id,
                        titleRef = account.partyName
                    )
                )
            } ?: emptyList()
        }
        val scheduleWork = snapshot.schedules.flatMap { schedule ->
            val account = activeAccounts[schedule.accountId] ?: return@flatMap emptyList()
            if (!schedule.isReminderEligible()) return@flatMap emptyList()
            val dueDate = LocalDate.parse(schedule.dueDate)
            buildList {
                if (schedule.reminderBeforeDue) {
                    add(
                        DebtReminderWork(
                            key = "debt:schedule:${schedule.id}:before:${schedule.dueDate}",
                            event = DebtReminderEvent.ScheduleBeforeDue,
                            fireDate = dueDate.minusDays(1).toString(),
                            accountId = schedule.accountId,
                            scheduleId = schedule.id,
                            titleRef = account.partyName,
                            amountDecimal = schedule.amountDecimal
                        )
                    )
                }
                if (schedule.reminderOnDue) {
                    add(
                        DebtReminderWork(
                            key = "debt:schedule:${schedule.id}:due:${schedule.dueDate}",
                            event = DebtReminderEvent.ScheduleDueToday,
                            fireDate = schedule.dueDate,
                            accountId = schedule.accountId,
                            scheduleId = schedule.id,
                            titleRef = account.partyName,
                            amountDecimal = schedule.amountDecimal
                        )
                    )
                }
                if (dueDate < currentDate) {
                    add(
                        DebtReminderWork(
                            key = "debt:schedule:${schedule.id}:missed:${schedule.dueDate}",
                            event = DebtReminderEvent.ScheduleMissed,
                            fireDate = today,
                            accountId = schedule.accountId,
                            scheduleId = schedule.id,
                            titleRef = account.partyName,
                            amountDecimal = schedule.amountDecimal
                        )
                    )
                }
            }
        }
        val weeklySummary = if (snapshot.schedules.any { it.status == "planned" && it.deletedAt == null }) {
            listOf(
                DebtReminderWork(
                    key = "debt:weekly:$today",
                    event = DebtReminderEvent.WeeklySummary,
                    fireDate = today,
                    titleRef = "weekly"
                )
            )
        } else {
            emptyList()
        }
        return (accountWork + scheduleWork + weeklySummary)
            .filter { LocalDate.parse(it.fireDate) >= currentDate }
            .distinctBy { it.key }
            .sortedWith(compareBy<DebtReminderWork> { it.fireDate }.thenBy { it.key })
    }

    fun cancellationKeys(snapshot: DebtReminderSnapshot): Set<String> =
        plannedWork(snapshot, LocalDate.MIN.plusYears(1).toString()).mapTo(mutableSetOf()) { it.key }

    private fun DebtReminderAccount.isReminderEligible(): Boolean =
        confirmed && archivedAt == null && closedAt == null && deletedAt == null

    private fun DebtReminderSchedule.isReminderEligible(): Boolean =
        status == "planned" && deletedAt == null
}

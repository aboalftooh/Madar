package com.shift.app.domain.debt

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.BalanceCalculator
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

data class DebtWealthSnapshot(
    val balanceDecimal: BigDecimal,
    val assetsValueDecimal: BigDecimal,
    val receivablesDecimal: BigDecimal,
    val payablesDecimal: BigDecimal
) {
    val totalAssetsDecimal: BigDecimal get() = balanceDecimal.add(assetsValueDecimal).add(receivablesDecimal).setScale(2, RoundingMode.HALF_UP)
    val netWorthDecimal: BigDecimal get() = balanceDecimal.add(assetsValueDecimal).add(receivablesDecimal).subtract(payablesDecimal).setScale(2, RoundingMode.HALF_UP)
}

data class DebtPeriodReport(
    val openedPrincipalDecimal: BigDecimal,
    val reducedPrincipalDecimal: BigDecimal,
    val waivedOrWrittenOffDecimal: BigDecimal,
    val earnedIncomeDecimal: BigDecimal,
    val collectedIncomeDecimal: BigDecimal
)

object DebtReportCalculator {
    fun wealth(
        balanceTransactions: List<BalanceTransaction>,
        assets: List<Asset>,
        valuations: List<AssetValuation>,
        accounts: List<DebtAccount>,
        transactions: List<DebtTransaction>
    ): DebtWealthSnapshot {
        val balance = BalanceCalculator.currentBalance(balanceTransactions).money()
        val assetValue = activeAssetsValue(assets, valuations)
        val remainingByAccount = accounts.associate { account ->
            account.id to remainingFor(account.id, transactions)
        }
        val receivables = accounts.asSequence()
            .filter { it.deletedAt == null && it.confirmed && it.direction == DebtDirection.Receivable.dbValue }
            .sumMoney { remainingByAccount[it.id] ?: BigDecimal.ZERO }
        val payables = accounts.asSequence()
            .filter { it.deletedAt == null && it.confirmed && it.direction == DebtDirection.Payable.dbValue }
            .sumMoney { remainingByAccount[it.id] ?: BigDecimal.ZERO }
        return DebtWealthSnapshot(balance, assetValue, receivables, payables)
    }

    fun period(
        debtTransactions: List<DebtTransaction>,
        legacyIncomeTransactions: List<Transaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate
    ): DebtPeriodReport {
        val visibleDebt = debtTransactions.filter { it.deletedAt == null && it.occurredAtDate().inRange(from, to) }
        val opened = visibleDebt.asSequence()
            .filter { it.type in setOf(DebtTransactionType.Opening.dbValue, DebtTransactionType.Increase.dbValue) }
            .sumMoney { it.amount() }
        val reduced = visibleDebt.asSequence()
            .filter { DebtTransactionType.fromDb(it.type).remainingSign < 0 }
            .sumMoney { it.amount() }
        val wealthChange = visibleDebt.asSequence()
            .filter { it.type in setOf(DebtTransactionType.Waiver.dbValue, DebtTransactionType.WriteOff.dbValue) }
            .sumMoney { it.amount() }
        val earnedIncome = legacyIncomeTransactions.asSequence()
            .filter { it.deletedAt == null && it.type == "income" && it.date.inRange(from, to) }
            .sumMoney { BigDecimal.valueOf(it.amount) }
        val collectedIncome = payments.asSequence()
            .filter { it.deletedAt == null && it.balanceTransactionId != null && it.date.inRange(from, to) }
            .sumMoney { it.amount() }
        return DebtPeriodReport(opened, reduced, wealthChange, earnedIncome, collectedIncome)
    }

    private fun activeAssetsValue(assets: List<Asset>, valuations: List<AssetValuation>): BigDecimal =
        assets.asSequence()
            .filter { it.deletedAt == null && it.status == AssetStatus.Active.dbValue }
            .sumMoney { asset ->
                latestValuation(asset.id, valuations)
                    ?: decimal(asset.currentValueCacheDecimal)
                    ?: decimal(asset.acquisitionAmountDecimal)
                    ?: BigDecimal.ZERO
            }

    private fun remainingFor(accountId: String, transactions: List<DebtTransaction>): BigDecimal =
        transactions.asSequence()
            .filter { it.accountId == accountId && it.deletedAt == null }
            .fold(BigDecimal.ZERO) { total, tx ->
                val type = DebtTransactionType.fromDb(tx.type)
                total.add(tx.amount().multiply(BigDecimal(type.remainingSign)))
            }
            .max(BigDecimal.ZERO)
            .money()

    private fun latestValuation(assetId: String, valuations: List<AssetValuation>): BigDecimal? =
        valuations.asSequence()
            .filter { it.assetId == assetId && it.deletedAt == null }
            .maxWithOrNull(compareBy<AssetValuation> { it.date }.thenBy { it.createdAt }.thenBy { it.id })
            ?.let { decimal(it.valueDecimal) }

    private fun DebtTransaction.amount(): BigDecimal = decimal(amountDecimal) ?: BigDecimal.ZERO
    private fun Payment.amount(): BigDecimal = decimal(amountDecimal) ?: BigDecimal.ZERO
    private fun DebtTransaction.occurredAtDate(): LocalDate = java.time.Instant.ofEpochMilli(occurredAt).atZone(java.time.ZoneOffset.UTC).toLocalDate()
    private fun String.inRange(from: LocalDate, to: LocalDate): Boolean =
        runCatching { LocalDate.parse(this) }.getOrNull()?.let { !it.isBefore(from) && !it.isAfter(to) } == true

    private fun LocalDate.inRange(from: LocalDate, to: LocalDate): Boolean = !isBefore(from) && !isAfter(to)

    private fun decimal(text: String?): BigDecimal? =
        text?.let { runCatching { DecimalText.toBigDecimal(it).money() }.getOrNull() }

    private inline fun <T> Sequence<T>.sumMoney(value: (T) -> BigDecimal): BigDecimal =
        fold(BigDecimal.ZERO) { total, item -> total.add(value(item)) }.money()

    private fun BigDecimal.money(): BigDecimal = setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP)
}

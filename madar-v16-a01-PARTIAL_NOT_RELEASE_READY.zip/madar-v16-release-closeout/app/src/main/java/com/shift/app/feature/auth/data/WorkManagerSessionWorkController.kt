package com.shift.app.feature.auth.data

import android.content.Context
import androidx.work.WorkManager
import com.shift.app.feature.auth.domain.SessionWorkController
import com.shift.app.sync.outbox.SyncWorkScheduler
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class WorkManagerSessionWorkController @Inject constructor(
    @ApplicationContext context: Context,
) : SessionWorkController {
    private val workManager = WorkManager.getInstance(context)

    override suspend fun cancelAndAwaitSessionWork() = withContext(Dispatchers.IO) {
        workManager.cancelUniqueWork(SyncWorkScheduler.UNIQUE_IMMEDIATE_WORK).result.get()
        workManager.cancelUniqueWork(SyncWorkScheduler.UNIQUE_PERIODIC_WORK).result.get()
    }
}

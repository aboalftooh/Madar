package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "ledger_history_migrations",
    indices = [
        Index(value = ["status", "deletedAt"]),
        Index(value = ["updatedAt"])
    ]
)
data class LedgerHistoryMigration(
    @PrimaryKey val migrationKey: String,
    val plannerVersion: Int,
    val status: String,
    val sourceFingerprint: String,
    val commitFingerprint: String,
    val candidateCount: Int,
    val incomeCount: Int,
    val expenseCount: Int,
    val historicalIncomeDecimal: String,
    val historicalExpenseDecimal: String,
    val targetBalanceDecimal: String,
    val adjustmentDecimal: String,
    val adjustmentBalanceTransactionId: String? = null,
    val confirmedAt: Long,
    val completedAt: Long? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

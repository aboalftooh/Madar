package com.shift.app.feature.session.presentation

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.feature.session.domain.AppSessionGateway
import com.shift.app.feature.session.domain.AppSessionSyncResult
import com.shift.app.feature.session.domain.AppSessionSyncStatus
import com.shift.app.utils.ErrorMessages
import dagger.hilt.android.lifecycle.HiltViewModel
import io.sentry.Sentry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SyncState {
    object Idle : SyncState()
    object Loading : SyncState()
    object Success : SyncState()
    data class Error(val message: String) : SyncState()
}

@HiltViewModel
class AppSessionViewModel @Inject constructor(
    private val sessionGateway: AppSessionGateway,
) : ViewModel() {
    val lastSync = sessionGateway.lastSync
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val pendingSyncCount = sessionGateway.pendingSyncCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val failedSyncCount = sessionGateway.failedSyncCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState = _syncState.asStateFlow()

    fun initialSync() = runSync("Initial sync") { sessionGateway.initialSync() }

    fun syncNow() = runSync("Manual sync") { sessionGateway.syncNow() }

    private fun runSync(
        operationName: String,
        operation: suspend () -> AppSessionSyncResult?,
    ) {
        viewModelScope.launch {
            _syncState.value = SyncState.Loading
            try {
                val result = operation()
                _syncState.value = when (result?.status) {
                    null, AppSessionSyncStatus.AUTHENTICATION_REQUIRED -> SyncState.Idle
                    AppSessionSyncStatus.SUCCESS -> SyncState.Success
                    AppSessionSyncStatus.PARTIAL_FAILURE -> {
                        Log.e("AppSessionViewModel", "$operationName partial failure: ${result.failedSteps}")
                        SyncState.Error("تعذرت مزامنة بعض البيانات. أعد المحاولة.")
                    }
                }
            } catch (error: Exception) {
                Log.e("AppSessionViewModel", "$operationName failed", error)
                Sentry.captureException(error)
                _syncState.value = SyncState.Error(ErrorMessages.userMessage(error))
            }
        }
    }
}

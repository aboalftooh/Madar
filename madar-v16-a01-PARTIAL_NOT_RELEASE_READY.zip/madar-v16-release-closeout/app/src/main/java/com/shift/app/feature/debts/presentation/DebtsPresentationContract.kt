package com.shift.app.feature.debts.presentation

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType

sealed interface DebtsUiEvent {
    data class TabSelected(val tab: DebtCenterTab) : DebtsUiEvent
    data class SearchChanged(val query: String) : DebtsUiEvent
    data object ErrorDismissed : DebtsUiEvent

    data class CreateOpening(
        val direction: DebtDirection,
        val partyName: String,
        val amountDecimal: String,
        val dueDate: String?,
        val includeInActivePayoffGoal: Boolean,
    ) : DebtsUiEvent

    data class RecordCashPrincipal(
        val accountId: String?,
        val direction: DebtDirection,
        val partyName: String,
        val amountDecimal: String,
        val cashSource: DebtCashSource,
    ) : DebtsUiEvent

    data class RecordDeferredExpense(
        val partyName: String,
        val amountDecimal: String,
        val purpose: String,
        val note: String = "",
    ) : DebtsUiEvent

    data class RecordAccruedIncome(
        val partyName: String,
        val amountDecimal: String,
        val incomeCategory: String,
        val note: String = "",
    ) : DebtsUiEvent

    data class RecordFinancedAssetPurchase(
        val partyName: String,
        val assetType: String,
        val assetName: String,
        val financedAmountDecimal: String,
        val assetValueDecimal: String,
        val cashPaidDecimal: String,
    ) : DebtsUiEvent

    data class RecordAssetSaleOnCredit(
        val assetId: String,
        val buyerName: String,
        val saleAmountDecimal: String,
        val cashCollectedDecimal: String,
    ) : DebtsUiEvent

    data class Reduce(
        val accountId: String,
        val amountDecimal: String,
        val cashSource: DebtCashSource,
    ) : DebtsUiEvent

    data class RecordAdjustment(
        val accountId: String,
        val type: DebtTransactionType,
        val amountDecimal: String,
        val reason: String,
    ) : DebtsUiEvent

    data class RecordAssetSettlement(
        val accountId: String,
        val assetId: String,
        val amountDecimal: String,
        val assetValueDecimal: String,
        val reason: String,
    ) : DebtsUiEvent

    data class RecordOffset(
        val payableAccountId: String,
        val receivableAccountId: String,
        val amountDecimal: String,
        val reason: String,
    ) : DebtsUiEvent

    data class ReverseTransaction(
        val originalTransactionId: String,
        val reason: String,
    ) : DebtsUiEvent

    data class TransferToNewParty(
        val accountId: String,
        val newPartyName: String,
        val amountDecimal: String,
        val reason: String,
    ) : DebtsUiEvent

    data class WriteSchedule(
        val accountId: String,
        val totalAmountDecimal: String,
        val firstDueDate: String,
        val count: Int,
    ) : DebtsUiEvent

    data class ArchiveAccount(
        val accountId: String,
        val reason: String,
    ) : DebtsUiEvent
}

package com.shift.app.data.local.dao

import androidx.room.*
import com.shift.app.data.local.entities.AssetTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetTransactionDao {
    @Query("SELECT * FROM asset_transactions WHERE deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getAll(): Flow<List<AssetTransaction>>

    @Query("SELECT * FROM asset_transactions WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getByAssetId(assetId: String): Flow<List<AssetTransaction>>

    @Query("SELECT * FROM asset_transactions WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    suspend fun getActiveByAssetIdOnce(assetId: String): List<AssetTransaction>

    @Query("SELECT * FROM asset_transactions")
    suspend fun getAllOnce(): List<AssetTransaction>

    @Query("SELECT * FROM asset_transactions WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<AssetTransaction>

    @Query("SELECT * FROM asset_transactions WHERE operationId = :operationId AND deletedAt IS NULL")
    suspend fun getActiveByOperationId(operationId: String): List<AssetTransaction>

    @Query("SELECT * FROM asset_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AssetTransaction?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: AssetTransaction)

    @Update
    suspend fun update(item: AssetTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AssetTransaction>)

    @Query("DELETE FROM asset_transactions")
    suspend fun deleteAll()
}

package com.shift.app.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(tableName = "income_sources")
data class IncomeSource(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val paymentMethod: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null,
    @ColumnInfo(defaultValue = "'pending'")
    val syncState: String = SyncState.Pending.dbValue
)

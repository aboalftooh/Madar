package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getAll(): Flow<List<Payment>>

    @Query("SELECT * FROM payments ORDER BY date DESC, createdAt DESC")
    fun getAllIncludingDeleted(): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE deletedAt IS NULL AND kind IN ('ordinary_expense', 'asset_maintenance') ORDER BY date DESC, createdAt DESC")
    fun getExpenseReportable(): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE deletedAt IS NULL AND operationId = :operationId")
    suspend fun getActiveByOperationId(operationId: String): List<Payment>

    @Query("SELECT * FROM payments WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<Payment>

    @Query("SELECT * FROM payments")
    suspend fun getAllOnce(): List<Payment>

    @Query("SELECT * FROM payments WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Payment?

    @Query("SELECT * FROM payments WHERE legacyTransactionId = :legacyTransactionId LIMIT 1")
    suspend fun getByLegacyTransactionId(legacyTransactionId: String): Payment?

    @Query("SELECT legacyTransactionId FROM payments WHERE legacyTransactionId IS NOT NULL")
    fun getAllLegacyTransactionIds(): Flow<List<String>>

    @Query("SELECT * FROM payments WHERE legacyTransactionId IS NOT NULL ORDER BY id ASC")
    suspend fun getLegacyMigrationRows(): List<Payment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: Payment)

    @Update
    suspend fun update(item: Payment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<Payment>)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun hardDeleteById(id: String)

    @Query("DELETE FROM payments")
    suspend fun deleteAll()
}

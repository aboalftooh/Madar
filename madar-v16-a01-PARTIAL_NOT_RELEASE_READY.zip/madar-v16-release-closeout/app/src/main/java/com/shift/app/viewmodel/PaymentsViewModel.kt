package com.shift.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.PaymentRequest
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.utils.ExpenseTextNormalizer
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PaymentActionState(
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

@HiltViewModel
class PaymentsViewModel @Inject constructor(
    private val ledgerRepo: FinancialLedgerRepository,
    private val transactionRepo: TransactionRepository,
    private val sync: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : ViewModel() {
    val payments: StateFlow<List<Payment>> = ledgerRepo.payments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _actionState = MutableStateFlow(PaymentActionState())
    val actionState: StateFlow<PaymentActionState> = _actionState

    fun clearActionMessage() = _actionState.update { PaymentActionState(busy = it.busy) }

    fun addPayment(
        kind: PaymentKind,
        amountInput: String,
        purpose: String,
        note: String,
        date: String = LocalDate.now().toString()
    ) = runAction("تمت إضافة المدفوعة") {
            val request = PaymentRequest(
                operationId = UUID.randomUUID().toString(),
                kind = kind,
                amountDecimal = DecimalText.canonicalPositive(amountInput, DecimalTextScale.Money),
                date = date,
                purpose = purpose,
                note = note
            )
            ledgerRepo.recordPayment(request)
            syncQueue.requestSync("payment", request.operationId)
    }

    fun replacePayment(
        original: Payment,
        kind: PaymentKind,
        amountInput: String,
        purpose: String,
        note: String,
        date: String
    ) = runAction("تم تعديل المدفوعة") {
            val canonicalAmount = DecimalText.canonicalPositive(amountInput, DecimalTextScale.Money)
            val legacyId = original.legacyTransactionId
            if (legacyId != null) {
                require(kind == PaymentKind.OrdinaryExpense) { "لا يمكن تغيير نوع المصروف المرحّل" }
                val transaction = requireNotNull(transactionRepo.getById(legacyId)) {
                    "تعذر العثور على سجل المصروف المرحّل"
                }
                val updated = transaction.copy(
                    amount = DecimalText.toBigDecimal(canonicalAmount).toDouble(),
                    category = purpose,
                    date = date,
                    note = note,
                    purpose = purpose,
                    purposeKey = ExpenseTextNormalizer.key(purpose),
                    updatedAt = System.currentTimeMillis(),
                    deletedAt = null
                )
                val records = transactionRepo.updateWithLinkedIncome(updated)
                syncQueue.requestSync(
                    reason = "legacy-expense",
                    operationId = records.transaction.operationId ?: records.transaction.id,
                )
            } else {
                val result = ledgerRepo.replacePayment(
                    operationId = original.operationId,
                    request = PaymentRequest(
                        operationId = UUID.randomUUID().toString(),
                        kind = kind,
                        amountDecimal = canonicalAmount,
                        date = date,
                        purpose = purpose,
                        note = note
                    )
                )
                syncQueue.requestSync(
                    reason = "payment-replacement",
                    operationId = result.replacement.balanceTransaction.operationId,
                )
            }
    }

    fun deletePayment(payment: Payment) = runAction("تم حذف المدفوعة") {
            val legacyId = payment.legacyTransactionId
            if (legacyId != null) {
                val records = transactionRepo.softDeleteWithLinkedIncome(legacyId, System.currentTimeMillis())
                syncQueue.requestSync(
                    reason = "legacy-expense-delete",
                    operationId = records.transaction.operationId ?: records.transaction.id,
                )
            } else {
                ledgerRepo.softDeleteOperation(payment.operationId)
                syncQueue.requestSync("payment-delete", payment.operationId)
            }
    }

    private fun runAction(
        successMessage: String,
        operation: suspend () -> Unit
    ) = viewModelScope.launch {
        if (_actionState.value.busy) return@launch
        _actionState.value = PaymentActionState(busy = true)
        val executed = sync.executeSessionOperation {
            runCatching { operation() }
                .onSuccess {
                    _actionState.value = PaymentActionState(message = successMessage)
                }
                .onFailure { error ->
                    _actionState.value = PaymentActionState(
                        error = error.message ?: "تعذر تنفيذ العملية"
                    )
                }
        }
        if (executed == null) {
            _actionState.value = PaymentActionState(error = "انتهت جلسة الحساب")
        }
    }


}

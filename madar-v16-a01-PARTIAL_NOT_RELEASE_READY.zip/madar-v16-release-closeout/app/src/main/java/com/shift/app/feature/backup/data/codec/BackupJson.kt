package com.shift.app.feature.backup.data.codec

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

internal fun JSONObject.optLongOrNull(name: String): Long? =
    if (has(name) && !isNull(name)) getLong(name) else null

internal fun JSONObject.optStringOrNull(name: String): String? =
    if (has(name) && !isNull(name)) getString(name) else null

internal fun normalizedDateOrToday(raw: String): String =
    runCatching { LocalDate.parse(raw).toString() }.getOrElse { LocalDate.now().toString() }

internal fun normalizedOptionalDate(raw: String): String =
    if (raw.isBlank()) "" else normalizedDateOrToday(raw)

internal inline fun <T> JSONArray?.mapObjects(transform: (JSONObject) -> T): List<T> {
    if (this == null) return emptyList()
    return List(length()) { index -> transform(getJSONObject(index)) }
}

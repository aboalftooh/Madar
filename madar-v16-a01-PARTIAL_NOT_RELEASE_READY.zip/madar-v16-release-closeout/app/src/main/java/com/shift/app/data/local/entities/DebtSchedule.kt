package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "debt_schedules",
    foreignKeys = [
        ForeignKey(
            entity = DebtAccount::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onUpdate = ForeignKey.NO_ACTION,
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["accountId", "dueDate"]),
        Index(value = ["operationId"]),
        Index(value = ["status", "dueDate"]),
        Index(value = ["syncState", "updatedAt"])
    ]
)
data class DebtSchedule(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val accountId: String,
    val installmentNo: Int,
    val dueDate: String,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val status: String = "planned",
    val reminderBeforeDue: Boolean = true,
    val reminderOnDue: Boolean = true,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

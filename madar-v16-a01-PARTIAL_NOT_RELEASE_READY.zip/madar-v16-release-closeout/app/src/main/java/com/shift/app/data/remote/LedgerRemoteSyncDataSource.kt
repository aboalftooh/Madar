package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.LedgerRemoteSync

@Singleton
class LedgerRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
    private val transactionDao: TransactionDao,
    private val balanceTransactionDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val ledgerHistoryMigrationDao: LedgerHistoryMigrationDao,
) : LedgerRemoteSync {
    // ─── Transactions ───────────────────────────────────────────

    override suspend fun pushTransactions(transactions: List<Transaction>) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (transactions.isEmpty()) return@withContext
        context.client.from("transactions").upsert(transactions.map { it.toRemote(uid) })
        transactionDao.upsertAll(transactions.map { it.copy(syncState = SyncState.Synced.dbValue) })
    }

    override suspend fun pullTransactions() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.Transactions.key)
        val remote = context.fetchAllOrdered<RemoteTransaction>("transactions", uid, context.remoteUpdatedSince(SyncCheckpointKey.Transactions))

        val localById = transactionDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("transactions", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, TxPayload.serializer())
                val sourceNameSnapshot = p.incomeSourceNameSnapshot
                    .ifBlank { if (p.type == "income") p.category else "" }
                val purpose = p.purpose.ifBlank {
                    if (p.type == "expense") p.category else ""
                }
                val purposeKey = p.purposeKey.ifBlank {
                    if (p.type == "expense") ExpenseTextNormalizer.key(purpose) else ""
                }
                Transaction(
                    id = item.id, type = p.type, amount = p.amount,
                    category = p.category, date = p.date, note = p.note, group = p.txGroup,
                    incomeSourceId = p.incomeSourceId,
                    incomeSourceNameSnapshot = sourceNameSnapshot,
                    paymentMethodSnapshot = p.paymentMethodSnapshot,
                    purpose = purpose,
                    purposeKey = purposeKey,
                    expenseBeneficiaryId = p.expenseBeneficiaryId,
                    expenseBeneficiaryNameSnapshot = p.expenseBeneficiaryNameSnapshot,
                    operationId = p.operationId,
                    balanceTransactionId = p.balanceTransactionId,
                    updatedAt = remoteUpdatedAt,
                    syncState = SyncState.Synced.dbValue,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("transactions", skipped)
        transactionDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("transactions", it.id, it.date, it.updatedAt)
        }
    }

    // ─── Balance transactions ───────────────────────────────────

    override suspend fun pullBalanceTransactions(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.BalanceTransactions.key)
        val remote = context.fetchAllOrdered<RemoteBalanceTransaction>(
            "balance_transactions",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.BalanceTransactions)
        )

        val localById = balanceTransactionDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("balance_transactions", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, BalanceTransactionPayload.serializer())
                BalanceTransaction(
                    id = item.id,
                    operationId = p.operationId,
                    direction = p.direction,
                    kind = p.kind,
                    amountDecimal = p.amountDecimal,
                    currencyCode = p.currencyCode,
                    date = p.date,
                    note = p.note,
                    sourceType = p.sourceType,
                    sourceId = p.sourceId,
                    legacyTransactionId = p.legacyTransactionId,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("balance_transactions", skipped)
        balanceTransactionDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("balance_transactions", it.id, it.date, it.updatedAt)
        }
    }

    // ─── Payments ────────────────────────────────────────────────

    override suspend fun pullPayments(
        forceFull: Boolean,
        repairAfterPull: Boolean
    ) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.Payments.key)
        val remote = context.fetchAllOrdered<RemotePayment>(
            "payments",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.Payments)
        )

        val localById = paymentDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("payments", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, PaymentPayload.serializer())
                Payment(
                    id = item.id,
                    operationId = p.operationId,
                    kind = p.kind,
                    amountDecimal = p.amountDecimal,
                    currencyCode = p.currencyCode,
                    date = p.date,
                    purpose = p.purpose,
                    purposeKey = p.purposeKey,
                    beneficiaryId = p.beneficiaryId,
                    beneficiaryNameSnapshot = p.beneficiaryNameSnapshot,
                    assetId = p.assetId,
                    assetNameSnapshot = p.assetNameSnapshot,
                    balanceTransactionId = p.balanceTransactionId,
                    legacyTransactionId = p.legacyTransactionId,
                    note = p.note,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("payments", skipped)
        paymentDao.upsertAll(merged)
        if (repairAfterPull) repairIncompletePaymentOperations()
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("payments", it.id, it.date, it.updatedAt)
        }
    }

    override suspend fun pullLedgerHistoryMigrations(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.LedgerHistoryMigrations.key)
        val remote = context.fetchAllOrdered<RemoteLedgerHistoryMigration>(
            "ledger_history_migrations",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.LedgerHistoryMigrations)
        )
        val localByKey = ledgerHistoryMigrationDao.getAllOnce().associateBy { it.migrationKey }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localByKey[item.id]
            context.decodeRemoteRow("ledger_history_migrations", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(
                    item.payload,
                    uid,
                    LedgerHistoryMigrationPayload.serializer()
                )
                if (local != null && local.commitFingerprint != p.commitFingerprint) {
                    return@decodeRemoteRow local.copy(
                        status = "conflict",
                        syncState = SyncState.Conflict.dbValue,
                        updatedAt = maxOf(local.updatedAt, remoteUpdatedAt)
                    )
                }
                if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) {
                    return@decodeRemoteRow null
                }
                LedgerHistoryMigration(
                    migrationKey = item.id,
                    plannerVersion = p.plannerVersion,
                    status = p.status,
                    sourceFingerprint = p.sourceFingerprint,
                    commitFingerprint = p.commitFingerprint,
                    candidateCount = p.candidateCount,
                    incomeCount = p.incomeCount,
                    expenseCount = p.expenseCount,
                    historicalIncomeDecimal = p.historicalIncomeDecimal,
                    historicalExpenseDecimal = p.historicalExpenseDecimal,
                    targetBalanceDecimal = p.targetBalanceDecimal,
                    adjustmentDecimal = p.adjustmentDecimal,
                    adjustmentBalanceTransactionId = p.adjustmentBalanceTransactionId,
                    confirmedAt = p.confirmedAt,
                    completedAt = p.completedAt,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { it > 0L }
                )
            }
        }.filterNotNull()
        context.logSkippedRows("ledger_history_migrations", skipped)
        ledgerHistoryMigrationDao.upsertAll(merged)
    }


    private fun Transaction.toRemote(uid: String): RemoteTransaction {
        val payload = context.json.encodeToString(TxPayload.serializer(),
            TxPayload(
                type = type,
                amount = amount,
                category = category,
                date = date,
                note = note,
                txGroup = group,
                incomeSourceId = incomeSourceId,
                incomeSourceNameSnapshot = incomeSourceNameSnapshot,
                paymentMethodSnapshot = paymentMethodSnapshot,
                purpose = purpose,
                purposeKey = purposeKey,
                expenseBeneficiaryId = expenseBeneficiaryId,
                expenseBeneficiaryNameSnapshot = expenseBeneficiaryNameSnapshot,
                operationId = operationId,
                balanceTransactionId = balanceTransactionId
            ))
        return RemoteTransaction(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

    private fun BalanceTransaction.toRemote(uid: String): RemoteBalanceTransaction {
        val payload = context.json.encodeToString(
            BalanceTransactionPayload.serializer(),
            BalanceTransactionPayload(
                operationId = operationId,
                direction = direction,
                kind = kind,
                amountDecimal = amountDecimal,
                currencyCode = currencyCode,
                date = date,
                note = note,
                sourceType = sourceType,
                sourceId = sourceId,
                legacyTransactionId = legacyTransactionId,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteBalanceTransaction(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

    private fun Payment.toRemote(uid: String): RemotePayment {
        val payload = context.json.encodeToString(
            PaymentPayload.serializer(),
            PaymentPayload(
                operationId = operationId,
                kind = kind,
                amountDecimal = amountDecimal,
                currencyCode = currencyCode,
                date = date,
                purpose = purpose,
                purposeKey = purposeKey,
                beneficiaryId = beneficiaryId,
                beneficiaryNameSnapshot = beneficiaryNameSnapshot,
                assetId = assetId,
                assetNameSnapshot = assetNameSnapshot,
                balanceTransactionId = balanceTransactionId,
                legacyTransactionId = legacyTransactionId,
                note = note,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemotePayment(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

    private fun LedgerHistoryMigration.toRemote(uid: String): RemoteLedgerHistoryMigration {
        val payload = context.json.encodeToString(
            LedgerHistoryMigrationPayload.serializer(),
            LedgerHistoryMigrationPayload(
                plannerVersion = plannerVersion,
                status = status,
                sourceFingerprint = sourceFingerprint,
                commitFingerprint = commitFingerprint,
                candidateCount = candidateCount,
                incomeCount = incomeCount,
                expenseCount = expenseCount,
                historicalIncomeDecimal = historicalIncomeDecimal,
                historicalExpenseDecimal = historicalExpenseDecimal,
                targetBalanceDecimal = targetBalanceDecimal,
                adjustmentDecimal = adjustmentDecimal,
                adjustmentBalanceTransactionId = adjustmentBalanceTransactionId,
                confirmedAt = confirmedAt,
                completedAt = completedAt,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteLedgerHistoryMigration(
            id = migrationKey,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }


    override suspend fun repairIncompletePaymentOperationsForSync() = repairIncompletePaymentOperations()

    private suspend fun repairIncompletePaymentOperations(fullPullAttempted: Boolean = false) {
        val activeBalanceTransactions = balanceTransactionDao.getAllOnce()
            .filter { it.deletedAt == null }
        val activePayments = paymentDao.getAllOnce()
            .filter { it.deletedAt == null }

        val balanceIds = activeBalanceTransactions.map { it.id }.toSet()
        val paymentOperationIds = activePayments.map { it.operationId }.toSet()

        val missingBalancePayments = activePayments.filter { it.balanceTransactionId != null && it.balanceTransactionId !in balanceIds }
        val missingPaymentBalances = activeBalanceTransactions.filter {
            it.sourceType == "payment" && it.operationId !in paymentOperationIds
        }

        if (!fullPullAttempted && (missingBalancePayments.isNotEmpty() || missingPaymentBalances.isNotEmpty())) {
            pullBalanceTransactions(forceFull = true)
            pullPayments(forceFull = true, repairAfterPull = false)
            repairIncompletePaymentOperations(fullPullAttempted = true)
            return
        }

        val incompletePayments = missingBalancePayments
            .filter { it.syncState != SyncState.IncompleteRemote.dbValue }
            .map {
                it.copy(
                    syncState = SyncState.IncompleteRemote.dbValue,
                    updatedAt = System.currentTimeMillis()
                )
            }
        val incompleteBalanceTransactions = missingPaymentBalances
            .filter { it.syncState != SyncState.IncompleteRemote.dbValue }
            .map {
                it.copy(
                    syncState = SyncState.IncompleteRemote.dbValue,
                    updatedAt = System.currentTimeMillis()
                )
            }

        if (incompletePayments.isNotEmpty()) paymentDao.upsertAll(incompletePayments)
        if (incompleteBalanceTransactions.isNotEmpty()) {
            balanceTransactionDao.upsertAll(incompleteBalanceTransactions)
        }
    }
}

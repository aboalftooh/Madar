package com.shift.app.data.local.migration

import com.shift.app.data.local.sync.SyncOutboxSqlPlan

/** Executable migration plan with no Android dependency, so SQL effects can be tested on the JVM. */
object Migration17To18Plan {
    const val FROM_VERSION = 17
    const val TO_VERSION = 18

    private val pendingStateTables = listOf(
        "transactions",
        "income_sources",
        "expense_beneficiaries",
        "debts",
    )

    fun migrate(executor: SqlMigrationExecutor, now: Long) {
        pendingStateTables.forEach { table ->
            executor.execute("ALTER TABLE $table ADD COLUMN syncState TEXT NOT NULL DEFAULT 'pending'")
        }
        SyncOutboxSqlPlan.install(executor)
        SyncOutboxSqlPlan.seedMigrationWakeUp(executor, now)
    }
}

package com.shift.app.utils

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object ErrorMessages {
    fun userMessage(error: Throwable): String {
        val text = error.message.orEmpty()
        val normalized = text.lowercase()
        return when {
            error is UnknownHostException ||
                error is SocketTimeoutException ||
                error is ConnectException ||
                normalized.contains("unable to resolve host") ||
                normalized.contains("failed to connect") ||
                normalized.contains("timeout") ||
                normalized.contains("network") ->
                "لا يوجد اتصال بالإنترنت (NET)"

            normalized.contains("invalid login") ||
                normalized.contains("invalid credentials") ||
                normalized.contains("invalid email or password") ||
                normalized.contains("email not confirmed") ||
                normalized.contains("invalid_grant") ->
                "بيانات الدخول غير صحيحة أو البريد غير مؤكد (AUTH)"

            normalized.contains("500") ||
                normalized.contains("502") ||
                normalized.contains("503") ||
                normalized.contains("504") ||
                normalized.contains("server") ||
                normalized.contains("service unavailable") ->
                "خطأ من الخادم. حاول لاحقاً (SRV)"

            error is IOException ->
                "لا يوجد اتصال بالإنترنت (NET)"

            else ->
                "حدث خطأ غير معروف (UNK)"
        }
    }
}

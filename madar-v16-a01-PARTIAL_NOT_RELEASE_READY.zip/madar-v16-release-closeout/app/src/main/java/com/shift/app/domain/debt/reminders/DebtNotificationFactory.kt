package com.shift.app.domain.debt.reminders

data class DebtNotificationPayload(
    val channelId: String,
    val dedupeKey: String,
    val title: String,
    val body: String,
    val permissionRequired: Boolean = true
)

object DebtNotificationFactory {
    const val CHANNEL_ID = "madar_debt_reminders"

    fun create(work: DebtReminderWork): DebtNotificationPayload =
        DebtNotificationPayload(
            channelId = CHANNEL_ID,
            dedupeKey = work.key,
            title = titleFor(work),
            body = bodyFor(work)
        )

    private fun titleFor(work: DebtReminderWork): String =
        when (work.event) {
            DebtReminderEvent.AccountBeforeDue -> "تذكير دين غداً"
            DebtReminderEvent.AccountDueToday -> "دين مستحق اليوم"
            DebtReminderEvent.ScheduleBeforeDue -> "دفعة مجدولة غداً"
            DebtReminderEvent.ScheduleDueToday -> "دفعة مجدولة اليوم"
            DebtReminderEvent.ScheduleMissed -> "دفعة فائتة"
            DebtReminderEvent.WeeklySummary -> "ملخص الديون الأسبوعي"
        }

    private fun bodyFor(work: DebtReminderWork): String {
        val amount = work.amountDecimal?.let { " بقيمة $it" }.orEmpty()
        return when (work.event) {
            DebtReminderEvent.WeeklySummary -> "راجع الديون والدفعات القادمة في مدار."
            DebtReminderEvent.ScheduleMissed -> "توجد دفعة فائتة لدى ${work.titleRef}$amount."
            DebtReminderEvent.ScheduleBeforeDue,
            DebtReminderEvent.ScheduleDueToday -> "دفعة لدى ${work.titleRef}$amount."
            DebtReminderEvent.AccountBeforeDue,
            DebtReminderEvent.AccountDueToday -> "راجع حساب الدين مع ${work.titleRef}."
        }
    }
}

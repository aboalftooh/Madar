package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.shift.app.data.local.entities.DebtTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtTransactionDao {
    @Query("SELECT * FROM debt_transactions WHERE deletedAt IS NULL ORDER BY occurredAt ASC, createdAt ASC")
    fun getActiveTransactions(): Flow<List<DebtTransaction>>

    @Query("SELECT * FROM debt_transactions WHERE accountId = :accountId AND deletedAt IS NULL ORDER BY occurredAt ASC, createdAt ASC")
    fun getActiveForAccount(accountId: String): Flow<List<DebtTransaction>>

    @Query("SELECT * FROM debt_transactions WHERE accountId = :accountId ORDER BY occurredAt ASC, createdAt ASC")
    suspend fun getAllForAccountOnce(accountId: String): List<DebtTransaction>

    @Query("SELECT * FROM debt_transactions WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<DebtTransaction>

    @Query("SELECT * FROM debt_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DebtTransaction?

    @Query("SELECT * FROM debt_transactions WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<DebtTransaction>

    @Query("SELECT * FROM debt_transactions WHERE sourceType = 'legacy_debt' ORDER BY sourceId ASC")
    suspend fun getLegacyMigrationTransactions(): List<DebtTransaction>

    @Query("SELECT COALESCE(SUM(CASE type WHEN 'opening' THEN CAST(amountDecimal AS REAL) WHEN 'increase' THEN CAST(amountDecimal AS REAL) WHEN 'split_in' THEN CAST(amountDecimal AS REAL) WHEN 'merge_in' THEN CAST(amountDecimal AS REAL) WHEN 'transfer_in' THEN CAST(amountDecimal AS REAL) ELSE -CAST(amountDecimal AS REAL) END), 0) FROM debt_transactions WHERE accountId = :accountId AND deletedAt IS NULL")
    suspend fun rawRemainingAmount(accountId: String): Double

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(transaction: DebtTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(transactions: List<DebtTransaction>)

    @Query("DELETE FROM debt_transactions WHERE id = :id")
    suspend fun hardDeleteById(id: String)

    @Query("DELETE FROM debt_transactions")
    suspend fun deleteAll()
}

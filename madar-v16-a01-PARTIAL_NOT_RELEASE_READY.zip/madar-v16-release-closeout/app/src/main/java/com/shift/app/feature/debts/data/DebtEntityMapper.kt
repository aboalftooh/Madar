package com.shift.app.feature.debts.data

import com.shift.app.data.local.entities.DebtAccount as DebtAccountEntity
import com.shift.app.data.local.entities.DebtMigrationReview as DebtMigrationReviewEntity
import com.shift.app.data.local.entities.DebtTransaction as DebtTransactionEntity
import com.shift.app.feature.debts.domain.model.DebtAccount
import com.shift.app.feature.debts.domain.model.DebtMigrationReview
import com.shift.app.feature.debts.domain.model.DebtTransaction

internal object DebtEntityMapper {
    fun account(entity: DebtAccountEntity) = DebtAccount(
        id = entity.id,
        operationId = entity.operationId,
        direction = entity.direction,
        partyName = entity.partyName,
        currencyCode = entity.currencyCode,
        dueDate = entity.dueDate,
        confirmed = entity.confirmed,
        archivedAt = entity.archivedAt,
        closedAt = entity.closedAt,
        legacyDebtId = entity.legacyDebtId,
        syncState = entity.syncState,
        deletedAt = entity.deletedAt,
    )

    fun transaction(entity: DebtTransactionEntity) = DebtTransaction(
        id = entity.id,
        accountId = entity.accountId,
        operationId = entity.operationId,
        type = entity.type,
        amountDecimal = entity.amountDecimal,
        occurredAt = entity.occurredAt,
        reason = entity.reason,
        originalTransactionId = entity.originalTransactionId,
        createdAt = entity.createdAt,
        deletedAt = entity.deletedAt,
    )

    fun review(entity: DebtMigrationReviewEntity) = DebtMigrationReview(
        id = entity.id,
        legacyDebtId = entity.legacyDebtId,
        proposedAccountId = entity.proposedAccountId,
        status = entity.status,
        deletedAt = entity.deletedAt,
    )
}

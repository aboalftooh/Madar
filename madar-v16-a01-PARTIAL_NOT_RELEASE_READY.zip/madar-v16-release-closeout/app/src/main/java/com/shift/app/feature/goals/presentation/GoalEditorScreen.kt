package com.shift.app.feature.goals.presentation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.templates.DebtPayoffScopeMode
import com.shift.app.ui.components.shiftTextFieldColors
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import com.shift.app.feature.goals.presentation.GoalEditorViewModel
import com.shift.app.feature.goals.presentation.arabicLabel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalEditorScreen(
    goalId: String?,
    onClose: (savedGoalId: String?) -> Unit,
    viewModel: GoalEditorViewModel = hiltViewModel(),
) {
    LaunchedEffect(goalId) { viewModel.load(goalId) }
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.savedGoalId) {
        state.savedGoalId?.let(onClose)
    }
    DisposableEffect(Unit) {
        onDispose { viewModel.autoSaveDraftIfDirty() }
    }
    BackHandler {
        viewModel.autoSaveDraftIfDirty()
        onClose(state.id)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
            .imePadding(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                viewModel.autoSaveDraftIfDirty()
                onClose(state.id)
            }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
            }
            Text(
                text = if (goalId == null) "هدف جديد" else "تعديل الهدف",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
            )
        }

        EditorSection("النوع") {
            GoalTypeMenu(selected = state.type, onSelected = viewModel::updateType)
        }
        EditorSection("القيمة والموعد") {
            OutlinedTextField(
                value = state.name,
                onValueChange = viewModel::updateName,
                label = { Text("اسم الهدف", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                singleLine = true,
            )
            OutlinedTextField(
                value = state.targetInput,
                onValueChange = viewModel::updateTarget,
                label = { Text("المبلغ المستهدف", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                singleLine = true,
            )
            OutlinedTextField(
                value = state.deadline,
                onValueChange = viewModel::updateDeadline,
                label = { Text("الموعد YYYY-MM-DD", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                singleLine = true,
            )
            OutlinedTextField(
                value = state.baselineInput,
                onValueChange = viewModel::updateBaseline,
                label = { Text(baselineLabel(state.type), color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                singleLine = true,
            )
        }
        EditorSection("القياس والنطاق") {
            OutlinedTextField(
                value = state.confirmationPeriods,
                onValueChange = viewModel::updateConfirmationPeriods,
                label = { Text("فترات التأكيد", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                singleLine = true,
            )
            CostThresholdMenu(selected = state.costThreshold, onSelected = viewModel::updateCostThreshold)
            if (state.type == GoalType.EMERGENCY_FUND) {
                OutlinedTextField(
                    value = state.essentialPurposeInput,
                    onValueChange = viewModel::updateEssentialPurposes,
                    label = { Text("الأغراض الأساسية مفصولة بفواصل", color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = shiftTextFieldColors(),
                    singleLine = false,
                    minLines = 2,
                )
            }
            if (state.type == GoalType.DEBT_PAYOFF) {
                DebtScopeSelector(
                    mode = state.debtScopeMode,
                    selectedIds = state.selectedDebtAccountIds,
                    options = state.debtAccountOptions,
                    onMode = viewModel::updateDebtScopeMode,
                    onToggle = viewModel::toggleDebtAccount,
                )
            }
        }
        EditorSection("مراجعة") {
            Text("سيحفظ الهدف كمسودة. التفعيل والتحولات تتم من شاشة التفاصيل.", color = TextSecondary, fontSize = 13.sp)
            state.error?.let { Text(it, color = ExpenseRed, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    viewModel.autoSaveDraftIfDirty()
                    onClose(state.id)
                },
                modifier = Modifier.weight(1f),
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = null)
                Text("رجوع")
            }
            Button(
                onClick = { viewModel.saveDraft() },
                enabled = state.canSave && !state.saving,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BackgroundDark),
            ) {
                Icon(if (state.id == null) Icons.Default.Save else Icons.Default.Check, contentDescription = null)
                Text("حفظ")
            }
        }
    }
}

private fun baselineLabel(type: GoalType): String = when (type) {
    GoalType.EXPENSE_REDUCTION, GoalType.EXPENSE_CEILING -> "خط أساس المصروف مطلوب"
    GoalType.NET_WORTH_GROWTH -> "خط أساس صافي الثروة مطلوب"
    GoalType.CAR_PURCHASE -> "أدنى رصيد بعد الشراء اختياري"
    GoalType.PROJECT_FUNDING, GoalType.TRIP_FUNDING -> "التكلفة الآمنة اختياري"
    else -> "خط الأساس اختياري"
}

@Composable
private fun DebtScopeSelector(
    mode: DebtPayoffScopeMode,
    selectedIds: Set<String>,
    options: List<com.shift.app.viewmodel.DebtAccountOption>,
    onMode: (DebtPayoffScopeMode) -> Unit,
    onToggle: (String) -> Unit,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        FilterChip(
            selected = mode == DebtPayoffScopeMode.ALL_PAYABLE,
            onClick = { onMode(DebtPayoffScopeMode.ALL_PAYABLE) },
            label = { Text("كل الديون") },
        )
        FilterChip(
            selected = mode == DebtPayoffScopeMode.SELECTED_ACCOUNTS,
            onClick = { onMode(DebtPayoffScopeMode.SELECTED_ACCOUNTS) },
            label = { Text("ديون محددة") },
        )
    }
    if (mode == DebtPayoffScopeMode.SELECTED_ACCOUNTS) {
        if (options.isEmpty()) {
            Text("لا توجد ديون مؤكدة قابلة للاختيار", color = TextMuted, fontSize = 13.sp)
        } else {
            options.forEach { option ->
                FilterChip(
                    selected = option.id in selectedIds,
                    onClick = { onToggle(option.id) },
                    label = { Text(option.partyName) },
                )
            }
        }
    }
}

@Composable
private fun EditorSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GoalTypeMenu(selected: GoalType, onSelected: (GoalType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected.arabicLabel(),
            onValueChange = {},
            readOnly = true,
            label = { Text("نوع الهدف", color = TextMuted) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = shiftTextFieldColors(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            GoalType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(type.arabicLabel()) },
                    onClick = {
                        onSelected(type)
                        expanded = false
                    },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CostThresholdMenu(selected: CostThreshold?, onSelected: (CostThreshold?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = when (selected) {
        CostThreshold.EXPECTED -> "التكلفة المتوقعة"
        CostThreshold.SAFE -> "التكلفة الآمنة"
        null -> "بدون حد تكلفة"
    }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = label,
            onValueChange = {},
            readOnly = true,
            label = { Text("عتبة التكلفة", color = TextMuted) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = shiftTextFieldColors(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("بدون حد تكلفة") }, onClick = { onSelected(null); expanded = false })
            DropdownMenuItem(text = { Text("التكلفة المتوقعة") }, onClick = { onSelected(CostThreshold.EXPECTED); expanded = false })
            DropdownMenuItem(text = { Text("التكلفة الآمنة") }, onClick = { onSelected(CostThreshold.SAFE); expanded = false })
        }
    }
}

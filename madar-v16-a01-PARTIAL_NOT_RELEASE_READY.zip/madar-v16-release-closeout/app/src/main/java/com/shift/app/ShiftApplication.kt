package com.shift.app

import android.app.Application
import android.util.Log
import dagger.hilt.android.HiltAndroidApp
import io.sentry.android.core.SentryAndroid
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.sync.outbox.SyncWorkScheduler
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class MadarApplication : Application() {
    @Inject lateinit var goalInvalidationProcessor: GoalInvalidationProcessor
    @Inject lateinit var syncWorkScheduler: SyncWorkScheduler

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        syncWorkScheduler.startRecovery(applicationScope)
        applicationScope.launch {
            runCatching { goalInvalidationProcessor.processPending() }
                .onFailure { Log.e("MadarApplication", "Goal invalidation bootstrap failed", it) }
        }
        if (BuildConfig.SENTRY_DSN.isBlank()) {
            Log.w("MadarApplication", "Sentry DSN is not configured")
            return
        }
        SentryAndroid.init(this) { options ->
            options.dsn = BuildConfig.SENTRY_DSN
            options.isEnableAutoSessionTracking = true
            options.tracesSampleRate = 0.0
        }
    }
}

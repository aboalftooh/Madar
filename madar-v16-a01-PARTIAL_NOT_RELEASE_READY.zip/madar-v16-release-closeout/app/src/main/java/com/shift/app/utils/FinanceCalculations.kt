package com.shift.app.utils

import com.shift.app.data.local.entities.Transaction
import java.time.LocalDate
import java.time.YearMonth

object FinanceCalculations {
    fun monthlyTotals(transactions: List<Transaction>, month: YearMonth): Totals {
        val monthTransactions = transactions.filterVisibleInMonth(month)
        return Totals(
            income = monthTransactions.filter { it.type == "income" }.sumOf { it.amount },
            expense = monthTransactions.filter { it.type == "expense" }.sumOf { it.amount }
        )
    }

    fun monthlyExpense(transactions: List<Transaction>, month: YearMonth): Double =
        monthlyTotals(transactions, month).expense

    fun budgetProgress(expense: Double, budgetLimit: Double): Double {
        val safeLimit = budgetLimit.coerceAtLeast(1.0)
        return (expense / safeLimit).coerceIn(0.0, 1.0)
    }

    fun totals(transactions: List<Transaction>): Totals =
        Totals(
            income = transactions.filter { it.type == "income" }.sumOf { it.amount },
            expense = transactions.filter { it.type == "expense" }.sumOf { it.amount }
        )

    fun savingRatePercent(income: Double, expense: Double): Int {
        val net = income - expense
        return if (income > 0) (net / income * 100).toInt() else 0
    }

    fun filterByDateRange(
        transactions: List<Transaction>,
        from: LocalDate,
        to: LocalDate
    ): List<Transaction> = transactions.filter { tx ->
        if (tx.deletedAt != null) return@filter false
        val date = runCatching { LocalDate.parse(tx.date) }.getOrNull() ?: return@filter false
        !date.isBefore(from) && !date.isAfter(to)
    }

    fun parseLocalizedDouble(raw: String): Double? =
        normalizeDigits(raw).toDoubleOrNull()

    fun normalizeDigits(raw: String): String =
        raw.map { ch ->
            when (ch) {
                in '٠'..'٩' -> '0' + (ch.code - '٠'.code)
                in '۰'..'۹' -> '0' + (ch.code - '۰'.code)
                else -> ch
            }
        }.joinToString("")

    private fun List<Transaction>.filterVisibleInMonth(month: YearMonth): List<Transaction> =
        filter { tx ->
            if (tx.deletedAt != null) return@filter false
            val date = runCatching { LocalDate.parse(tx.date) }.getOrNull() ?: return@filter false
            YearMonth.from(date) == month
        }
}

data class Totals(
    val income: Double,
    val expense: Double
)

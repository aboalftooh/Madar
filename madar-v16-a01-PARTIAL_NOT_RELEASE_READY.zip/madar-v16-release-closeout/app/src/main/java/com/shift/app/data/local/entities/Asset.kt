package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "assets",
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["status", "deletedAt"]),
        Index(value = ["type"])
    ]
)
data class Asset(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String? = null,
    val type: String,
    val name: String,
    val status: String = AssetStatus.Active.dbValue,
    val acquisitionMode: String,
    val acquisitionAmountDecimal: String,
    val currencyCode: String = "SDG",
    val purchasePaymentId: String? = null,
    val purchaseBalanceTransactionId: String? = null,
    val currentValueCacheDecimal: String? = null,
    val currentValueCacheValuationId: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.debt.DebtReviewStatus
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "debt_migration_reviews",
    indices = [
        Index(value = ["legacyDebtId"], unique = true),
        Index(value = ["status", "updatedAt"]),
        Index(value = ["syncState", "updatedAt"])
    ]
)
data class DebtMigrationReview(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val legacyDebtId: String,
    val proposedAccountId: String? = null,
    val status: String = DebtReviewStatus.Pending.dbValue,
    val reason: String,
    val legacyPayloadJson: String,
    val resolutionNote: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

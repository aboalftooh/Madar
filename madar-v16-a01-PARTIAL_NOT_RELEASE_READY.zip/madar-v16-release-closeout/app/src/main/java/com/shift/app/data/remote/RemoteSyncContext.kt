package com.shift.app.data.remote

import android.util.Log
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.sync.remote.SyncSessionRemote
import com.shift.app.utils.PreferencesManager
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.Json

@Singleton
class RemoteSyncContext @Inject constructor(
    @PublishedApi internal val client: SupabaseClient,
    internal val database: MadarDatabase,
    internal val preferences: PreferencesManager,
    internal val goalInvalidationProcessor: GoalInvalidationProcessor,
) : SyncSessionRemote {
    override val authenticatedUserId: String?
        get() = client.auth.currentUserOrNull()?.id

    internal val json: Json = Json { ignoreUnknownKeys = true }
    internal val payloadDecoder = RemotePayloadDecoder(json)
    @PublishedApi internal val pageSize = 1000

    internal suspend fun remoteUpdatedSince(participant: SyncCheckpointKey): String? =
        preferences.getSyncCheckpoint(participant.key).takeIf { it > 0L }?.toRemoteTime()

    internal suspend fun invalidatePulledChanges(
        sourceType: String,
        sourceId: String,
        effectiveDate: String?,
        updatedAt: Long,
    ) {
        val date = effectiveDate?.let { runCatching { LocalDate.parse(it).toString() }.getOrNull() }
            ?: Instant.ofEpochMilli(updatedAt).atZone(ZoneOffset.UTC).toLocalDate().toString()
        database.financialChangeOutboxDao().insert(
            FinancialChangeOutboxEntity(
                eventId = "pull:$sourceType:$sourceId:$updatedAt",
                sourceType = sourceType,
                sourceId = sourceId,
                operationId = "pull:$sourceType:$sourceId:$updatedAt",
                effectiveDate = date,
                changedFields = "sync-correction",
                createdAt = updatedAt,
                processedAt = null,
                attemptCount = 0,
                lastError = null,
            ),
        )
        goalInvalidationProcessor.processPending()
    }

    internal inline fun <T> decodeRemoteRow(
        table: String,
        id: String,
        skippedIds: MutableList<String>,
        decode: () -> T,
    ): T? = runCatching(decode).getOrElse { error ->
        skippedIds += id
        Log.e("SyncManager", "Skipping malformed remote row table=$table id=$id", error)
        null
    }

    internal fun logSkippedRows(table: String, skippedIds: List<String>) {
        if (skippedIds.isNotEmpty()) {
            Log.w("SyncManager", "Skipped ${skippedIds.size} malformed remote rows from $table: $skippedIds")
        }
    }

    internal suspend inline fun <reified T : Any> fetchAllOrdered(
        table: String,
        uid: String,
        updatedSince: String?,
    ): List<T> {
        val remote = mutableListOf<T>()
        var from = 0L
        do {
            val page = client.from(table)
                .select {
                    filter {
                        eq("user_id", uid)
                        updatedSince?.let { gte("updated_at", it) }
                    }
                    order("id", Order.ASCENDING)
                    range(from, from + pageSize - 1)
                }
                .decodeList<T>()
            remote += page
            from += pageSize
        } while (page.size == pageSize)
        return remote
    }
}

internal fun Long.toRemoteTime(): String = Instant.ofEpochMilli(this).toString()
internal fun String?.toLocalTime(): Long =
    this?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() } ?: 0L

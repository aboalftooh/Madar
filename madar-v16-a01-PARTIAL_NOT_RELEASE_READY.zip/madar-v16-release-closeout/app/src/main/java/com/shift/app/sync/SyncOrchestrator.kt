package com.shift.app.sync

import com.shift.app.sync.completedSyncCheckpoint
import com.shift.app.sync.runIsolatedSyncStep
import java.util.concurrent.CancellationException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class SyncOrchestrator @Inject constructor(
    participants: Set<@JvmSuppressWildcards SyncParticipant>,
    private val checkpoints: SyncCheckpointStore,
) {
    private val participants: List<SyncParticipant> = participants.sortedBy(SyncParticipant::order)

    suspend fun synchronize(
        expectedUserId: String,
        isSessionCurrent: () -> Boolean,
        afterPull: suspend () -> Unit = {},
    ): SyncRunResult = withContext(Dispatchers.IO) {
        val startedAt = System.currentTimeMillis()
        val failures = mutableListOf<SyncStepFailure>()

        participants.forEach { participant ->
            val operations = prepareOperations(
                step = "prepare_pull_${participant.key}",
                failures = failures,
            ) { participant.pullOperations() }
            operations.forEach { operation ->
                runOperation(operation, expectedUserId, startedAt, isSessionCurrent, failures)
            }
        }

        if (failures.none { it.step.startsWith("pull_") || it.step.startsWith("prepare_pull_") }) {
            runStep("after_pull_local_migration", failures) { afterPull() }
        }
        if (!isSessionCurrent()) return@withContext SyncRunResult.AuthenticationRequired

        val lastSync = checkpoints.lastSuccessfulSync()
        participants.forEach { participant ->
            val operations = prepareOperations(
                step = "prepare_push_${participant.key}",
                failures = failures,
            ) { participant.pushOperations(lastSync) }
            operations.forEach { operation ->
                runOperation(operation, expectedUserId, startedAt, isSessionCurrent, failures)
            }
        }
        participants.forEach { participant ->
            val operations = prepareOperations(
                step = "prepare_finalize_${participant.key}",
                failures = failures,
            ) { participant.finalizeOperations() }
            operations.forEach { operation ->
                runOperation(operation, expectedUserId, startedAt, isSessionCurrent, failures)
            }
        }

        if (!isSessionCurrent()) return@withContext SyncRunResult.AuthenticationRequired
        if (failures.isNotEmpty()) {
            return@withContext SyncRunResult.PartialFailure(failures.map { it.step }.distinct())
        }

        val checkpoint = completedSyncCheckpoint(startedAt)
        checkpoints.setLastSuccessfulSync(checkpoint)
        SyncRunResult.Success(checkpoint)
    }

    private suspend fun runOperation(
        operation: SyncOperation,
        expectedUserId: String,
        checkpoint: Long,
        isSessionCurrent: () -> Boolean,
        failures: MutableList<SyncStepFailure>,
    ) {
        runStep(operation.step, failures) {
            operation.execute()
            check(isSessionCurrent()) { "Authentication changed during sync for $expectedUserId" }
            operation.checkpointKey?.let { checkpoints.setParticipantCheckpoint(it.key, checkpoint) }
        }
    }

    private suspend fun prepareOperations(
        step: String,
        failures: MutableList<SyncStepFailure>,
        block: suspend () -> List<SyncOperation>,
    ): List<SyncOperation> {
        var operations = emptyList<SyncOperation>()
        runStep(step, failures) { operations = block() }
        return operations
    }

    private suspend fun runStep(
        step: String,
        failures: MutableList<SyncStepFailure>,
        block: suspend () -> Unit,
    ) {
        try {
            runIsolatedSyncStep(
                step = step,
                failures = failures,
                block = block,
            )
        } catch (error: CancellationException) {
            throw error
        }
    }
}

package com.shift.app.feature.backup.data.codec

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.repository.DebtRepository
import com.shift.app.data.repository.ExpenseBeneficiaryRepository
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.IncomeSourceRepository
import com.shift.app.data.repository.LegacyHistoryMigrationRepository
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.LEGACY_HISTORY_MIGRATION_KEY
import com.shift.app.domain.finance.LEGACY_HISTORY_PLANNER_VERSION
import com.shift.app.domain.finance.LEGACY_HISTORY_STATUS_COMPLETED
import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.domain.model.BackupImportMode
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import java.math.BigDecimal
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

internal data class BalanceBackupSettings(
    val activated: Boolean,
    val activatedAt: Long,
    val localCurrencyCode: String,
)

internal data class FinanceBackupSnapshot(
    val transactions: List<Transaction> = emptyList(),
    val balanceTransactions: List<BalanceTransaction> = emptyList(),
    val payments: List<Payment> = emptyList(),
    val incomeSources: List<IncomeSource> = emptyList(),
    val expenseBeneficiaries: List<ExpenseBeneficiary> = emptyList(),
    val legacyDebts: List<Debt> = emptyList(),
    val balanceSettings: BalanceBackupSettings? = null,
    val ledgerHistoryMigrations: List<LedgerHistoryMigration> = emptyList(),
    val financialDataIncluded: Boolean = true,
    val migrationDataIncluded: Boolean = true,
) : BackupSectionSnapshot {
    override val rowCount: Int = transactions.size + balanceTransactions.size + payments.size +
        incomeSources.size + expenseBeneficiaries.size + legacyDebts.size + ledgerHistoryMigrations.size
}

internal data class FinanceBackupPlan(
    val transactions: List<Transaction>,
    val balanceTransactions: List<BalanceTransaction>,
    val payments: List<Payment>,
    val incomeSources: List<IncomeSource>,
    val expenseBeneficiaries: List<ExpenseBeneficiary>,
    val legacyDebts: List<Debt>,
    val balanceSettings: BalanceBackupSettings?,
    val ledgerHistoryMigrations: List<LedgerHistoryMigration>,
    override val importedRowCount: Int,
    override val affectedRowCount: Int,
    override val deleteCount: Int,
) : BackupSectionPlan

@Suppress("DEPRECATION")
internal class FinanceBackupCodec @Inject constructor(
    private val transactionRepository: TransactionRepository,
    private val incomeSourceRepository: IncomeSourceRepository,
    private val expenseBeneficiaryRepository: ExpenseBeneficiaryRepository,
    private val debtRepository: DebtRepository,
    private val financialLedgerRepository: FinancialLedgerRepository,
    private val legacyHistoryMigrationRepository: LegacyHistoryMigrationRepository,
    private val preferences: PreferencesManager,
) : BackupSectionCodec {
    override val id: String = "finance"

    override suspend fun writeExport(root: JSONObject) {
        val snapshot = currentSnapshot()
        root.put("transactions", JSONArray(snapshot.transactions.map { it.toJson() }))
        root.put("balanceTransactions", JSONArray(snapshot.balanceTransactions.map { it.toJson() }))
        root.put("payments", JSONArray(snapshot.payments.map { it.toJson() }))
        root.put("incomeSources", JSONArray(snapshot.incomeSources.map { it.toJson() }))
        root.put("expenseBeneficiaries", JSONArray(snapshot.expenseBeneficiaries.map { it.toJson() }))
        root.put("debts", JSONArray(snapshot.legacyDebts.map { it.toJson() }))
        snapshot.balanceSettings?.let { root.put("balanceSettings", it.toJson()) }
        root.put("ledgerHistoryMigrations", JSONArray(snapshot.ledgerHistoryMigrations.map { it.toJson() }))
    }

    override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot = FinanceBackupSnapshot(
        transactions = root.optJSONArray("transactions").toTransactions(now),
        balanceTransactions = root.optJSONArray("balanceTransactions").toBalanceTransactions(now),
        payments = root.optJSONArray("payments").toPayments(now),
        incomeSources = root.optJSONArray("incomeSources").toIncomeSources(now),
        expenseBeneficiaries = root.optJSONArray("expenseBeneficiaries").toExpenseBeneficiaries(now),
        legacyDebts = root.optJSONArray("debts").toDebts(now),
        balanceSettings = root.optJSONObject("balanceSettings").toBalanceBackupSettings(),
        ledgerHistoryMigrations = root.optJSONArray("ledgerHistoryMigrations").toLedgerHistoryMigrations(now),
        financialDataIncluded = root.has("balanceTransactions") || root.has("payments") || root.has("balanceSettings"),
        migrationDataIncluded = root.has("ledgerHistoryMigrations"),
    )

    override suspend fun plan(
        imported: BackupSectionSnapshot,
        mode: BackupImportMode,
        now: Long,
    ): BackupSectionPlan {
        imported as FinanceBackupSnapshot
        val current = currentSnapshot()
        val currentTransactionById = current.transactions.associateBy { it.id }
        val currentMigrationBalanceIds = current.balanceTransactions
            .filter { it.legacyTransactionId != null || it.sourceType == "legacy_history_migration" }
            .map { it.id }
            .toSet()
        val plannedImportedTransactions = imported.transactions.map { candidate ->
            val stored = currentTransactionById[candidate.id]
            val candidateHasLink = candidate.operationId != null && candidate.balanceTransactionId != null
            val currentHasLink = stored?.operationId != null && stored.balanceTransactionId != null
            val currentIsMigrationLinked = stored?.balanceTransactionId in currentMigrationBalanceIds
            if (currentHasLink && !candidateHasLink &&
                (mode == BackupImportMode.MERGE || !imported.financialDataIncluded ||
                    (!imported.migrationDataIncluded && currentIsMigrationLinked))
            ) requireNotNull(stored) else candidate
        }
        validateFinancialLinks(imported, current, plannedImportedTransactions, currentMigrationBalanceIds, mode)
        val plannedMarkers = planMigrationMarkers(imported, current, mode)
        validateMigrationLinks(imported, current, plannedImportedTransactions, plannedMarkers, mode)

        val importedTransactionIds = plannedImportedTransactions.mapTo(hashSetOf()) { it.id }
        val importedBalanceIds = imported.balanceTransactions.mapTo(hashSetOf()) { it.id }
        val importedPaymentIds = imported.payments.mapTo(hashSetOf()) { it.id }
        val importedIncomeSourceIds = imported.incomeSources.mapTo(hashSetOf()) { it.id }
        val importedBeneficiaryIds = imported.expenseBeneficiaries.mapTo(hashSetOf()) { it.id }
        val importedDebtIds = imported.legacyDebts.mapTo(hashSetOf()) { it.id }

        val transactionDeletes = if (mode == BackupImportMode.REPLACE) {
            current.transactions.filterNot { it.id in importedTransactionIds }
                .filterNot {
                    (!imported.financialDataIncluded && it.operationId != null && it.balanceTransactionId != null) ||
                        (!imported.migrationDataIncluded && it.balanceTransactionId in currentMigrationBalanceIds)
                }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val balanceDeletes = if (mode == BackupImportMode.REPLACE && imported.financialDataIncluded) {
            current.balanceTransactions.filterNot { it.id in importedBalanceIds }
                .filterNot {
                    !imported.migrationDataIncluded &&
                        (it.legacyTransactionId != null || it.sourceType == "legacy_history_migration")
                }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val paymentDeletes = if (mode == BackupImportMode.REPLACE && imported.financialDataIncluded) {
            current.payments.filterNot { it.id in importedPaymentIds }
                .filterNot { !imported.migrationDataIncluded && it.legacyTransactionId != null }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val sourceDeletes = if (mode == BackupImportMode.REPLACE) {
            current.incomeSources.filterNot { it.id in importedIncomeSourceIds }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val beneficiaryDeletes = if (mode == BackupImportMode.REPLACE) {
            current.expenseBeneficiaries.filterNot { it.id in importedBeneficiaryIds }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val debtDeletes = if (mode == BackupImportMode.REPLACE) {
            current.legacyDebts.filterNot { it.id in importedDebtIds }
                .map { it.copy(updatedAt = now, deletedAt = now) }
        } else emptyList()
        val settings = when {
            imported.balanceSettings == null -> null
            mode == BackupImportMode.REPLACE -> imported.balanceSettings
            current.balanceSettings?.activated == true -> current.balanceSettings
            else -> imported.balanceSettings
        }
        val deletes = transactionDeletes.size + balanceDeletes.size + paymentDeletes.size + sourceDeletes.size +
            beneficiaryDeletes.size + debtDeletes.size
        val importedRows = imported.rowCount
        return FinanceBackupPlan(
            transactions = plannedImportedTransactions + transactionDeletes,
            balanceTransactions = imported.balanceTransactions + balanceDeletes,
            payments = imported.payments + paymentDeletes,
            incomeSources = imported.incomeSources + sourceDeletes,
            expenseBeneficiaries = imported.expenseBeneficiaries + beneficiaryDeletes,
            legacyDebts = imported.legacyDebts + debtDeletes,
            balanceSettings = settings,
            ledgerHistoryMigrations = plannedMarkers,
            importedRowCount = importedRows,
            affectedRowCount = importedRows + deletes,
            deleteCount = deletes,
        )
    }

    override suspend fun apply(plan: BackupSectionPlan) {
        plan as FinanceBackupPlan
        incomeSourceRepository.upsertAll(plan.incomeSources)
        expenseBeneficiaryRepository.upsertAll(plan.expenseBeneficiaries)
        transactionRepository.upsertAll(plan.transactions)
        financialLedgerRepository.upsertBalanceTransactions(plan.balanceTransactions)
        financialLedgerRepository.upsertPayments(plan.payments)
        legacyHistoryMigrationRepository.upsertMarkers(plan.ledgerHistoryMigrations)
        debtRepository.upsertAll(plan.legacyDebts)
    }

    override suspend fun captureExternalState(): Any = currentBalanceSettings()

    override suspend fun applyExternal(plan: BackupSectionPlan) {
        plan as FinanceBackupPlan
        plan.balanceSettings?.let { restoreBalanceSettings(it) }
    }

    override suspend fun rollbackExternal(snapshot: Any?) {
        (snapshot as? BalanceBackupSettings)?.let { restoreBalanceSettings(it) }
    }

    private suspend fun restoreBalanceSettings(settings: BalanceBackupSettings) {
        preferences.restoreBalanceSettings(
            activated = settings.activated,
            activatedAt = settings.activatedAt,
            localCurrencyCode = settings.localCurrencyCode,
        )
    }

    private suspend fun currentSnapshot() = FinanceBackupSnapshot(
        transactions = transactionRepository.getAllIncludingDeleted().first(),
        balanceTransactions = financialLedgerRepository.balanceTransactionsIncludingDeleted().first(),
        payments = financialLedgerRepository.paymentsIncludingDeleted().first(),
        incomeSources = incomeSourceRepository.getAll().first(),
        expenseBeneficiaries = expenseBeneficiaryRepository.getAll().first(),
        legacyDebts = debtRepository.getAll().first(),
        balanceSettings = currentBalanceSettings(),
        ledgerHistoryMigrations = legacyHistoryMigrationRepository.getAllMarkers(),
    )

    private suspend fun currentBalanceSettings() = BalanceBackupSettings(
        activated = preferences.balanceActivated.first(),
        activatedAt = preferences.balanceActivatedAt.first(),
        localCurrencyCode = preferences.localCurrencyCode.first(),
    )

    private fun validateFinancialLinks(
        imported: FinanceBackupSnapshot,
        current: FinanceBackupSnapshot,
        plannedImportedTransactions: List<Transaction>,
        currentMigrationBalanceIds: Set<String>,
        mode: BackupImportMode,
    ) {
        val availableBalances = ((if (
            mode == BackupImportMode.MERGE || !imported.financialDataIncluded || !imported.migrationDataIncluded
        ) current.balanceTransactions else emptyList()) + imported.balanceTransactions).associateBy { it.id }
        val availablePayments = ((if (
            mode == BackupImportMode.MERGE || !imported.financialDataIncluded || !imported.migrationDataIncluded
        ) current.payments else emptyList()) + imported.payments).associateBy { it.id }
        require(imported.balanceTransactions.mapNotNull { it.legacyTransactionId }.distinct().size ==
            imported.balanceTransactions.mapNotNull { it.legacyTransactionId }.size) {
            "Backup contains duplicate legacy balance links"
        }
        require(imported.payments.mapNotNull { it.legacyTransactionId }.distinct().size ==
            imported.payments.mapNotNull { it.legacyTransactionId }.size) {
            "Backup contains duplicate legacy payment links"
        }
        require(plannedImportedTransactions.all { transaction ->
            val operationId = transaction.operationId
            val balanceId = transaction.balanceTransactionId
            if (operationId == null && balanceId == null) return@all true
            if (operationId == null || balanceId == null) return@all false
            val balance = availableBalances[balanceId] ?: return@all false
            if (balance.operationId != operationId || balance.sourceType != "transaction" || balance.sourceId != transaction.id) {
                return@all false
            }
            if (transaction.type == "income") {
                return@all balance.kind == "income" &&
                    (balance.deletedAt == null) == (transaction.deletedAt == null) &&
                    (balance.legacyTransactionId == null || balance.legacyTransactionId == transaction.id)
            }
            if (transaction.type != "expense" || balance.kind != "expense_payment" ||
                balance.legacyTransactionId != transaction.id
            ) return@all false
            val payment = availablePayments.values.singleOrNull { it.legacyTransactionId == transaction.id }
                ?: return@all false
            payment.operationId == operationId && payment.kind == "ordinary_expense" &&
                payment.balanceTransactionId == balance.id && payment.legacyTransactionId == transaction.id &&
                (balance.deletedAt == null) == (transaction.deletedAt == null) &&
                (payment.deletedAt == null) == (transaction.deletedAt == null)
        }) { "Backup contains an invalid linked transaction" }

        val availableTransactions = ((if (
            mode == BackupImportMode.MERGE || !imported.migrationDataIncluded
        ) current.transactions else emptyList()) + plannedImportedTransactions).associateBy { it.id }
        require(availableBalances.values.filter { it.legacyTransactionId != null }.all { balance ->
            val transaction = availableTransactions[balance.legacyTransactionId]
            transaction != null && transaction.balanceTransactionId == balance.id &&
                transaction.operationId == balance.operationId && balance.sourceType == "transaction" &&
                balance.sourceId == transaction.id &&
                (balance.deletedAt == null) == (transaction.deletedAt == null)
        }) { "Backup contains an orphaned legacy balance" }
        require(availablePayments.values.filter { it.legacyTransactionId != null }.all { payment ->
            val transaction = availableTransactions[payment.legacyTransactionId]
            val balance = availableBalances[payment.balanceTransactionId]
            transaction?.type == "expense" && transaction.operationId == payment.operationId &&
                balance?.legacyTransactionId == payment.legacyTransactionId &&
                balance?.operationId == payment.operationId &&
                (payment.deletedAt == null) == (transaction.deletedAt == null) &&
                (balance.deletedAt == null) == (transaction.deletedAt == null)
        }) { "Backup contains an orphaned legacy payment" }

        // Preserve current migration-linked rows when importing older backups.
        require(currentMigrationBalanceIds.none { it.isBlank() })
    }

    private fun planMigrationMarkers(
        imported: FinanceBackupSnapshot,
        current: FinanceBackupSnapshot,
        mode: BackupImportMode,
    ): List<LedgerHistoryMigration> {
        require(imported.ledgerHistoryMigrations.size <= 1 && imported.ledgerHistoryMigrations.all {
            it.migrationKey == LEGACY_HISTORY_MIGRATION_KEY && it.plannerVersion == LEGACY_HISTORY_PLANNER_VERSION
        }) { "Backup contains an unsupported history migration marker" }
        require(current.ledgerHistoryMigrations.size <= 1 && current.ledgerHistoryMigrations.all {
            it.migrationKey == LEGACY_HISTORY_MIGRATION_KEY && it.plannerVersion == LEGACY_HISTORY_PLANNER_VERSION
        }) { "Current data contains an unsupported history migration marker" }
        val markerByKey = current.ledgerHistoryMigrations.associateBy { it.migrationKey }.toMutableMap()
        imported.ledgerHistoryMigrations.forEach { importedMarker ->
            val currentMarker = markerByKey[importedMarker.migrationKey]
            if (currentMarker?.status == "completed") {
                require(currentMarker.commitFingerprint == importedMarker.commitFingerprint) {
                    "Backup contains a conflicting completed history migration"
                }
            } else {
                markerByKey[importedMarker.migrationKey] = importedMarker
            }
        }
        if (mode == BackupImportMode.REPLACE && imported.migrationDataIncluded) {
            current.ledgerHistoryMigrations.filter { it.status == "completed" }.forEach { currentMarker ->
                val importedMarker = imported.ledgerHistoryMigrations.singleOrNull {
                    it.migrationKey == currentMarker.migrationKey
                }
                require(importedMarker?.commitFingerprint == currentMarker.commitFingerprint) {
                    "Replacement backup would remove a completed history migration"
                }
            }
        }
        return if (imported.migrationDataIncluded) markerByKey.values.toList() else current.ledgerHistoryMigrations
    }

    private fun validateMigrationLinks(
        imported: FinanceBackupSnapshot,
        current: FinanceBackupSnapshot,
        plannedTransactions: List<Transaction>,
        markers: List<LedgerHistoryMigration>,
        mode: BackupImportMode,
    ) {
        val availableBalances = ((if (
            mode == BackupImportMode.MERGE || !imported.financialDataIncluded || !imported.migrationDataIncluded
        ) current.balanceTransactions else emptyList()) + imported.balanceTransactions).associateBy { it.id }
        val availablePayments = ((if (
            mode == BackupImportMode.MERGE || !imported.financialDataIncluded || !imported.migrationDataIncluded
        ) current.payments else emptyList()) + imported.payments).associateBy { it.id }
        if (imported.balanceTransactions.any { it.legacyTransactionId != null } ||
            imported.payments.any { it.legacyTransactionId != null }
        ) {
            require(markers.any { it.status == "completed" }) {
                "Backup contains legacy migration links without their marker"
            }
        }
        require(markers.all {
            it.status in setOf(LEGACY_HISTORY_STATUS_COMPLETED, "conflict") &&
                it.commitFingerprint.matches(Regex("[0-9a-f]{64}")) &&
                it.sourceFingerprint.matches(Regex("[0-9a-f]{64}")) &&
                it.candidateCount >= 0 && it.incomeCount >= 0 && it.expenseCount >= 0
        }) { "Backup contains an invalid history migration fingerprint" }
        val linkedIncomeCount = availableBalances.values.count { it.legacyTransactionId != null && it.kind == "income" }
        val linkedExpenseCount = availablePayments.values.count {
            it.legacyTransactionId != null && it.kind == "ordinary_expense"
        }
        markers.filter { it.status == LEGACY_HISTORY_STATUS_COMPLETED }.forEach { marker ->
            require(marker.completedAt != null && marker.deletedAt == null) {
                "Completed history migration marker is incomplete"
            }
            require(marker.incomeCount <= linkedIncomeCount && marker.expenseCount <= linkedExpenseCount &&
                marker.candidateCount == marker.incomeCount + marker.expenseCount
            ) { "History migration marker counts do not match linked records" }
            val adjustmentAmount = DecimalText.toBigDecimal(marker.adjustmentDecimal)
            if (adjustmentAmount.signum() == 0) {
                require(marker.adjustmentBalanceTransactionId == null) {
                    "Zero history migration adjustment must not reference a row"
                }
            } else {
                val adjustmentId = requireNotNull(marker.adjustmentBalanceTransactionId) {
                    "History migration adjustment id is missing"
                }
                val adjustment = availableBalances[adjustmentId]
                require(adjustment?.kind == "opening_balance_adjustment" &&
                    adjustment.sourceType == "legacy_history_migration" &&
                    adjustment.sourceId == LEGACY_HISTORY_MIGRATION_KEY && adjustment.deletedAt == null &&
                    DecimalText.toBigDecimal(adjustment.amountDecimal).compareTo(adjustmentAmount.abs()) == 0 &&
                    adjustment.direction == if (adjustmentAmount.signum() > 0) "inflow" else "outflow"
                ) { "History migration adjustment is missing" }
            }
        }
        require(plannedTransactions.none { it.id.isBlank() })
    }

    private fun BalanceBackupSettings.toJson() = JSONObject().apply {
        put("activated", activated)
        put("activatedAt", activatedAt)
        put("localCurrencyCode", localCurrencyCode)
    }

    private fun JSONObject?.toBalanceBackupSettings(): BalanceBackupSettings? {
        if (this == null) return null
        require(has("activated") && has("activatedAt") && has("localCurrencyCode")) {
            "Incomplete balance settings in backup"
        }
        val rawActivated = opt("activated")
        val rawActivatedAt = opt("activatedAt")
        val rawCurrencyCode = opt("localCurrencyCode")
        require(rawActivated is Boolean && rawActivatedAt is Number && rawCurrencyCode is String) {
            "Invalid balance settings types in backup"
        }
        val activatedAtNumber = runCatching { BigDecimal(rawActivatedAt.toString()) }.getOrNull()
        require(activatedAtNumber != null && activatedAtNumber.signum() >= 0 &&
            activatedAtNumber.stripTrailingZeros().scale() <= 0 &&
            activatedAtNumber <= BigDecimal.valueOf(Long.MAX_VALUE)
        ) { "Invalid balance activation timestamp in backup" }
        val currencyCode = rawCurrencyCode.trim().uppercase().ifBlank { "SDG" }
        require(currencyCode.matches(Regex("[A-Z]{3}"))) { "Invalid local currency code in backup" }
        return BalanceBackupSettings(rawActivated, activatedAtNumber.longValueExact(), currencyCode)
    }

    private fun Transaction.toJson() = JSONObject().apply {
        put("id", id); put("type", type); put("amount", amount); put("category", category)
        put("date", date); put("note", note); put("tx_group", group)
        put("incomeSourceId", incomeSourceId); put("incomeSourceNameSnapshot", incomeSourceNameSnapshot)
        put("paymentMethodSnapshot", paymentMethodSnapshot); put("purpose", purpose); put("purposeKey", purposeKey)
        put("expenseBeneficiaryId", expenseBeneficiaryId)
        put("expenseBeneficiaryNameSnapshot", expenseBeneficiaryNameSnapshot)
        put("operationId", operationId); put("balanceTransactionId", balanceTransactionId)
        put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun BalanceTransaction.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("direction", direction); put("kind", kind)
        put("amountDecimal", amountDecimal); put("currencyCode", currencyCode); put("date", date); put("note", note)
        put("sourceType", sourceType); put("sourceId", sourceId); put("legacyTransactionId", legacyTransactionId)
        put("syncState", syncState); put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun Payment.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("kind", kind); put("amountDecimal", amountDecimal)
        put("currencyCode", currencyCode); put("date", date); put("purpose", purpose); put("purposeKey", purposeKey)
        put("beneficiaryId", beneficiaryId); put("beneficiaryNameSnapshot", beneficiaryNameSnapshot)
        put("assetId", assetId); put("assetNameSnapshot", assetNameSnapshot)
        put("balanceTransactionId", balanceTransactionId); put("legacyTransactionId", legacyTransactionId)
        put("note", note); put("syncState", syncState); put("createdAt", createdAt); put("updatedAt", updatedAt)
        put("deletedAt", deletedAt)
    }

    private fun LedgerHistoryMigration.toJson() = JSONObject().apply {
        put("migrationKey", migrationKey); put("plannerVersion", plannerVersion); put("status", status)
        put("sourceFingerprint", sourceFingerprint); put("commitFingerprint", commitFingerprint)
        put("candidateCount", candidateCount); put("incomeCount", incomeCount); put("expenseCount", expenseCount)
        put("historicalIncomeDecimal", historicalIncomeDecimal); put("historicalExpenseDecimal", historicalExpenseDecimal)
        put("targetBalanceDecimal", targetBalanceDecimal); put("adjustmentDecimal", adjustmentDecimal)
        put("adjustmentBalanceTransactionId", adjustmentBalanceTransactionId); put("confirmedAt", confirmedAt)
        put("completedAt", completedAt); put("syncState", syncState); put("createdAt", createdAt)
        put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun IncomeSource.toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("paymentMethod", paymentMethod)
        put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun ExpenseBeneficiary.toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun Debt.toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("amount", amount); put("type", type); put("dueDate", dueDate)
        put("note", note); put("isSettled", isSettled); put("createdAt", createdAt); put("updatedAt", updatedAt)
        put("deletedAt", deletedAt)
    }

    private fun JSONArray?.toTransactions(now: Long): List<Transaction> = mapObjects { o ->
        val type = o.getString("type")
        val category = o.optString("category")
        val purpose = o.optString("purpose").ifBlank { if (type == "expense") category else "" }
        Transaction(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            type = type,
            amount = o.getDouble("amount"),
            category = category,
            date = normalizedDateOrToday(o.optString("date")),
            note = o.optString("note"),
            group = o.optString("tx_group", o.optString("group")),
            incomeSourceId = o.optStringOrNull("incomeSourceId"),
            incomeSourceNameSnapshot = o.optString("incomeSourceNameSnapshot").ifBlank {
                if (type == "income") category else ""
            },
            paymentMethodSnapshot = o.optString("paymentMethodSnapshot"),
            purpose = purpose,
            purposeKey = o.optString("purposeKey").ifBlank {
                if (type == "expense") ExpenseTextNormalizer.key(purpose) else ""
            },
            expenseBeneficiaryId = o.optStringOrNull("expenseBeneficiaryId"),
            expenseBeneficiaryNameSnapshot = o.optString("expenseBeneficiaryNameSnapshot"),
            operationId = o.optStringOrNull("operationId"),
            balanceTransactionId = o.optStringOrNull("balanceTransactionId"),
            updatedAt = o.optLongOrNull("updatedAt") ?: now,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toIncomeSources(now: Long): List<IncomeSource> = mapObjects { o ->
        val name = o.optString("name").trim()
        require(name.isNotBlank()) { "Income source name is blank" }
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        IncomeSource(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = name,
            paymentMethod = o.optString("paymentMethod"),
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toExpenseBeneficiaries(now: Long): List<ExpenseBeneficiary> = mapObjects { o ->
        val name = ExpenseTextNormalizer.displayText(o.optString("name"))
        require(name.isNotBlank()) { "Expense beneficiary name is blank" }
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        ExpenseBeneficiary(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = name,
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toBalanceTransactions(now: Long): List<BalanceTransaction> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        BalanceTransaction(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            direction = o.getString("direction"),
            kind = o.getString("kind"),
            amountDecimal = DecimalText.canonical(o.getString("amountDecimal"), DecimalTextScale.Money),
            currencyCode = o.optString("currencyCode", "SDG").ifBlank { "SDG" },
            date = normalizedDateOrToday(o.optString("date")),
            note = o.optString("note"),
            sourceType = o.optString("sourceType"),
            sourceId = o.optStringOrNull("sourceId"),
            legacyTransactionId = o.optStringOrNull("legacyTransactionId"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toPayments(now: Long): List<Payment> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        Payment(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            kind = o.getString("kind"),
            amountDecimal = DecimalText.canonical(o.getString("amountDecimal"), DecimalTextScale.Money),
            currencyCode = o.optString("currencyCode", "SDG").ifBlank { "SDG" },
            date = normalizedDateOrToday(o.optString("date")),
            purpose = o.optString("purpose"),
            purposeKey = o.optString("purposeKey").ifBlank { ExpenseTextNormalizer.key(o.optString("purpose")) },
            beneficiaryId = o.optStringOrNull("beneficiaryId"),
            beneficiaryNameSnapshot = o.optString("beneficiaryNameSnapshot"),
            assetId = o.optStringOrNull("assetId"),
            assetNameSnapshot = o.optString("assetNameSnapshot"),
            balanceTransactionId = o.getString("balanceTransactionId"),
            legacyTransactionId = o.optStringOrNull("legacyTransactionId"),
            note = o.optString("note"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toLedgerHistoryMigrations(now: Long): List<LedgerHistoryMigration> = mapObjects { o ->
        val sourceFingerprint = o.getString("sourceFingerprint")
        val commitFingerprint = o.getString("commitFingerprint")
        require(sourceFingerprint.matches(Regex("[0-9a-f]{64}"))) { "Invalid migration source fingerprint" }
        require(commitFingerprint.matches(Regex("[0-9a-f]{64}"))) { "Invalid migration commit fingerprint" }
        val status = o.getString("status")
        require(status == "completed" || status == "conflict") { "Invalid migration status" }
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        LedgerHistoryMigration(
            migrationKey = o.getString("migrationKey"),
            plannerVersion = o.getInt("plannerVersion"),
            status = status,
            sourceFingerprint = sourceFingerprint,
            commitFingerprint = commitFingerprint,
            candidateCount = o.getInt("candidateCount").also { require(it >= 0) },
            incomeCount = o.getInt("incomeCount").also { require(it >= 0) },
            expenseCount = o.getInt("expenseCount").also { require(it >= 0) },
            historicalIncomeDecimal = DecimalText.canonicalNonNegative(o.getString("historicalIncomeDecimal"), DecimalTextScale.Money),
            historicalExpenseDecimal = DecimalText.canonicalNonNegative(o.getString("historicalExpenseDecimal"), DecimalTextScale.Money),
            targetBalanceDecimal = DecimalText.canonical(o.getString("targetBalanceDecimal"), DecimalTextScale.Money),
            adjustmentDecimal = DecimalText.canonical(o.getString("adjustmentDecimal"), DecimalTextScale.Money),
            adjustmentBalanceTransactionId = o.optStringOrNull("adjustmentBalanceTransactionId"),
            confirmedAt = o.getLong("confirmedAt"),
            completedAt = o.optLongOrNull("completedAt"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toDebts(now: Long): List<Debt> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        Debt(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = o.getString("name"),
            amount = o.getDouble("amount"),
            type = o.getString("type"),
            dueDate = normalizedOptionalDate(o.optString("dueDate")),
            note = o.optString("note"),
            isSettled = o.optBoolean("isSettled", false),
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }
}

package com.shift.app.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["balanceTransactionId"], unique = true)
    ]
)
data class Transaction(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val type: String,
    /** Legacy compatibility projection. Linked rows are financially valued from Ledger Decimal. */
    val amount: Double,
    val category: String,
    val date: String,
    val note: String = "",
    @ColumnInfo(name = "tx_group") val group: String = "",
    val incomeSourceId: String? = null,
    val incomeSourceNameSnapshot: String = "",
    val paymentMethodSnapshot: String = "",
    val purpose: String = "",
    val purposeKey: String = "",
    val expenseBeneficiaryId: String? = null,
    val expenseBeneficiaryNameSnapshot: String = "",
    val operationId: String? = null,
    val balanceTransactionId: String? = null,
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null,
    @ColumnInfo(defaultValue = "'pending'")
    val syncState: String = SyncState.Pending.dbValue
)

package com.shift.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary          = GoldPrimary,
    secondary        = GoldLight,
    tertiary         = GoldDark,
    background       = BackgroundDark,
    surface          = SurfaceDark,
    surfaceVariant   = SurfaceVariant,
    onPrimary        = BackgroundDark,    // نص أسود على الذهبي
    onSecondary      = BackgroundDark,
    onBackground     = TextPrimary,
    onSurface        = TextPrimary,
    onSurfaceVariant = TextSecondary,
    error            = ExpenseRed,
    outline          = CardBorder,
)

@Composable
fun MadarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = MadarTypography,
        content     = content
    )
}

package com.shift.app.feature.debts.di

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.DebtLinkDao
import com.shift.app.data.local.dao.DebtMigrationReviewDao
import com.shift.app.data.local.dao.DebtScheduleDao
import com.shift.app.data.local.dao.DebtTransactionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object DebtDataModule {
    @Provides fun provideLegacyDebtDao(database: MadarDatabase): DebtDao = database.debtDao()
    @Provides fun provideDebtAccountDao(database: MadarDatabase): DebtAccountDao = database.debtAccountDao()
    @Provides fun provideDebtTransactionDao(database: MadarDatabase): DebtTransactionDao = database.debtTransactionDao()
    @Provides fun provideDebtLinkDao(database: MadarDatabase): DebtLinkDao = database.debtLinkDao()
    @Provides fun provideDebtScheduleDao(database: MadarDatabase): DebtScheduleDao = database.debtScheduleDao()
    @Provides fun provideDebtMigrationReviewDao(database: MadarDatabase): DebtMigrationReviewDao = database.debtMigrationReviewDao()
}

package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.ReferenceDataRemoteSync

@Singleton
class ReferenceDataRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
    private val incomeSourceDao: IncomeSourceDao,
    private val expenseBeneficiaryDao: ExpenseBeneficiaryDao,
) : ReferenceDataRemoteSync {
    // ─── Income sources ─────────────────────────────────────────

    override suspend fun pushIncomeSources(sources: List<IncomeSource>) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (sources.isEmpty()) return@withContext
        context.client.from("income_sources").upsert(sources.map { it.toRemote(uid) })
        incomeSourceDao.upsertAll(sources.map { it.copy(syncState = SyncState.Synced.dbValue) })
    }

    override suspend fun pullIncomeSources() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.IncomeSources.key)
        val localItems = incomeSourceDao.getAllOnce()
        val updatedSince = if (localItems.isEmpty()) null else context.remoteUpdatedSince(SyncCheckpointKey.IncomeSources)
        val remote = context.fetchAllOrdered<RemoteIncomeSource>("income_sources", uid, updatedSince)

        val localById = localItems.associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("income_sources", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, IncomeSourcePayload.serializer())
                IncomeSource(
                    id = item.id,
                    name = p.name,
                    paymentMethod = p.paymentMethod,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    syncState = SyncState.Synced.dbValue,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("income_sources", skipped)
        incomeSourceDao.upsertAll(merged)
    }

    // ─── Expense beneficiaries ──────────────────────────────────

    override suspend fun pushExpenseBeneficiaries(sources: List<ExpenseBeneficiary>) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (sources.isEmpty()) return@withContext
        context.client.from("expense_beneficiaries").upsert(sources.map { it.toRemote(uid) })
        expenseBeneficiaryDao.upsertAll(sources.map { it.copy(syncState = SyncState.Synced.dbValue) })
    }

    override suspend fun pullExpenseBeneficiaries() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.ExpenseBeneficiaries.key)
        val localItems = expenseBeneficiaryDao.getAllOnce()
        val updatedSince = if (localItems.isEmpty()) null else context.remoteUpdatedSince(SyncCheckpointKey.ExpenseBeneficiaries)
        val remote = context.fetchAllOrdered<RemoteExpenseBeneficiary>("expense_beneficiaries", uid, updatedSince)

        val localById = localItems.associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("expense_beneficiaries", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, ExpenseBeneficiaryPayload.serializer())
                ExpenseBeneficiary(
                    id = item.id,
                    name = p.name,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    syncState = SyncState.Synced.dbValue,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("expense_beneficiaries", skipped)
        expenseBeneficiaryDao.upsertAll(merged)
    }


    private fun IncomeSource.toRemote(uid: String): RemoteIncomeSource {
        val payload = context.json.encodeToString(IncomeSourcePayload.serializer(),
            IncomeSourcePayload(name, paymentMethod, createdAt))
        return RemoteIncomeSource(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

    private fun ExpenseBeneficiary.toRemote(uid: String): RemoteExpenseBeneficiary {
        val payload = context.json.encodeToString(ExpenseBeneficiaryPayload.serializer(),
            ExpenseBeneficiaryPayload(name, createdAt))
        return RemoteExpenseBeneficiary(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

}

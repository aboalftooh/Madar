package com.shift.app.data.local.sync

import com.shift.app.data.local.migration.SqlMigrationExecutor
import com.shift.app.data.local.migration.execute

/** Pure SQL plan shared by Room migrations, fresh database callbacks, and JVM tests. */
object SyncOutboxSqlPlan {
    const val CREATE_TABLE = """
        CREATE TABLE IF NOT EXISTS sync_outbox (
            eventId TEXT NOT NULL PRIMARY KEY,
            entityType TEXT NOT NULL,
            entityId TEXT NOT NULL,
            operationId TEXT NOT NULL,
            createdAt INTEGER NOT NULL,
            updatedAt INTEGER NOT NULL,
            state TEXT NOT NULL,
            attemptCount INTEGER NOT NULL,
            nextAttemptAt INTEGER NOT NULL,
            lastError TEXT,
            revision INTEGER NOT NULL
        )
    """

    const val CREATE_READY_INDEX = """
        CREATE INDEX IF NOT EXISTS index_sync_outbox_state_nextAttemptAt_createdAt
        ON sync_outbox(state, nextAttemptAt, createdAt)
    """

    const val CREATE_OPERATION_INDEX = """
        CREATE INDEX IF NOT EXISTS index_sync_outbox_operationId
        ON sync_outbox(operationId)
    """

    data class TriggerOwner(
        val table: String,
        val entityIdExpression: String = "NEW.id",
        val operationExpression: String = entityIdExpression,
    )

    val owners: List<TriggerOwner> = listOf(
        TriggerOwner("transactions", operationExpression = "COALESCE(NEW.operationId, NEW.id)"),
        TriggerOwner("income_sources"),
        TriggerOwner("expense_beneficiaries"),
        TriggerOwner("debts"),
        TriggerOwner("balance_transactions", operationExpression = "NEW.operationId"),
        TriggerOwner("payments", operationExpression = "NEW.operationId"),
        TriggerOwner("assets", operationExpression = "COALESCE(NEW.operationId, NEW.id)"),
        TriggerOwner("asset_transactions", operationExpression = "NEW.operationId"),
        TriggerOwner("asset_valuations", operationExpression = "NEW.operationId"),
        TriggerOwner("currency_asset_lots", operationExpression = "NEW.operationId"),
        TriggerOwner("currency_asset_sale_allocations", operationExpression = "NEW.operationId"),
        TriggerOwner("ledger_history_migrations", entityIdExpression = "NEW.migrationKey"),
        TriggerOwner("debt_accounts", operationExpression = "NEW.operationId"),
        TriggerOwner("debt_transactions", operationExpression = "NEW.operationId"),
        TriggerOwner("debt_links", operationExpression = "NEW.operationId"),
        TriggerOwner("debt_schedules", operationExpression = "NEW.operationId"),
        TriggerOwner("debt_migration_reviews"),
        TriggerOwner("financial_goals"),
        TriggerOwner("goal_metrics"),
        TriggerOwner("goal_conditions"),
        TriggerOwner("goal_scopes"),
        TriggerOwner("goal_funding_transactions", operationExpression = "NEW.operationId"),
        TriggerOwner("goal_cost_estimates", operationExpression = "NEW.operationId"),
        TriggerOwner("goal_activities", operationExpression = "NEW.operationId"),
    )

    fun install(executor: SqlMigrationExecutor) {
        executor.execute(CREATE_TABLE)
        executor.execute(CREATE_READY_INDEX)
        executor.execute(CREATE_OPERATION_INDEX)
        owners.forEach { owner ->
            executor.execute(triggerSql(owner, "insert"))
            executor.execute(triggerSql(owner, "update"))
        }
    }

    fun seedMigrationWakeUp(executor: SqlMigrationExecutor, now: Long) {
        executor.execute(
            """
            INSERT OR REPLACE INTO sync_outbox(
                eventId, entityType, entityId, operationId, createdAt, updatedAt,
                state, attemptCount, nextAttemptAt, lastError, revision
            ) VALUES('migration:17:18', 'database', 'migration-17-18', 'migration:17:18', ?, ?, 'pending', 0, ?, NULL, 1)
            """.trimIndent(),
            arrayOf(now, now, now),
        )
    }

    fun triggerSql(owner: TriggerOwner, action: String): String {
        require(action == "insert" || action == "update") { "Unsupported trigger action: $action" }
        val triggerName = "sync_outbox_${owner.table}_$action"
        return """
            CREATE TRIGGER IF NOT EXISTS $triggerName
            AFTER ${action.uppercase()} ON ${owner.table}
            WHEN lower(NEW.syncState) <> 'synced'
            BEGIN
                INSERT OR IGNORE INTO sync_outbox(
                    eventId, entityType, entityId, operationId, createdAt, updatedAt,
                    state, attemptCount, nextAttemptAt, lastError, revision
                ) VALUES(
                    '${owner.table}:' || ${owner.operationExpression},
                    '${owner.table}',
                    ${owner.entityIdExpression},
                    ${owner.operationExpression},
                    NEW.updatedAt,
                    NEW.updatedAt,
                    'pending',
                    0,
                    NEW.updatedAt,
                    NULL,
                    0
                );
                UPDATE sync_outbox
                SET entityType = '${owner.table}',
                    entityId = ${owner.entityIdExpression},
                    operationId = ${owner.operationExpression},
                    updatedAt = NEW.updatedAt,
                    state = 'pending',
                    attemptCount = 0,
                    nextAttemptAt = NEW.updatedAt,
                    lastError = NULL,
                    revision = revision + 1
                WHERE eventId = '${owner.table}:' || ${owner.operationExpression};
            END
        """.trimIndent()
    }
}

package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "currency_asset_lots",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["assetId"],
            onDelete = ForeignKey.NO_ACTION
        ),
        ForeignKey(
            entity = AssetTransaction::class,
            parentColumns = ["id"],
            childColumns = ["purchaseAssetTransactionId"],
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["assetId", "purchaseDate", "createdAt"]),
        Index(value = ["purchaseAssetTransactionId"], unique = true)
    ]
)
data class CurrencyAssetLot(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val assetId: String,
    val purchaseAssetTransactionId: String,
    val foreignCurrencyCode: String,
    val quantityPurchasedDecimal: String,
    val purchaseExchangeRateDecimal: String,
    val localCostDecimal: String,
    val purchaseDate: String,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

package com.shift.app.feature.debts.data

import com.shift.app.domain.finance.AssetStatus
import com.shift.app.feature.assets.domain.repository.AssetGateway
import com.shift.app.feature.debts.domain.model.DebtSettlementAsset
import com.shift.app.feature.debts.domain.repository.DebtSettlementAssetQuery
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.map

@Singleton
class AssetDebtSettlementQueryAdapter @Inject constructor(
    private val assetGateway: AssetGateway,
) : DebtSettlementAssetQuery {
    override fun observeAvailableAssets() = assetGateway.observeAssets().map { assets ->
        assets.asSequence()
            .filter { it.deletedAt == null && it.status == AssetStatus.Active.dbValue }
            .map { asset ->
                DebtSettlementAsset(
                    id = asset.id,
                    name = asset.name,
                    valueDecimal = asset.currentValueCacheDecimal ?: asset.acquisitionAmountDecimal,
                )
            }
            .toList()
    }
}

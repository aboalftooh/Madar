package com.shift.app.feature.session.data

import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.repository.IncomeSourceRepository
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.utils.PreferencesManager
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LegacyIncomeSourceMigrator @Inject constructor(
    private val preferences: PreferencesManager,
    private val transactionRepository: TransactionRepository,
    private val incomeSourceRepository: IncomeSourceRepository,
    private val syncQueue: SyncQueueGateway,
) {
    suspend fun migrateIfNeeded() {
        if (preferences.incomeSourcesRoomMigratedV1.first()) return

        val workType = preferences.workType.first()
        val legacySources = preferences.incomeSources.first()
        val transactions = transactionRepository.getAllOnce()
        val names = (listOf(workType) + legacySources + transactions
            .filter { it.type == "income" }
            .map { it.category })
            .map(::normalize)
            .filter(String::isNotBlank)
            .distinct()

        val existingSources = incomeSourceRepository.getAllOnce()
        val existingNames = existingSources.map { normalize(it.name) }.toSet()
        val now = System.currentTimeMillis()
        val newSources = names
            .filterNot(existingNames::contains)
            .map { name ->
                IncomeSource(
                    name = name,
                    paymentMethod = "",
                    createdAt = now,
                    updatedAt = now,
                )
            }

        if (newSources.isNotEmpty()) {
            incomeSourceRepository.upsertAll(newSources)
        }

        val sourceByName = (existingSources + newSources).associateBy { normalize(it.name) }
        val updatedTransactions = transactions.mapNotNull { transaction ->
            if (transaction.type != "income" || transaction.incomeSourceId != null) return@mapNotNull null
            val sourceName = normalize(transaction.category.ifBlank { transaction.incomeSourceNameSnapshot })
            val source = sourceByName[sourceName] ?: return@mapNotNull null
            transaction.copy(
                incomeSourceId = source.id,
                incomeSourceNameSnapshot = source.name,
                paymentMethodSnapshot = source.paymentMethod,
                updatedAt = now,
            )
        }

        if (updatedTransactions.isNotEmpty()) {
            transactionRepository.upsertAll(updatedTransactions)
        }

        preferences.setIncomeSourcesRoomMigratedV1(true)
        if (newSources.isNotEmpty() || updatedTransactions.isNotEmpty()) {
            syncQueue.requestSync("legacy-income-source-migration")
        }
    }

    private fun normalize(value: String): String = value.trim().replace(Regex("\\s+"), " ")
}

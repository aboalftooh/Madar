package com.shift.app.feature.session.di

import com.shift.app.feature.session.data.AppSessionGatewayAdapter
import com.shift.app.feature.session.domain.AppSessionGateway
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class AppSessionModule {
    @Binds
    abstract fun bindAppSessionGateway(implementation: AppSessionGatewayAdapter): AppSessionGateway
}

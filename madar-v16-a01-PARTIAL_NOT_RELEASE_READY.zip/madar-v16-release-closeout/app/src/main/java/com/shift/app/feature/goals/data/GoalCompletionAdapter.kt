package com.shift.app.feature.goals.data

import com.shift.app.domain.goals.usecase.AssetGoalCompletionRequest
import com.shift.app.domain.goals.usecase.CompleteCostGoalRequest
import com.shift.app.domain.goals.usecase.GoalDebtPaymentRequest
import com.shift.app.feature.goals.domain.repository.GoalCompletionPort
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalCompletionAdapter @Inject constructor(
    private val assetCompletion: RoomAssetGoalCompletion,
    private val costCompletion: RoomCostGoalCompletion,
    private val debtPayment: RoomGoalDebtPayment,
) : GoalCompletionPort {
    override suspend fun completeAssetPurchase(request: AssetGoalCompletionRequest) = assetCompletion.complete(request)
    override suspend fun completeCostGoal(request: CompleteCostGoalRequest) = costCompletion.complete(request)
    override suspend fun recordDebtPayment(request: GoalDebtPaymentRequest) = debtPayment.record(request)
}

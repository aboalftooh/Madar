package com.shift.app.utils

import android.content.Context
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "madar_prefs")

@Singleton
class PreferencesManager @Inject constructor(private val context: Context) {

    companion object {
        private const val SECURE_PREFS = "shift_secure_prefs"
        private const val PIN = "pin_hash"
        private const val PIN_ENABLED = "pin_enabled"
        private const val SEC_QUESTION = "sec_question"
        private const val SEC_ANSWER = "sec_answer_hash"
        private const val USER_SALT = "user_salt"
        private const val PIN_FAILED_ATTEMPTS = "pin_failed_attempts"
        private const val PIN_LOCKED_UNTIL = "pin_locked_until"
        val USER_NAME        = stringPreferencesKey("user_name")
        val WORK_TYPE        = stringPreferencesKey("work_type")
        val BUDGET_LIMIT     = floatPreferencesKey("budget_limit")
        val INCOME_SOURCES   = stringPreferencesKey("income_sources")
        val SETUP_DONE       = booleanPreferencesKey("setup_done")
        val EXPENSE_GROUPS   = stringPreferencesKey("expense_groups")
        val REMEMBERED_EMAIL    = stringPreferencesKey("remembered_email")
        val LAST_SYNC           = longPreferencesKey("last_sync")
        val SYNC_CHECKPOINTS_V1 = stringPreferencesKey("sync_checkpoints_v1")
        val ENCRYPTION_MIGRATED_V2 = booleanPreferencesKey("encryption_migrated_v2")
        val SETTINGS_UPDATED_AT = longPreferencesKey("settings_updated_at")
        val INCOME_SOURCES_ROOM_MIGRATED_V1 = booleanPreferencesKey("income_sources_room_migrated_v1")
        val BALANCE_ACTIVATED = booleanPreferencesKey("balance_activated")
        val BALANCE_ACTIVATED_AT = longPreferencesKey("balance_activated_at")
        val LOCAL_CURRENCY_CODE = stringPreferencesKey("local_currency_code")
    }

    private val securePrefs by lazy {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            SECURE_PREFS,
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val pinState = MutableStateFlow(securePrefs.getString(PIN, "") ?: "")
    private val pinEnabledState = MutableStateFlow(securePrefs.getBoolean(PIN_ENABLED, true))
    private val secQuestionState = MutableStateFlow(securePrefs.getString(SEC_QUESTION, "اسم حيوانك الأليف؟") ?: "اسم حيوانك الأليف؟")
    private val secAnswerState = MutableStateFlow(securePrefs.getString(SEC_ANSWER, "") ?: "")
    private val pinFailedAttemptsState = MutableStateFlow(securePrefs.getInt(PIN_FAILED_ATTEMPTS, 0))
    private val pinLockedUntilState = MutableStateFlow(securePrefs.getLong(PIN_LOCKED_UNTIL, 0L))

    val pin: Flow<String>           = pinState
    val pinEnabled: Flow<Boolean>   = pinEnabledState
    val secQuestion: Flow<String>   = secQuestionState
    val secAnswer: Flow<String>     = secAnswerState
    val pinFailedAttempts: Flow<Int> = pinFailedAttemptsState
    val pinLockedUntil: Flow<Long>   = pinLockedUntilState
    val userName: Flow<String>      = context.dataStore.data.map { it[USER_NAME] ?: "" }
    val workType: Flow<String>      = context.dataStore.data.map { it[WORK_TYPE] ?: "وظيفة قطاع خاص" }
    val budgetLimit: Flow<Float>    = context.dataStore.data.map { it[BUDGET_LIMIT] ?: 5000f }
    val settingsUpdatedAt: Flow<Long> = context.dataStore.data.map { it[SETTINGS_UPDATED_AT] ?: 0L }
    val incomeSourcesRoomMigratedV1: Flow<Boolean> =
        context.dataStore.data.map { it[INCOME_SOURCES_ROOM_MIGRATED_V1] ?: false }
    val balanceActivated: Flow<Boolean> = context.dataStore.data.map { it[BALANCE_ACTIVATED] ?: false }
    val balanceActivatedAt: Flow<Long> = context.dataStore.data.map { it[BALANCE_ACTIVATED_AT] ?: 0L }
    val localCurrencyCode: Flow<String> = context.dataStore.data.map { it[LOCAL_CURRENCY_CODE] ?: "SDG" }
    // يرجع قائمة مصادر الدخل
    val setupDone: Flow<Boolean> = context.dataStore.data.map { it[SETUP_DONE] ?: false }

    private fun decodeStringList(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { i -> array.optString(i).trim() }
                .filter { it.isNotBlank() }
        }.getOrElse {
            raw.split(",").map { s -> s.trim() }.filter { s -> s.isNotBlank() }
        }
    }

    private fun encodeStringList(list: List<String>): String =
        JSONArray(list.map { it.trim() }.filter { it.isNotBlank() }).toString()

    val incomeSources: Flow<List<String>> = context.dataStore.data.map {
        decodeStringList(it[INCOME_SOURCES] ?: "")
    }

    private fun getOrCreateUserSalt(): String {
        securePrefs.getString(USER_SALT, null)?.let { return it }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return Base64.encodeToString(salt, Base64.NO_WRAP).also {
            securePrefs.edit().putString(USER_SALT, it).apply()
        }
    }

    private fun secureHash(value: String): String {
        if (value.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("${value.trim()}:${getOrCreateUserSalt()}".toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun verifyPin(rawPin: String): Boolean =
        pinState.value.isNotBlank() && secureHash(rawPin) == pinState.value

    fun verifySecAnswer(rawAnswer: String): Boolean =
        secAnswerState.value.isNotBlank() && secureHash(rawAnswer) == secAnswerState.value

    fun isPinTemporarilyLocked(now: Long = System.currentTimeMillis()): Boolean =
        pinLockedUntilState.value > now

    suspend fun recordFailedPinAttempt(now: Long = System.currentTimeMillis()): PinAttemptPenalty {
        val attempts = pinFailedAttemptsState.value + 1
        val lockedUntil = if (attempts >= 5) {
            val lockLevel = (attempts - 5).coerceAtMost(5)
            now + (60_000L shl lockLevel)
        } else {
            0L
        }
        securePrefs.edit()
            .putInt(PIN_FAILED_ATTEMPTS, attempts)
            .putLong(PIN_LOCKED_UNTIL, lockedUntil)
            .apply()
        pinFailedAttemptsState.value = attempts
        pinLockedUntilState.value = lockedUntil
        return PinAttemptPenalty(attempts, lockedUntil)
    }

    suspend fun resetPinAttempts() {
        securePrefs.edit()
            .putInt(PIN_FAILED_ATTEMPTS, 0)
            .putLong(PIN_LOCKED_UNTIL, 0L)
            .apply()
        pinFailedAttemptsState.value = 0
        pinLockedUntilState.value = 0L
    }

    suspend fun setPin(v: String) {
        val hashed = secureHash(v)
        securePrefs.edit().putString(PIN, hashed).apply()
        pinState.value = hashed
        resetPinAttempts()
    }
    suspend fun setPinEnabled(v: Boolean) {
        securePrefs.edit().putBoolean(PIN_ENABLED, v).apply()
        pinEnabledState.value = v
    }
    suspend fun setSecQuestion(v: String) {
        securePrefs.edit().putString(SEC_QUESTION, v).apply()
        secQuestionState.value = v
    }
    suspend fun setSecAnswer(v: String) {
        val hashed = secureHash(v)
        securePrefs.edit().putString(SEC_ANSWER, hashed).apply()
        secAnswerState.value = hashed
    }
    suspend fun setUserName(v: String) = context.dataStore.edit {
        it[USER_NAME] = v
        it[SETTINGS_UPDATED_AT] = System.currentTimeMillis()
    }
    suspend fun setWorkType(v: String) = context.dataStore.edit {
        it[WORK_TYPE] = v
        it[SETTINGS_UPDATED_AT] = System.currentTimeMillis()
    }
    suspend fun setBudgetLimit(v: Float) = context.dataStore.edit {
        it[BUDGET_LIMIT] = v
        it[SETTINGS_UPDATED_AT] = System.currentTimeMillis()
    }
    suspend fun setIncomeSources(list: List<String>) =
        context.dataStore.edit {
            it[INCOME_SOURCES] = encodeStringList(list)
            it[SETTINGS_UPDATED_AT] = System.currentTimeMillis()
        }
    suspend fun setIncomeSourcesRoomMigratedV1(v: Boolean) =
        context.dataStore.edit { it[INCOME_SOURCES_ROOM_MIGRATED_V1] = v }
    suspend fun setSetupDone(v: Boolean) = context.dataStore.edit { it[SETUP_DONE] = v }
    suspend fun activateBalance(localCurrencyCode: String = "SDG", activatedAt: Long = System.currentTimeMillis()) =
        context.dataStore.edit {
            it[BALANCE_ACTIVATED] = true
            it[BALANCE_ACTIVATED_AT] = activatedAt
            it[LOCAL_CURRENCY_CODE] = localCurrencyCode
            it[SETTINGS_UPDATED_AT] = activatedAt
        }

    suspend fun restoreBalanceSettings(
        activated: Boolean,
        activatedAt: Long,
        localCurrencyCode: String,
        updatedAt: Long = System.currentTimeMillis()
    ) = context.dataStore.edit {
        val code = localCurrencyCode.trim().uppercase()
        require(code.matches(Regex("[A-Z]{3}"))) { "Invalid local currency code" }
        it[BALANCE_ACTIVATED] = activated
        it[BALANCE_ACTIVATED_AT] = activatedAt.coerceAtLeast(0L)
        it[LOCAL_CURRENCY_CODE] = code
        it[SETTINGS_UPDATED_AT] = updatedAt
    }

    /** Clears account-owned preferences while preserving device-owned secrets and remembered email. */
    suspend fun clearAccountScopedState() = context.dataStore.edit { prefs ->
        prefs.remove(USER_NAME)
        prefs.remove(WORK_TYPE)
        prefs.remove(BUDGET_LIMIT)
        prefs.remove(INCOME_SOURCES)
        prefs.remove(SETUP_DONE)
        prefs.remove(EXPENSE_GROUPS)
        prefs.remove(LAST_SYNC)
        prefs.remove(SYNC_CHECKPOINTS_V1)
        prefs.remove(SETTINGS_UPDATED_AT)
        prefs.remove(INCOME_SOURCES_ROOM_MIGRATED_V1)
        prefs.remove(BALANCE_ACTIVATED)
        prefs.remove(BALANCE_ACTIVATED_AT)
        prefs.remove(LOCAL_CURRENCY_CODE)
    }

    val expenseGroups: Flow<List<String>> = context.dataStore.data.map {
        val raw = it[EXPENSE_GROUPS] ?: "شخصي,العائلة,العمل"
        decodeStringList(raw)
    }
    suspend fun setExpenseGroups(list: List<String>) =
        context.dataStore.edit {
            it[EXPENSE_GROUPS] = encodeStringList(list)
            it[SETTINGS_UPDATED_AT] = System.currentTimeMillis()
        }

    suspend fun replaceCloudSettings(
        userName: String,
        workType: String,
        budgetLimit: Float,
        incomeSources: List<String>,
        expenseGroups: List<String>,
        balanceActivated: Boolean = false,
        balanceActivatedAt: Long = 0L,
        localCurrencyCode: String = "SDG",
        updatedAt: Long
    ) = context.dataStore.edit {
        it[USER_NAME] = userName
        it[WORK_TYPE] = workType
        it[BUDGET_LIMIT] = budgetLimit
        it[INCOME_SOURCES] = encodeStringList(incomeSources)
        it[EXPENSE_GROUPS] = encodeStringList(expenseGroups)
        it[BALANCE_ACTIVATED] = balanceActivated
        it[BALANCE_ACTIVATED_AT] = balanceActivatedAt
        it[LOCAL_CURRENCY_CODE] = localCurrencyCode
        it[SETTINGS_UPDATED_AT] = updatedAt
    }

    val rememberedEmail: Flow<String>    = context.dataStore.data.map { it[REMEMBERED_EMAIL] ?: "" }
    suspend fun setRememberedEmail(email: String) = context.dataStore.edit { it[REMEMBERED_EMAIL] = email }

    val lastSync: Flow<Long> = context.dataStore.data.map { it[LAST_SYNC] ?: 0L }
    suspend fun setLastSync(v: Long) = context.dataStore.edit { it[LAST_SYNC] = v }

    private fun decodeSyncCheckpoints(raw: String?): MutableMap<String, Long> {
        if (raw.isNullOrBlank()) return mutableMapOf()
        return runCatching {
            val json = JSONObject(raw)
            buildMap {
                json.keys().forEach { key ->
                    val value = json.optLong(key, Long.MIN_VALUE)
                    if (value >= 0L) put(key, value)
                }
            }.toMutableMap()
        }.getOrDefault(mutableMapOf())
    }

    private fun encodeSyncCheckpoints(values: Map<String, Long>): String =
        JSONObject().apply {
            values.toSortedMap().forEach { (key, value) -> put(key, value.coerceAtLeast(0L)) }
        }.toString()

    /** Falls back to the old global checkpoint once, preserving upgrades from existing installs. */
    fun syncCheckpoint(participantKey: String): Flow<Long> = context.dataStore.data.map { prefs ->
        decodeSyncCheckpoints(prefs[SYNC_CHECKPOINTS_V1])[participantKey]
            ?: prefs[LAST_SYNC]
            ?: 0L
    }

    suspend fun getSyncCheckpoint(participantKey: String): Long =
        syncCheckpoint(participantKey).first()

    suspend fun setSyncCheckpoint(participantKey: String, value: Long) = context.dataStore.edit { prefs ->
        require(participantKey.isNotBlank()) { "Sync participant key cannot be blank" }
        val checkpoints = decodeSyncCheckpoints(prefs[SYNC_CHECKPOINTS_V1])
        checkpoints[participantKey] = value.coerceAtLeast(0L)
        prefs[SYNC_CHECKPOINTS_V1] = encodeSyncCheckpoints(checkpoints)
    }

    val encryptionMigratedV2: Flow<Boolean> = context.dataStore.data.map { it[ENCRYPTION_MIGRATED_V2] ?: false }
    suspend fun setEncryptionMigratedV2(v: Boolean) =
        context.dataStore.edit { it[ENCRYPTION_MIGRATED_V2] = v }
}

data class PinAttemptPenalty(
    val attempts: Int,
    val lockedUntilMillis: Long
)

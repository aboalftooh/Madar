package com.shift.app.feature.goals.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.usecase.AssetGoalCompletionRequest
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import java.time.LocalDate

@Composable
fun AssetGoalCompletionScreen(
    previewText: String,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إكمال شراء الأصل", color = TextPrimary)
        Text(previewText, color = TextSecondary)
        androidx.compose.material3.Button(onClick = onConfirm) {
            Text("تأكيد الشراء")
        }
    }
}

@Composable
fun AssetGoalCompletionScreen(
    goal: FinancialGoal,
    onSubmit: (AssetGoalCompletionRequest) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var assetName by remember(goal.id) { mutableStateOf(goal.name) }
    var amount by remember(goal.id) { mutableStateOf(goal.targetDecimal) }
    var date by remember(goal.id) { mutableStateOf(LocalDate.now().toString()) }
    var note by remember(goal.id) { mutableStateOf("") }
    var financed by remember(goal.id) { mutableStateOf(false) }
    var lender by remember(goal.id) { mutableStateOf("") }
    var financedAmount by remember(goal.id) { mutableStateOf("0.00") }
    var cashPaid by remember(goal.id) { mutableStateOf(goal.targetDecimal) }
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("إكمال شراء الأصل", color = TextPrimary)
        OutlinedTextField(assetName, { assetName = it }, label = { Text("اسم الأصل") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("قيمة الشراء") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(date, { date = it }, label = { Text("التاريخ") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") }, modifier = Modifier.fillMaxWidth())
        if (goal.type == GoalType.CAR_PURCHASE) {
            Row { Checkbox(financed, { financed = it }); Text("شراء ممول", color = TextPrimary) }
            if (financed) {
                OutlinedTextField(lender, { lender = it }, label = { Text("جهة التمويل") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(financedAmount, { financedAmount = it }, label = { Text("مبلغ التمويل") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cashPaid, { cashPaid = it }, label = { Text("النقد المدفوع") }, modifier = Modifier.fillMaxWidth())
            }
        }
        Button(
            onClick = {
                onSubmit(
                    AssetGoalCompletionRequest(
                        goalId = goal.id,
                        assetName = assetName,
                        assetType = if (goal.type == GoalType.HOUSE_PURCHASE) "house" else "car",
                        amountDecimal = amount,
                        date = date,
                        note = note,
                        financed = financed,
                        lenderName = lender,
                        financedAmountDecimal = financedAmount,
                        cashPaidDecimal = if (financed) cashPaid else amount,
                    ),
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("تسجيل الشراء وإكمال الهدف") }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}

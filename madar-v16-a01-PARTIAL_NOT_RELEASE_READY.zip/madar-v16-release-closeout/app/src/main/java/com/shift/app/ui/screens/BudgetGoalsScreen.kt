package com.shift.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.domain.finance.FinancialReportCalculator
import com.shift.app.ui.components.shiftTextFieldColors
import com.shift.app.ui.theme.*
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.viewmodel.TransactionsViewModel
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetGoalsScreen(vm: TransactionsViewModel = hiltViewModel()) {
    BudgetContent(vm = vm, includeTitle = true)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetContent(
    vm: TransactionsViewModel = hiltViewModel(),
    includeTitle: Boolean,
) {
    val transactions by vm.transactions.collectAsState()
    val balanceTransactions by vm.balanceTransactions.collectAsState()
    val payments     by vm.payments.collectAsState()
    val migratedLegacyExpenseIds by vm.migratedLegacyExpenseIds.collectAsState()
    val budgetLimit  by vm.budgetLimit.collectAsState()

    val currentMonth  = YearMonth.now()
    val today         = LocalDate.now()
    val daysRemaining = (currentMonth.lengthOfMonth() - today.dayOfMonth).coerceAtLeast(1)

    val monthReport = remember(transactions, balanceTransactions, payments, migratedLegacyExpenseIds, currentMonth) {
        FinancialReportCalculator.month(
            transactions,
            balanceTransactions,
            payments,
            currentMonth,
            migratedLegacyExpenseIds,
        )
    }
    val monthExpense = monthReport.actualExpenses
    val budgetDecimal = BigDecimal.valueOf(budgetLimit.toDouble()).max(BigDecimal.ONE)
    val progress = monthExpense.divide(budgetDecimal, 4, RoundingMode.HALF_UP).toFloat().coerceIn(0f, 1f)
    val remaining = BigDecimal.valueOf(budgetLimit.toDouble()).subtract(monthExpense).max(BigDecimal.ZERO)
    val dailyAvail = remaining.divide(BigDecimal(daysRemaining), 0, RoundingMode.DOWN).toInt()

    var editBudget     by remember { mutableStateOf(false) }
    var budgetInput    by remember { mutableStateOf(NumberDisplayFormatter.format(budgetLimit, useGrouping = false)) }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .imePadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (includeTitle) {
            Text(
                "الميزانية",
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                color = TextPrimary, modifier = Modifier.statusBarsPadding()
            )
        }

        // ══ الميزانية ══
        SectionCard(title = "الميزانية الشهرية") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("أنفقت ${NumberDisplayFormatter.format(monthExpense, useGrouping = true)} من ${NumberDisplayFormatter.format(BigDecimal.valueOf(budgetLimit.toDouble()), useGrouping = true)}", color = TextSecondary, fontSize = 13.sp)
                Text("${NumberDisplayFormatter.format(progress * 100)}%",
                    color = if (progress > 0.8f) ExpenseRed else AccentBlue,
                    fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(SurfaceVariant)) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                    .background(Brush.linearGradient(
                        if (progress > 0.8f) listOf(ExpenseRed, Color(0xFFFF6B6B))
                        else listOf(AccentBlue, AccentCyan)
                    ))
                )
            }
            if (progress > 0.8f) Text("⚠️ تجاوزت 80% من الميزانية!", color = ExpenseRed, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                BudgetStat("المتبقي",     NumberDisplayFormatter.format(remaining, useGrouping = true), IncomeGreen)
                BudgetStat("متاح يومياً", NumberDisplayFormatter.format(dailyAvail),      AccentCyan)
                BudgetStat("أيام متبقية", NumberDisplayFormatter.format(daysRemaining),   TextSecondary)
            }
            if (editBudget) {
                OutlinedTextField(
                    value = budgetInput, onValueChange = { budgetInput = it },
                    label = { Text("الحد الجديد", color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(), colors = shiftTextFieldColors()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { budgetInput.toFloatOrNull()?.let { vm.setBudgetLimit(it) }; editBudget = false },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) { Text("حفظ") }
                    OutlinedButton(onClick = { editBudget = false }, modifier = Modifier.weight(1f)) {
                        Text("إلغاء", color = TextMuted)
                    }
                }
            } else {
                TextButton(onClick = {
                    editBudget = true
                    budgetInput = NumberDisplayFormatter.format(budgetLimit, useGrouping = false)
                }) {
                    Text("✏️ تعديل الميزانية", color = AccentCyan, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            content()
        }
    }
}

@Composable
private fun BudgetStat(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(label, color = TextMuted, fontSize = 11.sp)
    }
}

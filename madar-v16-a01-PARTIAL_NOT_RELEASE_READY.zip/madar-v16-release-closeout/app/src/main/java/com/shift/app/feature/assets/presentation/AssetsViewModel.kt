package com.shift.app.feature.assets.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetCommandReceipt
import com.shift.app.feature.assets.domain.model.AssetDetails
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetSummary
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import com.shift.app.feature.assets.domain.usecase.CreateAssetUseCase
import com.shift.app.feature.assets.domain.usecase.EditAssetUseCase
import com.shift.app.feature.assets.domain.usecase.ManageAssetLifecycleUseCase
import com.shift.app.feature.assets.domain.usecase.ObserveAssetDetailsUseCase
import com.shift.app.feature.assets.domain.usecase.ObserveAssetSummariesUseCase
import com.shift.app.feature.assets.domain.usecase.ObserveAssetsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AssetActionState(
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
)

@HiltViewModel
class AssetsViewModel @Inject constructor(
    observeAssets: ObserveAssetsUseCase,
    observeSummaries: ObserveAssetSummariesUseCase,
    private val createAsset: CreateAssetUseCase,
    private val manageLifecycle: ManageAssetLifecycleUseCase,
    private val editAsset: EditAssetUseCase,
) : ViewModel() {
    val assets: StateFlow<List<Asset>> = observeAssets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val summaries: StateFlow<List<AssetSummary>> = observeSummaries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _actionState = MutableStateFlow(AssetActionState())
    val actionState: StateFlow<AssetActionState> = _actionState

    fun clearActionMessage() = _actionState.update { AssetActionState(busy = it.busy) }

    fun addPreexistingAsset(
        name: String,
        type: String,
        amount: String,
        currentValue: String,
        date: String = LocalDate.now().toString(),
        note: String = "",
    ) = runAction("تمت إضافة الأصل") {
        createAsset.addPreexisting(
            PreexistingAssetRequest(name, type, amount, currentValue.ifBlank { null }, date, note),
        )
    }

    fun purchaseAsset(
        name: String,
        type: String,
        amount: String,
        date: String = LocalDate.now().toString(),
        note: String = "",
    ) = runAction("تم شراء الأصل") {
        createAsset.purchase(PurchaseAssetRequest(name, type, amount, date, note))
    }

    fun purchaseCurrencyAsset(
        name: String,
        currencyCode: String,
        quantity: String,
        exchangeRate: String,
        localCost: String,
        date: String = LocalDate.now().toString(),
        note: String = "",
    ) = runAction("تم شراء العملة") {
        createAsset.purchaseCurrency(
            PurchaseCurrencyAssetRequest(name, currencyCode, quantity, exchangeRate, localCost, date, note),
        )
    }

    fun improveAsset(asset: Asset, amount: String, purpose: String, date: String, note: String) =
        runAction("تم تسجيل التحسين") {
            manageLifecycle.recordPayment(
                AssetPaymentRequest(asset.id, PaymentKind.AssetImprovement, amount, purpose, date, note),
            )
        }

    fun maintainAsset(asset: Asset, amount: String, purpose: String, date: String, note: String) =
        runAction("تم تسجيل الصيانة") {
            manageLifecycle.recordPayment(
                AssetPaymentRequest(asset.id, PaymentKind.AssetMaintenance, amount, purpose, date, note),
            )
        }

    fun updateAcquisition(asset: Asset, name: String, type: String, amount: String) =
        runAction("تم تعديل الأصل") { editAsset.acquisition(asset.id, name, type, amount) }

    fun updatePaymentEvent(operationId: String, amount: String, purpose: String, date: String, note: String) =
        runAction("تم تعديل العملية") { editAsset.payment(operationId, amount, purpose, date, note) }

    fun deleteOperation(operationId: String) =
        runAction("تم حذف العملية") { editAsset.deleteOperation(operationId) }

    private fun runAction(
        successMessage: String,
        operation: suspend () -> AssetCommandReceipt,
    ) = viewModelScope.launch {
        if (_actionState.value.busy) return@launch
        _actionState.value = AssetActionState(busy = true)
        runCatching { operation() }
            .onSuccess { _actionState.value = AssetActionState(message = successMessage) }
            .onFailure { error ->
                _actionState.value = AssetActionState(error = error.message ?: "تعذر تنفيذ العملية")
            }
    }
}

@HiltViewModel
class AssetDetailsViewModel @Inject constructor(
    observeDetails: ObserveAssetDetailsUseCase,
    private val manageLifecycle: ManageAssetLifecycleUseCase,
    private val editAsset: EditAssetUseCase,
) : ViewModel() {
    private val selectedAssetId = MutableStateFlow<String?>(null)
    val details: StateFlow<AssetDetails> = observeDetails(selectedAssetId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AssetDetails())

    private val _actionState = MutableStateFlow(AssetActionState())
    val actionState: StateFlow<AssetActionState> = _actionState

    fun selectAsset(assetId: String?) { selectedAssetId.value = assetId }
    fun clearActionMessage() = _actionState.update { AssetActionState(busy = it.busy) }

    fun improve(amount: String, purpose: String, date: String, note: String) = withAsset("تم تسجيل التحسين") { asset ->
        manageLifecycle.recordPayment(AssetPaymentRequest(asset.id, PaymentKind.AssetImprovement, amount, purpose, date, note))
    }

    fun maintain(amount: String, purpose: String, date: String, note: String) = withAsset("تم تسجيل الصيانة") { asset ->
        manageLifecycle.recordPayment(AssetPaymentRequest(asset.id, PaymentKind.AssetMaintenance, amount, purpose, date, note))
    }

    fun value(value: String, date: String, note: String) = withAsset("تم حفظ التقييم") { asset ->
        manageLifecycle.value(AssetValuationRequest(asset.id, value, date, note))
    }

    fun sell(amount: String, date: String, note: String) = withAsset("تم بيع الأصل") { asset ->
        manageLifecycle.sell(AssetSaleRequest(asset.id, amount, date, note))
    }

    fun addCurrencyLot(quantity: String, exchangeRate: String, localCost: String, date: String, note: String) =
        withAsset("تمت إضافة دفعة العملة") { asset ->
            manageLifecycle.addCurrencyLot(AddCurrencyLotRequest(asset.id, quantity, exchangeRate, localCost, date, note))
        }

    fun sellCurrency(quantity: String, localProceeds: String, date: String, note: String) =
        withAsset("تم بيع العملة") { asset ->
            manageLifecycle.sellCurrency(CurrencyAssetSaleRequest(asset.id, quantity, localProceeds, date, note))
        }

    fun updateAcquisition(name: String, type: String, amount: String) = withAsset("تم تعديل الأصل") { asset ->
        editAsset.acquisition(asset.id, name, type, amount)
    }

    fun updatePaymentEvent(operationId: String, amount: String, purpose: String, date: String, note: String) =
        runAction("تم تعديل العملية") { editAsset.payment(operationId, amount, purpose, date, note) }

    fun updateValuation(operationId: String, value: String, date: String, note: String) =
        runAction("تم تعديل التقييم") { editAsset.valuation(operationId, value, date, note) }

    fun updateSale(operationId: String, amount: String, date: String, note: String) =
        runAction("تم تعديل البيع") { editAsset.sale(operationId, amount, date, note) }

    fun deleteOperation(operationId: String) = runAction("تم حذف العملية") { editAsset.deleteOperation(operationId) }
    fun deleteValuation(operationId: String) = runAction("تم حذف التقييم") { editAsset.deleteValuation(operationId) }
    fun undoSale(operationId: String) = runAction("تم التراجع عن البيع") { editAsset.undoSale(operationId) }

    private fun withAsset(
        successMessage: String,
        operation: suspend (Asset) -> AssetCommandReceipt,
    ) = runAction(successMessage) {
        operation(details.value.asset ?: error("اختر أصلًا أولًا"))
    }

    private fun runAction(
        successMessage: String,
        operation: suspend () -> AssetCommandReceipt,
    ) = viewModelScope.launch {
        if (_actionState.value.busy) return@launch
        _actionState.value = AssetActionState(busy = true)
        runCatching { operation() }
            .onSuccess { _actionState.value = AssetActionState(message = successMessage) }
            .onFailure { error ->
                _actionState.value = AssetActionState(error = error.message ?: "تعذر تنفيذ العملية")
            }
    }
}

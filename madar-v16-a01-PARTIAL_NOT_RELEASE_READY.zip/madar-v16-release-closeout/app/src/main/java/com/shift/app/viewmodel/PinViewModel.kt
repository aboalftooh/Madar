package com.shift.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.utils.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PinViewModel @Inject constructor(private val prefs: PreferencesManager) : ViewModel() {

    val pin         = prefs.pin.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val pinEnabled: StateFlow<Boolean?> = prefs.pinEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val secQuestion = prefs.secQuestion.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "اسم حيوانك الأليف؟")
    val secAnswer   = prefs.secAnswer.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val failedAttempts = prefs.pinFailedAttempts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val lockedUntil = prefs.pinLockedUntil.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun setPin(v: String)         = viewModelScope.launch { prefs.setPin(v) }
    fun setPinEnabled(v: Boolean) = viewModelScope.launch { prefs.setPinEnabled(v) }
    fun setSecQuestion(v: String) = viewModelScope.launch { prefs.setSecQuestion(v) }
    fun setSecAnswer(v: String)   = viewModelScope.launch { prefs.setSecAnswer(v) }
    fun verifyPin(v: String): Boolean = !prefs.isPinTemporarilyLocked() && prefs.verifyPin(v)
    fun verifySecAnswer(v: String): Boolean = prefs.verifySecAnswer(v)

    fun recordFailedPinAttempt(onPenalty: (attempts: Int, lockedUntilMillis: Long) -> Unit) {
        viewModelScope.launch {
            val penalty = prefs.recordFailedPinAttempt()
            onPenalty(penalty.attempts, penalty.lockedUntilMillis)
        }
    }

    fun resetPinAttempts() = viewModelScope.launch { prefs.resetPinAttempts() }

    fun setRecoveredPin(pin: String, onComplete: () -> Unit) {
        viewModelScope.launch {
            prefs.setPin(pin)
            prefs.setPinEnabled(true)
            onComplete()
        }
    }
}

package com.shift.app.feature.goals.di

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.goals.FinancialChangeOutboxDao
import com.shift.app.data.local.dao.goals.FinancialGoalDao
import com.shift.app.data.local.dao.goals.GoalActivityDao
import com.shift.app.data.local.dao.goals.GoalConditionDao
import com.shift.app.data.local.dao.goals.GoalCostEstimateDao
import com.shift.app.data.local.dao.goals.GoalEvaluationDao
import com.shift.app.data.local.dao.goals.GoalFundingTransactionDao
import com.shift.app.data.local.dao.goals.GoalMetricDao
import com.shift.app.data.local.dao.goals.GoalScopeDao
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.domain.finance.BalanceCalculator
import com.shift.app.domain.finance.FinancialReportCalculator
import com.shift.app.domain.goals.evaluation.GoalMeasurementRegistry
import com.shift.app.domain.goals.measurement.AssetPurchaseMeasurementProvider
import com.shift.app.domain.goals.measurement.DebtPayoffMeasurementProvider
import com.shift.app.domain.goals.measurement.EmergencyFundMeasurementProvider
import com.shift.app.domain.goals.measurement.ExpenseGoalMeasurementProvider
import com.shift.app.domain.goals.measurement.IncomeGoalMeasurementProvider
import com.shift.app.domain.goals.measurement.NetWorthMeasurementProvider
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.feature.goals.data.GoalCompletionAdapter
import com.shift.app.feature.goals.data.GoalGatewayAdapter
import com.shift.app.feature.goals.domain.model.GoalAssetRow
import com.shift.app.feature.goals.domain.model.GoalAssetValuationRow
import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow
import com.shift.app.feature.goals.domain.model.GoalExpenseRow
import com.shift.app.feature.goals.domain.model.GoalIncomeRow
import com.shift.app.feature.goals.domain.model.GoalLegacyTransactionRow
import com.shift.app.feature.goals.domain.repository.GoalCompletionPort
import com.shift.app.feature.goals.domain.repository.GoalGateway
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import java.math.BigDecimal
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

@Module
@InstallIn(SingletonComponent::class)
abstract class GoalFeatureBindings {
    @Binds @Singleton abstract fun bindGoalGateway(impl: GoalGatewayAdapter): GoalGateway
    @Binds @Singleton abstract fun bindGoalCompletionPort(impl: GoalCompletionAdapter): GoalCompletionPort
}

@Module
@InstallIn(SingletonComponent::class)
object GoalFeatureModule {
    @Provides fun provideFinancialGoalDao(db: MadarDatabase): FinancialGoalDao = db.financialGoalDao()
    @Provides fun provideGoalMetricDao(db: MadarDatabase): GoalMetricDao = db.goalMetricDao()
    @Provides fun provideGoalConditionDao(db: MadarDatabase): GoalConditionDao = db.goalConditionDao()
    @Provides fun provideGoalScopeDao(db: MadarDatabase): GoalScopeDao = db.goalScopeDao()
    @Provides fun provideGoalFundingTransactionDao(db: MadarDatabase): GoalFundingTransactionDao = db.goalFundingTransactionDao()
    @Provides fun provideGoalCostEstimateDao(db: MadarDatabase): GoalCostEstimateDao = db.goalCostEstimateDao()
    @Provides fun provideGoalEvaluationDao(db: MadarDatabase): GoalEvaluationDao = db.goalEvaluationDao()
    @Provides fun provideGoalActivityDao(db: MadarDatabase): GoalActivityDao = db.goalActivityDao()
    @Provides fun provideFinancialChangeOutboxDao(db: MadarDatabase): FinancialChangeOutboxDao = db.financialChangeOutboxDao()

    @Provides @Singleton
    fun provideGoalMeasurementRegistry(
        transactionRepository: TransactionRepository,
        balanceDao: BalanceTransactionDao,
        paymentDao: PaymentDao,
        assetDao: AssetDao,
        valuationDao: AssetValuationDao,
        debtAccountDao: DebtAccountDao,
        debtTransactionDao: DebtTransactionDao,
    ): GoalMeasurementRegistry {
        val income = IncomeGoalMeasurementProvider {
            transactionRepository.getAllOnce().filter { it.type == "income" }.map {
                GoalIncomeRow(it.id, it.date, BigDecimal.valueOf(it.amount).setScale(2).toPlainString(), it.deletedAt)
            }
        }
        val expense = ExpenseGoalMeasurementProvider(
            payments = { paymentDao.getAllOnce().map { GoalExpenseRow(it.id, it.date, it.amountDecimal, it.kind, it.purpose, it.purposeKey, it.deletedAt) } },
            legacyTransactions = { transactionRepository.getAllOnce().map { GoalLegacyTransactionRow(it.id, it.date, BigDecimal.valueOf(it.amount).setScale(2).toPlainString(), it.type, it.balanceTransactionId, it.deletedAt) } },
        )
        val emergency = EmergencyFundMeasurementProvider {
            paymentDao.getAllOnce().map { GoalExpenseRow(it.id, it.date, it.amountDecimal, it.kind, it.purpose, it.purposeKey, it.deletedAt) }
        }
        val debt = DebtPayoffMeasurementProvider(
            accounts = { debtAccountDao.getActiveAccounts().first().map { GoalDebtAccountRow(it.id, it.direction, it.confirmed, it.createdAt, it.deletedAt) } },
            transactions = { debtTransactionDao.getActiveTransactions().first().map { GoalDebtTransactionRow(it.accountId, it.type, it.amountDecimal, it.occurredAt, it.deletedAt) } },
        )
        val netWorth = NetWorthMeasurementProvider(
            balanceTransactions = { balanceDao.getAllOnce().map { GoalBalanceRow(it.id, it.direction, it.amountDecimal, it.date, it.deletedAt) } },
            assets = { assetDao.getAllOnce().map { GoalAssetRow(it.id, it.status, it.acquisitionAmountDecimal, it.createdAt, it.deletedAt) } },
            valuations = { valuationDao.getAllOnce().map { GoalAssetValuationRow(it.id, it.assetId, it.valueDecimal, it.date, it.createdAt, it.deletedAt) } },
            debtAccounts = { debtAccountDao.getActiveAccounts().first().map { GoalDebtAccountRow(it.id, it.direction, it.confirmed, it.createdAt, it.deletedAt) } },
            debtTransactions = { debtTransactionDao.getActiveTransactions().first().map { GoalDebtTransactionRow(it.accountId, it.type, it.amountDecimal, it.occurredAt, it.deletedAt) } },
        )
        val assetPurchase = AssetPurchaseMeasurementProvider(
            realBalanceDecimal = { BalanceCalculator.currentBalance(balanceDao.getAllOnce()).setScale(2).toPlainString() },
            netWorthDecimal = {
                FinancialReportCalculator.wealth(
                    balanceDao.getAllOnce(), assetDao.getAllOnce(), valuationDao.getAllOnce(),
                    debtAccountDao.getActiveAccounts().first(), debtTransactionDao.getActiveTransactions().first(),
                ).netWorth.toPlainString()
            },
        )
        return GoalMeasurementRegistry().apply {
            register(MetricType.INCOME, income)
            register(MetricType.EXPENSE, expense)
            register(MetricType.EMERGENCY_COVERAGE, emergency)
            register(MetricType.DEBT_BALANCE, debt)
            register(MetricType.NET_WORTH, netWorth)
            register(MetricType.ALLOCATED_BALANCE, assetPurchase)
            register(MetricType.HOUSE_TO_NET_WORTH_RATIO, assetPurchase)
            register(MetricType.POST_PURCHASE_AVAILABLE_BALANCE, assetPurchase)
            register(MetricType.INSTALLMENT_AMOUNT, assetPurchase)
        }
    }
}

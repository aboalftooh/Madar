package com.shift.app.feature.assets.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.CairoFamily
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.feature.assets.domain.model.AssetSummary
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AssetCreateDialog(
    mode: AssetCreateMode,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String, String, String, String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val nameFocus = remember { FocusRequester() }
    val amountFocus = remember { FocusRequester() }
    val currencyCodeFocus = remember { FocusRequester() }
    val quantityFocus = remember { FocusRequester() }
    val exchangeRateFocus = remember { FocusRequester() }
    val noteFocus = remember { FocusRequester() }
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("other") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var note by remember { mutableStateOf("") }
    var currencyCode by remember { mutableStateOf("USD") }
    var quantity by remember { mutableStateOf("") }
    var exchangeRate by remember { mutableStateOf("") }
    var errors by remember { mutableStateOf(AssetCreateErrors()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    val isCurrency = type == FOREIGN_CURRENCY_ASSET_TYPE

    fun validate(): Boolean {
        val nextErrors = AssetCreateErrors(
            name = if (name.isBlank()) "أدخل اسم الأصل" else "",
            amount = if (amount.isBlank()) {
                if (isCurrency) "أدخل التكلفة المحلية" else "أدخل المبلغ"
            } else "",
            currencyCode = if (isCurrency && currencyCode.isBlank()) "أدخل رمز العملة" else "",
            quantity = if (isCurrency && quantity.isBlank()) "أدخل الكمية" else "",
            exchangeRate = if (isCurrency && exchangeRate.isBlank()) "أدخل سعر الصرف" else "",
            date = if (date.isBlank()) "اختر التاريخ" else ""
        )
        errors = nextErrors
        return listOf(
            nextErrors.name,
            nextErrors.amount,
            nextErrors.currencyCode,
            nextErrors.quantity,
            nextErrors.exchangeRate,
            nextErrors.date
        ).all { it.isBlank() }
    }

    fun submit() {
        if (!validate()) return
        focusManager.clearFocus()
        val initialValue = if (mode == AssetCreateMode.PREEXISTING) amount else ""
        onSave(name, type, amount, initialValue, date, note, currencyCode, quantity, exchangeRate)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text(if (mode == AssetCreateMode.PREEXISTING) "إضافة أصل سابق" else "شراء أصل", color = TextPrimary, fontFamily = CairoFamily) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (errors.name.isNotBlank()) errors = errors.copy(name = "")
                    },
                    label = { Text("اسم الأصل") },
                    modifier = Modifier.fillMaxWidth().focusRequester(nameFocus),
                    singleLine = true,
                    isError = errors.name.isNotBlank(),
                    supportingText = if (errors.name.isNotBlank()) {{ Text(errors.name) }} else null,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { amountFocus.requestFocus() })
                )
                AssetTypePicker(type, allowCurrency = mode == AssetCreateMode.PURCHASE) { type = it }
                OutlinedTextField(
                    value = amount,
                    onValueChange = {
                        amount = englishDigitsOnly(it)
                        if (errors.amount.isNotBlank()) errors = errors.copy(amount = "")
                    },
                    label = {
                        Text(
                            if (type == FOREIGN_CURRENCY_ASSET_TYPE) "التكلفة المحلية (SDG)"
                            else if (mode == AssetCreateMode.PREEXISTING) "قيمة الاقتناء"
                            else "مبلغ الشراء"
                        )
                    },
                    modifier = Modifier.fillMaxWidth().focusRequester(amountFocus),
                    singleLine = true,
                    isError = errors.amount.isNotBlank(),
                    supportingText = if (errors.amount.isNotBlank()) {{ Text(errors.amount) }} else null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {
                        if (isCurrency) currencyCodeFocus.requestFocus() else noteFocus.requestFocus()
                    })
                )
                if (isCurrency) {
                    OutlinedTextField(
                        value = currencyCode,
                        onValueChange = {
                            currencyCode = it.uppercase()
                            if (errors.currencyCode.isNotBlank()) errors = errors.copy(currencyCode = "")
                        },
                        label = { Text("رمز العملة") },
                        modifier = Modifier.fillMaxWidth().focusRequester(currencyCodeFocus),
                        singleLine = true,
                        isError = errors.currencyCode.isNotBlank(),
                        supportingText = if (errors.currencyCode.isNotBlank()) {{ Text(errors.currencyCode) }} else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { quantityFocus.requestFocus() })
                    )
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = {
                            quantity = englishDigitsOnly(it)
                            if (errors.quantity.isNotBlank()) errors = errors.copy(quantity = "")
                        },
                        label = { Text("الكمية المشتراة") },
                        modifier = Modifier.fillMaxWidth().focusRequester(quantityFocus),
                        singleLine = true,
                        isError = errors.quantity.isNotBlank(),
                        supportingText = if (errors.quantity.isNotBlank()) {{ Text(errors.quantity) }} else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { exchangeRateFocus.requestFocus() })
                    )
                    OutlinedTextField(
                        value = exchangeRate,
                        onValueChange = {
                            exchangeRate = englishDigitsOnly(it)
                            if (errors.exchangeRate.isNotBlank()) errors = errors.copy(exchangeRate = "")
                        },
                        label = { Text("سعر الصرف عند الشراء") },
                        modifier = Modifier.fillMaxWidth().focusRequester(exchangeRateFocus),
                        singleLine = true,
                        isError = errors.exchangeRate.isNotBlank(),
                        supportingText = if (errors.exchangeRate.isNotBlank()) {{ Text(errors.exchangeRate) }} else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { noteFocus.requestFocus() })
                    )
                }
                OutlinedTextField(
                    value = date,
                    onValueChange = {},
                    label = { Text("التاريخ") },
                    modifier = Modifier.fillMaxWidth().clickable { showDatePicker = true },
                    singleLine = true,
                    readOnly = true,
                    isError = errors.date.isNotBlank(),
                    supportingText = if (errors.date.isNotBlank()) {{ Text(errors.date) }} else null,
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Icon(Icons.Default.DateRange, contentDescription = "اختر التاريخ", tint = TextMuted)
                        }
                    }
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة") },
                    modifier = Modifier.fillMaxWidth().focusRequester(noteFocus),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() })
                )
            }
        },
        confirmButton = {
            Button(onClick = { submit() }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            date = Instant.ofEpochMilli(millis).atZone(ZoneId.of("UTC")).toLocalDate().toString()
                            if (errors.date.isNotBlank()) errors = errors.copy(date = "")
                        }
                        showDatePicker = false
                    }
                ) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } },
            colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
internal fun AssetEditDialog(asset: Asset, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember(asset) { mutableStateOf(asset.name) }
    var type by remember(asset) { mutableStateOf(asset.type) }
    var amount by remember(asset) { mutableStateOf(asset.acquisitionAmountDecimal) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("تعديل الأصل", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") })
                AssetTypePicker(type, allowCurrency = false) { type = it }
                OutlinedTextField(amount, { amount = it }, label = { Text("قيمة الاقتناء") })
            }
        },
        confirmButton = { Button(onClick = { onSave(name, type, amount) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
internal fun CurrencyLotDialog(
    currencyCode: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var quantity by remember { mutableStateOf("") }
    var exchangeRate by remember { mutableStateOf("") }
    var localCost by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("شراء دفعة $currencyCode", color = TextPrimary, fontFamily = CairoFamily) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(quantity, { quantity = it }, label = { Text("الكمية") }, singleLine = true)
                OutlinedTextField(exchangeRate, { exchangeRate = it }, label = { Text("سعر الصرف") }, singleLine = true)
                OutlinedTextField(localCost, { localCost = it }, label = { Text("التكلفة المحلية (SDG)") }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("التاريخ") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") })
                Text("تُحفظ كل دفعة بسعرها وتكلفتها مستقلّة", color = TextMuted, fontSize = 11.sp)
                if (error.isNotBlank()) Text(error, color = ExpenseRed, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (quantity.isBlank() || exchangeRate.isBlank() || localCost.isBlank() || date.isBlank()) {
                    error = "أكمل الكمية والسعر والتكلفة والتاريخ"
                } else {
                    onSave(quantity, exchangeRate, localCost, date, note)
                }
            }) { Text("حفظ الدفعة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
internal fun CurrencySaleDialog(
    currencyCode: String,
    availableQuantity: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var quantity by remember { mutableStateOf("") }
    var proceeds by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("بيع $currencyCode", color = TextPrimary, fontFamily = CairoFamily) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "المتاح: ${NumberDisplayFormatter.formatDecimalText(availableQuantity)} $currencyCode",
                    color = GoldPrimary,
                    fontFamily = CairoFamily
                )
                OutlinedTextField(quantity, { quantity = it }, label = { Text("الكمية المباعة") }, singleLine = true)
                OutlinedTextField(proceeds, { proceeds = it }, label = { Text("المبلغ المحلي المستلم (SDG)") }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("التاريخ") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") })
                Text("تُخصّص تكلفة البيع تلقائيًا من أقدم الدفعات (FIFO)", color = TextMuted, fontSize = 11.sp)
                if (error.isNotBlank()) Text(error, color = ExpenseRed, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val requested = quantity.toBigDecimalOrNull()
                val available = availableQuantity.toBigDecimalOrNull()
                when {
                    requested == null || requested.signum() <= 0 || proceeds.isBlank() || date.isBlank() -> {
                        error = "أدخل كمية ومبلغًا صحيحين والتاريخ"
                    }
                    available != null && requested > available -> {
                        error = "لا يمكن بيع كمية أكبر من المتاح"
                    }
                    else -> onSave(quantity, proceeds, date, note)
                }
            }) { Text("تأكيد البيع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AssetCommandDialog(
    command: AssetCommand,
    initialAmount: String = "",
    initialPurpose: String = "",
    initialDate: String = LocalDate.now().toString(),
    initialNote: String = "",
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val amountFocus = remember { FocusRequester() }
    val purposeFocus = remember { FocusRequester() }
    val noteFocus = remember { FocusRequester() }
    var amount by remember { mutableStateOf(moneyTextToWholeDigits(initialAmount)) }
    var purpose by remember { mutableStateOf(initialPurpose) }
    var date by remember { mutableStateOf(initialDate) }
    var note by remember { mutableStateOf(initialNote) }
    var errors by remember { mutableStateOf(AssetCommandErrors()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    val needsPurpose = command == AssetCommand.IMPROVE || command == AssetCommand.MAINTAIN

    fun validate(): Boolean {
        val nextErrors = AssetCommandErrors(
            amount = if (amount.isBlank()) {
                if (command == AssetCommand.VALUE) "أدخل القيمة" else "أدخل المبلغ"
            } else "",
            purpose = if (needsPurpose && purpose.isBlank()) "أدخل الوصف" else "",
            date = if (date.isBlank()) "اختر التاريخ" else ""
        )
        errors = nextErrors
        return listOf(nextErrors.amount, nextErrors.purpose, nextErrors.date).all { it.isBlank() }
    }

    fun submit() {
        if (!validate()) return
        focusManager.clearFocus()
        onSave(amount, purpose, date, note)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text(commandLabel(command), color = TextPrimary, fontFamily = CairoFamily) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = {
                        amount = englishDigitsOnly(it)
                        if (errors.amount.isNotBlank()) errors = errors.copy(amount = "")
                    },
                    label = { Text(if (command == AssetCommand.VALUE) "القيمة" else "المبلغ") },
                    modifier = Modifier.fillMaxWidth().focusRequester(amountFocus),
                    singleLine = true,
                    isError = errors.amount.isNotBlank(),
                    supportingText = if (errors.amount.isNotBlank()) {{ Text(errors.amount) }} else null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = if (needsPurpose) ImeAction.Next else ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(onNext = {
                        if (needsPurpose) purposeFocus.requestFocus() else noteFocus.requestFocus()
                    })
                )
                if (needsPurpose) {
                    OutlinedTextField(
                        value = purpose,
                        onValueChange = {
                            purpose = it
                            if (errors.purpose.isNotBlank()) errors = errors.copy(purpose = "")
                        },
                        label = { Text(if (command == AssetCommand.MAINTAIN) "وصف الصيانة" else "وصف التحسين") },
                        modifier = Modifier.fillMaxWidth().focusRequester(purposeFocus),
                        isError = errors.purpose.isNotBlank(),
                        supportingText = if (errors.purpose.isNotBlank()) {{ Text(errors.purpose) }} else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { noteFocus.requestFocus() })
                    )
                }
                OutlinedTextField(
                    value = date,
                    onValueChange = {},
                    label = { Text("التاريخ") },
                    modifier = Modifier.fillMaxWidth().clickable { showDatePicker = true },
                    singleLine = true,
                    readOnly = true,
                    isError = errors.date.isNotBlank(),
                    supportingText = if (errors.date.isNotBlank()) {{ Text(errors.date) }} else null,
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Icon(Icons.Default.DateRange, contentDescription = "اختر التاريخ", tint = TextMuted)
                        }
                    }
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة") },
                    modifier = Modifier.fillMaxWidth().focusRequester(noteFocus),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() })
                )
                if (command == AssetCommand.MAINTAIN) Text("يُسجل الأصل تلقائيًا كمرجع المستفيد", color = TextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(onClick = { submit() }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            date = Instant.ofEpochMilli(millis).atZone(ZoneId.of("UTC")).toLocalDate().toString()
                            if (errors.date.isNotBlank()) errors = errors.copy(date = "")
                        }
                        showDatePicker = false
                    }
                ) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } },
            colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
internal fun AssetTypePicker(selected: String, allowCurrency: Boolean, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }) { Text("النوع: ${assetTypeLabel(selected)}") }
        DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
            val types = listOf("car", "real_estate", "gold", "laptop", "phone", "other") +
                if (allowCurrency) listOf(FOREIGN_CURRENCY_ASSET_TYPE) else emptyList()
            types.forEach { type ->
                DropdownMenuItem(text = { Text(assetTypeLabel(type)) }, onClick = { expanded = false; onSelected(type) })
            }
        }
    }
}

@Composable
internal fun ActionSnackbar(state: AssetActionState, host: SnackbarHostState, consumed: () -> Unit) {
    LaunchedEffect(state.message, state.error) {
        val text = state.error ?: state.message ?: return@LaunchedEffect
        host.showSnackbar(text)
        consumed()
    }
}

internal fun commandLabel(command: AssetCommand) = when (command) {
    AssetCommand.IMPROVE -> "تحسين الأصل"
    AssetCommand.MAINTAIN -> "صيانة الأصل"
    AssetCommand.VALUE -> "تقييم الأصل"
    AssetCommand.SELL -> "بيع الأصل كاملًا"
}

internal fun assetTypeLabel(type: String) = when (type) {
    "car" -> "سيارة"
    "real_estate" -> "عقار"
    "gold" -> "ذهب"
    FOREIGN_CURRENCY_ASSET_TYPE -> "عملة أجنبية"
    "laptop" -> "حاسوب"
    "phone" -> "هاتف"
    else -> "أخرى"
}

internal fun assetStatusLabel(status: String) = when (status) {
    AssetStatus.Active.dbValue -> "نشط"
    AssetStatus.Sold.dbValue -> "مباع"
    else -> "غير متاح"
}

internal fun assetTransactionLabel(kind: String) = when (kind) {
    AssetTransactionKind.Purchase.dbValue -> "شراء الأصل"
    AssetTransactionKind.PreexistingAdd.dbValue -> "إضافة أصل سابق"
    AssetTransactionKind.Improvement.dbValue -> "تحسين"
    AssetTransactionKind.Maintenance.dbValue -> "صيانة"
    AssetTransactionKind.SaleFull.dbValue -> "بيع كامل"
    AssetTransactionKind.SalePartial.dbValue -> "بيع جزئي"
    AssetTransactionKind.Reversal.dbValue -> "عملية عكس"
    else -> kind
}

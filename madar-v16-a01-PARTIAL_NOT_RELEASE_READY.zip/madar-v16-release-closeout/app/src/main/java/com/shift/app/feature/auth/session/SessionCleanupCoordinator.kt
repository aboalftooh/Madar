package com.shift.app.feature.auth.session

import com.shift.app.feature.auth.domain.AccountLocalDataCleaner
import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionCleanup
import com.shift.app.feature.auth.domain.SessionSyncGateway
import com.shift.app.feature.auth.domain.SessionSyncResult
import com.shift.app.feature.auth.domain.SessionWorkController
import com.shift.app.feature.auth.domain.SessionWriter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionCleanupCoordinator @Inject constructor(
    private val authGateway: AuthGateway,
    private val sessionWriter: SessionWriter,
    private val sessionSyncGateway: SessionSyncGateway,
    private val localDataCleaner: AccountLocalDataCleaner,
    private val sessionWorkController: SessionWorkController,
) : SessionCleanup {
    override suspend fun logout(discardUnsyncedChanges: Boolean): LogoutResult {
        if (!discardUnsyncedChanges) {
            when (val syncResult = sessionSyncGateway.synchronizePendingChanges()) {
                SessionSyncResult.Success -> Unit
                is SessionSyncResult.PartialFailure -> {
                    return LogoutResult.Blocked(syncResult.failedSteps)
                }
                SessionSyncResult.AuthenticationRequired -> {
                    return LogoutResult.Blocked(
                        failedSteps = listOf("authentication_required"),
                        authenticationRequired = true,
                    )
                }
            }
        }

        return try {
            sessionSyncGateway.withExclusiveSession {
                sessionWorkController.cancelAndAwaitSessionWork()
                localDataCleaner.clearAccountData()
                sessionWriter.clearAccountScopedState()
                try {
                    authGateway.signOut()
                } catch (_: Exception) {
                    authGateway.clearLocalAuthSession()
                }
            }
            LogoutResult.Completed
        } catch (error: Exception) {
            LogoutResult.Failed(error)
        }
    }
}

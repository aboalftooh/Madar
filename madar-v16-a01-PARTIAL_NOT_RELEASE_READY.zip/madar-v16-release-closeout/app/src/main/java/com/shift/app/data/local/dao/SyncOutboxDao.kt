package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.shift.app.data.local.entities.SyncOutboxEntity
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SyncOutboxDao {
    @Query(
        """
        SELECT * FROM sync_outbox
        WHERE state IN ('pending', 'failed') AND nextAttemptAt <= :now
        ORDER BY createdAt ASC
        LIMIT :limit
        """,
    )
    abstract suspend fun getReady(now: Long, limit: Int): List<SyncOutboxEntity>

    @Query("SELECT COUNT(*) FROM sync_outbox WHERE state IN ('pending', 'failed')")
    abstract fun observePendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_outbox WHERE state IN ('pending', 'failed')")
    abstract suspend fun pendingCount(): Int

    @Query("SELECT COUNT(*) FROM sync_outbox WHERE state = 'failed'")
    abstract fun observeFailedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    protected abstract suspend fun insertIfAbsent(event: SyncOutboxEntity): Long

    @Query(
        """
        UPDATE sync_outbox
        SET entityType = :entityType,
            entityId = :entityId,
            operationId = :operationId,
            updatedAt = :updatedAt,
            state = 'pending',
            attemptCount = 0,
            nextAttemptAt = :nextAttemptAt,
            lastError = NULL,
            revision = revision + 1
        WHERE eventId = :eventId
        """,
    )
    protected abstract suspend fun touch(
        eventId: String,
        entityType: String,
        entityId: String,
        operationId: String,
        updatedAt: Long,
        nextAttemptAt: Long,
    ): Int

    /** INSERT + revision bump is atomic and coalesces repeated wake-ups by eventId. */
    @Transaction
    open suspend fun enqueue(event: SyncOutboxEntity) {
        insertIfAbsent(event.copy(revision = 0L))
        touch(
            eventId = event.eventId,
            entityType = event.entityType,
            entityId = event.entityId,
            operationId = event.operationId,
            updatedAt = event.updatedAt,
            nextAttemptAt = event.nextAttemptAt,
        )
    }

    @Query("DELETE FROM sync_outbox WHERE eventId = :eventId AND revision = :expectedRevision")
    abstract suspend fun deleteIfUnchanged(eventId: String, expectedRevision: Long): Int

    @Query(
        """
        UPDATE sync_outbox
        SET state = 'failed',
            attemptCount = :attemptCount,
            nextAttemptAt = :nextAttemptAt,
            lastError = :lastError,
            updatedAt = :updatedAt
        WHERE eventId = :eventId AND revision = :expectedRevision
        """,
    )
    abstract suspend fun markFailedIfUnchanged(
        eventId: String,
        expectedRevision: Long,
        attemptCount: Int,
        nextAttemptAt: Long,
        lastError: String,
        updatedAt: Long,
    ): Int

    @Query("DELETE FROM sync_outbox WHERE entityType = :entityType AND entityId = :entityId")
    abstract suspend fun deleteForEntity(entityType: String, entityId: String)

    @Query("DELETE FROM sync_outbox WHERE operationId = :operationId")
    abstract suspend fun deleteForOperation(operationId: String)

    @Query("DELETE FROM sync_outbox")
    abstract suspend fun deleteAll()
}

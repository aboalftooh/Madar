package com.shift.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.ui.theme.AccentBlue
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.viewmodel.LegacyHistoryMigrationViewModel

@Composable
fun LegacyHistoryMigrationWizard(vm: LegacyHistoryMigrationViewModel) {
    val state by vm.state.collectAsState()
    val marker = state.marker
    if (!state.activated) {
        Text("فعّل سجل الرصيد أولًا. الترحيل الكامل اختياري ولا يعمل تلقائيًا.", color = TextMuted)
        return
    }
    if (marker != null) {
        Text(
            if (marker.status == "completed") "تم ترحيل التاريخ الكامل وحمايته من التكرار."
            else "توجد حالة تعارض في ترحيل التاريخ؛ نفّذ المزامنة قبل أي تعديل.",
            color = if (marker.status == "completed") IncomeGreen else ExpenseRed,
            fontWeight = FontWeight.Bold
        )
        Text(
            "المعاملات: ${NumberDisplayFormatter.format(marker.candidateCount)} • التسوية: ${NumberDisplayFormatter.formatDecimalText(marker.adjustmentDecimal)}",
            color = TextMuted,
            fontSize = 12.sp
        )
        return
    }

    Text(
        "استخدم هذا المسار فقط إذا كانت سجلات الدخل والمصروف القديمة مكتملة.",
        color = TextMuted,
        fontSize = 13.sp
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(
            checked = state.recordsCompleteConfirmed,
            onCheckedChange = vm::setRecordsCompleteConfirmed,
            enabled = !state.busy
        )
        Text("أؤكد أن سجلاتي القديمة مكتملة", color = TextPrimary)
    }
    Button(
        onClick = vm::startPreview,
        enabled = state.recordsCompleteConfirmed && !state.busy,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
    ) { Text("إنشاء المعاينة") }

    state.preview?.let { preview ->
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                "دخل قديم: ${NumberDisplayFormatter.formatDecimalText(preview.historicalIncomeDecimal)} • مصروف قديم: ${NumberDisplayFormatter.formatDecimalText(preview.historicalExpenseDecimal)}",
                color = TextPrimary,
                fontSize = 13.sp
            )
            Text(
                "الرصيد المتوقع قبل التسوية: ${NumberDisplayFormatter.formatDecimalText(preview.projectedBalanceDecimal)}",
                color = TextMuted,
                fontSize = 13.sp
            )
            Text(
                "المعاملات المرشحة: ${NumberDisplayFormatter.format(preview.candidateCount)} (${NumberDisplayFormatter.format(preview.incomeCount)} دخل، ${NumberDisplayFormatter.format(preview.expenseCount)} مصروف)",
                color = TextMuted,
                fontSize = 12.sp
            )
            Text(
                "الديون المرشحة: ${NumberDisplayFormatter.format(state.debtCandidateCount)} • تحتاج مراجعة: ${NumberDisplayFormatter.format(state.debtReviewCount)}",
                color = if (state.debtReviewCount > 0) ExpenseRed else TextMuted,
                fontSize = 12.sp
            )
            OutlinedTextField(
                value = state.targetBalanceInput,
                onValueChange = vm::setTargetBalance,
                label = { Text("الرصيد الحقيقي الحالي") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors()
            )
            Button(
                onClick = vm::refreshAdjustmentPreview,
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text("تحديث حساب التسوية") }
            Text(
                "حركة التسوية المطلوبة: ${NumberDisplayFormatter.formatDecimalText(preview.adjustmentDecimal)}",
                color = if (preview.adjustmentDecimal.startsWith("-")) ExpenseRed else IncomeGreen,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = state.adjustmentConfirmed,
                    onCheckedChange = vm::setAdjustmentConfirmed,
                    enabled = !state.busy
                )
                Spacer(Modifier.width(4.dp))
                Text("راجعت الرصيد والتسوية وأوافق على التنفيذ", color = TextPrimary)
            }
            Button(
                onClick = vm::execute,
                enabled = state.recordsCompleteConfirmed && state.adjustmentConfirmed && !state.busy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
            ) {
                if (state.busy) {
                    CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("تنفيذ التحويل المالي الكامل", fontWeight = FontWeight.Bold)
            }
        }
    }
    state.message?.let { Text(it, color = IncomeGreen, fontSize = 13.sp) }
    state.error?.let { Text(it, color = ExpenseRed, fontSize = 13.sp) }
}

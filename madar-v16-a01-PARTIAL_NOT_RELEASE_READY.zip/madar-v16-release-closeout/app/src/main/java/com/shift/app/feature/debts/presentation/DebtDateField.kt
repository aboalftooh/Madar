package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.clickable
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun DebtDateField(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    onOpenPicker: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = {},
        readOnly = true,
        label = { Text(label) },
        singleLine = true,
        supportingText = { Text("النقر يفتح منتقي التاريخ") },
        modifier = modifier.clickable { onOpenPicker() }
    )
}

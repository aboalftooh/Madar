package com.shift.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.utils.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferences: PreferencesManager,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : ViewModel() {
    val userName = preferences.userName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")
    val workType = preferences.workType
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "وظيفة قطاع خاص")
    val balanceActivated = preferences.balanceActivated
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)
    val balanceActivatedAt = preferences.balanceActivatedAt
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val localCurrencyCode = preferences.localCurrencyCode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "SDG")

    fun setProfileSettings(name: String, workType: String) = viewModelScope.launch {
        syncManager.executeSessionOperation {
            preferences.setUserName(name)
            preferences.setWorkType(workType)
            syncQueue.requestSync("profile-settings")
        }
    }
}

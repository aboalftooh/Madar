package com.shift.app.data.remote.goals

import com.shift.app.data.backup.GoalActivityBackup
import com.shift.app.data.backup.GoalConditionBackup
import com.shift.app.data.backup.GoalCostEstimateBackup
import com.shift.app.data.backup.GoalEvaluationBackup
import com.shift.app.data.backup.GoalFundingTransactionBackup
import com.shift.app.data.backup.GoalMetricBackup
import com.shift.app.data.backup.GoalScopeBackup
import com.shift.app.data.backup.GoalBackup
import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.data.local.entities.goals.GoalActivityEntity
import com.shift.app.data.local.entities.goals.GoalConditionEntity
import com.shift.app.data.local.entities.goals.GoalCostEstimateEntity
import com.shift.app.data.local.entities.goals.GoalEvaluationEntity
import com.shift.app.data.local.entities.goals.GoalFundingTransactionEntity
import com.shift.app.data.local.entities.goals.GoalMetricEntity
import com.shift.app.data.local.entities.goals.GoalScopeEntity
import com.shift.app.domain.finance.SyncState
import java.time.Instant

object GoalSyncMapper {
    fun Long.toRemoteTime(): String = Instant.ofEpochMilli(this).toString()
    fun String?.toLocalTime(): Long = this?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() } ?: 0L

    fun FinancialGoalEntity.toRemote(uid: String) = RemoteFinancialGoal(
        id, uid, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId,
        targetDecimal, baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson,
        revision, readyAt?.toRemoteTime(), completedAt?.toRemoteTime(), cancelledAt?.toRemoteTime(),
        archivedAt?.toRemoteTime(), SyncState.Synced.dbValue, createdAt.toRemoteTime(), updatedAt.toRemoteTime(),
        deletedAt?.toRemoteTime()
    )

    fun GoalMetricEntity.toRemote(uid: String) = RemoteGoalMetric(
        id, uid, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal,
        SyncState.Synced.dbValue, createdAt.toRemoteTime(), updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun GoalConditionEntity.toRemote(uid: String) = RemoteGoalCondition(
        id, uid, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal,
        SyncState.Synced.dbValue, createdAt.toRemoteTime(), updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun GoalScopeEntity.toRemote(uid: String) = RemoteGoalScope(
        id, uid, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, SyncState.Synced.dbValue,
        createdAt.toRemoteTime(), updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun GoalFundingTransactionEntity.toRemote(uid: String) = RemoteGoalFundingTransaction(
        id, uid, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId,
        relatedFundingTransactionId, note, occurredAt.toRemoteTime(), SyncState.Synced.dbValue,
        createdAt.toRemoteTime(), updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun GoalCostEstimateEntity.toRemote(uid: String) = RemoteGoalCostEstimate(
        id, uid, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note,
        effectiveAt.toRemoteTime(), SyncState.Synced.dbValue, createdAt.toRemoteTime(), updatedAt.toRemoteTime(),
        deletedAt?.toRemoteTime()
    )

    fun GoalEvaluationEntity.toRemote(uid: String) = RemoteGoalEvaluation(
        id, uid, goalId, asOf.toRemoteTime(), engineVersion, inputFingerprint, lifecycleStatus, healthStatus,
        measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt.toRemoteTime(),
        updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun GoalActivityEntity.toRemote(uid: String) = RemoteGoalActivity(
        id, uid, goalId, operationId, type, occurredAt.toRemoteTime(), effectiveDate, detailsJson,
        SyncState.Synced.dbValue, createdAt.toRemoteTime(), updatedAt.toRemoteTime(), deletedAt?.toRemoteTime()
    )

    fun RemoteFinancialGoal.toLocal() = FinancialGoalEntity(
        id, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId, targetDecimal,
        baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson, revision,
        readyAt.toLocalTime().takeIf { it > 0L }, completedAt.toLocalTime().takeIf { it > 0L },
        cancelledAt.toLocalTime().takeIf { it > 0L }, archivedAt.toLocalTime().takeIf { it > 0L },
        createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L },
        SyncState.Synced.dbValue
    )

    fun RemoteGoalMetric.toLocal() = GoalMetricEntity(id, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal, createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)
    fun RemoteGoalCondition.toLocal() = GoalConditionEntity(id, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal, createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)
    fun RemoteGoalScope.toLocal() = GoalScopeEntity(id, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)
    fun RemoteGoalFundingTransaction.toLocal() = GoalFundingTransactionEntity(id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId, relatedFundingTransactionId, note, occurredAt.toLocalTime(), createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)
    fun RemoteGoalCostEstimate.toLocal() = GoalCostEstimateEntity(id, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note, effectiveAt.toLocalTime(), createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)
    fun RemoteGoalEvaluation.toLocal() = GoalEvaluationEntity(id, goalId, asOf.toLocalTime(), engineVersion, inputFingerprint, lifecycleStatus, healthStatus, measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L })
    fun RemoteGoalActivity.toLocal() = GoalActivityEntity(id, goalId, operationId, type, occurredAt.toLocalTime(), effectiveDate, detailsJson, createdAt.toLocalTime(), updatedAt.toLocalTime(), deletedAt.toLocalTime().takeIf { it > 0L }, SyncState.Synced.dbValue)

    fun GoalBackup.toEntity() = FinancialGoalEntity(id, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId, targetDecimal, baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson, revision, readyAt, completedAt, cancelledAt, archivedAt, createdAt, updatedAt, deletedAt, syncState)
    fun GoalMetricBackup.toEntity() = GoalMetricEntity(id, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
    fun GoalConditionBackup.toEntity() = GoalConditionEntity(id, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
    fun GoalScopeBackup.toEntity() = GoalScopeEntity(id, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, createdAt, updatedAt, deletedAt, syncState)
    fun GoalFundingTransactionBackup.toEntity() = GoalFundingTransactionEntity(id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId, relatedFundingTransactionId, note, occurredAt, createdAt, updatedAt, deletedAt, syncState)
    fun GoalCostEstimateBackup.toEntity() = GoalCostEstimateEntity(id, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note, effectiveAt, createdAt, updatedAt, deletedAt, syncState)
    fun GoalEvaluationBackup.toEntity() = GoalEvaluationEntity(id, goalId, asOf, engineVersion, inputFingerprint, lifecycleStatus, healthStatus, measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt, updatedAt, deletedAt)
    fun GoalActivityBackup.toEntity() = GoalActivityEntity(id, goalId, operationId, type, occurredAt, effectiveDate, detailsJson, createdAt, updatedAt, deletedAt, syncState)
}

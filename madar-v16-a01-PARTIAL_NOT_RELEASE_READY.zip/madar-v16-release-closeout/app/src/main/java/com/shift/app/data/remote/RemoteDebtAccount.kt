package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteDebtAccount(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("operation_id") val operationId: String,
    val direction: String,
    @SerialName("party_name") val partyName: String,
    @SerialName("party_key") val partyKey: String,
    @SerialName("currency_code") val currencyCode: String,
    val description: String = "",
    @SerialName("due_date") val dueDate: String? = null,
    val confirmed: Boolean = true,
    @SerialName("archived_at") val archivedAt: Long? = null,
    @SerialName("closed_at") val closedAt: Long? = null,
    @SerialName("close_reason") val closeReason: String? = null,
    @SerialName("legacy_debt_id") val legacyDebtId: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null
)

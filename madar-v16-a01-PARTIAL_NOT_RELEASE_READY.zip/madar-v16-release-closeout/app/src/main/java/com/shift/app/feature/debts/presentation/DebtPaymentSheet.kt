package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.input.ImeAction
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtMoney

data class DebtReductionSheetState(
    val accountId: String,
    val remainingDecimal: String,
    val amountDecimal: String,
    val cashSource: DebtCashSource,
    val submitted: Boolean = false
) {
    fun validationError(): String? = when {
        accountId.isBlank() -> "الحساب مطلوب"
        amountDecimal.isBlank() -> "المبلغ مطلوب"
        runCatching { DebtMoney.of(amountDecimal).value > DebtMoney.of(remainingDecimal).value }.getOrDefault(true) -> "المبلغ أكبر من المتبقي"
        else -> null
    }
}

@Composable
fun DebtPaymentSheet(
    state: DebtReductionSheetState,
    onAmountChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column {
        Text("سداد")
        DebtMoneyField(state.amountDecimal, onAmountChange, "المبلغ", ImeAction.Done, onDone = {
            if (state.validationError() == null && !state.submitted) onSubmit()
        })
        if (state.cashSource == DebtCashSource.External) Text("سيتم تسجيل السداد من مصدر خارجي")
        Button(enabled = state.validationError() == null && !state.submitted, onClick = onSubmit) { Text("حفظ السداد") }
    }
}

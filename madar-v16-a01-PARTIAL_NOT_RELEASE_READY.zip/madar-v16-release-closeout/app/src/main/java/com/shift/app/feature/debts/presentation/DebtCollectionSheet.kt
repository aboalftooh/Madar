package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.shift.app.domain.debt.DebtCashSource

@Composable
fun DebtCollectionSheet(
    state: DebtReductionSheetState,
    onAmountChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column {
        Text("تحصيل")
        DebtMoneyField(state.amountDecimal, onAmountChange, "المبلغ", onDone = {
            if (state.validationError() == null && !state.submitted) onSubmit()
        })
        if (state.cashSource == DebtCashSource.External) Text("سيتم تسجيل التحصيل إلى وجهة خارجية")
        Button(enabled = state.validationError() == null && !state.submitted, onClick = onSubmit) { Text("حفظ التحصيل") }
    }
}

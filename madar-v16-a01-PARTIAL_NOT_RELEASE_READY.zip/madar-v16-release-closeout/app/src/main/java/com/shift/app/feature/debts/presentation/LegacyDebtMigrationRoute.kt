package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun LegacyDebtMigrationRoute(pendingReviews: Int, resolvedReviews: Int) {
    Column {
        Text("مراجعة ترحيل الديون القديمة")
        Text("بانتظار المراجعة: $pendingReviews")
        Text("تمت معالجتها: $resolvedReviews")
    }
}

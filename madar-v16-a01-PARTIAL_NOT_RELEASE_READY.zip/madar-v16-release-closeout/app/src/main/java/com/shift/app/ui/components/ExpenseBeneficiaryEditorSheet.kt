package com.shift.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.ui.theme.AccentBlue
import com.shift.app.ui.theme.CairoFamily
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.viewmodel.TransactionsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseBeneficiaryEditorSheet(
    vm: TransactionsViewModel,
    editItem: ExpenseBeneficiary? = null,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val focusManager = LocalFocusManager.current
    var name by remember(editItem) { mutableStateOf(editItem?.name.orEmpty()) }
    var nameError by remember { mutableStateOf("") }

    fun save() {
        val displayName = ExpenseTextNormalizer.displayText(name)
        nameError = if (displayName.isBlank()) "اسم المستفيد مطلوب" else ""
        if (nameError.isNotBlank()) return

        val beneficiary = editItem?.copy(name = displayName) ?: ExpenseBeneficiary(name = displayName)
        if (editItem == null) vm.addExpenseBeneficiary(beneficiary) else vm.updateExpenseBeneficiary(beneficiary)
        onDismiss()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .padding(horizontal = 24.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                if (editItem == null) "إضافة مستفيد" else "تعديل مستفيد",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily
            )
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    nameError = ""
                },
                label = { Text("اسم المستفيد", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                isError = nameError.isNotBlank(),
                supportingText = if (nameError.isNotBlank()) {{ Text(nameError, color = ExpenseRed) }} else null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                    save()
                })
            )
            Spacer(Modifier.height(2.dp))
            Button(
                onClick = { save() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Text("حفظ", fontWeight = FontWeight.Bold)
            }
        }
    }
}

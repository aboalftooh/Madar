package com.shift.app.ui.screens.plans

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.ui.screens.BudgetContent
import com.shift.app.feature.goals.presentation.GoalsListScreen
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun PlansScreen(
    financialGoalsEnabled: Boolean,
) {
    val pagerState = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val tabs = listOf("الميزانية", "الأهداف")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Text(
            text = "الخطط",
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 8.dp),
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        ScrollableTabRow(
            selectedTabIndex = pagerState.currentPage,
            edgePadding = 20.dp,
            containerColor = SurfaceDark,
            contentColor = GoldPrimary,
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = pagerState.currentPage == index,
                    onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                    selectedContentColor = GoldPrimary,
                    unselectedContentColor = TextMuted,
                    text = { Text(title, fontWeight = FontWeight.SemiBold) },
                )
            }
        }
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            when (page) {
                0 -> BudgetContent(includeTitle = false)
                1 -> GoalsListScreen(financialGoalsEnabled = financialGoalsEnabled)
            }
        }
    }

    LaunchedEffect(financialGoalsEnabled) {
        if (financialGoalsEnabled) return@LaunchedEffect
        if (pagerState.currentPage == 1) pagerState.animateScrollToPage(0)
    }
}

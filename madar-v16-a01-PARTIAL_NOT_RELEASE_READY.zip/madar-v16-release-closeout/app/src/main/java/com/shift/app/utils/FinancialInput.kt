package com.shift.app.utils

/** قواعد إدخال موحدة للحقول المالية التي تقبل الأرقام الإنجليزية الصحيحة فقط. */
object FinancialInput {
    fun englishDigitsOnly(value: String): String = value.filter { it in '0'..'9' }

    fun isPositiveEnglishAmount(value: String): Boolean =
        value.isNotEmpty() && value.all { it in '0'..'9' } && value.any { it != '0' }
}

package com.shift.app.sync.participant

import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.sync.remote.AssetRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.data.remote.shouldPushFinancialRecord
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AssetSyncParticipant @Inject constructor(
    private val assetDao: AssetDao,
    private val transactionDao: AssetTransactionDao,
    private val valuationDao: AssetValuationDao,
    private val lotDao: CurrencyAssetLotDao,
    private val allocationDao: CurrencyAssetSaleAllocationDao,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val assetOperationIndex: RoomAssetOperationIndex,
    private val remote: AssetRemoteSync,
) : SyncParticipant {
    override val key: String = "assets"
    override val order: Int = 30

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_assets", SyncCheckpointKey.Assets) { remote.pullAssets() },
        SyncOperation("pull_asset_transactions", SyncCheckpointKey.AssetTransactions) {
            remote.pullAssetTransactions()
        },
        SyncOperation("pull_asset_valuations", SyncCheckpointKey.AssetValuations) {
            remote.pullAssetValuations()
        },
        SyncOperation("pull_currency_asset_lots", SyncCheckpointKey.CurrencyAssetLots) {
            remote.pullCurrencyAssetLots()
        },
        SyncOperation(
            "pull_currency_asset_sale_allocations",
            SyncCheckpointKey.CurrencyAssetSaleAllocations,
        ) { remote.pullCurrencyAssetSaleAllocations() },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> {
        val allAssets = assetDao.getAllOnce()
        val allTransactions = transactionDao.getAllOnce()
        val allValuations = valuationDao.getAllOnce()
        val allLots = lotDao.getAllOnce()
        val allAllocations = allocationDao.getAllOnce()
        val allBalances = balanceDao.getAllOnce()
        val allPayments = paymentDao.getAllOnce()

        val changedAssets = allAssets.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedTransactions = allTransactions.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedValuations = allValuations.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedLots = allLots.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedAllocations = allAllocations.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }

        val transactionsByOperation = allTransactions.groupBy { it.operationId }
        val valuationsByOperation = allValuations.groupBy { it.operationId }
        val lotsByOperation = allLots.groupBy { it.operationId }
        val allocationsByOperation = allAllocations.groupBy { it.operationId }
        val balancesByOperation = allBalances.groupBy { it.operationId }
        val paymentsByOperation = allPayments.groupBy { it.operationId }
        val assetsById = allAssets.associateBy { it.id }
        val assetsByOperation = allAssets.filter { it.operationId != null }.groupBy { it.operationId!! }
        val knownAssetOperationIds = assetOperationIndex.readOperationIds()

        return buildList {
            val ungroupedAssets = changedAssets.filter { it.operationId == null }
            if (ungroupedAssets.isNotEmpty()) {
                add(SyncOperation("push_assets") { remote.pushAssets(ungroupedAssets) })
            }

            val operationIds = buildSet {
                addAll(changedTransactions.map { it.operationId })
                addAll(changedValuations.map { it.operationId })
                addAll(changedLots.map { it.operationId })
                addAll(changedAllocations.map { it.operationId })
                addAll(changedAssets.mapNotNull { it.operationId })
                addAll(allBalances.asSequence()
                    .filter { balance ->
                        balance.operationId in knownAssetOperationIds &&
                            shouldPushFinancialRecord(balance.updatedAt, balance.syncState, lastSuccessfulSync)
                    }
                    .map { it.operationId })
                addAll(allPayments.asSequence()
                    .filter { payment ->
                        payment.operationId in knownAssetOperationIds &&
                            shouldPushFinancialRecord(payment.updatedAt, payment.syncState, lastSuccessfulSync)
                    }
                    .map { it.operationId })
            }

            operationIds.sorted().forEach { operationId ->
                val transactions = transactionsByOperation[operationId].orEmpty()
                val valuations = valuationsByOperation[operationId].orEmpty()
                val lots = lotsByOperation[operationId].orEmpty()
                val allocations = allocationsByOperation[operationId].orEmpty()
                val payments = paymentsByOperation[operationId].orEmpty()
                val balances = balancesByOperation[operationId].orEmpty()
                val referencedAssetIds = buildSet {
                    addAll(transactions.map { it.assetId })
                    addAll(valuations.map { it.assetId })
                    addAll(lots.map { it.assetId })
                    addAll(allocations.map { it.assetId })
                    addAll(payments.mapNotNull { it.assetId })
                }
                val assets = buildMap {
                    referencedAssetIds.mapNotNull(assetsById::get).forEach { put(it.id, it) }
                    assetsByOperation[operationId].orEmpty()
                        .filter { it in changedAssets }
                        .forEach { put(it.id, it) }
                }.values.toList()

                add(SyncOperation("push_asset_operation:$operationId") {
                    remote.pushAssetOperation(
                        assets = assets,
                        transactions = transactions,
                        valuations = valuations,
                        balanceTransactions = balances,
                        payments = payments,
                        currencyLots = lots,
                        currencySaleAllocations = allocations,
                    )
                })
            }
        }
    }
}

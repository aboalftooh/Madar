package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.IncomeSource
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeSourceDao {
    @Query("SELECT * FROM income_sources WHERE deletedAt IS NULL ORDER BY name COLLATE NOCASE ASC")
    fun getAll(): Flow<List<IncomeSource>>

    @Query("SELECT * FROM income_sources")
    suspend fun getAllOnce(): List<IncomeSource>

    @Query("SELECT * FROM income_sources WHERE deletedAt IS NULL")
    suspend fun getActiveOnce(): List<IncomeSource>

    @Query("SELECT * FROM income_sources WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): IncomeSource?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(source: IncomeSource)

    @Update
    suspend fun update(source: IncomeSource)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<IncomeSource>)

    @Query("DELETE FROM income_sources")
    suspend fun deleteAll()

    @Query("SELECT DISTINCT paymentMethod FROM income_sources WHERE deletedAt IS NULL AND paymentMethod != '' ORDER BY paymentMethod COLLATE NOCASE ASC")
    fun paymentMethodSuggestions(): Flow<List<String>>
}

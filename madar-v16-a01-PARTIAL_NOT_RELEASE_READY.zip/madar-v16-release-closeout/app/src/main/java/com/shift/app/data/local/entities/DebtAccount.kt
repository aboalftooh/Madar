package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "debt_accounts",
    indices = [
        Index(value = ["direction", "deletedAt"]),
        Index(value = ["partyKey"]),
        Index(value = ["operationId"]),
        Index(value = ["syncState", "updatedAt"])
    ]
)
data class DebtAccount(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val direction: String,
    val partyName: String,
    val partyKey: String,
    val currencyCode: String = "SDG",
    val description: String = "",
    val dueDate: String? = null,
    val confirmed: Boolean = true,
    val archivedAt: Long? = null,
    val closedAt: Long? = null,
    val closeReason: String? = null,
    val legacyDebtId: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
) {
    constructor(
        operationId: String,
        direction: DebtDirection,
        partyName: String,
        currencyCode: String = "SDG",
        description: String = "",
        dueDate: String? = null,
        confirmed: Boolean = true
    ) : this(
        operationId = operationId,
        direction = direction.dbValue,
        partyName = partyName.trim(),
        partyKey = partyName.trim().lowercase(),
        currencyCode = currencyCode,
        description = description,
        dueDate = dueDate,
        confirmed = confirmed
    )
}

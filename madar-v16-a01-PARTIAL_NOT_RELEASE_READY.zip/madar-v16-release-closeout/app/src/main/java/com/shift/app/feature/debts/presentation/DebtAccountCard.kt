package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DebtAccountCard(model: DebtAccountUiModel, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(model.partyName)
            Text("${model.directionLabel} · ${model.remainingDecimal}")
            Text(model.dueDate ?: "بلا تاريخ")
            if (model.needsReview) Text("بحاجة إلى مراجعة")
        }
    }
}

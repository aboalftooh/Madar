package com.shift.app.sync.participant

import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.sync.remote.AssetRemoteSync
import com.shift.app.sync.remote.LedgerRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.data.remote.shouldPushFinancialRecord
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import javax.inject.Inject
import javax.inject.Singleton

/** Owns legacy transactions and the balance/payment ledger synchronization boundary. */
@Singleton
class LedgerSyncParticipant @Inject constructor(
    private val transactionDao: TransactionDao,
    private val balanceTransactionDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val migrationDao: LedgerHistoryMigrationDao,
    private val assetOperationIndex: RoomAssetOperationIndex,
    private val ledgerRemote: LedgerRemoteSync,
    private val assetRemote: AssetRemoteSync,
) : SyncParticipant {
    override val key: String = "ledger"
    override val order: Int = 20

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_transactions", SyncCheckpointKey.Transactions) { ledgerRemote.pullTransactions() },
        SyncOperation("pull_balance_transactions", SyncCheckpointKey.BalanceTransactions) {
            ledgerRemote.pullBalanceTransactions()
        },
        SyncOperation("pull_payments", SyncCheckpointKey.Payments) { ledgerRemote.pullPayments() },
        SyncOperation("pull_ledger_history_migrations", SyncCheckpointKey.LedgerHistoryMigrations) {
            ledgerRemote.pullLedgerHistoryMigrations()
        },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> {
        val allTransactions = transactionDao.getAllOnce()
        val allBalances = balanceTransactionDao.getAllOnce()
        val allPayments = paymentDao.getAllOnce()
        val allMigrations = migrationDao.getAllOnce()

        val transactionsByOperation = allTransactions.filter { it.operationId != null }.groupBy { it.operationId!! }
        val balancesByOperation = allBalances.groupBy { it.operationId }
        val paymentsByOperation = allPayments.groupBy { it.operationId }

        val changedTransactions = allTransactions.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedBalances = allBalances.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedPayments = allPayments.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        val changedMigrations = allMigrations.filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }

        val linkedChangedTransactions = changedTransactions.filter {
            it.operationId != null && it.balanceTransactionId != null
        }
        val standaloneTransactions = changedTransactions.filterNot {
            it.operationId != null && it.balanceTransactionId != null
        }

        val migratedLegacyIds = buildSet {
            addAll(allBalances.mapNotNull { it.legacyTransactionId })
            addAll(allPayments.mapNotNull { it.legacyTransactionId })
        }
        val historyOperationIds = buildSet {
            addAll(allBalances.asSequence()
                .filter { it.legacyTransactionId != null || it.sourceType == "legacy_history_migration" }
                .map { it.operationId })
            addAll(allPayments.asSequence().filter { it.legacyTransactionId != null }.map { it.operationId })
        }
        val assetOperationIds = assetOperationIndex.readOperationIds()

        val changedAssetBalances = changedBalances.filter { it.operationId in assetOperationIds }
        val changedAssetPayments = changedPayments.filter {
            it.operationId in assetOperationIds || it.assetId != null
        }
        val changedRegularBalances = changedBalances.filterNot {
            it.operationId in assetOperationIds || it.operationId in historyOperationIds
        }
        val changedRegularPayments = changedPayments.filterNot {
            it.operationId in assetOperationIds || it.assetId != null || it.operationId in historyOperationIds
        }

        return buildList {
            if (standaloneTransactions.isNotEmpty()) {
                add(SyncOperation("push_transactions") { ledgerRemote.pushTransactions(standaloneTransactions) })
            }

            if (changedMigrations.isNotEmpty()) {
                val historyBalances = historyOperationIds.flatMap { balancesByOperation[it].orEmpty() }
                val historyPayments = historyOperationIds.flatMap { paymentsByOperation[it].orEmpty() }
                val legacyTransactions = allTransactions.filter { it.id in migratedLegacyIds }
                add(SyncOperation("push_ledger_history_migrations") {
                    assetRemote.pushAssetOperation(
                        assets = emptyList(),
                        transactions = emptyList(),
                        valuations = emptyList(),
                        balanceTransactions = historyBalances,
                        payments = historyPayments,
                        legacyTransactions = legacyTransactions,
                        ledgerHistoryMigrations = changedMigrations,
                    )
                })
            } else {
                val changedHistoryIds = historyOperationIds.filter { operationId ->
                    changedBalances.any { it.operationId == operationId } ||
                        changedPayments.any { it.operationId == operationId } ||
                        linkedChangedTransactions.any { it.operationId == operationId }
                }
                changedHistoryIds.sorted().forEach { operationId ->
                    val balances = balancesByOperation[operationId].orEmpty()
                    val payments = paymentsByOperation[operationId].orEmpty()
                    val transactions = transactionsByOperation[operationId].orEmpty()
                    add(SyncOperation("push_history_operation:$operationId") {
                        assetRemote.pushAssetOperation(
                            assets = emptyList(),
                            transactions = emptyList(),
                            valuations = emptyList(),
                            balanceTransactions = balances,
                            payments = payments,
                            legacyTransactions = transactions,
                        )
                    })
                }
            }

            val changedRegularOperationIds = buildSet {
                addAll(changedRegularBalances.map { it.operationId })
                addAll(changedRegularPayments.map { it.operationId })
                addAll(linkedChangedTransactions.mapNotNull { it.operationId }
                    .filterNot { it in historyOperationIds || it in assetOperationIds })
            }
            changedRegularOperationIds.sorted().forEach { operationId ->
                val balances = balancesByOperation[operationId].orEmpty()
                val payments = paymentsByOperation[operationId].orEmpty().filter { it.assetId == null }
                val transactions = transactionsByOperation[operationId].orEmpty()
                    .filter { it.balanceTransactionId != null }
                add(SyncOperation("push_regular_operation:$operationId") {
                    assetRemote.pushAssetOperation(
                        assets = emptyList(),
                        transactions = emptyList(),
                        valuations = emptyList(),
                        balanceTransactions = balances,
                        payments = payments,
                        legacyTransactions = transactions,
                    )
                })
            }

            // The asset participant owns these linked records. Keeping the values here makes the
            // exclusion explicit and guards against accidentally pushing one operation twice.
            check(changedAssetBalances.all { it.operationId in assetOperationIds })
            check(changedAssetPayments.all { it.operationId in assetOperationIds || it.assetId != null })

        }
    }

    override suspend fun finalizeOperations(): List<SyncOperation> = listOf(
        SyncOperation("repair_incomplete_payment_operations") {
            ledgerRemote.repairIncompletePaymentOperationsForSync()
        },
    )
}

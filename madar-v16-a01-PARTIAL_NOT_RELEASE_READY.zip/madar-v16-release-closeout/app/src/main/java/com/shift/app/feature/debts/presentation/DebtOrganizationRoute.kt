package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun DebtOrganizationRoute(scheduleTotalDecimal: String, installments: Int) {
    Column {
        Text("تنظيم الدين")
        Text("إجمالي الجدول: $scheduleTotalDecimal")
        Text("عدد الدفعات: $installments")
        Text("الأثر المالي: 0.00")
    }
}

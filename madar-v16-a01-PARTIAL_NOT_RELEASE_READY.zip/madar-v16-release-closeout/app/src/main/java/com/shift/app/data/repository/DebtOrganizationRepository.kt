package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtScheduleDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtMoney
import com.shift.app.domain.debt.DebtScheduleCalculator
import com.shift.app.domain.debt.DebtTransactionType
import javax.inject.Inject

class DebtOrganizationRepository @Inject constructor(
    private val db: MadarDatabase,
    private val accountDao: DebtAccountDao,
    private val transactionDao: DebtTransactionDao,
    private val scheduleDao: DebtScheduleDao
) {
    suspend fun transferToNewParty(
        operationId: String,
        sourceAccountId: String,
        targetAccountId: String,
        newPartyName: String,
        amountDecimal: String,
        occurredAt: Long = System.currentTimeMillis(),
        reason: String
    ): Pair<DebtAccount, DebtAccount> = db.withTransaction {
        require(reason.isNotBlank()) { "Transfer reason is required" }
        val source = accountDao.getById(sourceAccountId) ?: throw IllegalArgumentException("Source account not found")
        val amount = DebtMoney.of(amountDecimal)
        val target = DebtAccount(
            id = targetAccountId,
            operationId = operationId,
            direction = source.direction,
            partyName = newPartyName.trim(),
            partyKey = newPartyName.trim().lowercase(),
            currencyCode = source.currencyCode,
            description = "Transferred from ${source.partyName}",
            confirmed = source.confirmed,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        transactionDao.upsert(orgTx("$operationId:out", source.id, operationId, DebtTransactionType.TransferOut, amount.decimalText, source.currencyCode, occurredAt, reason))
        transactionDao.upsert(orgTx("$operationId:in", target.id, operationId, DebtTransactionType.TransferIn, amount.decimalText, source.currencyCode, occurredAt, reason))
        accountDao.upsert(source.copy(closedAt = occurredAt, closeReason = reason, updatedAt = occurredAt))
        accountDao.upsert(target)
        source to target
    }

    suspend fun writeSchedule(
        operationId: String,
        accountId: String,
        totalAmountDecimal: String,
        firstDueDate: String,
        count: Int
    ): List<DebtSchedule> = db.withTransaction {
        val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
        DebtScheduleCalculator.equalInstallments(totalAmountDecimal, firstDueDate, count).map {
            DebtSchedule(
                operationId = operationId,
                accountId = account.id,
                installmentNo = it.installmentNo,
                dueDate = it.dueDate,
                amountDecimal = it.amountDecimal,
                currencyCode = account.currencyCode
            )
        }.also { scheduleDao.upsertAll(it) }
    }

    suspend fun archiveAccount(accountId: String, reason: String, archivedAt: Long = System.currentTimeMillis()): DebtAccount =
        db.withTransaction {
            require(reason.isNotBlank()) { "Archive reason is required" }
            val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
            account.copy(archivedAt = archivedAt, closeReason = reason, updatedAt = archivedAt).also { accountDao.upsert(it) }
        }

    private fun orgTx(
        id: String,
        accountId: String,
        operationId: String,
        type: DebtTransactionType,
        amountDecimal: String,
        currencyCode: String,
        occurredAt: Long,
        reason: String
    ) = DebtTransaction(
        id = id,
        accountId = accountId,
        operationId = operationId,
        type = type.dbValue,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        occurredAt = occurredAt,
        reason = reason,
        sourceType = "debt_organization",
        sourceId = operationId,
        createdAt = occurredAt,
        updatedAt = occurredAt
    )
}

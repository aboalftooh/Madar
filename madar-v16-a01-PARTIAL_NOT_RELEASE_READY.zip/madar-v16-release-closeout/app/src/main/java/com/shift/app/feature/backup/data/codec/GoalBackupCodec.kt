package com.shift.app.feature.backup.data.codec

import com.shift.app.data.backup.GoalActivityBackup
import com.shift.app.data.backup.GoalBackup
import com.shift.app.data.backup.GoalBackupMapper
import com.shift.app.data.backup.GoalBackupPayload
import com.shift.app.data.backup.GoalConditionBackup
import com.shift.app.data.backup.GoalCostEstimateBackup
import com.shift.app.data.backup.GoalEvaluationBackup
import com.shift.app.data.backup.GoalFundingTransactionBackup
import com.shift.app.data.backup.GoalMetricBackup
import com.shift.app.data.backup.GoalScopeBackup
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.domain.model.BackupImportMode
import javax.inject.Inject
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject

internal data class GoalSectionSnapshot(
    val payload: GoalBackupPayload,
    val included: Boolean,
) : BackupSectionSnapshot {
    override val rowCount: Int = payload.goals.size + payload.metrics.size + payload.conditions.size +
        payload.scopes.size + payload.fundingTransactions.size + payload.costEstimates.size +
        payload.evaluations.size + payload.activities.size
}

internal data class GoalSectionPlan(
    val payload: GoalBackupPayload,
    override val importedRowCount: Int,
    override val affectedRowCount: Int,
    override val deleteCount: Int,
) : BackupSectionPlan

internal class GoalBackupCodec @Inject constructor(
    private val database: MadarDatabase,
) : BackupSectionCodec {
    override val id: String = "goals"
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun writeExport(root: JSONObject) {
        val payload = currentPayload()
        root.put("financialGoals", JSONObject(json.encodeToString(payload)))
    }

    override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot {
        @Suppress("UNUSED_VARIABLE") val timestamp = now
        val included = root.has("financialGoals")
        val payload = root.optJSONObject("financialGoals")?.let {
            json.decodeFromString(GoalBackupPayload.serializer(), it.toString())
        } ?: GoalBackupPayload()
        payload.validateForRestore()
        return GoalSectionSnapshot(payload, included)
    }

    override suspend fun plan(
        imported: BackupSectionSnapshot,
        mode: BackupImportMode,
        now: Long,
    ): BackupSectionPlan {
        imported as GoalSectionSnapshot
        val current = currentPayload()
        if (!imported.included) return GoalSectionPlan(current, 0, 0, 0)
        val planned = merge(imported.payload, current, mode, now)
        val deletes = planned.goals.count { it.deletedAt == now } +
            planned.metrics.count { it.deletedAt == now } +
            planned.conditions.count { it.deletedAt == now } +
            planned.scopes.count { it.deletedAt == now } +
            planned.fundingTransactions.count { it.deletedAt == now } +
            planned.costEstimates.count { it.deletedAt == now } +
            planned.evaluations.count { it.deletedAt == now } +
            planned.activities.count { it.deletedAt == now }
        return GoalSectionPlan(
            payload = planned,
            importedRowCount = imported.rowCount,
            affectedRowCount = imported.rowCount + deletes,
            deleteCount = deletes,
        )
    }

    override suspend fun apply(plan: BackupSectionPlan) {
        plan as GoalSectionPlan
        val payload = plan.payload.also { it.validateForRestore() }
        with(GoalSyncMapper) {
            database.financialGoalDao().upsertAll(payload.goals.map { it.toEntity() })
            database.goalMetricDao().upsertAll(payload.metrics.map { it.toEntity() })
            database.goalConditionDao().upsertAll(payload.conditions.map { it.toEntity() })
            database.goalScopeDao().upsertAll(payload.scopes.map { it.toEntity() })
            database.goalFundingTransactionDao().upsertAll(payload.fundingTransactions.map { it.toEntity() })
            database.goalCostEstimateDao().upsertAll(payload.costEstimates.map { it.toEntity() })
            database.goalEvaluationDao().upsertAll(payload.evaluations.map { it.toEntity() })
            database.goalActivityDao().upsertAll(payload.activities.map { it.toEntity() })
        }
    }

    private suspend fun currentPayload(): GoalBackupPayload = GoalBackupMapper.fromEntities(
        goals = database.financialGoalDao().getAllOnce(),
        metrics = database.goalMetricDao().getAllOnce(),
        conditions = database.goalConditionDao().getAllOnce(),
        scopes = database.goalScopeDao().getAllOnce(),
        fundingTransactions = database.goalFundingTransactionDao().getAllOnce(),
        costEstimates = database.goalCostEstimateDao().getAllOnce(),
        evaluations = database.goalEvaluationDao().getAllOnce(),
        activities = database.goalActivityDao().getAllOnce(),
    ).also { it.validateForRestore() }

    private fun merge(
        imported: GoalBackupPayload,
        current: GoalBackupPayload,
        mode: BackupImportMode,
        now: Long,
    ): GoalBackupPayload {
        imported.validateForRestore()
        current.validateForRestore()
        fun goals() = mergeRows(current.goals, imported.goals, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", revision = it.revision + 1L, updatedAt = now, deletedAt = now)
        }
        fun metrics() = mergeRows(current.metrics, imported.metrics, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun conditions() = mergeRows(current.conditions, imported.conditions, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun scopes() = mergeRows(current.scopes, imported.scopes, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun funding() = mergeRows(current.fundingTransactions, imported.fundingTransactions, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun costs() = mergeRows(current.costEstimates, imported.costEstimates, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun evaluations() = mergeRows(current.evaluations, imported.evaluations, mode, { it.id }, { it.updatedAt }) {
            it.copy(updatedAt = now, deletedAt = now)
        }
        fun activities() = mergeRows(current.activities, imported.activities, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        return GoalBackupPayload(
            goals = goals(),
            metrics = metrics(),
            conditions = conditions(),
            scopes = scopes(),
            fundingTransactions = funding(),
            costEstimates = costs(),
            evaluations = evaluations(),
            activities = activities(),
        ).also { it.validateForRestore() }
    }

    private fun <T> mergeRows(
        current: List<T>,
        imported: List<T>,
        mode: BackupImportMode,
        id: (T) -> String,
        updatedAt: (T) -> Long,
        tombstone: (T) -> T,
    ): List<T> = when (mode) {
        BackupImportMode.MERGE -> (current + imported)
            .groupBy(id)
            .map { (_, rows) -> rows.maxBy(updatedAt) }
        BackupImportMode.REPLACE -> imported + current
            .filterNot { currentRow -> imported.any { id(it) == id(currentRow) } }
            .map(tombstone)
    }
}

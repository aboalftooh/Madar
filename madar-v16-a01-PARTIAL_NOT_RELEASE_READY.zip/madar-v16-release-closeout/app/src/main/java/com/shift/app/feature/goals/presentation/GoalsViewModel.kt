package com.shift.app.feature.goals.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.feature.goals.domain.repository.GoalGateway
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.usecase.GoalFundingUseCases
import com.shift.app.domain.goals.usecase.GoalLifecycleStateMachine
import com.shift.app.domain.goals.usecase.GoalLifecycleUseCases
import com.shift.app.domain.goals.usecase.AssetGoalCompletionRequest
import com.shift.app.domain.goals.usecase.CompleteAssetPurchaseGoal
import com.shift.app.domain.goals.usecase.CompleteCostGoal
import com.shift.app.domain.goals.usecase.CompleteCostGoalRequest
import com.shift.app.domain.goals.usecase.GoalDebtPaymentRequest
import com.shift.app.domain.goals.usecase.RecordGoalDebtPayment
import com.shift.app.domain.goals.usecase.specializedCompletionTypes
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GoalListItem(
    val id: String,
    val name: String,
    val type: GoalType,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val targetDecimal: String,
    val deadline: String,
    val revision: Long,
)

data class GoalFundingUiSummary(
    val allocatedDecimal: String = "0.00",
    val transactions: List<GoalFundingTransaction> = emptyList(),
)

data class GoalEvaluationUiSummary(
    val measuredDecimal: String?,
    val asOf: Long,
    val estimated: Boolean,
    val correctionOfId: String?,
)

enum class GoalListFilter(val statuses: Set<GoalLifecycleStatus>) {
    ACTIVE(setOf(GoalLifecycleStatus.ACTIVE, GoalLifecycleStatus.READY)),
    PAUSED(setOf(GoalLifecycleStatus.PAUSED)),
    COMPLETED(setOf(GoalLifecycleStatus.COMPLETED)),
    ARCHIVED(setOf(GoalLifecycleStatus.ARCHIVED, GoalLifecycleStatus.CANCELLED)),
}

sealed class GoalActionResult {
    object Idle : GoalActionResult()
    data class Success(val message: String) : GoalActionResult()
    data class Error(val message: String) : GoalActionResult()
}

@HiltViewModel
class GoalsViewModel @Inject constructor(
    private val gateway: GoalGateway,
    private val lifecycleUseCases: GoalLifecycleUseCases,
    private val fundingUseCases: GoalFundingUseCases,
    private val completeAssetPurchaseGoal: CompleteAssetPurchaseGoal,
    private val completeCostGoal: CompleteCostGoal,
    private val recordGoalDebtPayment: RecordGoalDebtPayment,
) : ViewModel() {
    val goals: StateFlow<List<GoalListItem>> = gateway.observeActiveGoals()
        .map { rows -> rows.map { it.toListItem() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedGoal = MutableStateFlow<FinancialGoal?>(null)
    val selectedGoal: StateFlow<FinancialGoal?> = _selectedGoal.asStateFlow()
    private val _selectedFunding = MutableStateFlow(GoalFundingUiSummary())
    val selectedFunding: StateFlow<GoalFundingUiSummary> = _selectedFunding.asStateFlow()
    private val _selectedEvaluation = MutableStateFlow<GoalEvaluationUiSummary?>(null)
    val selectedEvaluation: StateFlow<GoalEvaluationUiSummary?> = _selectedEvaluation.asStateFlow()

    private val _actionResult = MutableStateFlow<GoalActionResult>(GoalActionResult.Idle)
    val actionResult: StateFlow<GoalActionResult> = _actionResult.asStateFlow()

    fun selectGoal(goalId: String) {
        viewModelScope.launch {
            refreshSelectedGoal(goalId)
        }
    }

    fun clearActionResult() {
        _actionResult.value = GoalActionResult.Idle
    }

    fun transition(goal: FinancialGoal, to: GoalLifecycleStatus) {
        if (to == GoalLifecycleStatus.COMPLETED && goal.type in specializedCompletionTypes) {
            _actionResult.value = GoalActionResult.Error("استخدم شاشة الإكمال المحاسبي الخاصة بهذا الهدف")
            return
        }
        if (!GoalLifecycleStateMachine.isAllowed(goal.lifecycleStatus, to)) {
            _actionResult.value = GoalActionResult.Error("لا يمكن تنفيذ هذا الانتقال من الحالة الحالية")
            return
        }
        viewModelScope.launch {
            runCatching {
                val now = System.currentTimeMillis()
                val operationId = "goal-ui:${goal.id}:${to.name.lowercase()}:$now"
                when (to) {
                    GoalLifecycleStatus.ACTIVE -> {
                        if (goal.lifecycleStatus == GoalLifecycleStatus.PAUSED) {
                            lifecycleUseCases.resume(goal.id, goal.revision, operationId, now)
                        } else {
                            lifecycleUseCases.activate(goal.id, goal.revision, operationId, now)
                        }
                    }
                    GoalLifecycleStatus.PAUSED -> lifecycleUseCases.pause(goal.id, goal.revision, operationId, now)
                    GoalLifecycleStatus.COMPLETED -> lifecycleUseCases.complete(goal.id, goal.revision, operationId, now)
                    GoalLifecycleStatus.CANCELLED -> lifecycleUseCases.cancel(goal.id, goal.revision, operationId, now)
                    GoalLifecycleStatus.ARCHIVED -> lifecycleUseCases.archive(goal.id, goal.revision, operationId, now)
                    GoalLifecycleStatus.READY -> gateway.transition(
                        goalId = goal.id,
                        expectedRevision = goal.revision,
                        to = GoalLifecycleStatus.READY,
                        operationId = operationId,
                        now = now,
                        activityType = "LIFECYCLE_READY",
                    )
                    GoalLifecycleStatus.DRAFT -> error("Draft transition is not supported")
                }
            }.onSuccess {
                refreshSelectedGoal(goal.id)
                _actionResult.value = GoalActionResult.Success("تم تحديث حالة الهدف")
            }.onFailure {
                _actionResult.value = GoalActionResult.Error(it.message ?: "تعذر تحديث الهدف")
            }
        }
    }

    fun allocate(goal: FinancialGoal, amount: String, note: String) {
        viewModelScope.launch {
            runCatching {
                fundingUseCases.allocate(
                    goalId = goal.id,
                    amountDecimal = amount,
                    currencyCode = goal.currencyCode,
                    note = note,
                )
            }.onSuccess {
                refreshSelectedGoal(goal.id)
                _actionResult.value = GoalActionResult.Success("تم تخصيص المبلغ للهدف")
            }.onFailure {
                _actionResult.value = GoalActionResult.Error(it.message ?: "تعذر تخصيص المبلغ")
            }
        }
    }

    fun release(goal: FinancialGoal, amount: String, reason: String) {
        viewModelScope.launch {
            runCatching {
                fundingUseCases.release(
                    goalId = goal.id,
                    amountDecimal = amount,
                    currencyCode = goal.currencyCode,
                    reason = reason,
                )
            }.onSuccess {
                refreshSelectedGoal(goal.id)
                _actionResult.value = GoalActionResult.Success("تم سحب التخصيص")
            }.onFailure {
                _actionResult.value = GoalActionResult.Error(it.message ?: "تعذر سحب التخصيص")
            }
        }
    }

    fun reverse(goal: FinancialGoal, transaction: GoalFundingTransaction) {
        viewModelScope.launch {
            runCatching {
                fundingUseCases.reverse(
                    goalId = goal.id,
                    original = transaction,
                    reason = "عكس من شاشة الهدف",
                )
            }.onSuccess {
                refreshSelectedGoal(goal.id)
                _actionResult.value = GoalActionResult.Success("تم عكس العملية")
            }.onFailure {
                _actionResult.value = GoalActionResult.Error(it.message ?: "تعذر عكس العملية")
            }
        }
    }

    fun archiveCancelledOrCompleted(goal: FinancialGoal) {
        transition(goal, GoalLifecycleStatus.ARCHIVED)
    }

    fun completeAsset(request: AssetGoalCompletionRequest) = runSpecializedCompletion(
        goalId = request.goalId,
        successMessage = "تم تسجيل شراء الأصل وإكمال الهدف",
    ) { completeAssetPurchaseGoal.complete(request) }

    fun completeCost(request: CompleteCostGoalRequest) = runSpecializedCompletion(
        goalId = request.goalId,
        successMessage = "تم تسجيل أثر التكلفة وإكمال الهدف",
    ) { completeCostGoal.complete(request) }

    fun recordDebtPayment(request: GoalDebtPaymentRequest) = runSpecializedCompletion(
        goalId = request.goalId,
        successMessage = if (request.completeGoalWhenPaidOff) "تم تسجيل السداد وإكمال الهدف" else "تم تسجيل دفعة الدين",
    ) { recordGoalDebtPayment.record(request) }

    private fun runSpecializedCompletion(
        goalId: String,
        successMessage: String,
        operation: suspend () -> Unit,
    ) {
        viewModelScope.launch {
            runCatching { operation() }
                .onSuccess {
                    refreshSelectedGoal(goalId)
                    _actionResult.value = GoalActionResult.Success(successMessage)
                }
                .onFailure {
                    refreshSelectedGoal(goalId)
                    _actionResult.value = GoalActionResult.Error(it.message ?: "تعذر إكمال العملية المحاسبية")
                }
        }
    }

    private suspend fun refreshSelectedGoal(goalId: String) {
        val aggregate = gateway.getAggregate(goalId)
        _selectedGoal.value = aggregate?.goal
        _selectedFunding.value = aggregate.toFundingSummary()
        _selectedEvaluation.value = aggregate.toEvaluationSummary()
    }
}

private fun GoalAggregate?.toFundingSummary(): GoalFundingUiSummary =
    if (this == null) {
        GoalFundingUiSummary()
    } else {
        GoalFundingUiSummary(
            allocatedDecimal = GoalFundingCalculator.allocatedForGoal(fundingTransactions).toPlainString(),
            transactions = fundingTransactions,
        )
    }

private fun GoalAggregate?.toEvaluationSummary(): GoalEvaluationUiSummary? {
    val latest = this?.evaluations?.firstOrNull() ?: return null
    return GoalEvaluationUiSummary(
        measuredDecimal = latest.measuredDecimal,
        asOf = latest.asOf,
        estimated = latest.resultJson.contains("\"estimated\":true"),
        correctionOfId = latest.correctionOfId,
    )
}

private fun FinancialGoal.toListItem() = GoalListItem(
    id = id,
    name = name,
    type = type,
    lifecycleStatus = lifecycleStatus,
    healthStatus = healthStatus,
    targetDecimal = targetDecimal,
    deadline = deadline,
    revision = revision,
)

fun GoalType.arabicLabel(): String = when (this) {
    GoalType.HOUSE_PURCHASE -> "شراء منزل"
    GoalType.CAR_PURCHASE -> "شراء سيارة"
    GoalType.PROJECT_FUNDING -> "تمويل مشروع"
    GoalType.TRIP_FUNDING -> "تمويل رحلة"
    GoalType.INCOME_GROWTH -> "زيادة الدخل"
    GoalType.EXPENSE_REDUCTION -> "خفض المصروف"
    GoalType.EXPENSE_CEILING -> "سقف المصروف"
    GoalType.EMERGENCY_FUND -> "صندوق الطوارئ"
    GoalType.DEBT_PAYOFF -> "سداد الديون"
    GoalType.NET_WORTH_GROWTH -> "نمو صافي الثروة"
}

fun GoalLifecycleStatus.arabicLabel(): String = when (this) {
    GoalLifecycleStatus.DRAFT -> "مسودة"
    GoalLifecycleStatus.ACTIVE -> "نشط"
    GoalLifecycleStatus.PAUSED -> "متوقف"
    GoalLifecycleStatus.READY -> "جاهز"
    GoalLifecycleStatus.COMPLETED -> "مكتمل"
    GoalLifecycleStatus.CANCELLED -> "ملغي"
    GoalLifecycleStatus.ARCHIVED -> "مؤرشف"
}

fun GoalHealthStatus.arabicLabel(): String = when (this) {
    GoalHealthStatus.ON_TRACK -> "على المسار"
    GoalHealthStatus.NEEDS_ATTENTION -> "يحتاج انتباه"
    GoalHealthStatus.BEHIND -> "متأخر"
    GoalHealthStatus.UNAVAILABLE -> "غير متاح"
}

fun defaultGoalDeadline(): String =
    LocalDate.now(ZoneId.systemDefault()).plusMonths(6).toString()

fun nowIsoDate(): String = Instant.now().atZone(ZoneId.systemDefault()).toLocalDate().toString()

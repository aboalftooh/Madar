package com.shift.app.feature.backup.di

import com.shift.app.feature.backup.data.BackupGatewayAdapter
import com.shift.app.feature.backup.domain.repository.BackupGateway
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class BackupFeatureModule {
    @Binds
    @Singleton
    internal abstract fun bindBackupGateway(adapter: BackupGatewayAdapter): BackupGateway
}

package com.shift.app.feature.assets.data

import com.shift.app.data.remote.SyncManager
import com.shift.app.data.repository.AssetRepository
import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.AssetCommandReceipt
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetSessionExpiredException
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import com.shift.app.feature.assets.domain.repository.AssetGateway
import com.shift.app.sync.SyncQueueGateway
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.map

@Singleton
class AssetGatewayAdapter @Inject constructor(
    private val repository: AssetRepository,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : AssetGateway {
    override fun observeAssets() = repository.assets().map { rows -> rows.map(AssetEntityMapper::asset) }
    override fun observeTransactions() = repository.assetTransactions().map { rows -> rows.map(AssetEntityMapper::transaction) }
    override fun observeValuations() = repository.assetValuations().map { rows -> rows.map(AssetEntityMapper::valuation) }
    override fun observeCurrencyLots() = repository.currencyLots().map { rows -> rows.map(AssetEntityMapper::lot) }
    override fun observeCurrencySaleAllocations() = repository.currencySaleAllocations().map { rows -> rows.map(AssetEntityMapper::allocation) }

    override suspend fun addPreexistingAsset(request: PreexistingAssetRequest) = execute {
        repository.addPreexistingAsset(request)
    }

    override suspend fun purchaseAsset(request: PurchaseAssetRequest) = execute {
        repository.purchaseAsset(request)
    }

    override suspend fun purchaseCurrencyAsset(request: PurchaseCurrencyAssetRequest) = execute {
        repository.purchaseCurrencyAsset(request)
    }

    override suspend fun recordAssetPayment(request: AssetPaymentRequest) = execute {
        repository.recordAssetPayment(request)
    }

    override suspend fun valueAsset(request: AssetValuationRequest) = execute {
        repository.valueAsset(request)
    }

    override suspend fun sellAsset(request: AssetSaleRequest) = execute {
        repository.sellAsset(request)
    }

    override suspend fun addCurrencyLot(request: AddCurrencyLotRequest) = execute {
        repository.addCurrencyLot(request)
    }

    override suspend fun sellCurrencyAsset(request: CurrencyAssetSaleRequest) = execute {
        repository.sellCurrencyAsset(request)
    }

    override suspend fun updateAcquisition(assetId: String, name: String, type: String, amountDecimal: String) = execute {
        repository.updateAcquisition(assetId, name, type, amountDecimal)
    }

    override suspend fun updatePaymentEvent(operationId: String, amountDecimal: String, purpose: String, date: String, note: String) = execute {
        repository.updatePaymentEvent(operationId, amountDecimal, purpose, date, note)
    }

    override suspend fun updateValuation(operationId: String, valueDecimal: String, date: String, note: String) = execute {
        repository.updateValuation(operationId, valueDecimal, date, note)
    }

    override suspend fun updateSale(operationId: String, amountDecimal: String, date: String, note: String) = execute {
        repository.updateSale(operationId, amountDecimal, date, note)
    }

    override suspend fun deleteOperation(operationId: String) = execute {
        repository.softDeleteOperation(operationId)
    }

    override suspend fun deleteValuation(operationId: String) = execute {
        repository.softDeleteValuation(operationId)
    }

    override suspend fun undoSale(operationId: String) = execute {
        repository.undoSale(operationId)
    }

    private suspend fun execute(operation: suspend () -> AssetOperationRecords): AssetCommandReceipt {
        val records = syncManager.executeSessionOperation(operation) ?: throw AssetSessionExpiredException()
        val operationId = records.operationId()
        val syncRequested = runCatching {
            syncQueue.requestSync(reason = "asset-operation", operationId = operationId)
        }.isSuccess
        return AssetCommandReceipt(operationId = operationId, syncRequested = syncRequested)
    }

    private fun AssetOperationRecords.operationId(): String =
        assetTransactions.firstOrNull()?.operationId
            ?: assetValuations.firstOrNull()?.operationId
            ?: balanceTransactions.firstOrNull()?.operationId
            ?: payments.firstOrNull()?.operationId
            ?: currencyLots.firstOrNull()?.operationId
            ?: currencySaleAllocations.firstOrNull()?.operationId
            ?: assets.firstOrNull()?.operationId
            ?: error("Asset operation has no operationId")
}

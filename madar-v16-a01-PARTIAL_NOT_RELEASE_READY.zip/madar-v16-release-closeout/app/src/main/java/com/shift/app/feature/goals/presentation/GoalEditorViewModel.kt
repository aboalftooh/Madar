package com.shift.app.feature.goals.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.feature.debts.domain.usecase.ObservePayableDebtAccountsUseCase
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.repository.GoalGateway
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.GoalConfigJson
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.templates.AssetPurchaseGoalTemplate
import com.shift.app.domain.goals.templates.AssetPurchaseTemplateRequest
import com.shift.app.domain.goals.templates.CostFundingGoalTemplate
import com.shift.app.domain.goals.templates.CostFundingTemplateRequest
import com.shift.app.domain.goals.templates.DebtPayoffGoalTemplate
import com.shift.app.domain.goals.templates.DebtPayoffScopeMode
import com.shift.app.domain.goals.templates.DebtPayoffTemplateRequest
import com.shift.app.domain.goals.templates.EmergencyFundGoalTemplate
import com.shift.app.domain.goals.templates.EmergencyFundTemplateRequest
import com.shift.app.domain.goals.templates.ExpenseGoalTemplateRequest
import com.shift.app.domain.goals.templates.ExpenseGoalTemplates
import com.shift.app.domain.goals.templates.IncomeGrowthGoalTemplate
import com.shift.app.domain.goals.templates.IncomeGrowthTemplateRequest
import com.shift.app.domain.goals.templates.NetWorthGrowthGoalTemplate
import com.shift.app.domain.goals.templates.NetWorthGrowthTemplateRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GoalEditorState(
    val id: String? = null,
    val name: String = "",
    val type: GoalType = GoalType.HOUSE_PURCHASE,
    val targetInput: String = "",
    val deadline: String = defaultGoalDeadline(),
    val confirmationPeriods: String = "1",
    val costThreshold: CostThreshold? = null,
    val essentialPurposeInput: String = "",
    val debtScopeMode: DebtPayoffScopeMode = DebtPayoffScopeMode.ALL_PAYABLE,
    val selectedDebtAccountIds: Set<String> = emptySet(),
    val debtAccountOptions: List<DebtAccountOption> = emptyList(),
    val baselineInput: String = "",
    val revision: Long = 0L,
    val lifecycleStatus: GoalLifecycleStatus = GoalLifecycleStatus.DRAFT,
    val healthStatus: GoalHealthStatus = GoalHealthStatus.UNAVAILABLE,
    val readyAt: Long? = null,
    val completedAt: Long? = null,
    val cancelledAt: Long? = null,
    val archivedAt: Long? = null,
    val dirty: Boolean = false,
    val saving: Boolean = false,
    val error: String? = null,
    val savedGoalId: String? = null,
) {
    val essentialPurposeKeys: List<String>
        get() = essentialPurposeInput.split(",", "،", "\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

    val canSave: Boolean
        get() = name.isNotBlank() && targetInput.isNotBlank() && deadline.isNotBlank() && when (type) {
            GoalType.EMERGENCY_FUND -> essentialPurposeKeys.isNotEmpty()
            GoalType.EXPENSE_REDUCTION, GoalType.EXPENSE_CEILING, GoalType.NET_WORTH_GROWTH -> baselineInput.isNotBlank()
            GoalType.DEBT_PAYOFF -> debtScopeMode == DebtPayoffScopeMode.ALL_PAYABLE || selectedDebtAccountIds.isNotEmpty()
            else -> true
        }
}

data class DebtAccountOption(
    val id: String,
    val partyName: String,
    val direction: String,
)

@HiltViewModel
class GoalEditorViewModel @Inject constructor(
    private val gateway: GoalGateway,
    observePayableDebtAccounts: ObservePayableDebtAccountsUseCase,
) : ViewModel() {
    private val _state = MutableStateFlow(GoalEditorState())
    val state: StateFlow<GoalEditorState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            observePayableDebtAccounts().collect { accounts ->
                _state.update { current ->
                    current.copy(
                        debtAccountOptions = accounts.map { DebtAccountOption(it.id, it.partyName, it.direction) },
                    )
                }
            }
        }
    }

    fun load(goalId: String?) {
        if (goalId == null || _state.value.id == goalId) return
        viewModelScope.launch {
            val aggregate = gateway.getAggregate(goalId) ?: return@launch
            _state.value = aggregate.toEditorState(debtAccountOptions = _state.value.debtAccountOptions)
        }
    }

    fun updateName(value: String) = mutate { copy(name = value.take(80)) }
    fun updateType(value: GoalType) = mutate { copy(type = value) }
    fun updateTarget(value: String) = mutate { copy(targetInput = value.filterMoneyInput()) }
    fun updateDeadline(value: String) = mutate { copy(deadline = value.take(10)) }
    fun updateBaseline(value: String) = mutate { copy(baselineInput = value.filterMoneyInput()) }
    fun updateConfirmationPeriods(value: String) = mutate { copy(confirmationPeriods = value.filter { it.isDigit() }.take(2)) }
    fun updateCostThreshold(value: CostThreshold?) = mutate { copy(costThreshold = value) }
    fun updateEssentialPurposes(value: String) = mutate { copy(essentialPurposeInput = value.take(160)) }
    fun updateDebtScopeMode(value: DebtPayoffScopeMode) = mutate { copy(debtScopeMode = value) }
    fun toggleDebtAccount(accountId: String) = mutate {
        val next = if (accountId in selectedDebtAccountIds) selectedDebtAccountIds - accountId else selectedDebtAccountIds + accountId
        copy(selectedDebtAccountIds = next)
    }

    fun saveDraft(onSaved: (String) -> Unit = {}) {
        save(activate = false, onSaved = onSaved)
    }

    fun saveAndActivate(onSaved: (String) -> Unit = {}) {
        save(activate = true, onSaved = onSaved)
    }

    fun autoSaveDraftIfDirty() {
        val current = _state.value
        if (current.dirty && !current.saving && current.canSave) {
            saveDraft()
        }
    }

    private fun save(activate: Boolean, onSaved: (String) -> Unit) {
        val current = _state.value
        viewModelScope.launch {
            _state.update { it.copy(saving = true, error = null) }
            runCatching {
                val now = System.currentTimeMillis()
                val aggregate = current.toAggregate(now, activate)
                if (current.id == null) {
                    gateway.createAggregate(aggregate, operationId = "goal-ui-create:${aggregate.goal.id}")
                    aggregate.goal.id
                } else {
                    gateway.updateAggregate(
                        aggregate = aggregate,
                        expectedRevision = current.revision,
                        now = now,
                        operationId = "goal-ui-update:${aggregate.goal.id}:${current.revision + 1}",
                    ).goal.id
                }
            }.onSuccess { goalId ->
                _state.update { it.copy(id = goalId, saving = false, dirty = false, savedGoalId = goalId) }
                onSaved(goalId)
            }.onFailure { error ->
                _state.update { it.copy(saving = false, error = error.message ?: "تعذر حفظ الهدف") }
            }
        }
    }

    private fun mutate(block: GoalEditorState.() -> GoalEditorState) {
        _state.update { it.block().copy(dirty = true, error = null, savedGoalId = null) }
    }
}

private fun GoalEditorState.toAggregate(now: Long, activate: Boolean): GoalAggregate {
    val goalId = id ?: UUID.randomUUID().toString()
    val canonicalTarget = DecimalText.canonicalPositive(targetInput, DecimalTextScale.Money)
    val canonicalBaseline = baselineInput.takeIf { it.isNotBlank() }?.let {
        DecimalText.canonicalNonNegative(it, DecimalTextScale.Money)
    }
    val parsedDeadline = LocalDate.parse(deadline)
    require(!parsedDeadline.isBefore(LocalDate.now(ZoneId.systemDefault()))) { "الموعد يجب أن يكون اليوم أو بعده" }
    val periods = confirmationPeriods.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val status = if (activate && id == null) GoalLifecycleStatus.ACTIVE else lifecycleStatus
    val startDate = nowIsoDate()
    val timezoneId = ZoneId.systemDefault().id
    val aggregate = when (type) {
        GoalType.HOUSE_PURCHASE, GoalType.CAR_PURCHASE -> AssetPurchaseGoalTemplate.build(
            AssetPurchaseTemplateRequest(
                id = goalId,
                name = name.trim(),
                type = type,
                targetDecimal = canonicalTarget,
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                minimumPostPurchaseBalanceDecimal = canonicalBaseline ?: "0.00",
                now = now,
            ),
        )
        GoalType.PROJECT_FUNDING, GoalType.TRIP_FUNDING -> CostFundingGoalTemplate.build(
            CostFundingTemplateRequest(
                id = goalId,
                name = name.trim(),
                type = type,
                expectedDecimal = canonicalTarget,
                safeDecimal = canonicalBaseline ?: canonicalTarget,
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                threshold = costThreshold,
                now = now,
            ),
        )
        GoalType.INCOME_GROWTH -> IncomeGrowthGoalTemplate.build(
            IncomeGrowthTemplateRequest(
                id = goalId,
                name = name.trim(),
                targetDecimal = canonicalTarget,
                baselineDecimal = canonicalBaseline,
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                confirmationPeriods = periods.coerceIn(1, 3),
                now = now,
            ),
        )
        GoalType.EXPENSE_REDUCTION, GoalType.EXPENSE_CEILING -> ExpenseGoalTemplates.build(
            ExpenseGoalTemplateRequest(
                id = goalId,
                name = name.trim(),
                type = type,
                baselineDecimal = requireNotNull(canonicalBaseline) { "خط الأساس مطلوب لهذا النوع" },
                fixedTargetDecimal = canonicalTarget,
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                confirmationPeriods = periods,
                now = now,
            ),
        )
        GoalType.EMERGENCY_FUND -> EmergencyFundGoalTemplate.build(
            EmergencyFundTemplateRequest(
                id = goalId,
                name = name.trim(),
                coverageMonths = coverageMonthsFrom(canonicalTarget),
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                essentialPurposeKeys = essentialPurposeKeys,
                now = now,
            ),
        )
        GoalType.DEBT_PAYOFF -> DebtPayoffGoalTemplate.build(
            DebtPayoffTemplateRequest(
                id = goalId,
                name = name.trim(),
                baselineDebtDecimal = canonicalTarget,
                scopeMode = debtScopeMode,
                selectedAccountIds = selectedDebtAccountIds.toList().sorted(),
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                now = now,
            ),
        )
        GoalType.NET_WORTH_GROWTH -> NetWorthGrowthGoalTemplate.build(
            NetWorthGrowthTemplateRequest(
                id = goalId,
                name = name.trim(),
                baselineDecimal = requireNotNull(canonicalBaseline) { "خط الأساس مطلوب لهذا النوع" },
                fixedTargetDecimal = canonicalTarget,
                startDate = startDate,
                deadline = parsedDeadline.toString(),
                timezoneId = timezoneId,
                now = now,
            ),
        )
    }
    return aggregate.copy(
        goal = aggregate.goal.copy(
            lifecycleStatus = status,
            healthStatus = healthStatus,
            confirmationPeriods = aggregate.goal.confirmationPeriods,
            revision = revision,
            readyAt = readyAt,
            completedAt = completedAt,
            cancelledAt = cancelledAt,
            archivedAt = archivedAt,
            syncState = "PENDING",
        ),
    )
}

private fun GoalAggregate.toEditorState(debtAccountOptions: List<DebtAccountOption>): GoalEditorState {
    val selectedDebtIds = scopes
        .filter { it.deletedAt == null && it.dimension == ScopeDimension.DEBT_ACCOUNT && it.mode == "INCLUDE" }
        .map { it.referenceId }
        .toSet()
    val essentialKeys = scopes
        .filter { it.deletedAt == null && it.dimension == ScopeDimension.ESSENTIAL_PURPOSE && it.mode == "INCLUDE" }
        .joinToString(", ") { it.referenceId }
    val debtMode = GoalConfigJson.decode(goal.configJson).settings["debtSelection"]
        ?.let { runCatching { DebtPayoffScopeMode.valueOf(it) }.getOrNull() }
        ?: if (selectedDebtIds.isEmpty()) DebtPayoffScopeMode.ALL_PAYABLE else DebtPayoffScopeMode.SELECTED_ACCOUNTS

    return GoalEditorState(
        id = goal.id,
        name = goal.name,
        type = goal.type,
        targetInput = if (goal.type == GoalType.DEBT_PAYOFF) goal.baselineDecimal.orEmpty() else goal.targetDecimal,
        deadline = goal.deadline,
        confirmationPeriods = goal.confirmationPeriods.toString(),
        costThreshold = goal.costThreshold,
        essentialPurposeInput = essentialKeys,
        debtScopeMode = debtMode,
        selectedDebtAccountIds = selectedDebtIds,
        debtAccountOptions = debtAccountOptions,
        baselineInput = goal.baselineDecimal.orEmpty(),
        revision = goal.revision,
        lifecycleStatus = goal.lifecycleStatus,
        healthStatus = goal.healthStatus,
        readyAt = goal.readyAt,
        completedAt = goal.completedAt,
        cancelledAt = goal.cancelledAt,
        archivedAt = goal.archivedAt,
        dirty = false,
    )
}

private fun coverageMonthsFrom(canonicalTarget: String): Int {
    val value = BigDecimal(canonicalTarget).setScale(0, RoundingMode.UNNECESSARY).toInt()
    require(value > 0) { "عدد أشهر صندوق الطوارئ يجب أن يكون عددًا صحيحًا موجبًا" }
    return value
}

private fun String.filterMoneyInput(): String =
    filter { it.isDigit() || it == '.' }.let { value ->
        val dot = value.indexOf('.')
        if (dot == -1) value else value.take(dot + 1) + value.drop(dot + 1).replace(".", "")
    }

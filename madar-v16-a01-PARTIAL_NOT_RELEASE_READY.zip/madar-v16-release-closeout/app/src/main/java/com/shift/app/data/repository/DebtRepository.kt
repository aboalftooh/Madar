package com.shift.app.data.repository

import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.entities.Debt
import com.shift.app.domain.finance.SyncState
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@Deprecated(
    message = "Legacy debt storage is backup/migration-only; use DebtLedgerRepository for financial behavior",
    level = DeprecationLevel.WARNING,
)
class DebtRepository @Inject constructor(
    private val dao: DebtDao,
    private val changePublisher: FinancialChangePublisher,
) {
    fun getAll(): Flow<List<Debt>>        = dao.getAll()
    suspend fun insert(d: Debt) {
        val pending = d.copy(syncState = SyncState.Pending.dbValue)
        dao.insert(pending)
        publish(pending, "insert")
    }
    suspend fun update(d: Debt) {
        val pending = d.copy(syncState = SyncState.Pending.dbValue)
        dao.update(pending)
        publish(pending, "update")
    }
    suspend fun upsertAll(items: List<Debt>) {
        val pending = items.map { it.copy(syncState = SyncState.Pending.dbValue) }
        dao.upsertAll(pending)
        pending.forEach { publish(it, "restore") }
    }
    suspend fun getById(id: String): Debt? = dao.getById(id)
    suspend fun deleteAll()               = dao.deleteAll()

    private suspend fun publish(debt: Debt, mutation: String) {
        changePublisher.publish(
            sourceType = "debts",
            sourceId = debt.id,
            operationId = "legacy-debt:$mutation:${debt.id}:${debt.updatedAt}",
            effectiveDate = debt.dueDate,
            changedFields = "amount,type,dueDate,isSettled,deletedAt",
            createdAt = debt.updatedAt,
        )
    }
}

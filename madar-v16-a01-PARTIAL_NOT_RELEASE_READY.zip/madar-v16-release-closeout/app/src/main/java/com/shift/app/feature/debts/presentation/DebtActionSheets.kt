package com.shift.app.feature.debts.presentation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.ui.theme.AccentBlue
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.SurfaceVariant
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import com.shift.app.utils.NumberDisplayFormatter
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID

@Composable
internal fun CreateDebtAccountSheet(
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onCreate: (DebtDirection, String, String, String?, Boolean) -> Unit
) {
    var direction by remember { mutableStateOf(DebtDirection.Payable) }
    var partyName by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }
    var includeInActivePayoffGoal by remember { mutableStateOf(true) }
    var showDueDatePicker by remember { mutableStateOf(false) }
    val dueDatePickerState = rememberDatePickerState()
    val previewState = remember(direction, partyName, amount) {
        DebtOperationWizardState(
            operationId = UUID.randomUUID().toString(),
            accountId = UUID.randomUUID().toString(),
            direction = direction,
            partyName = partyName.ifBlank { "طرف" },
            amountDecimal = amount,
            cashSource = DebtCashSource.External
        )
    }
    val canSubmit = partyName.isNotBlank() && amount.isNotBlank() && !isSubmitting

    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("إضافة حساب دين", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            DirectionPicker(direction) { direction = it }
            OutlinedTextField(value = partyName, onValueChange = { partyName = it }, label = { Text("الطرف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            DebtMoneyField(value = amount, onValueChange = { amount = it }, label = "المبلغ")
            DebtDateField(
                value = dueDate,
                label = "تاريخ الاستحقاق اختياري",
                modifier = Modifier.fillMaxWidth(),
                onOpenPicker = { showDueDatePicker = true }
            )
            if (direction == DebtDirection.Payable) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = includeInActivePayoffGoal,
                        onCheckedChange = { includeInActivePayoffGoal = it },
                    )
                    Text(
                        text = if (includeInActivePayoffGoal) "إدخال الدين في هدف سداد نشط" else "استبعاد الدين من هدف سداد نشط",
                        color = TextSecondary,
                        fontSize = 13.sp,
                    )
                }
            }
            if (amount.isNotBlank()) DebtImpactPreview(previewState.previewOrNull())
            Button(
                enabled = canSubmit,
                onClick = {
                    onCreate(
                        direction,
                        partyName.trim(),
                        amount,
                        dueDate.takeIf { it.isNotBlank() },
                        includeInActivePayoffGoal,
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("حفظ") }
        }
    }
    if (showDueDatePicker) {
        DebtDatePickerDialog(
            state = dueDatePickerState,
            onDismiss = { showDueDatePicker = false },
            onConfirm = { selected ->
                dueDate = selected
                showDueDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CompositeOperationSheet(
    state: DebtCenterState,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onEvent: (DebtsUiEvent) -> Unit,
) {
    var mode by remember { mutableStateOf(CompositeMode.Cash) }
    var direction by remember { mutableStateOf(DebtDirection.Payable) }
    var party by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var secondaryAmount by remember { mutableStateOf("") }
    var text1 by remember { mutableStateOf("") }
    var text2 by remember { mutableStateOf("") }
    var cashSource by remember { mutableStateOf(DebtCashSource.External) }
    val canSubmit = party.isNotBlank() && amount.isNotBlank() && !isSubmitting

    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("عملية دين مركبة", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CompositeMode.entries.toList()) { item: CompositeMode ->
                    FilterChip(selected = mode == item, onClick = { mode = item }, label = { Text(item.label) })
                }
            }
            if (mode == CompositeMode.Cash) DirectionPicker(direction) { direction = it }
            OutlinedTextField(value = party, onValueChange = { party = it }, label = { Text(if (mode == CompositeMode.CreditSale) "المشتري" else "الطرف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            DebtMoneyField(value = amount, onValueChange = { amount = it }, label = when (mode) {
                CompositeMode.FinancedAsset -> "قيمة الدين الممول"
                CompositeMode.CreditSale -> "مبلغ البيع"
                else -> "المبلغ"
            })
            when (mode) {
                CompositeMode.Cash -> {
                    CashSourcePicker(cashSource) { cashSource = it }
                    DebtOperationRoute(
                        state = DebtOperationWizardState(UUID.randomUUID().toString(), UUID.randomUUID().toString(), direction, party.ifBlank { "طرف" }, amount, cashSource),
                        amount = amount,
                        onAmountChange = { amount = it },
                        onSubmit = {
                            onEvent(DebtsUiEvent.RecordCashPrincipal(null, direction, party, amount, cashSource))
                            onDismiss()
                        }
                    )
                }
                CompositeMode.DeferredExpense -> {
                    OutlinedTextField(value = text1, onValueChange = { text1 = it }, label = { Text("الغرض") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(enabled = canSubmit && text1.isNotBlank(), onClick = {
                        onEvent(DebtsUiEvent.RecordDeferredExpense(party, amount, text1))
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("حفظ مصروف آجل") }
                }
                CompositeMode.AccruedIncome -> {
                    OutlinedTextField(value = text1, onValueChange = { text1 = it }, label = { Text("تصنيف الدخل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(enabled = canSubmit && text1.isNotBlank(), onClick = {
                        onEvent(DebtsUiEvent.RecordAccruedIncome(party, amount, text1))
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("حفظ دخل مستحق") }
                }
                CompositeMode.FinancedAsset -> {
                    OutlinedTextField(value = text1, onValueChange = { text1 = it }, label = { Text("نوع الأصل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = text2, onValueChange = { text2 = it }, label = { Text("اسم الأصل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    DebtMoneyField(value = secondaryAmount, onValueChange = { secondaryAmount = it }, label = "قيمة الأصل / الدفعة النقدية إن وجدت")
                    Button(enabled = canSubmit && text1.isNotBlank() && text2.isNotBlank(), onClick = {
                        onEvent(DebtsUiEvent.RecordFinancedAssetPurchase(party, text1, text2, amount, secondaryAmount.ifBlank { amount }, "0.00"))
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("حفظ أصل ممول") }
                }
                CompositeMode.CreditSale -> {
                    AssetOptions(state)
                    OutlinedTextField(value = text1, onValueChange = { text1 = it }, label = { Text("معرف الأصل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    DebtMoneyField(value = secondaryAmount, onValueChange = { secondaryAmount = it }, label = "المحصل نقداً")
                    Button(enabled = canSubmit && text1.isNotBlank(), onClick = {
                        onEvent(DebtsUiEvent.RecordAssetSaleOnCredit(text1, party, amount, secondaryAmount.ifBlank { "0.00" }))
                        onDismiss()
                    }, modifier = Modifier.fillMaxWidth()) { Text("حفظ بيع بالأجل") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CashPrincipalSheet(
    account: DebtAccountUiModel,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (String, DebtCashSource) -> Unit
) {
    var amount by remember(account.id) { mutableStateOf("") }
    var cashSource by remember { mutableStateOf(DebtCashSource.External) }
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("زيادة أصل الدين", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            CashSourcePicker(cashSource) { cashSource = it }
            DebtOperationRoute(
                state = DebtOperationWizardState(UUID.randomUUID().toString(), account.id, DebtDirection.fromDb(account.directionLabel), account.partyName, amount, cashSource, isSubmitting),
                amount = amount,
                onAmountChange = { amount = it },
                onSubmit = { if (amount.isNotBlank()) onSubmit(amount, cashSource) }
            )
            Button(enabled = amount.isNotBlank() && !isSubmitting, onClick = { onSubmit(amount, cashSource) }, modifier = Modifier.fillMaxWidth()) {
                Text("حفظ الزيادة")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ReduceDebtSheet(
    account: DebtAccountUiModel,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (String, DebtCashSource) -> Unit
) {
    var amount by remember(account.id) { mutableStateOf("") }
    var cashSource by remember { mutableStateOf(DebtCashSource.External) }
    val state = DebtReductionSheetState(account.id, account.remainingDecimal, amount, cashSource, isSubmitting)
    val isReceivable = account.directionLabel == DebtDirection.Receivable.dbValue
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text(account.partyName, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text("المتبقي: ${NumberDisplayFormatter.formatDecimalText(account.remainingDecimal, useGrouping = true)} جنيه", color = TextMuted)
            CashSourcePicker(cashSource) { cashSource = it }
            if (isReceivable) {
                DebtCollectionSheet(state = state, onAmountChange = { amount = it }, onSubmit = { onSubmit(amount, cashSource) })
            } else {
                DebtPaymentSheet(state = state, onAmountChange = { amount = it }, onSubmit = { onSubmit(amount, cashSource) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SettlementActionSheet(
    state: DebtCenterState,
    account: DebtAccountUiModel,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onEvent: (DebtsUiEvent) -> Unit,
) {
    var action by remember { mutableStateOf(DebtTransactionType.Waiver) }
    var amount by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var assetId by remember { mutableStateOf("") }
    var assetValue by remember { mutableStateOf("") }
    var counterAccountId by remember { mutableStateOf("") }
    val reasoned = DebtReasonedActionState(amount, reason, isSubmitting)
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("تسوية الدين", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(
                    listOf(
                        DebtTransactionType.Waiver,
                        DebtTransactionType.WriteOff,
                        DebtTransactionType.GiftConversion,
                        DebtTransactionType.Offset,
                        DebtTransactionType.AssetSettlement
                    )
                ) { item: DebtTransactionType ->
                    FilterChip(selected = action == item, onClick = { action = item }, label = { Text(item.dbValue) })
                }
            }
            DebtMoneyField(value = amount, onValueChange = { amount = it }, label = "المبلغ")
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("السبب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            if (action == DebtTransactionType.AssetSettlement) {
                AssetOptions(state)
                OutlinedTextField(value = assetId, onValueChange = { assetId = it }, label = { Text("معرف الأصل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DebtMoneyField(value = assetValue, onValueChange = { assetValue = it }, label = "قيمة الأصل")
            }
            if (action == DebtTransactionType.Offset) {
                Text("اختر الحساب المقابل للمقاصة", color = TextMuted)
                state.accounts
                    .filter { it.id != account.id && it.directionLabel != account.directionLabel }
                    .take(6)
                    .forEach { Text("${it.id} · ${it.partyName} · ${it.remainingDecimal}", color = TextMuted, fontSize = 11.sp) }
                OutlinedTextField(value = counterAccountId, onValueChange = { counterAccountId = it }, label = { Text("معرف الحساب المقابل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            DebtSettlementRoute(state = reasoned, onSubmit = {
                when (action) {
                    DebtTransactionType.AssetSettlement -> onEvent(DebtsUiEvent.RecordAssetSettlement(account.id, assetId, amount, assetValue, reason))
                    DebtTransactionType.Offset -> {
                        if (account.directionLabel == DebtDirection.Payable.dbValue) {
                            onEvent(DebtsUiEvent.RecordOffset(account.id, counterAccountId, amount, reason))
                        } else {
                            onEvent(DebtsUiEvent.RecordOffset(counterAccountId, account.id, amount, reason))
                        }
                    }
                    else -> onEvent(DebtsUiEvent.RecordAdjustment(account.id, action, amount, reason))
                }
                onDismiss()
            })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CorrectionActionSheet(
    account: DebtAccountUiModel,
    timeline: List<com.shift.app.feature.debts.presentation.DebtTimelineItemUiModel>,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onReverse: (String, String) -> Unit
) {
    var originalId by remember { mutableStateOf(timeline.lastOrNull()?.id.orEmpty()) }
    var reason by remember { mutableStateOf("") }
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("عكس / تصحيح ${account.partyName}", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("آخر الحركات", color = TextMuted)
            timeline.takeLast(5).forEach { Text("${it.id} · ${it.title} · ${it.amountDecimal}", color = TextMuted, fontSize = 11.sp) }
            OutlinedTextField(value = originalId, onValueChange = { originalId = it }, label = { Text("معرف الحركة الأصلية") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب العكس") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            DebtCorrectionRoute(
                state = DebtReasonedActionState(amountDecimal = "0.00", reason = reason, submitted = isSubmitting),
                historical = true,
                onSubmit = { onReverse(originalId, reason) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun OrganizationActionSheet(
    account: DebtAccountUiModel,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onEvent: (DebtsUiEvent) -> Unit,
) {
    var mode by remember { mutableStateOf("schedule") }
    var amount by remember { mutableStateOf(account.remainingDecimal) }
    var text by remember { mutableStateOf("") }
    var count by remember { mutableStateOf("3") }
    var reason by remember { mutableStateOf("") }
    var showScheduleDatePicker by remember { mutableStateOf(false) }
    val scheduleDatePickerState = rememberDatePickerState()
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            Text("تنظيم الدين", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            DebtOrganizationRoute(scheduleTotalDecimal = amount, installments = count.toIntOrNull() ?: 0)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { mode = "schedule" }, modifier = Modifier.weight(1f)) { Text("جدولة") }
                Button(onClick = { mode = "transfer" }, modifier = Modifier.weight(1f)) { Text("نقل") }
                Button(onClick = { mode = "archive" }, modifier = Modifier.weight(1f)) { Text("أرشفة") }
            }
            DebtMoneyField(value = amount, onValueChange = { amount = it }, label = "المبلغ")
            if (mode == "schedule") {
                DebtDateField(
                    value = text,
                    label = "أول تاريخ استحقاق",
                    modifier = Modifier.fillMaxWidth(),
                    onOpenPicker = { showScheduleDatePicker = true }
                )
                OutlinedTextField(value = count, onValueChange = { count = it.filter(Char::isDigit) }, label = { Text("عدد الدفعات") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            } else if (mode == "transfer") {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("الطرف الجديد") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب النقل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            } else {
                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب الأرشفة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            Button(enabled = !isSubmitting, onClick = {
                when (mode) {
                    "schedule" -> onEvent(DebtsUiEvent.WriteSchedule(account.id, amount, text, count.toIntOrNull() ?: 1))
                    "transfer" -> onEvent(DebtsUiEvent.TransferToNewParty(account.id, text, amount, reason))
                    else -> onEvent(DebtsUiEvent.ArchiveAccount(account.id, reason))
                }
                onDismiss()
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ التنظيم") }
        }
    }
    if (showScheduleDatePicker) {
        DebtDatePickerDialog(
            state = scheduleDatePickerState,
            onDismiss = { showScheduleDatePicker = false },
            onConfirm = { selected ->
                text = selected
                showScheduleDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MigrationReviewSheet(state: DebtCenterState, onDismiss: () -> Unit) {
    DebtDialog(onDismiss = onDismiss) {
        SheetColumn {
            LegacyDebtMigrationRoute(
                pendingReviews = state.pendingMigrationReviews,
                resolvedReviews = state.resolvedMigrationReviews
            )
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("تم") }
        }
    }
}

@Composable
private fun DebtDialog(
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 18.dp),
            shape = RoundedCornerShape(18.dp),
            color = SurfaceDark
        ) {
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DebtDatePickerDialog(
    state: androidx.compose.material3.DatePickerState,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    state.selectedDateMillis
                        ?.let { onConfirm(formatDateMillis(it)) }
                        ?: onDismiss()
                }
            ) { Text("اختيار") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
        colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
    ) {
        DatePicker(state = state)
    }
}

@Composable
private fun DirectionPicker(value: DebtDirection, onChange: (DebtDirection) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = { onChange(DebtDirection.Payable) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = if (value == DebtDirection.Payable) ExpenseRed else SurfaceVariant)
        ) { Text("علي", color = TextPrimary) }
        Button(
            onClick = { onChange(DebtDirection.Receivable) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = if (value == DebtDirection.Receivable) IncomeGreen else SurfaceVariant)
        ) { Text("لي", color = TextPrimary) }
    }
}

@Composable
private fun CashSourcePicker(value: DebtCashSource, onChange: (DebtCashSource) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onChange(DebtCashSource.External) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (value == DebtCashSource.External) AccentBlue else SurfaceVariant)) {
            Text("خارجي")
        }
        Button(onClick = { onChange(DebtCashSource.MadarBalance) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (value == DebtCashSource.MadarBalance) AccentBlue else SurfaceVariant)) {
            Text("رصيد Madar")
        }
    }
}

@Composable
private fun AssetOptions(state: DebtCenterState) {
    if (state.activeAssets.isNotEmpty()) {
        Text("الأصول المتاحة:", color = TextMuted)
        state.activeAssets.take(5).forEach {
            Text("${it.id} · ${it.name} · ${it.valueDecimal}", color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SheetColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun DebtImpactPreview(impact: com.shift.app.domain.debt.DebtFinancialImpact?) {
    if (impact != null) {
        com.shift.app.feature.debts.presentation.DebtImpactPreview(impact)
    }
}

private fun DebtOperationWizardState.previewOrNull() =
    runCatching { preview(System.currentTimeMillis()) }.getOrNull()

private fun formatDateMillis(millis: Long): String =
    Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate().toString()

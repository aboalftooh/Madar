package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.LEGACY_HISTORY_MIGRATION_KEY
import com.shift.app.domain.finance.LEGACY_HISTORY_STATUS_COMPLETED
import com.shift.app.domain.finance.LegacyHistoryMigrationPlanner
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject

data class LinkedIncomeRecords(
    val transaction: Transaction,
    val balanceTransaction: BalanceTransaction? = null,
    val payment: Payment? = null
)

object IncomeLedgerFactory {
    fun create(
        transaction: Transaction,
        operationId: String = UUID.randomUUID().toString(),
        balanceTransactionId: String = UUID.randomUUID().toString()
    ): LinkedIncomeRecords {
        require(transaction.type == "income") { "Only income can be linked to an income ledger row" }
        val amount = DecimalText.moneyFromLegacyDouble(transaction.amount).also {
            require(DecimalText.toBigDecimal(it).signum() > 0) { "Income must be positive" }
        }
        val balance = BalanceTransaction(
            id = balanceTransactionId,
            operationId = operationId,
            direction = BalanceDirection.Inflow.dbValue,
            kind = BalanceTransactionKind.Income.dbValue,
            amountDecimal = amount,
            date = transaction.date,
            note = transaction.note,
            sourceType = "transaction",
            sourceId = transaction.id,
            updatedAt = transaction.updatedAt
        )
        return LinkedIncomeRecords(
            transaction = transaction.copy(
                operationId = operationId,
                balanceTransactionId = balance.id
            ),
            balanceTransaction = balance
        )
    }
}

class TransactionRepository @Inject constructor(
    private val db: MadarDatabase,
    private val dao: TransactionDao,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val markerDao: LedgerHistoryMigrationDao,
    private val changePublisher: FinancialChangePublisher,
) {
    fun getAll(): Flow<List<Transaction>> = dao.getAll()
    fun getAllIncludingDeleted(): Flow<List<Transaction>> = dao.getAllIncludingDeleted()
    suspend fun insert(t: Transaction) = db.withTransaction {
        val pending = t.copy(syncState = SyncState.Pending.dbValue)
        dao.insert(pending)
        publishTransaction(pending, "insert")
    }
    suspend fun update(t: Transaction) = db.withTransaction {
        val pending = t.copy(syncState = SyncState.Pending.dbValue)
        dao.update(pending)
        publishTransaction(pending, "update")
    }
    suspend fun upsertAll(items: List<Transaction>) = db.withTransaction {
        val pending = items.map { it.copy(syncState = SyncState.Pending.dbValue) }
        dao.upsertAll(pending)
        pending.forEach { publishTransaction(it, "restore") }
    }
    suspend fun getById(id: String): Transaction? = dao.getById(id)
    suspend fun getAllOnce(): List<Transaction> = dao.getAllOnce()
    suspend fun deleteAll()               = dao.deleteAll()
    fun expensePurposeSuggestions(): Flow<List<String>> = dao.expensePurposeSuggestions()

    /** Links only newly-created income. Existing legacy rows are never backfilled here. */
    suspend fun insertNew(transaction: Transaction, linkIncomeToBalance: Boolean): LinkedIncomeRecords =
        db.withTransaction {
            require(dao.getById(transaction.id) == null) { "Transaction already exists" }
            val historyCompleted = markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)?.status ==
                LEGACY_HISTORY_STATUS_COMPLETED
            if (historyCompleted && transaction.type == "expense") {
                val currency = balanceDao.getActiveOpeningBalance()?.currencyCode ?: "SDG"
                val operation = LegacyHistoryMigrationPlanner.operationForTransaction(transaction, currency)
                balanceDao.insert(operation.balanceTransaction)
                paymentDao.insert(requireNotNull(operation.payment))
                dao.insert(operation.transaction)
                publishTransaction(operation.transaction, "insert")
                return@withTransaction LinkedIncomeRecords(
                    operation.transaction,
                    operation.balanceTransaction,
                    operation.payment
                )
            }
            if (transaction.type != "income" || (!linkIncomeToBalance && !historyCompleted)) {
                dao.insert(transaction)
                publishTransaction(transaction, "insert")
                return@withTransaction LinkedIncomeRecords(transaction)
            }

            val records = IncomeLedgerFactory.create(transaction)
            balanceDao.insert(requireNotNull(records.balanceTransaction))
            dao.insert(records.transaction)
            publishTransaction(records.transaction, "insert")
            records
        }

    suspend fun updateWithLinkedIncome(transaction: Transaction): LinkedIncomeRecords = db.withTransaction {
        val stored = requireNotNull(dao.getById(transaction.id)) { "Transaction not found" }
        val balanceId = stored.balanceTransactionId
        if (balanceId == null) {
            if (
                transaction.deletedAt == null &&
                markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)?.status == LEGACY_HISTORY_STATUS_COMPLETED
            ) {
                val currency = balanceDao.getActiveOpeningBalance()?.currencyCode ?: "SDG"
                val operation = LegacyHistoryMigrationPlanner.operationForTransaction(transaction, currency)
                val now = transaction.updatedAt
                val balance = operation.balanceTransaction.copy(updatedAt = now)
                val payment = operation.payment?.copy(updatedAt = now)
                balanceDao.insert(balance)
                payment?.let { paymentDao.insert(it) }
                dao.update(operation.transaction.copy(updatedAt = now))
                publishTransaction(operation.transaction.copy(updatedAt = now), "update")
                return@withTransaction LinkedIncomeRecords(
                    operation.transaction.copy(updatedAt = now),
                    balance,
                    payment
                )
            }
            // Before full-history migration, a legacy row remains report-only when edited.
            val updated = transaction.copy(operationId = null, balanceTransactionId = null)
            dao.update(updated)
            publishTransaction(updated, "update")
            return@withTransaction LinkedIncomeRecords(updated)
        }

        val balance = requireNotNull(balanceDao.getById(balanceId)) { "Linked balance transaction not found" }
        val operationId = requireNotNull(stored.operationId ?: balance.operationId)
        val updatedAt = transaction.updatedAt
        require(transaction.type == stored.type) { "Linked transaction type cannot be changed" }
        val updatedBalance = balance.copy(
            operationId = operationId,
            amountDecimal = DecimalText.moneyFromLegacyDouble(transaction.amount).also {
                require(DecimalText.toBigDecimal(it).signum() > 0) { "Income must be positive" }
            },
            date = transaction.date,
            note = transaction.note,
            sourceId = transaction.id,
            syncState = SyncState.Pending.dbValue,
            updatedAt = updatedAt,
            deletedAt = null
        )
        val updatedTransaction = transaction.copy(
            operationId = operationId,
            balanceTransactionId = balance.id,
            deletedAt = null
        )
        val updatedPayment = if (transaction.type == "expense") {
            require(balance.legacyTransactionId == transaction.id) { "Linked expense is not a migrated legacy expense" }
            val payment = requireNotNull(paymentDao.getByLegacyTransactionId(transaction.id)) {
                "Linked legacy expense payment not found"
            }
            val purpose = transaction.purpose.ifBlank { transaction.category }
            payment.copy(
                operationId = operationId,
                amountDecimal = updatedBalance.amountDecimal,
                date = transaction.date,
                purpose = purpose,
                purposeKey = transaction.purposeKey.ifBlank { purpose.trim().lowercase() },
                beneficiaryId = transaction.expenseBeneficiaryId,
                beneficiaryNameSnapshot = transaction.expenseBeneficiaryNameSnapshot,
                balanceTransactionId = balance.id,
                legacyTransactionId = transaction.id,
                note = transaction.note,
                syncState = SyncState.Pending.dbValue,
                updatedAt = updatedAt,
                deletedAt = null
            )
        } else {
            require(transaction.type == "income") { "Unsupported linked transaction type" }
            null
        }
        balanceDao.update(updatedBalance)
        updatedPayment?.let { paymentDao.update(it) }
        dao.update(updatedTransaction)
        publishTransaction(updatedTransaction, "update")
        LinkedIncomeRecords(updatedTransaction, updatedBalance, updatedPayment)
    }

    suspend fun softDeleteWithLinkedIncome(id: String, deletedAt: Long): LinkedIncomeRecords =
        db.withTransaction {
            val stored = requireNotNull(dao.getById(id)) { "Transaction not found" }
            require((stored.operationId == null) == (stored.balanceTransactionId == null)) {
                "Transaction contains a partial ledger link"
            }
            val deletedTransaction = stored.copy(updatedAt = deletedAt, deletedAt = deletedAt)
            val linkedBalance = if (stored.balanceTransactionId != null) {
                requireNotNull(balanceDao.getById(stored.balanceTransactionId)) {
                    "Linked balance transaction not found"
                }.also {
                    require(it.operationId == stored.operationId) { "Linked balance operation does not match" }
                }
            } else {
                null
            }
            val deletedBalance = linkedBalance?.copy(
                syncState = SyncState.Pending.dbValue,
                updatedAt = deletedAt,
                deletedAt = deletedAt
            )
            val linkedPayment = paymentDao.getByLegacyTransactionId(stored.id)
            if (stored.type == "expense" && linkedBalance != null) {
                require(linkedBalance.legacyTransactionId == stored.id) {
                    "Linked expense is missing its legacy identity"
                }
                requireNotNull(linkedPayment) { "Linked legacy expense payment not found" }
            } else {
                require(linkedPayment == null) { "Legacy payment exists without its linked expense balance" }
            }
            val deletedPayment = linkedPayment?.copy(
                syncState = SyncState.Pending.dbValue,
                updatedAt = deletedAt,
                deletedAt = deletedAt
            )
            deletedBalance?.let { balanceDao.update(it) }
            deletedPayment?.let { paymentDao.update(it) }
            dao.update(deletedTransaction)
            publishTransaction(deletedTransaction, "delete")
            LinkedIncomeRecords(deletedTransaction, deletedBalance, deletedPayment)
        }

    private suspend fun publishTransaction(transaction: Transaction, mutation: String) {
        changePublisher.publish(
            sourceType = "transactions",
            sourceId = transaction.id,
            operationId = "transaction:$mutation:${transaction.id}:${transaction.updatedAt}",
            effectiveDate = transaction.date,
            changedFields = "type,amount,date,purpose,deletedAt",
            createdAt = transaction.updatedAt,
        )
    }
}

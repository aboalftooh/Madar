package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.shift.app.data.local.entities.DebtLink

@Dao
interface DebtLinkDao {
    @Query("SELECT * FROM debt_links WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<DebtLink>

    @Query("SELECT * FROM debt_links WHERE accountId = :accountId AND deletedAt IS NULL")
    suspend fun getActiveForAccount(accountId: String): List<DebtLink>

    @Query("SELECT * FROM debt_links WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<DebtLink>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(link: DebtLink)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(links: List<DebtLink>)

    @Query("DELETE FROM debt_links")
    suspend fun deleteAll()
}

package com.shift.app.feature.auth.data

import com.shift.app.feature.auth.domain.AuthGateway
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.OtpType
import io.github.jan.supabase.gotrue.providers.builtin.Email
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SupabaseAuthGateway @Inject constructor(
    private val auth: Auth,
) : AuthGateway {
    override suspend fun signIn(email: String, password: String) {
        auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
    }

    override suspend fun signUp(email: String, password: String) {
        auth.signUpWith(Email) {
            this.email = email
            this.password = password
        }
    }

    override suspend fun requestPasswordReset(email: String) {
        auth.resetPasswordForEmail(email)
    }

    override suspend fun updatePassword(newPassword: String) {
        auth.updateUser { password = newPassword }
    }

    override suspend fun verifyRecoveryOtp(email: String, code: String) {
        auth.verifyEmailOtp(
            type = OtpType.Email.RECOVERY,
            email = email,
            token = code,
        )
    }

    override suspend fun signOut() {
        auth.signOut()
    }

    override suspend fun clearLocalAuthSession() {
        auth.clearSession()
    }
}

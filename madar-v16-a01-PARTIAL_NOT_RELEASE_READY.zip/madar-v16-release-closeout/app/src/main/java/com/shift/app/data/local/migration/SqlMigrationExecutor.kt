package com.shift.app.data.local.migration

/** Small SQL port that keeps migration plans executable in plain JVM tests. */
fun interface SqlMigrationExecutor {
    fun execute(sql: String, bindArgs: Array<out Any?>)
}

fun SqlMigrationExecutor.execute(sql: String) = execute(sql, emptyArray())

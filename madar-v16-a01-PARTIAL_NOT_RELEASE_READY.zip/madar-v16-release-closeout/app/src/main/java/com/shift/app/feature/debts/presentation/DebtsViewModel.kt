package com.shift.app.feature.debts.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import com.shift.app.feature.debts.domain.usecase.DebtCommandUseCases
import com.shift.app.feature.debts.domain.usecase.ObserveDebtCenterUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch


data class DebtCenterState(
    val selectedTab: DebtCenterTab = DebtCenterTab.All,
    val searchQuery: String = "",
    val accounts: List<DebtAccountUiModel> = emptyList(),
    val timelinesByAccount: Map<String, List<DebtTimelineItemUiModel>> = emptyMap(),
    val activeAssets: List<DebtAssetOptionUiModel> = emptyList(),
    val pendingMigrationReviews: Int = 0,
    val resolvedMigrationReviews: Int = 0,
    val totalReceivableDecimal: String = "0.00",
    val totalPayableDecimal: String = "0.00",
    val netDecimal: String = "0.00",
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
) {
    val visibleAccounts: List<DebtAccountUiModel>
        get() = accounts
            .filter { searchQuery.isBlank() || it.partyName.contains(searchQuery, ignoreCase = true) }
            .filter {
                when (selectedTab) {
                    DebtCenterTab.Payables -> it.directionLabel == DebtDirection.Payable.dbValue
                    DebtCenterTab.Receivables -> it.directionLabel == DebtDirection.Receivable.dbValue
                    DebtCenterTab.DueToday -> it.status == "due_today"
                    DebtCenterTab.Overdue -> it.status == "overdue"
                    DebtCenterTab.Upcoming -> it.status == "upcoming"
                    DebtCenterTab.Settled -> it.status == "settled"
                    DebtCenterTab.NoDate -> it.status == "no_date"
                    DebtCenterTab.All -> true
                }
            }
}

private data class DebtCenterFilters(
    val selectedTab: DebtCenterTab,
    val searchQuery: String,
    val isSubmitting: Boolean,
    val errorMessage: String?,
)

@HiltViewModel
class DebtsViewModel @Inject constructor(
    observeDebtCenter: ObserveDebtCenterUseCase,
    private val commands: DebtCommandUseCases,
) : ViewModel() {
    private val selectedTab = MutableStateFlow(DebtCenterTab.All)
    private val searchQuery = MutableStateFlow("")
    private val isSubmitting = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)

    private val filters = combine(selectedTab, searchQuery, isSubmitting, errorMessage) { tab, query, submitting, error ->
        DebtCenterFilters(tab, query, submitting, error)
    }

    val state: StateFlow<DebtCenterState> = combine(observeDebtCenter(), filters) { snapshot, currentFilters ->
        DebtCenterState(
            selectedTab = currentFilters.selectedTab,
            searchQuery = currentFilters.searchQuery,
            accounts = snapshot.accounts.map {
                DebtAccountUiModel(
                    id = it.id,
                    partyName = it.partyName,
                    directionLabel = it.direction,
                    remainingDecimal = it.remainingDecimal,
                    dueDate = it.dueDate,
                    status = it.status,
                    syncState = it.syncState,
                    needsReview = it.needsReview,
                )
            },
            timelinesByAccount = snapshot.timelinesByAccount.mapValues { (_, items) ->
                items.map { DebtTimelineItemUiModel(it.id, it.title, it.amountDecimal, it.occurredAt, it.operationId) }
            },
            activeAssets = snapshot.activeAssets.map { DebtAssetOptionUiModel(it.id, it.name, it.valueDecimal) },
            pendingMigrationReviews = snapshot.pendingMigrationReviews,
            resolvedMigrationReviews = snapshot.resolvedMigrationReviews,
            totalReceivableDecimal = snapshot.totalReceivableDecimal,
            totalPayableDecimal = snapshot.totalPayableDecimal,
            netDecimal = snapshot.netDecimal,
            isSubmitting = currentFilters.isSubmitting,
            errorMessage = currentFilters.errorMessage,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DebtCenterState())


    fun onEvent(event: DebtsUiEvent) {
        when (event) {
            is DebtsUiEvent.TabSelected -> selectTab(event.tab)
            is DebtsUiEvent.SearchChanged -> updateSearch(event.query)
            DebtsUiEvent.ErrorDismissed -> clearError()
            is DebtsUiEvent.CreateOpening -> createOpening(
                event.direction, event.partyName, event.amountDecimal, event.dueDate, event.includeInActivePayoffGoal
            )
            is DebtsUiEvent.RecordCashPrincipal -> recordCashPrincipal(
                event.accountId, event.direction, event.partyName, event.amountDecimal, event.cashSource
            )
            is DebtsUiEvent.RecordDeferredExpense -> recordDeferredExpense(
                event.partyName, event.amountDecimal, event.purpose, event.note
            )
            is DebtsUiEvent.RecordAccruedIncome -> recordAccruedIncome(
                event.partyName, event.amountDecimal, event.incomeCategory, event.note
            )
            is DebtsUiEvent.RecordFinancedAssetPurchase -> recordFinancedAssetPurchase(
                event.partyName, event.assetType, event.assetName, event.financedAmountDecimal,
                event.assetValueDecimal, event.cashPaidDecimal
            )
            is DebtsUiEvent.RecordAssetSaleOnCredit -> recordAssetSaleOnCredit(
                event.assetId, event.buyerName, event.saleAmountDecimal, event.cashCollectedDecimal
            )
            is DebtsUiEvent.Reduce -> reduce(event.accountId, event.amountDecimal, event.cashSource)
            is DebtsUiEvent.RecordAdjustment -> recordAdjustment(
                event.accountId, event.type, event.amountDecimal, event.reason
            )
            is DebtsUiEvent.RecordAssetSettlement -> recordAssetSettlement(
                event.accountId, event.assetId, event.amountDecimal, event.assetValueDecimal, event.reason
            )
            is DebtsUiEvent.RecordOffset -> recordOffset(
                event.payableAccountId, event.receivableAccountId, event.amountDecimal, event.reason
            )
            is DebtsUiEvent.ReverseTransaction -> reverseTransaction(event.originalTransactionId, event.reason)
            is DebtsUiEvent.TransferToNewParty -> transferToNewParty(
                event.accountId, event.newPartyName, event.amountDecimal, event.reason
            )
            is DebtsUiEvent.WriteSchedule -> writeSchedule(
                event.accountId, event.totalAmountDecimal, event.firstDueDate, event.count
            )
            is DebtsUiEvent.ArchiveAccount -> archiveAccount(event.accountId, event.reason)
        }
    }

    fun selectTab(tab: DebtCenterTab) { selectedTab.value = tab }
    fun updateSearch(query: String) { searchQuery.value = query }
    fun clearError() { errorMessage.value = null }

    fun createOpening(direction: DebtDirection, partyName: String, amountDecimal: String, dueDate: String? = null, includeInActivePayoffGoal: Boolean) = mutate {
        commands.open(OpenDebtRequest(direction, partyName, amountDecimal, dueDate, includeInActivePayoffGoal))
    }

    fun recordCashPrincipal(accountId: String?, direction: DebtDirection, partyName: String, amountDecimal: String, cashSource: DebtCashSource) = mutate {
        commands.cashPrincipal(CashPrincipalRequest(accountId, direction, partyName, amountDecimal, cashSource))
    }

    fun recordDeferredExpense(partyName: String, amountDecimal: String, purpose: String, note: String = "") = mutate {
        commands.deferredExpense(DeferredExpenseRequest(partyName, amountDecimal, purpose, note))
    }

    fun recordAccruedIncome(partyName: String, amountDecimal: String, incomeCategory: String, note: String = "") = mutate {
        commands.accruedIncome(AccruedIncomeRequest(partyName, amountDecimal, incomeCategory, note))
    }

    fun recordFinancedAssetPurchase(partyName: String, assetType: String, assetName: String, financedAmountDecimal: String, assetValueDecimal: String, cashPaidDecimal: String) = mutate {
        commands.financedAsset(FinancedAssetPurchaseRequest(partyName, assetType, assetName, financedAmountDecimal, assetValueDecimal, cashPaidDecimal))
    }

    fun recordAssetSaleOnCredit(assetId: String, buyerName: String, saleAmountDecimal: String, cashCollectedDecimal: String) = mutate {
        commands.assetSaleOnCredit(AssetSaleOnCreditRequest(assetId, buyerName, saleAmountDecimal, cashCollectedDecimal))
    }

    fun reduce(accountId: String, amountDecimal: String, cashSource: DebtCashSource = DebtCashSource.External) = mutate {
        commands.reduce(ReduceDebtRequest(accountId, amountDecimal, cashSource))
    }

    fun recordAdjustment(accountId: String, type: DebtTransactionType, amountDecimal: String, reason: String) = mutate {
        commands.adjust(AdjustDebtRequest(accountId, type, amountDecimal, reason))
    }

    fun recordAssetSettlement(accountId: String, assetId: String, amountDecimal: String, assetValueDecimal: String, reason: String) = mutate {
        commands.settleWithAsset(AssetSettlementRequest(accountId, assetId, amountDecimal, assetValueDecimal, reason))
    }

    fun recordOffset(payableAccountId: String, receivableAccountId: String, amountDecimal: String, reason: String) = mutate {
        commands.offset(OffsetDebtRequest(payableAccountId, receivableAccountId, amountDecimal, reason))
    }

    fun reverseTransaction(originalTransactionId: String, reason: String) = mutate {
        commands.reverse(ReverseDebtTransactionRequest(originalTransactionId, reason))
    }

    fun transferToNewParty(accountId: String, newPartyName: String, amountDecimal: String, reason: String) = mutate {
        commands.transfer(TransferDebtRequest(accountId, newPartyName, amountDecimal, reason))
    }

    fun writeSchedule(accountId: String, totalAmountDecimal: String, firstDueDate: String, count: Int) = mutate {
        commands.writeSchedule(WriteDebtScheduleRequest(accountId, totalAmountDecimal, firstDueDate, count))
    }

    fun archiveAccount(accountId: String, reason: String) = mutate {
        commands.archive(ArchiveDebtRequest(accountId, reason))
    }

    private fun mutate(block: suspend () -> Unit) {
        viewModelScope.launch {
            if (isSubmitting.value) return@launch
            isSubmitting.value = true
            errorMessage.value = null
            try {
                block()
            } catch (error: Exception) {
                errorMessage.value = error.message ?: "تعذر تنفيذ العملية"
            } finally {
                isSubmitting.value = false
            }
        }
    }
}

package com.shift.app.ui.screens

import com.shift.app.feature.assets.presentation.AssetsScreen
import com.shift.app.feature.debts.presentation.DebtsRoute
import com.shift.app.feature.reports.presentation.ReportsRoute
import com.shift.app.BuildConfig
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.ui.components.AddTransactionSheet
import com.shift.app.ui.screens.plans.PlansScreen
import com.shift.app.ui.theme.*
import com.shift.app.feature.session.presentation.AppSessionViewModel
import com.shift.app.viewmodel.TransactionsViewModel
import com.shift.app.feature.session.presentation.SyncState

enum class Page { DASHBOARD, BALANCE, ASSETS, PLANS, DEBTS, REPORTS, SETTINGS }

@Composable
fun MainScreen(
    onLogout: (onBlocked: () -> Unit) -> Unit = { _ -> },
    onForceLogout: () -> Unit = {},
    sessionVm: AppSessionViewModel = hiltViewModel(),
    transactionsVm: TransactionsViewModel = hiltViewModel(),
) {
    var currentPage by remember { mutableStateOf(Page.DASHBOARD) }
    var showAddTx   by remember { mutableStateOf(false) }
    var openDebtCreateSignal by remember { mutableIntStateOf(0) }
    var openPaymentsEditorSignal by remember { mutableIntStateOf(0) }
    var openAssetsEditorSignal by remember { mutableIntStateOf(0) }
    var dashboardSection by remember { mutableStateOf(DashboardSection.INCOME) }
    var previousPageBeforeAssets by remember { mutableStateOf(Page.DASHBOARD) }
    val syncState by sessionVm.syncState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    fun navigateTo(page: Page) {
        if (page == Page.ASSETS && currentPage != Page.ASSETS) {
            previousPageBeforeAssets = currentPage
        }
        currentPage = page
    }

    LaunchedEffect(Unit) { sessionVm.initialSync() }
    LaunchedEffect(syncState) {
        val error = syncState as? SyncState.Error ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(
            message = error.message,
            duration = SnackbarDuration.Long
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(bottom = 72.dp)
        ) {
            when (currentPage) {
                Page.DASHBOARD    -> DashboardScreen(
                    vm = transactionsVm,
                    selectedSection = dashboardSection,
                    onSectionSelected = { dashboardSection = it },
                    openPaymentsEditorSignal = openPaymentsEditorSignal,
                    onPaymentsEditorConsumed = { openPaymentsEditorSignal = 0 }
                )
                Page.BALANCE      -> BalanceScreen()
                Page.ASSETS       -> AssetsScreen(
                    openEditorSignal = openAssetsEditorSignal,
                    onEditorConsumed = {},
                    onBack = {
                        currentPage = previousPageBeforeAssets.takeIf { it != Page.ASSETS } ?: Page.DASHBOARD
                    }
                )
                Page.PLANS        -> PlansScreen(
                    financialGoalsEnabled = BuildConfig.FINANCIAL_GOALS_PHASE_1
                )
                Page.DEBTS        -> DebtsRoute(
                    openCreateSignal = openDebtCreateSignal,
                    onCreateConsumed = { openDebtCreateSignal = 0 }
                )
                Page.REPORTS      -> ReportsRoute()
                Page.SETTINGS     -> SettingsScreen(onLogout = onLogout, onForceLogout = onForceLogout)
            }
        }

        // ── FAB مركزي ثابت ─────────────────────────────────────────────
        if (currentPage == Page.DASHBOARD || currentPage == Page.DEBTS || currentPage == Page.ASSETS) {
            val isDashboard = currentPage == Page.DASHBOARD
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 115.dp)
                    .size(56.dp)
                    .shadow(
                        12.dp, CircleShape,
                        ambientColor = if (isDashboard) GoldPrimary else AccentBlue,
                        spotColor    = if (isDashboard) GoldPrimary else AccentBlue
                    )
                    .clip(CircleShape)
                    .background(
                        if (isDashboard)
                            Brush.radialGradient(listOf(GoldLight, GoldPrimary, GoldDark))
                        else
                            Brush.radialGradient(listOf(AccentBlue, AccentBlue.copy(0.8f)))
                    )
                    .clickable {
                        when (currentPage) {
                            Page.DASHBOARD -> if (dashboardSection == DashboardSection.PAYMENTS) {
                                openPaymentsEditorSignal += 1
                            } else {
                                showAddTx = true
                            }
                            Page.DEBTS -> openDebtCreateSignal += 1
                            Page.ASSETS -> openAssetsEditorSignal += 1
                            else -> Unit
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = when (currentPage) {
                        Page.DASHBOARD -> if (dashboardSection == DashboardSection.PAYMENTS) {
                            "إضافة مدفوعة"
                        } else {
                            "إضافة دخل"
                        }
                        Page.ASSETS -> "إضافة أصل"
                        Page.DEBTS -> "إضافة دين"
                        else -> "إضافة"
                    },
                    tint     = if (isDashboard) BackgroundDark else TextPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        LuxuryBottomBar(
            current    = currentPage,
            onNavigate = { navigateTo(it) },
            modifier   = Modifier.align(Alignment.BottomCenter)
        )
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(16.dp)
        )
    }

    if (showAddTx)   AddTransactionSheet(
        vm = transactionsVm,
        initialType = "income",
        onDismiss = { showAddTx = false }
    )
}

@Composable
private fun LuxuryBottomBar(
    current: Page,
    onNavigate: (Page) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Transparent)
    ) {
        // توهج ذهبي خفيف في الأسفل
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, GoldPrimary, GoldLight, GoldPrimary, Color.Transparent)
                    )
                )
        )

        Surface(
            modifier       = Modifier.fillMaxWidth(),
            color          = SurfaceDark.copy(alpha = 0.97f),
            tonalElevation = 0.dp,
            shape          = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(72.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavItem(Icons.Default.Home,        "الرئيسية",  current == Page.DASHBOARD)    { onNavigate(Page.DASHBOARD) }
                NavItem(Icons.Default.AccountBalanceWallet, "الرصيد", current == Page.BALANCE) { onNavigate(Page.BALANCE) }
                NavItem(Icons.Default.Inventory2,  "الأصول",    current == Page.ASSETS)       { onNavigate(Page.ASSETS) }
                NavItem(Icons.Default.Savings,     "الخطط", current == Page.PLANS) { onNavigate(Page.PLANS) }
                NavItem(Icons.Default.CreditCard,  "الديون",    current == Page.DEBTS)        { onNavigate(Page.DEBTS) }
                NavItem(Icons.Default.BarChart,    "التقارير",  current == Page.REPORTS)      { onNavigate(Page.REPORTS) }
                NavItem(Icons.Default.Settings,    "الإعدادات", current == Page.SETTINGS)     { onNavigate(Page.SETTINGS) }
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val color by animateColorAsState(
        targetValue   = if (selected) GoldPrimary else TextMuted,
        animationSpec = tween(300),
        label         = "navColor"
    )
    val scale by animateFloatAsState(
        targetValue   = if (selected) 1.15f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label         = "navScale"
    )

    Column(
        modifier            = Modifier
            .weight(1f)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // خلفية دائرية للعنصر المحدد
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) GoldGlow else Color.Transparent)
        ) {
            IconButton(onClick = onClick) {
                Icon(
                    icon,
                    contentDescription = label,
                    tint               = color,
                    modifier           = Modifier
                        .size(24.dp)
                        .scale(scale)
                )
            }
        }

        Spacer(Modifier.height(2.dp))

        Text(
            text     = label,
            color    = color,
            fontSize = 10.sp,
            maxLines = 1,
            style    = MaterialTheme.typography.labelSmall
        )

        // نقطة ذهبية صغيرة تحت العنصر المحدد
        if (selected) {
            Spacer(Modifier.height(3.dp))
            Box(
                Modifier
                    .size(4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(GoldPrimary)
            )
        }
    }
}

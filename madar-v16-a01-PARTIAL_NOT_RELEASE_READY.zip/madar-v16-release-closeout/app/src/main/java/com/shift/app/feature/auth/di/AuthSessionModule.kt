package com.shift.app.feature.auth.di

import com.shift.app.feature.auth.data.PreferencesSessionStore
import com.shift.app.feature.auth.data.RoomAccountLocalDataCleaner
import com.shift.app.feature.auth.data.SupabaseAuthGateway
import com.shift.app.feature.auth.data.SyncManagerSessionGateway
import com.shift.app.feature.auth.data.WorkManagerSessionWorkController
import com.shift.app.feature.auth.domain.AccountLocalDataCleaner
import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.SessionBootstrapper
import com.shift.app.feature.auth.domain.SessionCleanup
import com.shift.app.feature.auth.domain.SessionReader
import com.shift.app.feature.auth.domain.SessionSyncGateway
import com.shift.app.feature.auth.domain.SessionWorkController
import com.shift.app.feature.auth.domain.SessionWriter
import com.shift.app.feature.auth.session.SessionBootstrapCoordinator
import com.shift.app.feature.auth.session.SessionCleanupCoordinator
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class AuthSessionModule {
    @Binds
    abstract fun bindAuthGateway(implementation: SupabaseAuthGateway): AuthGateway

    @Binds
    abstract fun bindSessionReader(implementation: PreferencesSessionStore): SessionReader

    @Binds
    abstract fun bindSessionWriter(implementation: PreferencesSessionStore): SessionWriter

    @Binds
    abstract fun bindSessionBootstrapper(implementation: SessionBootstrapCoordinator): SessionBootstrapper

    @Binds
    abstract fun bindSessionCleanup(implementation: SessionCleanupCoordinator): SessionCleanup

    @Binds
    abstract fun bindSessionSyncGateway(implementation: SyncManagerSessionGateway): SessionSyncGateway

    @Binds
    abstract fun bindAccountLocalDataCleaner(implementation: RoomAccountLocalDataCleaner): AccountLocalDataCleaner

    @Binds
    abstract fun bindSessionWorkController(implementation: WorkManagerSessionWorkController): SessionWorkController
}

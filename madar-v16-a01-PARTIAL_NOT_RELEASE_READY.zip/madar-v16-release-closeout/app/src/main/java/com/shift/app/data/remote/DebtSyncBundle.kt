package com.shift.app.data.remote

import kotlinx.serialization.Serializable

@Serializable
data class DebtSyncBundle(
    val operationId: String,
    val accounts: List<RemoteDebtAccount> = emptyList(),
    val transactions: List<RemoteDebtTransaction> = emptyList(),
    val links: List<RemoteDebtLink> = emptyList(),
    val schedules: List<RemoteDebtSchedule> = emptyList(),
    val reviews: List<RemoteDebtMigrationReview> = emptyList()
) {
    val isComplete: Boolean
        get() {
            val accountIds = accounts.map { it.id }.toSet()
            val transactionIds = transactions.map { it.id }.toSet()
            val users = (accounts.map { it.userId } + transactions.map { it.userId } + links.map { it.userId } +
                schedules.map { it.userId } + reviews.map { it.userId }).toSet()
            val transactionAccountsOk = transactions.all { it.accountId in accountIds }
            val linksOk = links.all {
                it.accountId in accountIds && it.debtTransactionId in transactionIds
            }
            val schedulesOk = schedules.all { it.accountId in accountIds }
            val reviewsOk = reviews.all { it.proposedAccountId == null || it.proposedAccountId in accountIds }
            return operationId.isNotBlank() && users.size <= 1 &&
                transactionAccountsOk && linksOk && schedulesOk && reviewsOk
        }

    val incompleteReason: String?
        get() = if (isComplete) null else "IncompleteRemote debt bundle: ownership, operation, or FK dependency mismatch"
}

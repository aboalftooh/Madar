package com.shift.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.ui.theme.AccentBlue
import com.shift.app.ui.theme.CairoFamily
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.viewmodel.TransactionsViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun IncomeSourceEditorSheet(
    vm: TransactionsViewModel,
    editItem: IncomeSource? = null,
    onDismiss: () -> Unit
) {
    val suggestions by vm.paymentMethodSuggestions.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val focusManager = LocalFocusManager.current
    var name by remember(editItem) { mutableStateOf(editItem?.name.orEmpty()) }
    var paymentMethod by remember(editItem) { mutableStateOf(editItem?.paymentMethod.orEmpty()) }
    var nameError by remember { mutableStateOf("") }
    var paymentMethodError by remember { mutableStateOf("") }

    fun save() {
        val trimmedName = name.trim()
        val trimmedPaymentMethod = paymentMethod.trim()
        nameError = if (trimmedName.isBlank()) "اسم المصدر مطلوب" else ""
        paymentMethodError = if (trimmedPaymentMethod.isBlank()) "طريقة الدفع مطلوبة" else ""
        if (nameError.isNotBlank() || paymentMethodError.isNotBlank()) return

        val source = editItem?.copy(
            name = trimmedName,
            paymentMethod = trimmedPaymentMethod
        ) ?: IncomeSource(
            name = trimmedName,
            paymentMethod = trimmedPaymentMethod
        )
        if (editItem == null) vm.addIncomeSource(source) else vm.updateIncomeSource(source)
        onDismiss()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .padding(horizontal = 24.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                if (editItem == null) "إضافة مصدر دخل" else "تعديل مصدر دخل",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily
            )
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    nameError = ""
                },
                label = { Text("اسم المصدر", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                isError = nameError.isNotBlank(),
                supportingText = if (nameError.isNotBlank()) {{ Text(nameError, color = ExpenseRed) }} else null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
            )
            OutlinedTextField(
                value = paymentMethod,
                onValueChange = {
                    paymentMethod = it
                    paymentMethodError = ""
                },
                label = { Text("طريقة الدفع", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                isError = paymentMethodError.isNotBlank(),
                supportingText = if (paymentMethodError.isNotBlank()) {{ Text(paymentMethodError, color = ExpenseRed) }} else null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                    save()
                })
            )
            if (suggestions.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    suggestions.forEach { suggestion ->
                        AssistChip(
                            onClick = {
                                paymentMethod = suggestion
                                paymentMethodError = ""
                            },
                            label = { Text(suggestion, color = TextPrimary) }
                        )
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Button(
                onClick = { save() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Text("حفظ", fontWeight = FontWeight.Bold)
            }
        }
    }
}

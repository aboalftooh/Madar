package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.DebtMigrationReview
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtMigrationReviewDao {
    @Query("SELECT * FROM debt_migration_reviews WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun getActiveReviews(): Flow<List<DebtMigrationReview>>

    @Query("SELECT * FROM debt_migration_reviews WHERE legacyDebtId = :legacyDebtId LIMIT 1")
    suspend fun getByLegacyDebtId(legacyDebtId: String): DebtMigrationReview?

    @Query("SELECT * FROM debt_migration_reviews WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<DebtMigrationReview>

    @Query("SELECT * FROM debt_migration_reviews ORDER BY legacyDebtId ASC")
    suspend fun getAllOnce(): List<DebtMigrationReview>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(review: DebtMigrationReview)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(reviews: List<DebtMigrationReview>)

    @Update
    suspend fun update(review: DebtMigrationReview)

    @Query("DELETE FROM debt_migration_reviews WHERE id = :id")
    suspend fun hardDeleteById(id: String)

    @Query("DELETE FROM debt_migration_reviews")
    suspend fun deleteAll()
}

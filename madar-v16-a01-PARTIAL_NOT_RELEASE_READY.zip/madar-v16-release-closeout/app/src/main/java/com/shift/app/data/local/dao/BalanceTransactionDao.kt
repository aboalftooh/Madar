package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.BalanceTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface BalanceTransactionDao {
    @Query("SELECT * FROM balance_transactions WHERE deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getAll(): Flow<List<BalanceTransaction>>

    @Query("SELECT * FROM balance_transactions ORDER BY date DESC, createdAt DESC")
    fun getAllIncludingDeleted(): Flow<List<BalanceTransaction>>

    @Query("SELECT * FROM balance_transactions WHERE deletedAt IS NULL AND operationId = :operationId")
    suspend fun getActiveByOperationId(operationId: String): List<BalanceTransaction>

    @Query("SELECT * FROM balance_transactions WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<BalanceTransaction>

    @Query("SELECT * FROM balance_transactions")
    suspend fun getAllOnce(): List<BalanceTransaction>

    @Query("SELECT * FROM balance_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): BalanceTransaction?

    @Query("SELECT * FROM balance_transactions WHERE legacyTransactionId = :legacyTransactionId LIMIT 1")
    suspend fun getByLegacyTransactionId(legacyTransactionId: String): BalanceTransaction?

    @Query("SELECT * FROM balance_transactions WHERE legacyTransactionId IS NOT NULL OR sourceType = 'legacy_history_migration' ORDER BY id ASC")
    suspend fun getLegacyMigrationRows(): List<BalanceTransaction>

    @Query("SELECT * FROM balance_transactions WHERE kind = 'opening_balance' AND deletedAt IS NULL ORDER BY createdAt ASC LIMIT 1")
    suspend fun getActiveOpeningBalance(): BalanceTransaction?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: BalanceTransaction)

    @Update
    suspend fun update(item: BalanceTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<BalanceTransaction>)

    @Query("DELETE FROM balance_transactions WHERE id = :id")
    suspend fun hardDeleteById(id: String)

    @Query("DELETE FROM balance_transactions")
    suspend fun deleteAll()
}

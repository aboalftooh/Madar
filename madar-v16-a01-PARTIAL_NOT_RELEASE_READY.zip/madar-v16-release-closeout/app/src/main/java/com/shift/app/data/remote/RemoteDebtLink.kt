package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteDebtLink(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("operation_id") val operationId: String,
    @SerialName("account_id") val accountId: String,
    @SerialName("debt_transaction_id") val debtTransactionId: String,
    @SerialName("target_type") val targetType: String,
    @SerialName("target_id") val targetId: String,
    val role: String,
    @SerialName("amount_decimal") val amountDecimal: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null
)

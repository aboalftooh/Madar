package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun DebtCorrectionRoute(state: DebtReasonedActionState, historical: Boolean, onSubmit: () -> Unit) {
    Column {
        Text("عكس / تصحيح")
        if (historical) Text("تحذير: عكس حركة قديمة يغير التقارير التاريخية")
        Button(enabled = state.error() == null && !state.submitted, onClick = onSubmit) { Text("تنفيذ") }
    }
}

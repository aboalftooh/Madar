package com.shift.app.feature.assets.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.CairoFamily
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.feature.assets.domain.model.AssetSummary
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
internal fun AssetList(
    summaries: List<AssetSummary>,
    onBack: () -> Unit,
    onAssetClick: (Asset) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
                    }
                    Column {
                        Text("الأصول", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
                        Text("القيمة من آخر تقييم محفوظ", color = TextMuted, fontSize = 12.sp, fontFamily = CairoFamily)
                    }
                }
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(30.dp))
            }
        }
        if (summaries.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 42.dp), contentAlignment = Alignment.Center) {
                    Text("لا توجد أصول حالياً", color = TextMuted, fontFamily = CairoFamily)
                }
            }
        }
        items(summaries, key = { it.asset.id }) { summary ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onAssetClick(summary.asset) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(summary.asset.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
                        Text("${assetTypeLabel(summary.asset.type)} • ${assetStatusLabel(summary.asset.status)}", color = TextMuted, fontSize = 12.sp, fontFamily = CairoFamily)
                        Text("الاستثمار: ${NumberDisplayFormatter.formatDecimalText(summary.totalInvestmentDecimal)} SDG", color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                    }
                    Text(
                        summary.currentValueDecimal?.let { "${NumberDisplayFormatter.formatDecimalText(it)} SDG" } ?: "غير مقيّم",
                        color = GoldPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = CairoFamily
                    )
                }
            }
        }
    }
}

@Composable
internal fun AssetCreateChoiceDialog(
    onDismiss: () -> Unit,
    onPurchase: () -> Unit,
    onAddPreexisting: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("إضافة أصل", color = TextPrimary, fontFamily = CairoFamily) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onPurchase, modifier = Modifier.fillMaxWidth()) {
                    Text("شراء أصل")
                }
                Button(onClick = onAddPreexisting, modifier = Modifier.fillMaxWidth()) {
                    Text("إضافة أصل سابق")
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
internal fun AssetDetails(
    state: com.shift.app.feature.assets.domain.model.AssetDetails,
    busy: Boolean,
    onBack: () -> Unit,
    vm: AssetDetailsViewModel
) {
    val asset = state.asset ?: return Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = GoldPrimary)
    }
    var command by remember { mutableStateOf<AssetCommand?>(null) }
    var editingAsset by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<AssetTransaction?>(null) }
    var editingValuation by remember { mutableStateOf<AssetValuation?>(null) }
    var showAddCurrencyLot by remember { mutableStateOf(false) }
    var showCurrencySale by remember { mutableStateOf(false) }
    val isCurrency = asset.type == FOREIGN_CURRENCY_ASSET_TYPE
    val lotBalances = remember(state.currencyLots, state.currencySaleAllocations) {
        CurrencyAssetCalculator.lotBalances(
            state.currencyLots.map {
                CurrencyLotSnapshot(
                    id = it.id,
                    quantityPurchasedDecimal = it.quantityPurchasedDecimal,
                    localCostDecimal = it.localCostDecimal,
                    purchaseDate = it.purchaseDate,
                    createdAt = it.createdAt,
                    deletedAt = it.deletedAt
                )
            },
            state.currencySaleAllocations.map {
                CurrencyAllocationSnapshot(
                    lotId = it.lotId,
                    quantitySoldDecimal = it.quantitySoldDecimal,
                    allocatedLocalCostDecimal = it.allocatedLocalCostDecimal,
                    deletedAt = it.deletedAt
                )
            }
        ).associateBy { it.lotId }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary) }
                Column(Modifier.weight(1f)) {
                    Text(asset.name, color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
                    Text("${assetTypeLabel(asset.type)} • ${assetStatusLabel(asset.status)}", color = GoldPrimary, fontFamily = CairoFamily)
                }
                if (!isCurrency) {
                    IconButton(onClick = { editingAsset = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل الأصل", tint = TextMuted)
                    }
                }
            }
        }
        item {
            if (isCurrency) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            "الكمية المتاحة",
                            "${NumberDisplayFormatter.formatDecimalText(state.availableCurrencyQuantityDecimal ?: "0.00000000")} ${asset.currencyCode}",
                            Modifier.weight(1f)
                        )
                        MetricCard(
                            "القيمة الحالية",
                            state.currentValueDecimal?.let { NumberDisplayFormatter.formatDecimalText(it) } ?: "غير مقيّم",
                            Modifier.weight(1f)
                        )
                    }
                    MetricCard(
                        "إجمالي تكلفة الدفعات (SDG)",
                        NumberDisplayFormatter.formatDecimalText(state.totalInvestmentDecimal),
                        Modifier.fillMaxWidth()
                    )
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(
                        "القيمة الحالية",
                        state.currentValueDecimal?.let { NumberDisplayFormatter.formatDecimalText(it) } ?: "غير مقيّم",
                        Modifier.weight(1f)
                    )
                    MetricCard(
                        "إجمالي الاستثمار",
                        NumberDisplayFormatter.formatDecimalText(state.totalInvestmentDecimal),
                        Modifier.weight(1f)
                    )
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (asset.status == AssetStatus.Active.dbValue) {
                    if (isCurrency) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showAddCurrencyLot = true }, Modifier.weight(1f)) { Text("شراء دفعة") }
                            Button(
                                onClick = { showCurrencySale = true },
                                enabled = state.availableCurrencyQuantityDecimal?.toBigDecimalOrNull()?.signum() == 1,
                                modifier = Modifier.weight(1f)
                            ) { Text("بيع عملة") }
                        }
                        Button(onClick = { command = AssetCommand.VALUE }, modifier = Modifier.fillMaxWidth()) {
                            Text("تحديث القيمة المرجعية")
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { command = AssetCommand.IMPROVE }, Modifier.weight(1f)) { Text("تحسين") }
                            Button(onClick = { command = AssetCommand.MAINTAIN }, Modifier.weight(1f)) { Text("صيانة") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { command = AssetCommand.VALUE }, Modifier.weight(1f)) { Text("تقييم") }
                            Button(onClick = { command = AssetCommand.SELL }, Modifier.weight(1f)) { Text("بيع كامل") }
                        }
                    }
                } else if (asset.status == AssetStatus.Sold.dbValue) {
                    val sale = state.transactions.firstOrNull { it.kind == AssetTransactionKind.SaleFull.dbValue }
                    Button(
                        enabled = sale != null && !busy,
                        onClick = { sale?.let { vm.undoSale(it.operationId) } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("التراجع عن البيع") }
                }
            }
        }
        if (isCurrency) {
            item { Text("دفعات العملة", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = CairoFamily) }
            items(state.currencyLots, key = { "lot-${it.id}" }) { lot ->
                val balance = lotBalances[lot.id]
                HistoryRow(
                    title = "${NumberDisplayFormatter.formatDecimalText(lot.quantityPurchasedDecimal)} ${lot.foreignCurrencyCode} بسعر ${NumberDisplayFormatter.formatDecimalText(lot.purchaseExchangeRateDecimal)}",
                    subtitle = "${lot.purchaseDate} • المتبقي ${NumberDisplayFormatter.formatDecimalText(balance?.quantityRemainingDecimal ?: "0.00000000")} • التكلفة ${NumberDisplayFormatter.formatDecimalText(lot.localCostDecimal)} SDG",
                    onEdit = null,
                    onDelete = null
                )
            }
        }
        item { Text("سجل الأصل", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = CairoFamily) }
        items(state.transactions, key = { it.id }) { event ->
            HistoryRow(
                title = assetTransactionLabel(event.kind),
                subtitle = "${event.date}${event.amountDecimal?.let { " • ${NumberDisplayFormatter.formatDecimalText(it)} SDG" }.orEmpty()}",
                onEdit = when (event.kind) {
                    AssetTransactionKind.Improvement.dbValue,
                    AssetTransactionKind.Maintenance.dbValue,
                    AssetTransactionKind.SaleFull.dbValue -> if (!isCurrency) ({ editingEvent = event }) else null
                    else -> null
                },
                onDelete = when (event.kind) {
                    AssetTransactionKind.Improvement.dbValue,
                    AssetTransactionKind.Maintenance.dbValue -> ({ vm.deleteOperation(event.operationId) })
                    AssetTransactionKind.Purchase.dbValue,
                    AssetTransactionKind.PreexistingAdd.dbValue -> ({ vm.deleteOperation(event.operationId) })
                    AssetTransactionKind.SalePartial.dbValue -> if (isCurrency) ({ vm.undoSale(event.operationId) }) else null
                    else -> null
                }
            )
        }
        items(state.valuations, key = { it.id }) { valuation ->
            HistoryRow(
                title = "تقييم: ${NumberDisplayFormatter.formatDecimalText(valuation.valueDecimal)} SDG",
                subtitle = valuation.date,
                onEdit = { editingValuation = valuation },
                onDelete = { vm.deleteValuation(valuation.operationId) }
            )
        }
    }
    if (showAddCurrencyLot) {
        CurrencyLotDialog(
            currencyCode = asset.currencyCode,
            onDismiss = { showAddCurrencyLot = false },
            onSave = { quantity, exchangeRate, localCost, date, note ->
                vm.addCurrencyLot(quantity, exchangeRate, localCost, date, note)
                showAddCurrencyLot = false
            }
        )
    }
    if (showCurrencySale) {
        CurrencySaleDialog(
            currencyCode = asset.currencyCode,
            availableQuantity = state.availableCurrencyQuantityDecimal ?: "0.00000000",
            onDismiss = { showCurrencySale = false },
            onSave = { quantity, proceeds, date, note ->
                vm.sellCurrency(quantity, proceeds, date, note)
                showCurrencySale = false
            }
        )
    }

    command?.let { selected ->
        AssetCommandDialog(
            command = selected,
            onDismiss = { command = null },
            onSave = { amount, purpose, date, note ->
                when (selected) {
                    AssetCommand.IMPROVE -> vm.improve(amount, purpose, date, note)
                    AssetCommand.MAINTAIN -> vm.maintain(amount, purpose, date, note)
                    AssetCommand.VALUE -> vm.value(amount, date, note)
                    AssetCommand.SELL -> vm.sell(amount, date, note)
                }
                command = null
            }
        )
    }
    if (editingAsset) {
        AssetEditDialog(asset, onDismiss = { editingAsset = false }) { name, type, amount ->
            vm.updateAcquisition(name, type, amount)
            editingAsset = false
        }
    }
    editingEvent?.let { event ->
        val selectedCommand = when (event.kind) {
            AssetTransactionKind.Improvement.dbValue -> AssetCommand.IMPROVE
            AssetTransactionKind.Maintenance.dbValue -> AssetCommand.MAINTAIN
            else -> AssetCommand.SELL
        }
        AssetCommandDialog(
            command = selectedCommand,
            initialAmount = event.amountDecimal.orEmpty(),
            initialPurpose = event.note,
            initialDate = event.date,
            initialNote = event.note,
            onDismiss = { editingEvent = null },
            onSave = { amount, purpose, date, note ->
                if (event.kind == AssetTransactionKind.SaleFull.dbValue) {
                    vm.updateSale(event.operationId, amount, date, note)
                } else {
                    vm.updatePaymentEvent(event.operationId, amount, purpose, date, note)
                }
                editingEvent = null
            }
        )
    }
    editingValuation?.let { valuation ->
        AssetCommandDialog(
            command = AssetCommand.VALUE,
            initialAmount = valuation.valueDecimal,
            initialDate = valuation.date,
            initialNote = valuation.note,
            onDismiss = { editingValuation = null },
            onSave = { value, _, date, note ->
                vm.updateValuation(valuation.operationId, value, date, note)
                editingValuation = null
            }
        )
    }
}

@Composable
internal fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
            Text(value, color = GoldPrimary, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
        }
    }
}

@Composable
internal fun HistoryRow(title: String, subtitle: String, onEdit: (() -> Unit)?, onDelete: (() -> Unit)?) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(13.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontFamily = CairoFamily)
                Text(subtitle, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
            }
            onEdit?.let { IconButton(onClick = it) { Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = TextMuted) } }
            onDelete?.let { IconButton(onClick = it) { Icon(Icons.Default.Delete, contentDescription = "حذف", tint = ExpenseRed) } }
        }
    }
}


package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "asset_transactions",
    foreignKeys = [
        ForeignKey(entity = Asset::class, parentColumns = ["id"], childColumns = ["assetId"], onDelete = ForeignKey.NO_ACTION)
    ],
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["assetId", "deletedAt"]),
        Index(value = ["kind"])
    ]
)
data class AssetTransaction(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val assetId: String,
    val kind: String = AssetTransactionKind.PreexistingAdd.dbValue,
    val amountDecimal: String? = null,
    val currencyQuantityDeltaDecimal: String? = null,
    val paymentId: String? = null,
    val balanceTransactionId: String? = null,
    val date: String,
    val note: String = "",
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

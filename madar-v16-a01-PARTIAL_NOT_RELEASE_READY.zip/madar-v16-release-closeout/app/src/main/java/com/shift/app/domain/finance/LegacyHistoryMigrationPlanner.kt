package com.shift.app.domain.finance

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.utils.ExpenseTextNormalizer
import java.math.BigDecimal
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.LocalDate
import java.util.UUID

const val LEGACY_HISTORY_MIGRATION_KEY = "legacy_full_history_v1"
const val LEGACY_HISTORY_PLANNER_VERSION = 1
const val LEGACY_HISTORY_STATUS_COMPLETED = "completed"

enum class LegacyHistoryExecutionDecision {
    Execute,
    AlreadyCompleted,
    Conflict
}

fun legacyHistoryExecutionDecision(
    existingCommitFingerprint: String?,
    requestedCommitFingerprint: String
): LegacyHistoryExecutionDecision = when {
    existingCommitFingerprint == null -> LegacyHistoryExecutionDecision.Execute
    existingCommitFingerprint == requestedCommitFingerprint -> LegacyHistoryExecutionDecision.AlreadyCompleted
    else -> LegacyHistoryExecutionDecision.Conflict
}

data class LegacyHistoryMigrationOperation(
    val transaction: Transaction,
    val balanceTransaction: BalanceTransaction,
    val payment: Payment? = null
)

data class LegacyHistoryMigrationPreview(
    val sourceFingerprint: String,
    val commitFingerprint: String,
    val candidateCount: Int,
    val incomeCount: Int,
    val expenseCount: Int,
    val historicalIncomeDecimal: String,
    val historicalExpenseDecimal: String,
    val historicalNetDecimal: String,
    val currentBalanceDecimal: String,
    val projectedBalanceDecimal: String,
    val targetBalanceDecimal: String,
    val adjustmentDecimal: String,
    val operations: List<LegacyHistoryMigrationOperation>,
    val adjustmentBalanceTransaction: BalanceTransaction?
)

object LegacyHistoryMigrationPlanner {
    fun operationForTransaction(
        transaction: Transaction,
        localCurrencyCode: String
    ): LegacyHistoryMigrationOperation {
        require(transaction.type == "income" || transaction.type == "expense") {
            "Unsupported transaction type"
        }
        val normalized = transaction.copy(date = parsedDate(transaction).toString())
        val amount = runCatching { DecimalText.moneyFromLegacyDouble(transaction.amount) }
            .getOrElse { throw IllegalArgumentException("Transaction has an invalid amount", it) }
        require(DecimalText.toBigDecimal(amount).signum() > 0) { "Transaction amount must be positive" }
        val currency = localCurrencyCode.trim().uppercase()
        require(currency.matches(Regex("[A-Z]{3}"))) { "Invalid local currency code" }
        return operationFor(normalized, amount, currency)
    }

    fun preview(
        transactions: List<Transaction>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        localCurrencyCode: String,
        targetBalanceInput: String
    ): LegacyHistoryMigrationPreview {
        val currency = localCurrencyCode.trim().uppercase()
        require(currency.matches(Regex("[A-Z]{3}"))) { "Invalid local currency code" }

        validateExistingLinks(transactions, balanceTransactions, payments)
        val linkedLegacyIds = buildSet {
            addAll(balanceTransactions.mapNotNull { it.legacyTransactionId })
            addAll(payments.mapNotNull { it.legacyTransactionId })
        }
        val candidates = transactions.asSequence()
            .filter { it.deletedAt == null }
            .filter { it.id !in linkedLegacyIds }
            .filter { it.operationId == null && it.balanceTransactionId == null }
            .sortedWith(compareBy<Transaction> { parsedDate(it) }.thenBy { it.id })
            .toList()

        require(candidates.all { it.type == "income" || it.type == "expense" }) {
            "Legacy history contains an unsupported transaction type"
        }

        val canonicalCandidates = candidates.map { transaction ->
            val date = parsedDate(transaction).toString()
            val amount = runCatching { DecimalText.moneyFromLegacyDouble(transaction.amount) }
                .getOrElse { throw IllegalArgumentException("Legacy transaction has an invalid amount", it) }
            require(DecimalText.toBigDecimal(amount).signum() > 0) {
                "Legacy transaction amount must be positive"
            }
            transaction.copy(date = date) to amount
        }
        val sourceFingerprint = fingerprint(
            buildList {
                add("planner=$LEGACY_HISTORY_PLANNER_VERSION")
                add("currency=$currency")
                canonicalCandidates.forEach { (transaction, amount) ->
                    addAll(transactionFingerprintFields(transaction, amount))
                }
            }
        )
        val activeBalances = balanceTransactions.filter { it.deletedAt == null }
        val openingBalances = activeBalances.filter { it.kind == BalanceTransactionKind.OpeningBalance.dbValue }
        require(openingBalances.size == 1) { "A single active opening balance is required" }
        val ledgerFingerprint = fingerprint(
            activeBalances.sortedBy { it.id }.flatMap { balance ->
                listOf(
                    balance.id,
                    balance.operationId,
                    balance.direction,
                    balance.kind,
                    balance.amountDecimal,
                    balance.currencyCode,
                    balance.date,
                    balance.updatedAt.toString()
                )
            }
        )
        val target = DecimalText.canonical(targetBalanceInput.ifBlank { "0" }, DecimalTextScale.Money)
        val commitFingerprint = fingerprint(
            listOf("commit", sourceFingerprint, ledgerFingerprint, currency, target)
        )

        val operations = canonicalCandidates.map { (transaction, amount) ->
            operationFor(transaction, amount, currency)
        }
        val incomeTotal = operations.asSequence()
            .filter { it.transaction.type == "income" }
            .fold(BigDecimal.ZERO) { sum, item -> sum.add(DecimalText.toBigDecimal(item.balanceTransaction.amountDecimal)) }
            .money()
        val expenseTotal = operations.asSequence()
            .filter { it.transaction.type == "expense" }
            .fold(BigDecimal.ZERO) { sum, item -> sum.add(DecimalText.toBigDecimal(item.balanceTransaction.amountDecimal)) }
            .money()
        val historicalNet = incomeTotal.subtract(expenseTotal).money()
        val currentBalance = BalanceCalculator.currentBalance(activeBalances).money()
        val projected = currentBalance.add(historicalNet).money()
        val adjustment = DecimalText.toBigDecimal(target).subtract(projected).money()
        val opening = openingBalances.single()
        val adjustmentRow = if (adjustment.signum() == 0) {
            null
        } else {
            BalanceTransaction(
                id = deterministicId("adjustment-row", commitFingerprint),
                operationId = deterministicId("adjustment-operation", commitFingerprint),
                direction = if (adjustment.signum() > 0) {
                    BalanceDirection.Inflow.dbValue
                } else {
                    BalanceDirection.Outflow.dbValue
                },
                kind = BalanceTransactionKind.OpeningBalanceAdjustment.dbValue,
                amountDecimal = adjustment.abs().money().toPlainString(),
                currencyCode = currency,
                date = opening.date,
                note = "تسوية ترحيل التاريخ الكامل",
                sourceType = "legacy_history_migration",
                sourceId = LEGACY_HISTORY_MIGRATION_KEY,
                createdAt = opening.createdAt,
                updatedAt = opening.updatedAt
            )
        }

        return LegacyHistoryMigrationPreview(
            sourceFingerprint = sourceFingerprint,
            commitFingerprint = commitFingerprint,
            candidateCount = operations.size,
            incomeCount = operations.count { it.transaction.type == "income" },
            expenseCount = operations.count { it.transaction.type == "expense" },
            historicalIncomeDecimal = incomeTotal.toPlainString(),
            historicalExpenseDecimal = expenseTotal.toPlainString(),
            historicalNetDecimal = historicalNet.toPlainString(),
            currentBalanceDecimal = currentBalance.toPlainString(),
            projectedBalanceDecimal = projected.toPlainString(),
            targetBalanceDecimal = target,
            adjustmentDecimal = adjustment.toPlainString(),
            operations = operations,
            adjustmentBalanceTransaction = adjustmentRow
        )
    }

    private fun operationFor(
        transaction: Transaction,
        amount: String,
        currencyCode: String
    ): LegacyHistoryMigrationOperation {
        val operationId = deterministicId("operation", transaction.id)
        val balanceId = deterministicId("balance", transaction.id)
        val updatedTransaction = transaction.copy(
            operationId = operationId,
            balanceTransactionId = balanceId
        )
        val balance = BalanceTransaction(
            id = balanceId,
            operationId = operationId,
            direction = if (transaction.type == "income") {
                BalanceDirection.Inflow.dbValue
            } else {
                BalanceDirection.Outflow.dbValue
            },
            kind = if (transaction.type == "income") {
                BalanceTransactionKind.Income.dbValue
            } else {
                BalanceTransactionKind.ExpensePayment.dbValue
            },
            amountDecimal = amount,
            currencyCode = currencyCode,
            date = transaction.date,
            note = transaction.note,
            sourceType = "transaction",
            sourceId = transaction.id,
            legacyTransactionId = transaction.id,
            createdAt = transaction.updatedAt,
            updatedAt = transaction.updatedAt
        )
        val payment = if (transaction.type == "expense") {
            val purpose = transaction.purpose.ifBlank { transaction.category }
            Payment(
                id = deterministicId("payment", transaction.id),
                operationId = operationId,
                kind = PaymentKind.OrdinaryExpense.dbValue,
                amountDecimal = amount,
                currencyCode = currencyCode,
                date = transaction.date,
                purpose = purpose,
                purposeKey = transaction.purposeKey.ifBlank { ExpenseTextNormalizer.key(purpose) },
                beneficiaryId = transaction.expenseBeneficiaryId,
                beneficiaryNameSnapshot = transaction.expenseBeneficiaryNameSnapshot,
                balanceTransactionId = balanceId,
                legacyTransactionId = transaction.id,
                note = transaction.note,
                createdAt = transaction.updatedAt,
                updatedAt = transaction.updatedAt
            )
        } else {
            null
        }
        return LegacyHistoryMigrationOperation(updatedTransaction, balance, payment)
    }

    private fun validateExistingLinks(
        transactions: List<Transaction>,
        balances: List<BalanceTransaction>,
        payments: List<Payment>
    ) {
        require(balances.mapNotNull { it.legacyTransactionId }.groupingBy { it }.eachCount().values.none { it > 1 }) {
            "Duplicate legacy balance links found"
        }
        require(payments.mapNotNull { it.legacyTransactionId }.groupingBy { it }.eachCount().values.none { it > 1 }) {
            "Duplicate legacy payment links found"
        }
        val transactionById = transactions.associateBy { it.id }
        balances.filter { it.legacyTransactionId != null }.forEach { balance ->
            require(transactionById[balance.legacyTransactionId] != null) { "Legacy balance link is orphaned" }
        }
        payments.filter { it.legacyTransactionId != null }.forEach { payment ->
            val transaction = transactionById[payment.legacyTransactionId]
            require(transaction?.type == "expense") { "Legacy payment link must reference an expense" }
            val balance = balances.singleOrNull { it.id == payment.balanceTransactionId }
            require(balance?.legacyTransactionId == payment.legacyTransactionId) {
                "Legacy payment and balance links do not match"
            }
        }
        transactions.forEach { transaction ->
            require((transaction.operationId == null) == (transaction.balanceTransactionId == null)) {
                "Transaction contains a partial ledger link"
            }
            val balanceId = transaction.balanceTransactionId ?: return@forEach
            val operationId = requireNotNull(transaction.operationId)
            val balance = balances.singleOrNull { it.id == balanceId }
            require(
                balance != null &&
                    balance.operationId == operationId &&
                    balance.sourceType == "transaction" &&
                    balance.sourceId == transaction.id
            ) { "Transaction contains an orphaned or mismatched ledger link" }
            if (transaction.type == "income") {
                require(balance.kind == BalanceTransactionKind.Income.dbValue) {
                    "Linked income has an invalid balance kind"
                }
            } else {
                require(balance.legacyTransactionId == transaction.id) {
                    "Linked expense is missing its legacy identity"
                }
                val payment = payments.singleOrNull { it.legacyTransactionId == transaction.id }
                require(
                    transaction.type == "expense" &&
                        balance.kind == BalanceTransactionKind.ExpensePayment.dbValue &&
                        payment != null &&
                        payment.operationId == operationId &&
                        payment.balanceTransactionId == balance.id
                ) { "Linked legacy expense is incomplete" }
            }
        }
    }

    private fun transactionFingerprintFields(transaction: Transaction, amount: String): List<String> = listOf(
        transaction.id,
        transaction.type,
        amount,
        transaction.category,
        transaction.date,
        transaction.note,
        transaction.group,
        transaction.incomeSourceId.orEmpty(),
        transaction.incomeSourceNameSnapshot,
        transaction.paymentMethodSnapshot,
        transaction.purpose,
        transaction.purposeKey,
        transaction.expenseBeneficiaryId.orEmpty(),
        transaction.expenseBeneficiaryNameSnapshot,
        transaction.updatedAt.toString()
    )

    private fun parsedDate(transaction: Transaction): LocalDate = runCatching { LocalDate.parse(transaction.date) }
        .getOrElse { throw IllegalArgumentException("Legacy transaction has an invalid date", it) }

    private fun deterministicId(role: String, value: String): String {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest("madar:$LEGACY_HISTORY_MIGRATION_KEY:$role:$value".toByteArray(StandardCharsets.UTF_8))
        hash[6] = ((hash[6].toInt() and 0x0f) or 0x50).toByte()
        hash[8] = ((hash[8].toInt() and 0x3f) or 0x80).toByte()
        val buffer = ByteBuffer.wrap(hash)
        return UUID(buffer.long, buffer.long).toString()
    }

    private fun fingerprint(fields: List<String>): String {
        val digest = MessageDigest.getInstance("SHA-256")
        fields.forEach { field ->
            val bytes = field.toByteArray(StandardCharsets.UTF_8)
            digest.update(ByteBuffer.allocate(4).putInt(bytes.size).array())
            digest.update(bytes)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun BigDecimal.money(): BigDecimal = setScale(DecimalTextScale.Money.places)
}

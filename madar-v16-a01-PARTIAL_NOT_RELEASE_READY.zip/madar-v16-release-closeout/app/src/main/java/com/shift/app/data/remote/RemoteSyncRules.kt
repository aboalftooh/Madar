package com.shift.app.data.remote

import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.domain.finance.SyncState

internal fun isSingleCurrencySalePayloadForRollback(
    transactions: List<AssetTransaction>,
    balances: List<BalanceTransaction>,
    allocations: List<CurrencyAssetSaleAllocation>
): Boolean {
    if (allocations.isEmpty() || transactions.isEmpty() || balances.isEmpty()) return false
    val operationIds = (
        transactions.map { it.operationId } +
            balances.map { it.operationId } +
            allocations.map { it.operationId }
        ).toSet()
    return operationIds.size == 1 && transactions.all {
        it.kind == "sale_full" || it.kind == "sale_partial"
    }
}

internal fun shouldPushFinancialRecord(
    updatedAt: Long,
    syncState: String,
    lastSync: Long
): Boolean = updatedAt > lastSync || syncState != SyncState.Synced.dbValue

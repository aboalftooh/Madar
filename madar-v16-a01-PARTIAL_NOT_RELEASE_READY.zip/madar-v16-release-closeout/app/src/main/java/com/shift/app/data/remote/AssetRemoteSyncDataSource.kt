package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.AssetRemoteSync
import com.shift.app.sync.remote.LedgerRemoteSync

@Singleton
class AssetRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
    private val ledgerRemote: LedgerRemoteSync,
    private val assetDao: AssetDao,
    private val assetTransactionDao: AssetTransactionDao,
    private val assetValuationDao: AssetValuationDao,
    private val currencyAssetLotDao: CurrencyAssetLotDao,
    private val currencyAssetSaleAllocationDao: CurrencyAssetSaleAllocationDao,
    private val balanceTransactionDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val transactionDao: TransactionDao,
    private val ledgerHistoryMigrationDao: LedgerHistoryMigrationDao,
) : AssetRemoteSync {
    // ─── Assets ─────────────────────────────────────────────────

    override suspend fun pushAssets(items: List<Asset>) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (items.isEmpty()) return@withContext
        context.client.from("assets").upsert(items.map { it.toRemote(uid) })
        assetDao.upsertAll(items.map { it.copy(syncState = SyncState.Synced.dbValue) })
    }

    override suspend fun pushAssetOperation(
        assets: List<Asset>,
        transactions: List<AssetTransaction>,
        valuations: List<AssetValuation>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        currencyLots: List<CurrencyAssetLot>,
        currencySaleAllocations: List<CurrencyAssetSaleAllocation>,
        legacyTransactions: List<Transaction>,
        ledgerHistoryMigrations: List<LedgerHistoryMigration>
    ) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (
            assets.isEmpty() && transactions.isEmpty() && valuations.isEmpty() &&
            balanceTransactions.isEmpty() && payments.isEmpty() &&
            currencyLots.isEmpty() && currencySaleAllocations.isEmpty() &&
            legacyTransactions.isEmpty() && ledgerHistoryMigrations.isEmpty()
        ) return@withContext

        try {
            context.client.postgrest.rpc(
                function = ASSET_OPERATION_RPC_FUNCTION,
                parameters = AssetOperationRpcParams(
                    balanceTransactions = balanceTransactions.map { it.toRemote(uid) },
                    payments = payments.map { it.toRemote(uid) },
                    assets = assets.map { it.toRemote(uid) },
                    assetTransactions = transactions.map { it.toRemote(uid) },
                    assetValuations = valuations.map { it.toRemote(uid) },
                    currencyAssetLots = currencyLots.map { it.toRemote(uid) },
                    currencyAssetSaleAllocations = currencySaleAllocations.map { it.toRemote(uid) },
                    legacyTransactions = legacyTransactions.map { it.toRemote(uid) },
                    ledgerHistoryMigrations = ledgerHistoryMigrations.map { it.toRemote(uid) }
                )
            )
            updateAssetOperationSyncState(
                assets,
                transactions,
                valuations,
                balanceTransactions,
                payments,
                currencyLots,
                currencySaleAllocations,
                legacyTransactions,
                ledgerHistoryMigrations,
                SyncState.Synced.dbValue
            )
        } catch (error: Exception) {
            if (
                isSingleCurrencySalePayloadForRollback(transactions, balanceTransactions, currencySaleAllocations) &&
                error.isCurrencyAllocationConflict()
            ) {
                rollbackRejectedCurrencySale(
                    assets = assets,
                    transactions = transactions,
                    balanceTransactions = balanceTransactions,
                    allocations = currencySaleAllocations
                )
                runCatching { refreshCurrencyConflictFromRemote(assets.map { it.id }.toSet()) }
                throw IllegalStateException(
                    "رفض الخادم البيع لأن الكمية لم تعد متاحة بعد مزامنة جهاز آخر",
                    error
                )
            } else if (
                currencyLots.any { it.deletedAt != null } &&
                error.isUnavailableCurrencyLotConflict()
            ) {
                rollbackRejectedCurrencyLotDeletion(
                    assets = assets,
                    transactions = transactions,
                    valuations = valuations,
                    balanceTransactions = balanceTransactions,
                    payments = payments,
                    lots = currencyLots
                )
                runCatching {
                    refreshCurrencyConflictFromRemote(
                        (assets.map { it.id } + currencyLots.map { it.assetId }).toSet()
                    )
                }
                throw IllegalStateException(
                    "تعذر حذف دفعة العملة لأن لها مبيعات متزامنة؛ أُعيدت الدفعة محليًا",
                    error
                )
            } else {
                updateAssetOperationSyncState(
                    assets,
                    transactions,
                    valuations,
                    balanceTransactions,
                    payments,
                    currencyLots,
                    currencySaleAllocations,
                    legacyTransactions,
                    ledgerHistoryMigrations,
                    SyncState.Failed.dbValue
                )
                throw error
            }
        }
    }

    private suspend fun rollbackRejectedCurrencySale(
        assets: List<Asset>,
        transactions: List<AssetTransaction>,
        balanceTransactions: List<BalanceTransaction>,
        allocations: List<CurrencyAssetSaleAllocation>
    ) = context.database.withTransaction {
        val now = System.currentTimeMillis()
        assets.forEach {
            assetDao.update(
                it.copy(
                    status = AssetStatus.Active.dbValue,
                    syncState = SyncState.Conflict.dbValue,
                    updatedAt = now
                )
            )
        }
        transactions.forEach {
            assetTransactionDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = now)
            )
        }
        balanceTransactions.forEach {
            balanceTransactionDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = now)
            )
        }
        allocations.forEach {
            currencyAssetSaleAllocationDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = now)
            )
        }
    }

    private suspend fun rollbackRejectedCurrencyLotDeletion(
        assets: List<Asset>,
        transactions: List<AssetTransaction>,
        valuations: List<AssetValuation>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        lots: List<CurrencyAssetLot>
    ) = context.database.withTransaction {
        val now = System.currentTimeMillis()
        assets.forEach {
            assetDao.update(it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null))
        }
        transactions.forEach {
            assetTransactionDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null)
            )
        }
        valuations.forEach {
            assetValuationDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null)
            )
        }
        balanceTransactions.forEach {
            balanceTransactionDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null)
            )
        }
        payments.forEach {
            paymentDao.update(it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null))
        }
        lots.forEach {
            currencyAssetLotDao.update(
                it.copy(syncState = SyncState.Conflict.dbValue, updatedAt = now, deletedAt = null)
            )
        }
    }

    private suspend fun refreshCurrencyConflictFromRemote(assetIds: Set<String>) {
        ledgerRemote.pullBalanceTransactions(forceFull = true)
        pullAssets(forceFull = true)
        pullAssetTransactions(forceFull = true)
        pullCurrencyAssetLots(forceFull = true)
        pullCurrencyAssetSaleAllocations(forceFull = true)
        reconcileCurrencyAssetStatuses(assetIds)
    }

    private suspend fun reconcileCurrencyAssetStatuses(assetIds: Set<String>) = context.database.withTransaction {
        val now = System.currentTimeMillis()
        assetIds.forEach { assetId ->
            val asset = assetDao.getById(assetId) ?: return@forEach
            if (
                asset.type != "foreign_currency" ||
                asset.status !in setOf(AssetStatus.Active.dbValue, AssetStatus.Sold.dbValue)
            ) return@forEach
            val lots = currencyAssetLotDao.getActiveByAssetId(assetId)
            if (lots.isEmpty()) return@forEach
            val allocations = currencyAssetSaleAllocationDao.getActiveByAssetId(assetId)
            val available = CurrencyAssetCalculator.availableQuantity(
                lots.map {
                    CurrencyLotSnapshot(
                        id = it.id,
                        quantityPurchasedDecimal = it.quantityPurchasedDecimal,
                        localCostDecimal = it.localCostDecimal,
                        purchaseDate = it.purchaseDate,
                        createdAt = it.createdAt,
                        deletedAt = it.deletedAt
                    )
                },
                allocations.map {
                    CurrencyAllocationSnapshot(
                        lotId = it.lotId,
                        quantitySoldDecimal = it.quantitySoldDecimal,
                        allocatedLocalCostDecimal = it.allocatedLocalCostDecimal,
                        deletedAt = it.deletedAt
                    )
                }
            )
            val derivedStatus = if (DecimalText.toBigDecimal(available).signum() == 0) {
                AssetStatus.Sold.dbValue
            } else {
                AssetStatus.Active.dbValue
            }
            if (asset.status != derivedStatus) {
                assetDao.update(
                    asset.copy(status = derivedStatus, syncState = SyncState.Pending.dbValue, updatedAt = now)
                )
            }
        }
    }

    private suspend fun updateAssetOperationSyncState(
        assets: List<Asset>,
        transactions: List<AssetTransaction>,
        valuations: List<AssetValuation>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        currencyLots: List<CurrencyAssetLot>,
        currencySaleAllocations: List<CurrencyAssetSaleAllocation>,
        legacyTransactions: List<Transaction>,
        ledgerHistoryMigrations: List<LedgerHistoryMigration>,
        state: String
    ) = context.database.withTransaction {
        assets.forEach { assetDao.update(it.copy(syncState = state)) }
        transactions.forEach { assetTransactionDao.update(it.copy(syncState = state)) }
        valuations.forEach { assetValuationDao.update(it.copy(syncState = state)) }
        balanceTransactions.forEach { balanceTransactionDao.update(it.copy(syncState = state)) }
        payments.forEach { paymentDao.update(it.copy(syncState = state)) }
        currencyLots.forEach { currencyAssetLotDao.update(it.copy(syncState = state)) }
        currencySaleAllocations.forEach { currencyAssetSaleAllocationDao.update(it.copy(syncState = state)) }
        legacyTransactions.forEach { transactionDao.update(it.copy(syncState = state)) }
        ledgerHistoryMigrations.forEach { ledgerHistoryMigrationDao.update(it.copy(syncState = state)) }
    }

    override suspend fun pullAssets(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.Assets.key)
        val remote = context.fetchAllOrdered<RemoteAsset>("assets", uid, if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.Assets))
        val localById = assetDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("assets", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, AssetPayload.serializer())
                Asset(
                    id = item.id,
                    operationId = p.operationId,
                    type = p.type,
                    name = p.name,
                    status = p.status,
                    acquisitionMode = p.acquisitionMode,
                    acquisitionAmountDecimal = p.acquisitionAmountDecimal,
                    currencyCode = p.currencyCode,
                    purchasePaymentId = p.purchasePaymentId,
                    purchaseBalanceTransactionId = p.purchaseBalanceTransactionId,
                    currentValueCacheDecimal = p.currentValueCacheDecimal,
                    currentValueCacheValuationId = p.currentValueCacheValuationId,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("assets", skipped)
        assetDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("assets", it.id, null, it.updatedAt)
        }
    }

    override suspend fun pullAssetTransactions(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.AssetTransactions.key)
        val remote = context.fetchAllOrdered<RemoteAssetTransaction>(
            "asset_transactions",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.AssetTransactions)
        )
        val localById = assetTransactionDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("asset_transactions", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, AssetTransactionPayload.serializer())
                AssetTransaction(
                    id = item.id,
                    operationId = p.operationId,
                    assetId = p.assetId,
                    kind = p.kind,
                    amountDecimal = p.amountDecimal,
                    currencyQuantityDeltaDecimal = p.currencyQuantityDeltaDecimal,
                    paymentId = p.paymentId,
                    balanceTransactionId = p.balanceTransactionId,
                    date = p.date,
                    note = p.note,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("asset_transactions", skipped)
        assetTransactionDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("assets", it.assetId, it.date, it.updatedAt)
        }
    }

    override suspend fun pullAssetValuations() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.AssetValuations.key)
        val remote = context.fetchAllOrdered<RemoteAssetValuation>("asset_valuations", uid, context.remoteUpdatedSince(SyncCheckpointKey.AssetValuations))
        val localById = assetValuationDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("asset_valuations", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, AssetValuationPayload.serializer())
                AssetValuation(
                    id = item.id,
                    operationId = p.operationId,
                    assetId = p.assetId,
                    valueDecimal = p.valueDecimal,
                    date = p.date,
                    note = p.note,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("asset_valuations", skipped)
        assetValuationDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("assets", it.assetId, it.date, it.updatedAt)
        }
    }

    override suspend fun pullCurrencyAssetLots(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.CurrencyAssetLots.key)
        val remote = context.fetchAllOrdered<RemoteCurrencyAssetLot>(
            "currency_asset_lots",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.CurrencyAssetLots)
        )
        val localById = currencyAssetLotDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("currency_asset_lots", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, CurrencyAssetLotPayload.serializer())
                CurrencyAssetLot(
                    id = item.id,
                    operationId = p.operationId,
                    assetId = p.assetId,
                    purchaseAssetTransactionId = p.purchaseAssetTransactionId,
                    foreignCurrencyCode = p.foreignCurrencyCode,
                    quantityPurchasedDecimal = p.quantityPurchasedDecimal,
                    purchaseExchangeRateDecimal = p.purchaseExchangeRateDecimal,
                    localCostDecimal = p.localCostDecimal,
                    purchaseDate = p.purchaseDate,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { it > 0L }
                )
            }
        }
        context.logSkippedRows("currency_asset_lots", skipped)
        currencyAssetLotDao.upsertAll(merged)
    }

    override suspend fun pullCurrencyAssetSaleAllocations(forceFull: Boolean) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.CurrencyAssetSaleAllocations.key)
        val remote = context.fetchAllOrdered<RemoteCurrencyAssetSaleAllocation>(
            "currency_asset_sale_allocations",
            uid,
            if (forceFull) null else context.remoteUpdatedSince(SyncCheckpointKey.CurrencyAssetSaleAllocations)
        )
        val localById = currencyAssetSaleAllocationDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("currency_asset_sale_allocations", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(
                    item.payload,
                    uid,
                    CurrencyAssetSaleAllocationPayload.serializer()
                )
                CurrencyAssetSaleAllocation(
                    id = item.id,
                    operationId = p.operationId,
                    assetId = p.assetId,
                    saleAssetTransactionId = p.saleAssetTransactionId,
                    lotId = p.lotId,
                    quantitySoldDecimal = p.quantitySoldDecimal,
                    allocatedLocalCostDecimal = p.allocatedLocalCostDecimal,
                    syncState = SyncState.Synced.dbValue,
                    createdAt = p.createdAt,
                    updatedAt = remoteUpdatedAt,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { it > 0L }
                )
            }
        }
        context.logSkippedRows("currency_asset_sale_allocations", skipped)
        currencyAssetSaleAllocationDao.upsertAll(merged)
    }


    private fun Asset.toRemote(uid: String): RemoteAsset {
        val payload = context.json.encodeToString(
            AssetPayload.serializer(),
            AssetPayload(
                operationId = operationId,
                type = type,
                name = name,
                status = status,
                acquisitionMode = acquisitionMode,
                acquisitionAmountDecimal = acquisitionAmountDecimal,
                currencyCode = currencyCode,
                purchasePaymentId = purchasePaymentId,
                purchaseBalanceTransactionId = purchaseBalanceTransactionId,
                currentValueCacheDecimal = currentValueCacheDecimal,
                currentValueCacheValuationId = currentValueCacheValuationId,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteAsset(id, uid, payload, updatedAt.toRemoteTime(), deletedAt?.toRemoteTime())
    }

    private fun AssetTransaction.toRemote(uid: String): RemoteAssetTransaction {
        val payload = context.json.encodeToString(
            AssetTransactionPayload.serializer(),
            AssetTransactionPayload(
                operationId = operationId,
                assetId = assetId,
                kind = kind,
                amountDecimal = amountDecimal,
                currencyQuantityDeltaDecimal = currencyQuantityDeltaDecimal,
                paymentId = paymentId,
                balanceTransactionId = balanceTransactionId,
                date = date,
                note = note,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteAssetTransaction(id, uid, payload, updatedAt.toRemoteTime(), deletedAt?.toRemoteTime())
    }

    private fun AssetValuation.toRemote(uid: String): RemoteAssetValuation {
        val payload = context.json.encodeToString(
            AssetValuationPayload.serializer(),
            AssetValuationPayload(
                operationId = operationId,
                assetId = assetId,
                valueDecimal = valueDecimal,
                date = date,
                note = note,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteAssetValuation(id, uid, payload, updatedAt.toRemoteTime(), deletedAt?.toRemoteTime())
    }

    private fun CurrencyAssetLot.toRemote(uid: String): RemoteCurrencyAssetLot {
        val payload = context.json.encodeToString(
            CurrencyAssetLotPayload.serializer(),
            CurrencyAssetLotPayload(
                operationId = operationId,
                assetId = assetId,
                purchaseAssetTransactionId = purchaseAssetTransactionId,
                foreignCurrencyCode = foreignCurrencyCode,
                quantityPurchasedDecimal = quantityPurchasedDecimal,
                purchaseExchangeRateDecimal = purchaseExchangeRateDecimal,
                localCostDecimal = localCostDecimal,
                purchaseDate = purchaseDate,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteCurrencyAssetLot(id, uid, payload, updatedAt.toRemoteTime(), deletedAt?.toRemoteTime())
    }

    private fun CurrencyAssetSaleAllocation.toRemote(uid: String): RemoteCurrencyAssetSaleAllocation {
        val payload = context.json.encodeToString(
            CurrencyAssetSaleAllocationPayload.serializer(),
            CurrencyAssetSaleAllocationPayload(
                operationId = operationId,
                assetId = assetId,
                saleAssetTransactionId = saleAssetTransactionId,
                lotId = lotId,
                quantitySoldDecimal = quantitySoldDecimal,
                allocatedLocalCostDecimal = allocatedLocalCostDecimal,
                syncState = syncState,
                createdAt = createdAt
            )
        )
        return RemoteCurrencyAssetSaleAllocation(id, uid, payload, updatedAt.toRemoteTime(), deletedAt?.toRemoteTime())
    }


    private fun Throwable.isCurrencyAllocationConflict(): Boolean =
        generateSequence(this) { it.cause }
            .mapNotNull { it.message }
            .any { message ->
                message.contains("Currency sale exceeds available lot quantity", ignoreCase = true) ||
                    message.contains("Currency sale allocation references an unavailable lot", ignoreCase = true)
            }

    private fun Throwable.isUnavailableCurrencyLotConflict(): Boolean =
        generateSequence(this) { it.cause }
            .mapNotNull { it.message }
            .any {
                it.contains("Currency sale allocation references an unavailable lot", ignoreCase = true)
            }

}

package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType

fun debtAsciiDecimalOnly(raw: String): String =
    raw.filter { it in '0'..'9' || it == '.' }.let { filtered ->
        val firstDot = filtered.indexOf('.')
        if (firstDot < 0) filtered else filtered.take(firstDot + 1) + filtered.drop(firstDot + 1).replace(".", "")
    }

@Composable
fun DebtMoneyField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    imeAction: ImeAction = ImeAction.Next,
    onNext: () -> Unit = {},
    onDone: () -> Unit = {}
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(debtAsciiDecimalOnly(it)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = imeAction),
        keyboardActions = KeyboardActions(onNext = { onNext() }, onDone = { onDone() })
    )
}

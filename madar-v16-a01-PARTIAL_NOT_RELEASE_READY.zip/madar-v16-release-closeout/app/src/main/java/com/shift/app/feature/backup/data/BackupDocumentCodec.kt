package com.shift.app.feature.backup.data

import com.shift.app.feature.backup.domain.model.BackupCompatibility
import com.shift.app.feature.backup.domain.model.BackupManifest
import com.shift.app.feature.backup.domain.model.CorruptBackupException
import com.shift.app.feature.backup.domain.model.IncompatibleBackupException
import com.shift.app.feature.backup.domain.model.compatibility
import org.json.JSONObject

internal class BackupDocumentCodec(
    codecs: List<BackupSectionCodec>,
) {
    private val codecs = codecs.associateBy { it.id }.also { byId ->
        require(byId.size == codecs.size) { "Duplicate backup section codec" }
    }

    suspend fun encode(now: Long): String {
        val root = JSONObject().apply {
            put("manifest", BackupManifest.current(now).toJson())
        }
        codecs.values.forEach { it.writeExport(root) }
        return root.toString(2)
    }

    fun decode(text: String, now: Long): DecodedBackupDocument {
        val fingerprint = BackupRedactor.fingerprint(text)
        val root = try {
            JSONObject(text)
        } catch (error: Throwable) {
            throw CorruptBackupException("Backup JSON is invalid", error)
        }
        val manifest = try {
            root.optJSONObject("manifest")?.toManifest() ?: BackupManifest.legacy()
        } catch (error: Throwable) {
            throw CorruptBackupException("Backup manifest is invalid", error)
        }
        val compatibility = manifest.compatibility()
        if (compatibility != BackupCompatibility.COMPATIBLE) {
            throw IncompatibleBackupException(manifest, compatibility)
        }
        val decoded = linkedMapOf<String, BackupSectionSnapshot>()
        codecs.forEach { (id, codec) ->
            decoded[id] = try {
                codec.decode(root, now)
            } catch (error: Throwable) {
                throw CorruptBackupException("Backup section '$id' is invalid", error)
            }
        }
        return DecodedBackupDocument(manifest, decoded, fingerprint)
    }

    fun sectionIds(): List<String> = codecs.keys.sorted()

    private fun BackupManifest.toJson() = JSONObject().apply {
        put("applicationId", applicationId)
        put("formatVersion", formatVersion)
        put("minimumReaderVersion", minimumReaderVersion)
        put("maximumReaderVersion", maximumReaderVersion)
        put("databaseSchemaVersion", databaseSchemaVersion)
        put("createdAt", createdAt)
    }

    private fun JSONObject.toManifest() = BackupManifest(
        applicationId = requireString("applicationId"),
        formatVersion = requirePositiveInt("formatVersion"),
        minimumReaderVersion = requirePositiveInt("minimumReaderVersion"),
        maximumReaderVersion = requirePositiveInt("maximumReaderVersion"),
        databaseSchemaVersion = requirePositiveInt("databaseSchemaVersion"),
        createdAt = requireNonNegativeLong("createdAt"),
    )

    private fun JSONObject.requireString(name: String): String {
        val value = opt(name)
        require(value is String && value.isNotBlank()) { "Missing $name" }
        return value
    }

    private fun JSONObject.requirePositiveInt(name: String): Int {
        val value = opt(name)
        require(value is Number) { "Missing $name" }
        val long = value.toLong()
        require(long in 1..Int.MAX_VALUE.toLong()) { "Invalid $name" }
        return long.toInt()
    }

    private fun JSONObject.requireNonNegativeLong(name: String): Long {
        val value = opt(name)
        require(value is Number) { "Missing $name" }
        val long = value.toLong()
        require(long >= 0L) { "Invalid $name" }
        return long
    }
}

package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "debt_links",
    foreignKeys = [
        ForeignKey(
            entity = DebtAccount::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onUpdate = ForeignKey.NO_ACTION,
            onDelete = ForeignKey.NO_ACTION
        ),
        ForeignKey(
            entity = DebtTransaction::class,
            parentColumns = ["id"],
            childColumns = ["debtTransactionId"],
            onUpdate = ForeignKey.NO_ACTION,
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["accountId"]),
        Index(value = ["debtTransactionId"]),
        Index(value = ["operationId"]),
        Index(value = ["targetType", "targetId"]),
        Index(value = ["syncState", "updatedAt"])
    ]
)
data class DebtLink(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val accountId: String,
    val debtTransactionId: String,
    val targetType: String,
    val targetId: String,
    val role: String,
    val amountDecimal: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

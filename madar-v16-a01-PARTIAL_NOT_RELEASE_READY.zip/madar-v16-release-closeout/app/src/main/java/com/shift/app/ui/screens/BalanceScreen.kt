package com.shift.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.ui.theme.*
import com.shift.app.utils.FinancialInput
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.viewmodel.BalanceUiState
import com.shift.app.viewmodel.BalanceViewModel
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BalanceScreen(vm: BalanceViewModel = hiltViewModel()) {
    val state by vm.state.collectAsState()
    var showManualDialog by remember { mutableStateOf(false) }
    var waitingForSave by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.message, state.error) {
        val feedback = state.error ?: state.message ?: return@LaunchedEffect
        if (waitingForSave && state.message != null) {
            showManualDialog = false
            waitingForSave = false
        } else if (state.error != null) {
            waitingForSave = false
        }
        snackbarHostState.showSnackbar(feedback)
        vm.clearFeedback()
    }

    Scaffold(
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (state.activated) {
                FloatingActionButton(
                    onClick = {
                        if (!state.busy) showManualDialog = true
                    },
                    containerColor = AccentBlue,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة أو سحب رصيد")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundDark),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "الرصيد",
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = CairoFamily
                    )
                    Icon(
                        Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            item { BalanceValueCard(state) }

            if (!state.activated) {
                item { BalanceActivationCard(state, vm::activate) }
            } else {
                item {
                    Text(
                        "حركة الرصيد",
                        color = AccentCyan,
                        fontWeight = FontWeight.Bold,
                        fontFamily = CairoFamily
                    )
                }

                if (state.transactions.isEmpty()) {
                    item {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 44.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لا توجد حركات رصيد بعد", color = TextMuted, fontFamily = CairoFamily)
                        }
                    }
                }

                items(
                    items = state.transactions.distinctBy { "${it.operationId}:${it.kind}" },
                    key = { it.id }
                ) { transaction ->
                    BalanceMovementRow(transaction)
                }
            }
        }
    }

    if (showManualDialog) {
        ManualBalanceDialog(
            saving = waitingForSave || state.busy,
            onDismiss = {
                if (!waitingForSave && !state.busy) showManualDialog = false
            },
            onSave = { isAddition, amount, date, note ->
                if (!waitingForSave && !state.busy) {
                    waitingForSave = true
                    vm.saveManualBalance(isAddition, amount, date, note)
                }
            }
        )
    }
}

@Composable
private fun BalanceValueCard(state: BalanceUiState) {
    val value = runCatching { BigDecimal(state.currentBalanceDecimal) }.getOrDefault(BigDecimal.ZERO)
    val allocated = runCatching { BigDecimal(state.allocatedBalanceDecimal) }.getOrDefault(BigDecimal.ZERO)
    val available = runCatching { BigDecimal(state.availableBalanceDecimal) }.getOrDefault(BigDecimal.ZERO)
    val valueColor = if (value.signum() < 0) ExpenseRed else IncomeGreen
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("الرصيد الحالي", color = TextMuted, fontSize = 12.sp, fontFamily = CairoFamily)
            Text(
                "${NumberDisplayFormatter.format(value.abs(), useGrouping = true)} ${state.currencyCode}",
                color = valueColor,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily
            )
            Spacer(Modifier.height(10.dp))
            BalanceSummaryRow("المخصص للأهداف", allocated, state.currencyCode, GoldPrimary)
            BalanceSummaryRow("الرصيد المتاح", available, state.currencyCode, if (available.signum() < 0) ExpenseRed else AccentCyan)
        }
    }
}

@Composable
private fun BalanceSummaryRow(label: String, value: BigDecimal, currencyCode: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextMuted, fontSize = 12.sp, fontFamily = CairoFamily)
        Text(
            "${NumberDisplayFormatter.format(value, useGrouping = true)} $currencyCode",
            color = color,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = CairoFamily
        )
    }
}

@Composable
private fun BalanceActivationCard(state: BalanceUiState, onActivate: (String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("تفعيل الرصيد", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
            Text(
                "أدخل رصيدك الحالي لبدء سجل الحركات من اليوم.",
                color = TextMuted,
                fontSize = 12.sp,
                fontFamily = CairoFamily
            )
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = FinancialInput.englishDigitsOnly(it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("الرصيد الحالي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
            )
            Button(
                onClick = { onActivate(amount.ifBlank { "0" }) },
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text("تفعيل الرصيد", color = BackgroundDark, fontFamily = CairoFamily)
            }
        }
    }
}

private data class MovementStyle(
    val label: String,
    val color: Color,
    val pointsUp: Boolean
)

@Composable
private fun BalanceMovementRow(item: BalanceTransaction) {
    val style = movementStyle(item)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .background(style.color.copy(alpha = 0.15f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (style.pointsUp) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = style.color
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(style.label, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontFamily = CairoFamily)
                Text(item.date, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                if (item.note.isNotBlank()) {
                    Text(item.note, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                }
            }
            Text(
                "${NumberDisplayFormatter.formatDecimalText(item.amountDecimal, useGrouping = true, absolute = true)} ${item.currencyCode}",
                color = style.color,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily
            )
        }
    }
}

private fun movementStyle(item: BalanceTransaction): MovementStyle = when (item.kind) {
    BalanceTransactionKind.Income.dbValue -> MovementStyle("دخل", IncomeGreen, true)
    BalanceTransactionKind.AssetSale.dbValue -> MovementStyle("بيع أصل", IncomeGreen, true)
    BalanceTransactionKind.AssetPurchase.dbValue -> MovementStyle("شراء أصل", AccentBlue, true)
    BalanceTransactionKind.AssetImprovement.dbValue -> MovementStyle("تحسين أصل", AccentBlue, true)
    BalanceTransactionKind.ExpensePayment.dbValue -> MovementStyle("مصروف", ExpenseRed, false)
    BalanceTransactionKind.AssetMaintenance.dbValue -> MovementStyle("صيانة أصل", ExpenseRed, false)
    BalanceTransactionKind.ManualAdd.dbValue -> MovementStyle("إضافة رصيد يدوية", IncomeGreen, true)
    BalanceTransactionKind.ManualWithdrawal.dbValue -> MovementStyle("سحب رصيد يدوي", ExpenseRed, false)
    BalanceTransactionKind.OpeningBalance.dbValue -> MovementStyle(
        "رصيد افتتاحي",
        if (item.direction == BalanceDirection.Outflow.dbValue) ExpenseRed else IncomeGreen,
        item.direction != BalanceDirection.Outflow.dbValue
    )
    BalanceTransactionKind.OpeningBalanceAdjustment.dbValue -> MovementStyle(
        "تسوية الرصيد",
        if (item.direction == BalanceDirection.Outflow.dbValue) ExpenseRed else IncomeGreen,
        item.direction != BalanceDirection.Outflow.dbValue
    )
    else -> MovementStyle(
        item.kind,
        if (item.direction == BalanceDirection.Outflow.dbValue) ExpenseRed else IncomeGreen,
        item.direction != BalanceDirection.Outflow.dbValue
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManualBalanceDialog(
    saving: Boolean,
    onDismiss: () -> Unit,
    onSave: (isAddition: Boolean, amount: String, date: String, note: String) -> Unit
) {
    var isAddition by remember { mutableStateOf(true) }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var note by remember { mutableStateOf("") }
    var amountError by remember { mutableStateOf("") }
    var dateError by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    val selectedDateMillis = remember(date) {
        runCatching { LocalDate.parse(date).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
    }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
    val noteFocus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    fun submit() {
        if (saving) return
        amountError = if (FinancialInput.isPositiveEnglishAmount(amount)) "" else "أدخل مبلغاً أكبر من صفر"
        dateError = if (runCatching { LocalDate.parse(date) }.isSuccess) "" else "اختر تاريخاً صحيحاً"
        if (amountError.isEmpty() && dateError.isEmpty()) {
            focusManager.clearFocus()
            onSave(isAddition, amount, date, note.trim())
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .imePadding()
                .heightIn(max = 640.dp),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceDark
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("إضافة أو سحب رصيد", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isAddition,
                        enabled = !saving,
                        onClick = { isAddition = true },
                        label = { Text("إضافة") }
                    )
                    FilterChip(
                        selected = !isAddition,
                        enabled = !saving,
                        onClick = { isAddition = false },
                        label = { Text("سحب") }
                    )
                }
                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = amount,
                        onValueChange = {
                            amount = FinancialInput.englishDigitsOnly(it)
                            amountError = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("المبلغ") },
                        singleLine = true,
                        enabled = !saving,
                        isError = amountError.isNotEmpty(),
                        supportingText = if (amountError.isNotEmpty()) {{ Text(amountError) }} else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = {
                            focusManager.clearFocus()
                            showDatePicker = true
                        })
                    )
                    Box {
                        OutlinedTextField(
                            value = date,
                            onValueChange = {},
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("التاريخ") },
                            readOnly = true,
                            enabled = !saving,
                            isError = dateError.isNotEmpty(),
                            supportingText = if (dateError.isNotEmpty()) {{ Text(dateError) }} else null,
                            trailingIcon = { Icon(Icons.Default.DateRange, contentDescription = "اختر التاريخ") }
                        )
                        Box(
                            Modifier
                                .matchParentSize()
                                .clickable(enabled = !saving) { showDatePicker = true }
                        )
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(noteFocus),
                        label = { Text("ملاحظات (اختياري)") },
                        enabled = !saving,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { submit() })
                    )
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, enabled = !saving) { Text("إلغاء", color = TextMuted) }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { submit() },
                        enabled = !saving,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAddition) IncomeGreen else ExpenseRed)
                    ) {
                        if (saving) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Text("حفظ")
                        }
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        date = Instant.ofEpochMilli(millis).atZone(ZoneId.of("UTC")).toLocalDate().toString()
                        dateError = ""
                    }
                    showDatePicker = false
                    noteFocus.requestFocus()
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

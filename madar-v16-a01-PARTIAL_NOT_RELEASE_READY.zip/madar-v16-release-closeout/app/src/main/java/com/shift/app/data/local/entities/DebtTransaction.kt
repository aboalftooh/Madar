package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "debt_transactions",
    foreignKeys = [
        ForeignKey(
            entity = DebtAccount::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onUpdate = ForeignKey.NO_ACTION,
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["accountId", "deletedAt"]),
        Index(value = ["operationId"]),
        Index(value = ["type"]),
        Index(value = ["originalTransactionId"]),
        Index(value = ["syncState", "updatedAt"])
    ]
)
data class DebtTransaction(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val accountId: String,
    val operationId: String,
    val type: String,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val occurredAt: Long,
    val note: String = "",
    val reason: String? = null,
    val originalTransactionId: String? = null,
    val sourceType: String = "",
    val sourceId: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
) {
    constructor(
        accountId: String,
        operationId: String,
        type: DebtTransactionType,
        amountDecimal: String,
        currencyCode: String = "SDG",
        occurredAt: Long,
        note: String = "",
        reason: String? = null,
        originalTransactionId: String? = null,
        sourceType: String = "",
        sourceId: String? = null
    ) : this(
        accountId = accountId,
        operationId = operationId,
        type = type.dbValue,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        occurredAt = occurredAt,
        note = note,
        reason = reason,
        originalTransactionId = originalTransactionId,
        sourceType = sourceType,
        sourceId = sourceId
    )
}

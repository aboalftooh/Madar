package com.shift.app.feature.reports.di

import com.shift.app.feature.reports.data.ReportsQueryAdapter
import com.shift.app.feature.reports.domain.repository.ReportsQuery
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class ReportsFeatureModule {
    @Binds
    @Singleton
    abstract fun bindReportsQuery(impl: ReportsQueryAdapter): ReportsQuery
}

package com.shift.app.feature.backup.data.codec

import com.shift.app.data.backup.DebtAccountBackup
import com.shift.app.data.backup.DebtBackupMapper
import com.shift.app.data.backup.DebtBackupPayload
import com.shift.app.data.backup.DebtLinkBackup
import com.shift.app.data.backup.DebtMigrationReviewBackup
import com.shift.app.data.backup.DebtScheduleBackup
import com.shift.app.data.backup.DebtTransactionBackup
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.domain.model.BackupImportMode
import javax.inject.Inject
import kotlinx.coroutines.flow.first
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject

internal data class DebtSectionSnapshot(
    val payload: DebtBackupPayload,
    val included: Boolean,
) : BackupSectionSnapshot {
    override val rowCount: Int = payload.accounts.size + payload.transactions.size + payload.links.size +
        payload.schedules.size + payload.reviews.size
}

internal data class DebtSectionPlan(
    val payload: DebtBackupPayload,
    override val importedRowCount: Int,
    override val affectedRowCount: Int,
    override val deleteCount: Int,
) : BackupSectionPlan

internal class DebtBackupCodec @Inject constructor(
    private val database: MadarDatabase,
) : BackupSectionCodec {
    override val id: String = "debts"
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun writeExport(root: JSONObject) {
        val payload = currentPayload()
        root.put("debtLedger", JSONObject(json.encodeToString(payload)))
    }

    override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot {
        @Suppress("UNUSED_VARIABLE") val timestamp = now
        val included = root.has("debtLedger")
        val payload = root.optJSONObject("debtLedger")?.let {
            json.decodeFromString(DebtBackupPayload.serializer(), it.toString())
        } ?: DebtBackupPayload()
        payload.validateForRestore()
        return DebtSectionSnapshot(payload, included)
    }

    override suspend fun plan(
        imported: BackupSectionSnapshot,
        mode: BackupImportMode,
        now: Long,
    ): BackupSectionPlan {
        imported as DebtSectionSnapshot
        val current = currentPayload()
        if (!imported.included) {
            return DebtSectionPlan(current, 0, 0, 0)
        }
        val planned = merge(imported.payload, current, mode, now)
        val deletes = planned.accounts.count { it.deletedAt == now } +
            planned.transactions.count { it.deletedAt == now } +
            planned.links.count { it.deletedAt == now } +
            planned.schedules.count { it.deletedAt == now } +
            planned.reviews.count { it.deletedAt == now }
        return DebtSectionPlan(
            payload = planned,
            importedRowCount = imported.rowCount,
            affectedRowCount = imported.rowCount + deletes,
            deleteCount = deletes,
        )
    }

    override suspend fun apply(plan: BackupSectionPlan) {
        plan as DebtSectionPlan
        val payload = plan.payload.also { it.validateForRestore() }
        database.debtAccountDao().upsertAll(payload.accounts.map { it.toEntity() })
        database.debtTransactionDao().upsertAll(payload.transactions.map { it.toEntity() })
        database.debtLinkDao().upsertAll(payload.links.map { it.toEntity() })
        database.debtScheduleDao().upsertAll(payload.schedules.map { it.toEntity() })
        database.debtMigrationReviewDao().upsertAll(payload.reviews.map { it.toEntity() })
    }

    private suspend fun currentPayload(): DebtBackupPayload {
        val accountDao = database.debtAccountDao()
        val transactionDao = database.debtTransactionDao()
        val linkDao = database.debtLinkDao()
        val scheduleDao = database.debtScheduleDao()
        val reviewDao = database.debtMigrationReviewDao()
        val accounts = (accountDao.getActiveAccounts().first() + accountDao.getPendingSync())
            .distinctByNewest { it.id to it.updatedAt }
        val transactions = (transactionDao.getActiveTransactions().first() + transactionDao.getPendingSync())
            .distinctByNewest { it.id to it.updatedAt }
        val links = (accounts.flatMap { linkDao.getActiveForAccount(it.id) } + linkDao.getPendingSync())
            .distinctByNewest { it.id to it.updatedAt }
        val schedules = (accounts.flatMap { scheduleDao.getActiveForAccount(it.id).first() } + scheduleDao.getPendingSync())
            .distinctByNewest { it.id to it.updatedAt }
        val reviews = (reviewDao.getActiveReviews().first() + reviewDao.getPendingSync())
            .distinctByNewest { it.id to it.updatedAt }
        return DebtBackupMapper.fromEntities(accounts, transactions, links, schedules, reviews)
            .also { it.validateForRestore() }
    }

    private fun merge(
        imported: DebtBackupPayload,
        current: DebtBackupPayload,
        mode: BackupImportMode,
        now: Long,
    ): DebtBackupPayload {
        imported.validateForRestore()
        current.validateForRestore()
        fun accounts() = mergeRows(current.accounts, imported.accounts, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun transactions() = mergeRows(current.transactions, imported.transactions, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun links() = mergeRows(current.links, imported.links, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun schedules() = mergeRows(current.schedules, imported.schedules, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        fun reviews() = mergeRows(current.reviews, imported.reviews, mode, { it.id }, { it.updatedAt }) {
            it.copy(syncState = "pending", updatedAt = now, deletedAt = now)
        }
        return DebtBackupPayload(
            accounts = accounts(),
            transactions = transactions(),
            links = links(),
            schedules = schedules(),
            reviews = reviews(),
        ).also { it.validateForRestore() }
    }

    private fun <T> mergeRows(
        current: List<T>,
        imported: List<T>,
        mode: BackupImportMode,
        id: (T) -> String,
        updatedAt: (T) -> Long,
        tombstone: (T) -> T,
    ): List<T> = when (mode) {
        BackupImportMode.MERGE -> (current + imported)
            .groupBy(id)
            .map { (_, rows) -> rows.maxBy(updatedAt) }
        BackupImportMode.REPLACE -> imported + current
            .filterNot { currentRow -> imported.any { id(it) == id(currentRow) } }
            .map(tombstone)
    }

    private fun <T> List<T>.distinctByNewest(key: (T) -> Pair<String, Long>): List<T> =
        groupBy { key(it).first }.map { (_, rows) -> rows.maxBy { key(it).second } }

    private fun DebtAccountBackup.toEntity() = DebtAccount(
        id = id,
        operationId = operationId,
        direction = direction,
        partyName = partyName,
        partyKey = partyKey,
        currencyCode = currencyCode,
        confirmed = confirmed,
        syncState = syncState,
        createdAt = updatedAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt,
    )

    private fun DebtTransactionBackup.toEntity() = DebtTransaction(
        id = id,
        accountId = accountId,
        operationId = operationId,
        type = type,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        occurredAt = occurredAt,
        syncState = syncState,
        createdAt = updatedAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt,
    )

    private fun DebtLinkBackup.toEntity() = DebtLink(
        id = id,
        operationId = operationId,
        accountId = accountId,
        debtTransactionId = debtTransactionId,
        targetType = targetType,
        targetId = targetId,
        role = role,
        amountDecimal = amountDecimal,
        syncState = syncState,
        createdAt = updatedAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt,
    )

    private fun DebtScheduleBackup.toEntity() = DebtSchedule(
        id = id,
        operationId = operationId,
        accountId = accountId,
        installmentNo = installmentNo,
        dueDate = dueDate,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        status = status,
        syncState = syncState,
        createdAt = updatedAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt,
    )

    private fun DebtMigrationReviewBackup.toEntity() = DebtMigrationReview(
        id = id,
        legacyDebtId = legacyDebtId,
        status = status,
        reason = reason,
        legacyPayloadJson = legacyPayloadJson,
        syncState = syncState,
        createdAt = updatedAt,
        updatedAt = updatedAt,
        deletedAt = deletedAt,
    )
}

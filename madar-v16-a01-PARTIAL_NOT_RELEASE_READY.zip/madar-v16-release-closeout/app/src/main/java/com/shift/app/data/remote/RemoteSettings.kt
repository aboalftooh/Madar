package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteSettings(
    @SerialName("user_id") val userId: String,
    val payload: String,
    @SerialName("updated_at") val updatedAt: String? = null
)

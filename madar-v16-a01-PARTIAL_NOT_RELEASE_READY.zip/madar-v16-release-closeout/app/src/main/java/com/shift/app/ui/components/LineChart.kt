package com.shift.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.TextMuted

data class MonthlyPoint(val label: String, val income: Float, val expense: Float)

@Composable
fun ShiftLineChart(
    data: List<MonthlyPoint>,
    modifier: Modifier = Modifier
) {
    if (data.size < 2) return

    Canvas(modifier = modifier.fillMaxSize()) {
        val maxVal = data.maxOf { maxOf(it.income, it.expense) }.coerceAtLeast(1f)
        val padL = 8.dp.toPx()
        val padR = 8.dp.toPx()
        val padT = 8.dp.toPx()
        val padB = 24.dp.toPx()
        val w = size.width - padL - padR
        val h = size.height - padT - padB

        fun xOf(i: Int) = padL + i * w / (data.size - 1)
        fun yOf(v: Float) = padT + h - (v / maxVal) * h

        // Grid lines
        repeat(3) { i ->
            val y = padT + i * h / 2f
            drawLine(TextMuted.copy(alpha = 0.15f), Offset(padL, y), Offset(padL + w, y), strokeWidth = 1f)
        }

        // Income line
        val incomePath = Path().apply {
            data.forEachIndexed { i, p ->
                if (i == 0) moveTo(xOf(i), yOf(p.income)) else lineTo(xOf(i), yOf(p.income))
            }
        }
        drawPath(incomePath, IncomeGreen, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

        // Expense line
        val expensePath = Path().apply {
            data.forEachIndexed { i, p ->
                if (i == 0) moveTo(xOf(i), yOf(p.expense)) else lineTo(xOf(i), yOf(p.expense))
            }
        }
        drawPath(expensePath, ExpenseRed, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

        // Dots
        data.forEachIndexed { i, p ->
            drawCircle(IncomeGreen, 5.dp.toPx(), Offset(xOf(i), yOf(p.income)))
            drawCircle(ExpenseRed,  5.dp.toPx(), Offset(xOf(i), yOf(p.expense)))
        }
    }
}

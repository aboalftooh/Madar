package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.SettingsRemoteSync

@Singleton
class SettingsRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
) : SettingsRemoteSync {
    // ─── Cloud settings ────────────────────────────────────────

    override suspend fun pushSettings() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val updatedAt = context.preferences.settingsUpdatedAt.first().takeIf { it > 0L } ?: System.currentTimeMillis()
        val payload = SettingsPayload(
            budgetLimit = context.preferences.budgetLimit.first(),
            incomeSources = context.preferences.incomeSources.first(),
            expenseGroups = context.preferences.expenseGroups.first(),
            userName = context.preferences.userName.first(),
            workType = context.preferences.workType.first(),
            balanceActivated = context.preferences.balanceActivated.first(),
            balanceActivatedAt = context.preferences.balanceActivatedAt.first(),
            localCurrencyCode = context.preferences.localCurrencyCode.first()
        )
        context.client.from("user_settings").upsert(
            RemoteSettings(
                userId = uid,
                payload = context.json.encodeToString(SettingsPayload.serializer(), payload),
                updatedAt = updatedAt.toRemoteTime()
            )
        )
    }

    override suspend fun pullSettings() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.Settings.key)
        val updatedSince = context.remoteUpdatedSince(SyncCheckpointKey.Settings)
        val remote = context.client.from("user_settings")
            .select {
                filter {
                    eq("user_id", uid)
                    updatedSince?.let { gte("updated_at", it) }
                }
            }
            .decodeList<RemoteSettings>()
            .firstOrNull() ?: return@withContext
        val remoteUpdatedAt = remote.updatedAt.toLocalTime()
        val localUpdatedAt = context.preferences.settingsUpdatedAt.first()
        if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = localUpdatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
            )) return@withContext

        val payload = context.json.decodeFromString(SettingsPayload.serializer(), remote.payload)
        context.preferences.replaceCloudSettings(
            userName = payload.userName,
            workType = payload.workType,
            budgetLimit = payload.budgetLimit,
            incomeSources = payload.incomeSources,
            expenseGroups = payload.expenseGroups,
            balanceActivated = payload.balanceActivated,
            balanceActivatedAt = payload.balanceActivatedAt,
            localCurrencyCode = payload.localCurrencyCode,
            updatedAt = remoteUpdatedAt
        )
    }
}

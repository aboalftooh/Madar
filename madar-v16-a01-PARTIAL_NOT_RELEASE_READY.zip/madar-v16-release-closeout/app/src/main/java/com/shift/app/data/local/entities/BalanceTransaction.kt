package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "balance_transactions",
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["date", "deletedAt"]),
        Index(value = ["sourceType", "sourceId"]),
        Index(value = ["legacyTransactionId"], unique = true)
    ]
)
data class BalanceTransaction(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val direction: String,
    val kind: String,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val date: String,
    val note: String = "",
    val sourceType: String = "",
    val sourceId: String? = null,
    val legacyTransactionId: String? = null,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
) {
    constructor(
        operationId: String,
        kind: BalanceTransactionKind,
        amountDecimal: String,
        currencyCode: String = "SDG",
        date: String,
        note: String = "",
        sourceType: String = "",
        sourceId: String? = null
    ) : this(
        operationId = operationId,
        direction = kind.direction.dbValue,
        kind = kind.dbValue,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        date = date,
        note = note,
        sourceType = sourceType,
        sourceId = sourceId
    )
}

package com.shift.app.data.local.sync

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.shift.app.data.local.migration.SqlMigrationExecutor

/** Android adapter around the pure [SyncOutboxSqlPlan]. */
object SyncOutboxSchema {
    private fun SupportSQLiteDatabase.executor() = SqlMigrationExecutor { sql, bindArgs ->
        if (bindArgs.isEmpty()) execSQL(sql) else execSQL(sql, bindArgs)
    }

    fun install(db: SupportSQLiteDatabase) {
        SyncOutboxSqlPlan.install(db.executor())
    }

    fun seedMigrationWakeUp(db: SupportSQLiteDatabase, now: Long = System.currentTimeMillis()) {
        SyncOutboxSqlPlan.seedMigrationWakeUp(db.executor(), now)
    }

    val callback = object : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            install(db)
        }

        override fun onOpen(db: SupportSQLiteDatabase) {
            install(db)
        }
    }
}

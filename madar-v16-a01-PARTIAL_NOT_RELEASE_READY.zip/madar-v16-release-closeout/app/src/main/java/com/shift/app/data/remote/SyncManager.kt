package com.shift.app.data.remote

import android.util.Log
import com.shift.app.sync.SyncOrchestrator
import com.shift.app.sync.remote.SyncSessionRemote
import com.shift.app.sync.SyncRunResult
import java.util.concurrent.CancellationException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Session-safe facade. Feature ordering lives in [SyncOrchestrator]; remote/Room details
 * live behind feature-specific remote ports.
 */
@Singleton
class SyncManager @Inject constructor(
    private val orchestrator: SyncOrchestrator,
    private val remote: SyncSessionRemote,
) {
    private val sessionMutex = Mutex()
    private var initialSyncedUserId: String? = null

    suspend fun initialSync(): SyncRunResult = sessionMutex.withLock { runSyncSafely() }

    suspend fun initialSyncOnce(afterPull: suspend () -> Unit = {}): SyncRunResult? = sessionMutex.withLock {
        val uid = remote.authenticatedUserId ?: return@withLock SyncRunResult.AuthenticationRequired
        if (initialSyncedUserId == uid) return@withLock null
        val result = runSyncSafely(afterPull)
        if (result is SyncRunResult.Success) initialSyncedUserId = uid
        result
    }

    suspend fun syncAll(): SyncRunResult = sessionMutex.withLock { runSyncSafely() }

    suspend fun runSessionCleanup(cleanup: suspend () -> Unit) {
        sessionMutex.withLock {
            try {
                cleanup()
            } finally {
                initialSyncedUserId = null
            }
        }
    }

    suspend fun <T> executeSessionOperation(operation: suspend () -> T): T? = sessionMutex.withLock {
        if (remote.authenticatedUserId == null) return@withLock null
        operation()
    }

    private suspend fun runSyncSafely(afterPull: suspend () -> Unit = {}): SyncRunResult {
        val uid = remote.authenticatedUserId ?: return SyncRunResult.AuthenticationRequired
        return try {
            orchestrator.synchronize(
                expectedUserId = uid,
                isSessionCurrent = { remote.authenticatedUserId == uid },
                afterPull = afterPull,
            )
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            Log.e("SyncManager", "Unhandled sync failure", error)
            SyncRunResult.PartialFailure(listOf("sync_unhandled"))
        }
    }
}

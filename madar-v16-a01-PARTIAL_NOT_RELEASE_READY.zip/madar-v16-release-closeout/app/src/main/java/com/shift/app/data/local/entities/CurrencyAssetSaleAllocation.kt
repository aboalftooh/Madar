package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "currency_asset_sale_allocations",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["assetId"],
            onDelete = ForeignKey.NO_ACTION
        ),
        ForeignKey(
            entity = AssetTransaction::class,
            parentColumns = ["id"],
            childColumns = ["saleAssetTransactionId"],
            onDelete = ForeignKey.NO_ACTION
        ),
        ForeignKey(
            entity = CurrencyAssetLot::class,
            parentColumns = ["id"],
            childColumns = ["lotId"],
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["assetId", "lotId"]),
        Index(value = ["lotId"]),
        Index(value = ["saleAssetTransactionId", "lotId"], unique = true)
    ]
)
data class CurrencyAssetSaleAllocation(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val assetId: String,
    val saleAssetTransactionId: String,
    val lotId: String,
    val quantitySoldDecimal: String,
    val allocatedLocalCostDecimal: String,
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

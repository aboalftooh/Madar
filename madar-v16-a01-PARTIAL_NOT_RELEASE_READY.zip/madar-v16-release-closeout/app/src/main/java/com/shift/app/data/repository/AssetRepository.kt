package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Payment
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.CurrencySalePlan
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.domain.finance.SyncState
import com.shift.app.feature.assets.data.AssetOperationFactory
import com.shift.app.feature.assets.data.AssetOperationRecords
import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import java.math.RoundingMode
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow


class AssetRepository @Inject constructor(
    private val db: MadarDatabase,
    private val assetDao: AssetDao,
    private val assetTransactionDao: AssetTransactionDao,
    private val assetValuationDao: AssetValuationDao,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val currencyLotDao: CurrencyAssetLotDao,
    private val currencyAllocationDao: CurrencyAssetSaleAllocationDao,
    private val changePublisher: FinancialChangePublisher,
) {
    fun assets(): Flow<List<Asset>> = assetDao.getAll()
    fun asset(id: String): Flow<Asset?> = assetDao.observeById(id)
    fun assetTransactions(): Flow<List<AssetTransaction>> = assetTransactionDao.getAll()
    fun assetTransactions(id: String): Flow<List<AssetTransaction>> = assetTransactionDao.getByAssetId(id)
    fun assetValuations(): Flow<List<AssetValuation>> = assetValuationDao.getAll()
    fun assetValuations(id: String): Flow<List<AssetValuation>> = assetValuationDao.getByAssetId(id)
    fun currencyLots(): Flow<List<CurrencyAssetLot>> = currencyLotDao.getAll()
    fun currencySaleAllocations(): Flow<List<CurrencyAssetSaleAllocation>> = currencyAllocationDao.getAll()

    suspend fun getAssetsOnce(): List<Asset> = assetDao.getAllOnce()
    suspend fun getAssetTransactionsOnce(): List<AssetTransaction> = assetTransactionDao.getAllOnce()
    suspend fun getAssetValuationsOnce(): List<AssetValuation> = assetValuationDao.getAllOnce()
    suspend fun getCurrencyLotsOnce(): List<CurrencyAssetLot> = currencyLotDao.getAllOnce()
    suspend fun getCurrencySaleAllocationsOnce(): List<CurrencyAssetSaleAllocation> = currencyAllocationDao.getAllOnce()
    suspend fun getAssetById(id: String): Asset? = assetDao.getById(id)

    suspend fun upsertAssets(items: List<Asset>) = assetDao.upsertAll(items)
    suspend fun upsertAssetTransactions(items: List<AssetTransaction>) = assetTransactionDao.upsertAll(items)
    suspend fun upsertAssetValuations(items: List<AssetValuation>) = assetValuationDao.upsertAll(items)
    suspend fun upsertCurrencyLots(items: List<CurrencyAssetLot>) = currencyLotDao.upsertAll(items)
    suspend fun upsertCurrencySaleAllocations(items: List<CurrencyAssetSaleAllocation>) = currencyAllocationDao.upsertAll(items)

    suspend fun deleteAllLocalData() = db.withTransaction {
        currencyAllocationDao.deleteAll()
        currencyLotDao.deleteAll()
        assetValuationDao.deleteAll()
        assetTransactionDao.deleteAll()
        assetDao.deleteAll()
    }

    suspend fun upsertAssetBackupBundle(
        assets: List<Asset>,
        assetTransactions: List<AssetTransaction>,
        assetValuations: List<AssetValuation>,
        currencyLots: List<CurrencyAssetLot>,
        currencySaleAllocations: List<CurrencyAssetSaleAllocation>
    ) = db.withTransaction {
        persist(
            AssetOperationRecords(
                assets = assets,
                assetTransactions = assetTransactions,
                assetValuations = assetValuations,
                currencyLots = currencyLots,
                currencySaleAllocations = currencySaleAllocations
            )
        )
        validateCurrencyInventory()
    }

    suspend fun addPreexistingAsset(request: PreexistingAssetRequest): AssetOperationRecords {
        require(request.type != FOREIGN_CURRENCY_ASSET_TYPE) {
            "Foreign currency must be created with quantity, rate, and a lot"
        }
        return insertNewOperation(AssetOperationFactory.preexisting(request))
    }

    suspend fun purchaseAsset(request: PurchaseAssetRequest): AssetOperationRecords {
        require(request.type != FOREIGN_CURRENCY_ASSET_TYPE) {
            "Use purchaseCurrencyAsset for foreign currency"
        }
        return insertNewOperation(AssetOperationFactory.purchase(request))
    }

    suspend fun purchaseCurrencyAsset(request: PurchaseCurrencyAssetRequest): AssetOperationRecords =
        insertNewOperation(AssetOperationFactory.purchaseCurrency(request))

    suspend fun addCurrencyLot(request: AddCurrencyLotRequest): AssetOperationRecords =
        db.withTransaction {
            val records = AssetOperationFactory.addCurrencyLot(requireActiveAsset(request.assetId), request)
            ensureSingleNewOperation(records)
            persist(records)
            records
        }

    suspend fun sellCurrencyAsset(request: CurrencyAssetSaleRequest): AssetOperationRecords =
        db.withTransaction {
            val asset = requireActiveAsset(request.assetId)
            require(asset.type == FOREIGN_CURRENCY_ASSET_TYPE) { "Asset is not a foreign currency asset" }
            val lots = currencyLotDao.getActiveByAssetId(asset.id)
            val allocations = currencyAllocationDao.getActiveByAssetId(asset.id)
            val plan = CurrencyAssetCalculator.allocateFifo(
                lots = lots.map(CurrencyAssetLot::toSnapshot),
                existingAllocations = allocations.map(CurrencyAssetSaleAllocation::toSnapshot),
                quantityToSellDecimal = request.quantityDecimal
            )
            val records = AssetOperationFactory.currencySale(asset, request, plan)
            ensureSingleNewOperation(records)
            persist(records)
            records
        }

    suspend fun availableCurrencyQuantity(assetId: String): String = db.withTransaction {
        CurrencyAssetCalculator.availableQuantity(
            currencyLotDao.getActiveByAssetId(assetId).map(CurrencyAssetLot::toSnapshot),
            currencyAllocationDao.getActiveByAssetId(assetId).map(CurrencyAssetSaleAllocation::toSnapshot)
        )
    }

    suspend fun recordAssetPayment(request: AssetPaymentRequest): AssetOperationRecords {
        val asset = requireActiveAsset(request.assetId)
        if (request.kind == PaymentKind.AssetImprovement) {
            require(asset.status == AssetStatus.Active.dbValue) { "Only an active asset can be improved" }
        } else {
            require(asset.status == AssetStatus.Active.dbValue) {
                "Only an active asset can be maintained"
            }
        }
        return insertNewOperation(AssetOperationFactory.paymentEvent(asset, request))
    }

    suspend fun valueAsset(request: AssetValuationRequest): AssetOperationRecords {
        val asset = requireActiveAsset(request.assetId)
        require(asset.status == AssetStatus.Active.dbValue) {
            "This asset cannot be valued in its current status"
        }
        return insertNewOperation(AssetOperationFactory.valuation(asset, request))
    }

    suspend fun sellAsset(request: AssetSaleRequest): AssetOperationRecords {
        val asset = requireActiveAsset(request.assetId)
        require(asset.type != FOREIGN_CURRENCY_ASSET_TYPE) {
            "Currency assets must be sold with quantity and FIFO allocations"
        }
        return insertNewOperation(AssetOperationFactory.sale(asset, request))
    }

    suspend fun updateAcquisition(
        assetId: String,
        name: String,
        type: String,
        amountDecimal: String
    ): AssetOperationRecords = db.withTransaction {
        val asset = requireActiveAsset(assetId)
        require(asset.type != FOREIGN_CURRENCY_ASSET_TYPE && type.trim() != FOREIGN_CURRENCY_ASSET_TYPE) {
            "Currency acquisition data is derived from lots"
        }
        val operationId = requireNotNull(asset.operationId).required("asset operationId")
        val amount = DecimalText.canonicalNonNegative(amountDecimal, DecimalTextScale.Money)
        if (asset.acquisitionMode == "purchased_in_app") {
            require(DecimalText.toBigDecimal(amount).signum() > 0) { "Purchase amount must be positive" }
        }
        val now = System.currentTimeMillis()
        val updatedAsset = asset.copy(
            name = name.trim().required("name"),
            type = type.trim().required("type"),
            acquisitionAmountDecimal = amount,
            updatedAt = now
        )
        val updatedEvents = assetTransactionDao.getActiveByOperationId(operationId).map {
            it.copy(amountDecimal = amount, updatedAt = now)
        }
        val updatedPayments = paymentDao.getActiveByOperationId(operationId).map {
            it.copy(amountDecimal = amount, assetNameSnapshot = updatedAsset.name, updatedAt = now)
        }
        val updatedBalances = balanceDao.getActiveByOperationId(operationId).map {
            it.copy(amountDecimal = amount, updatedAt = now)
        }
        val records = AssetOperationRecords(
            assets = listOf(updatedAsset),
            assetTransactions = updatedEvents,
            payments = updatedPayments,
            balanceTransactions = updatedBalances
        )
        persist(records)
        records
    }

    suspend fun updatePaymentEvent(
        operationId: String,
        amountDecimal: String,
        purpose: String,
        date: String,
        note: String
    ): AssetOperationRecords = db.withTransaction {
        val event = assetTransactionDao.getActiveByOperationId(operationId).singleOrNull()
            ?: error("Asset event not found")
        require(event.kind == AssetTransactionKind.Improvement.dbValue || event.kind == AssetTransactionKind.Maintenance.dbValue) {
            "Only improvement or maintenance can be edited here"
        }
        val asset = requireActiveAsset(event.assetId)
        val amount = DecimalText.canonicalPositive(amountDecimal, DecimalTextScale.Money)
        val purposeText = purpose.trim().required("purpose")
        val now = System.currentTimeMillis()
        val maintenance = event.kind == AssetTransactionKind.Maintenance.dbValue
        val payments = paymentDao.getActiveByOperationId(operationId).map {
            it.copy(
                amountDecimal = amount,
                date = date.required("date"),
                purpose = purposeText,
                purposeKey = purposeText.lowercase(),
                beneficiaryId = asset.id.takeIf { maintenance },
                beneficiaryNameSnapshot = asset.name.takeIf { maintenance }.orEmpty(),
                assetId = asset.id,
                assetNameSnapshot = asset.name,
                note = note,
                updatedAt = now
            )
        }
        val balances = balanceDao.getActiveByOperationId(operationId).map {
            it.copy(amountDecimal = amount, date = date, note = note, updatedAt = now)
        }
        val events = listOf(event.copy(amountDecimal = amount, date = date, note = note.ifBlank { purposeText }, updatedAt = now))
        val records = AssetOperationRecords(assetTransactions = events, payments = payments, balanceTransactions = balances)
        persist(records)
        records
    }

    suspend fun updateValuation(
        operationId: String,
        valueDecimal: String,
        date: String,
        note: String
    ): AssetOperationRecords = db.withTransaction {
        val now = System.currentTimeMillis()
        val valuations = assetValuationDao.getActiveByOperationId(operationId).map {
            it.copy(
                valueDecimal = DecimalText.canonicalNonNegative(valueDecimal, DecimalTextScale.Money),
                date = date.required("date"),
                note = note,
                updatedAt = now
            )
        }
        require(valuations.isNotEmpty()) { "Valuation not found" }
        val records = AssetOperationRecords(assetValuations = valuations)
        persist(records)
        records
    }

    suspend fun updateSale(
        operationId: String,
        amountDecimal: String,
        date: String,
        note: String
    ): AssetOperationRecords = db.withTransaction {
        val event = assetTransactionDao.getActiveByOperationId(operationId).singleOrNull()
            ?: error("Sale not found")
        require(event.kind == AssetTransactionKind.SaleFull.dbValue) { "Operation is not a full sale" }
        require(requireActiveAsset(event.assetId).type != FOREIGN_CURRENCY_ASSET_TYPE) {
            "Currency sales must be rebuilt from quantity and FIFO allocations"
        }
        require(currencyAllocationDao.getActiveByOperationId(operationId).isEmpty()) {
            "Currency sales must be rebuilt from quantity and FIFO allocations"
        }
        val amount = DecimalText.canonicalPositive(amountDecimal, DecimalTextScale.Money)
        val now = System.currentTimeMillis()
        val events = listOf(event.copy(amountDecimal = amount, date = date.required("date"), note = note, updatedAt = now))
        val balances = balanceDao.getActiveByOperationId(operationId).map {
            it.copy(amountDecimal = amount, date = date, note = note, updatedAt = now)
        }
        require(balances.isNotEmpty()) { "Sale balance entry not found" }
        val records = AssetOperationRecords(assetTransactions = events, balanceTransactions = balances)
        persist(records)
        records
    }

    suspend fun softDeleteOperation(operationId: String): AssetOperationRecords = db.withTransaction {
        val events = assetTransactionDao.getActiveByOperationId(operationId)
        require(events.isNotEmpty()) { "Asset operation not found" }
        require(events.none {
            it.kind == AssetTransactionKind.SaleFull.dbValue || it.kind == AssetTransactionKind.SalePartial.dbValue
        }) {
            "Use undoSale for asset sales"
        }
        val eventAsset = requireActiveAsset(events.first().assetId)
        val creation = events.firstOrNull {
            eventAsset.operationId == operationId &&
                (it.kind == AssetTransactionKind.Purchase.dbValue || it.kind == AssetTransactionKind.PreexistingAdd.dbValue)
        }
        val currencyLots = currencyLotDao.getActiveByOperationId(operationId)
        val lotIds = currencyLots.map { it.id }.toSet()
        val dependentAllocations = if (lotIds.isEmpty()) emptyList() else {
            currencyAllocationDao.getActiveByAssetId(eventAsset.id).filter { it.lotId in lotIds }
        }
        require(dependentAllocations.isEmpty()) { "A purchased currency lot has sale allocations and cannot be deleted" }
        val now = System.currentTimeMillis()
        val assets = if (creation != null) {
            val asset = eventAsset
            val laterEvents = assetTransactionDao.getActiveByAssetIdOnce(asset.id).filter { it.operationId != operationId }
            val laterValuations = assetValuationDao.getActiveByAssetIdOnce(asset.id).filter { it.operationId != operationId }
            val laterLots = currencyLotDao.getActiveByAssetId(asset.id).filter { it.operationId != operationId }
            val laterAllocations = currencyAllocationDao.getActiveByAssetId(asset.id).filter { it.operationId != operationId }
            require(laterEvents.isEmpty() && laterValuations.isEmpty() && laterLots.isEmpty() && laterAllocations.isEmpty()) {
                "Asset has history; archive it instead of deleting it"
            }
            listOf(asset.copy(updatedAt = now, deletedAt = now))
        } else {
            emptyList()
        }
        val records = AssetOperationRecords(
            assets = assets,
            assetTransactions = events.map { it.copy(updatedAt = now, deletedAt = now) },
            assetValuations = assetValuationDao.getActiveByOperationId(operationId).map { it.copy(updatedAt = now, deletedAt = now) },
            payments = paymentDao.getActiveByOperationId(operationId).map { it.copy(updatedAt = now, deletedAt = now) },
            balanceTransactions = balanceDao.getActiveByOperationId(operationId).map { it.copy(updatedAt = now, deletedAt = now) },
            currencyLots = currencyLots.map { it.copy(updatedAt = now, deletedAt = now) },
            currencySaleAllocations = currencyAllocationDao.getActiveByOperationId(operationId).map {
                it.copy(updatedAt = now, deletedAt = now)
            }
        )
        persist(records)
        records
    }

    suspend fun softDeleteValuation(operationId: String): AssetOperationRecords = db.withTransaction {
        val now = System.currentTimeMillis()
        val valuations = assetValuationDao.getActiveByOperationId(operationId).map {
            it.copy(updatedAt = now, deletedAt = now)
        }
        require(valuations.isNotEmpty()) { "Valuation not found" }
        val records = AssetOperationRecords(assetValuations = valuations)
        persist(records)
        records
    }

    suspend fun undoSale(operationId: String): AssetOperationRecords = db.withTransaction {
        val sale = assetTransactionDao.getActiveByOperationId(operationId).singleOrNull()
            ?: error("Sale not found")
        require(
            sale.kind == AssetTransactionKind.SaleFull.dbValue ||
                sale.kind == AssetTransactionKind.SalePartial.dbValue
        ) { "Operation is not an asset sale" }
        val asset = requireActiveAsset(sale.assetId)
        val saleBalances = balanceDao.getActiveByOperationId(operationId)
        val saleAllocations = currencyAllocationDao.getActiveByOperationId(operationId)
        if (asset.type == FOREIGN_CURRENCY_ASSET_TYPE) {
            require(saleAllocations.isNotEmpty()) { "Currency sale allocations are missing" }
        } else {
            require(saleAllocations.isEmpty()) { "Unexpected currency allocations for this asset" }
        }
        val now = System.currentTimeMillis()
        val wasSynced = sale.syncState == SyncState.Synced.dbValue ||
            saleBalances.any { it.syncState == SyncState.Synced.dbValue } ||
            saleAllocations.any { it.syncState == SyncState.Synced.dbValue }
        val records = if (!wasSynced) {
            AssetOperationRecords(
                assets = listOf(asset.copy(status = AssetStatus.Active.dbValue, updatedAt = now)),
                assetTransactions = listOf(sale.copy(updatedAt = now, deletedAt = now)),
                balanceTransactions = saleBalances.map { it.copy(updatedAt = now, deletedAt = now) },
                currencySaleAllocations = saleAllocations.map { it.copy(updatedAt = now, deletedAt = now) }
            )
        } else {
            val reversalOperationId = UUID.randomUUID().toString()
            val reverseBalance = BalanceTransaction(
                operationId = reversalOperationId,
                direction = BalanceDirection.Outflow.dbValue,
                kind = BalanceTransactionKind.AssetSale.dbValue,
                amountDecimal = requireNotNull(sale.amountDecimal).required("sale amount"),
                date = sale.date,
                note = "عكس بيع: ${sale.note}".trim(),
                sourceType = "asset_sale_reversal",
                sourceId = asset.id,
                createdAt = now,
                updatedAt = now
            )
            val reversal = AssetTransaction(
                operationId = reversalOperationId,
                assetId = asset.id,
                kind = AssetTransactionKind.Reversal.dbValue,
                amountDecimal = sale.amountDecimal,
                balanceTransactionId = reverseBalance.id,
                date = sale.date,
                note = "عكس عملية البيع $operationId",
                createdAt = now,
                updatedAt = now
            )
            AssetOperationRecords(
                assets = listOf(asset.copy(status = AssetStatus.Active.dbValue, updatedAt = now)),
                assetTransactions = listOf(reversal),
                balanceTransactions = listOf(reverseBalance),
                currencySaleAllocations = saleAllocations.map { it.copy(updatedAt = now, deletedAt = now) }
            )
        }
        persist(records)
        records
    }

    private suspend fun insertNewOperation(records: AssetOperationRecords): AssetOperationRecords = db.withTransaction {
        ensureSingleNewOperation(records)
        persist(records)
        records
    }

    private suspend fun ensureSingleNewOperation(records: AssetOperationRecords) {
        val newAssetOperationIds = records.assets
            .filter { assetDao.getById(it.id) == null }
            .mapNotNull { it.operationId }
        val operationIds = (records.assetTransactions.map { it.operationId } +
            records.assetValuations.map { it.operationId } +
            records.payments.map { it.operationId } +
            records.balanceTransactions.map { it.operationId } +
            records.currencyLots.map { it.operationId } +
            records.currencySaleAllocations.map { it.operationId } +
            newAssetOperationIds)
            .toSet()
        require(operationIds.size == 1) { "A new composite operation must have one operationId" }
        ensureOperationDoesNotExist(operationIds.single())
    }

    private suspend fun persist(records: AssetOperationRecords) {
        records.balanceTransactions.forEach { item ->
            if (balanceDao.getById(item.id) == null) balanceDao.insert(item) else balanceDao.update(item)
        }
        records.assets.forEach { item ->
            if (assetDao.getById(item.id) == null) assetDao.insert(item) else assetDao.update(item)
        }
        records.payments.forEach { item ->
            if (paymentDao.getById(item.id) == null) paymentDao.insert(item) else paymentDao.update(item)
        }
        records.assetTransactions.forEach { item ->
            if (assetTransactionDao.getById(item.id) == null) assetTransactionDao.insert(item) else assetTransactionDao.update(item)
        }
        records.assetValuations.forEach { item ->
            if (assetValuationDao.getById(item.id) == null) assetValuationDao.insert(item) else assetValuationDao.update(item)
        }
        records.currencyLots.forEach { item ->
            if (currencyLotDao.getById(item.id) == null) currencyLotDao.insert(item) else currencyLotDao.update(item)
        }
        records.currencySaleAllocations.forEach { item ->
            if (currencyAllocationDao.getById(item.id) == null) {
                currencyAllocationDao.insert(item)
            } else {
                currencyAllocationDao.update(item)
            }
        }
        publishChanges(records)
    }

    private suspend fun publishChanges(records: AssetOperationRecords) {
        val operationIds = (
            records.assets.mapNotNull { it.operationId } +
                records.assetTransactions.map { it.operationId } +
                records.assetValuations.map { it.operationId } +
                records.payments.map { it.operationId } +
                records.balanceTransactions.map { it.operationId } +
                records.currencyLots.map { it.operationId } +
                records.currencySaleAllocations.map { it.operationId }
            ).distinct()
        operationIds.forEach { operationId ->
            val event = records.assetTransactions.firstOrNull { it.operationId == operationId }
            val valuation = records.assetValuations.firstOrNull { it.operationId == operationId }
            val balance = records.balanceTransactions.firstOrNull { it.operationId == operationId }
            val lot = records.currencyLots.firstOrNull { it.operationId == operationId }
            val asset = records.assets.firstOrNull { it.operationId == operationId }
                ?: event?.assetId?.let { id -> records.assets.firstOrNull { it.id == id } }
            val updatedAt = listOfNotNull(
                asset?.updatedAt,
                event?.updatedAt,
                valuation?.updatedAt,
                balance?.updatedAt,
                lot?.updatedAt,
            ).maxOrNull() ?: System.currentTimeMillis()
            changePublisher.publish(
                sourceType = "assets",
                sourceId = asset?.id ?: event?.assetId ?: valuation?.assetId ?: operationId,
                operationId = "asset:$operationId:$updatedAt",
                effectiveDate = event?.date ?: valuation?.date ?: balance?.date ?: lot?.purchaseDate
                    ?: LocalDate.ofEpochDay(updatedAt / 86_400_000L).toString(),
                changedFields = "asset,transaction,valuation,payment,balance,deletedAt",
                createdAt = updatedAt,
            )
        }
    }

    private suspend fun ensureOperationDoesNotExist(operationId: String) {
        require(assetDao.getByOperationId(operationId).isEmpty()) { "Asset operation already exists" }
        require(assetTransactionDao.getByOperationId(operationId).isEmpty()) { "Asset event operation already exists" }
        require(assetValuationDao.getByOperationId(operationId).isEmpty()) { "Valuation operation already exists" }
        require(paymentDao.getByOperationId(operationId).isEmpty()) { "Payment operation already exists" }
        require(balanceDao.getByOperationId(operationId).isEmpty()) { "Balance operation already exists" }
        require(currencyLotDao.getByOperationId(operationId).isEmpty()) { "Currency lot operation already exists" }
        require(currencyAllocationDao.getByOperationId(operationId).isEmpty()) {
            "Currency sale allocation operation already exists"
        }
    }

    private suspend fun validateCurrencyInventory() {
        val activeLots = currencyLotDao.getAllOnce().filter { it.deletedAt == null }
        val activeAllocations = currencyAllocationDao.getAllOnce().filter { it.deletedAt == null }
        val lotsById = activeLots.associateBy { it.id }
        val activeCurrencyAssets = assetDao.getAllOnce()
            .filter { it.deletedAt == null && it.type == FOREIGN_CURRENCY_ASSET_TYPE }
        val currencyAssetsById = activeCurrencyAssets.associateBy { it.id }
        activeLots.forEach { lot ->
            require(lot.assetId in currencyAssetsById) { "Currency lot references a missing or non-currency asset" }
        }
        activeAllocations.forEach { allocation ->
            val lot = lotsById[allocation.lotId]
            require(lot != null && lot.assetId == allocation.assetId) {
                "Currency allocation references a missing lot or a different asset"
            }
        }
        activeCurrencyAssets.forEach { asset ->
                val assetCode = asset.currencyCode.currencyCode()
                val lots = activeLots.filter { it.assetId == asset.id }
                require(lots.isNotEmpty()) { "Foreign currency asset has no lots" }
                lots.forEach { lot ->
                    require(lot.foreignCurrencyCode.currencyCode() == assetCode) {
                        "Currency lot code does not match its asset"
                    }
                    require(
                        DecimalText.canonicalPositive(
                            lot.quantityPurchasedDecimal,
                            DecimalTextScale.Quantity
                        ) == lot.quantityPurchasedDecimal &&
                            DecimalText.canonicalPositive(
                                lot.purchaseExchangeRateDecimal,
                                DecimalTextScale.ExchangeRate
                            ) == lot.purchaseExchangeRateDecimal &&
                            DecimalText.canonicalPositive(
                                lot.localCostDecimal,
                                DecimalTextScale.Money
                            ) == lot.localCostDecimal
                    ) { "Currency lot contains non-canonical decimal values" }
                }
                activeAllocations.filter { it.assetId == asset.id }.forEach { allocation ->
                    require(
                        DecimalText.canonicalPositive(
                            allocation.quantitySoldDecimal,
                            DecimalTextScale.Quantity
                        ) == allocation.quantitySoldDecimal &&
                            DecimalText.canonicalNonNegative(
                                allocation.allocatedLocalCostDecimal,
                                DecimalTextScale.Money
                            ) == allocation.allocatedLocalCostDecimal
                    ) { "Currency allocation contains non-canonical decimal values" }
                }
                CurrencyAssetCalculator.lotBalances(
                    lots.map { it.toSnapshot() },
                    activeAllocations.filter { it.assetId == asset.id }.map { it.toSnapshot() }
                )
            }
    }

    private suspend fun requireActiveAsset(id: String): Asset =
        requireNotNull(assetDao.getById(id)) { "Asset not found" }
            .also { require(it.deletedAt == null) { "Asset is deleted" } }
}

const val FOREIGN_CURRENCY_ASSET_TYPE = "foreign_currency"

private fun CurrencyAssetLot.toSnapshot() = CurrencyLotSnapshot(
    id = id,
    quantityPurchasedDecimal = quantityPurchasedDecimal,
    localCostDecimal = localCostDecimal,
    purchaseDate = purchaseDate,
    createdAt = createdAt,
    deletedAt = deletedAt
)

private fun CurrencyAssetSaleAllocation.toSnapshot() = CurrencyAllocationSnapshot(
    lotId = lotId,
    quantitySoldDecimal = quantitySoldDecimal,
    allocatedLocalCostDecimal = allocatedLocalCostDecimal,
    deletedAt = deletedAt
)

private fun String.currencyCode(): String {
    val code = trim().uppercase().required("foreignCurrencyCode")
    require(code.matches(Regex("[A-Z]{3}"))) { "Currency code must contain exactly three Latin letters" }
    require(code != "SDG") { "Foreign currency code cannot be the local SDG currency" }
    return code
}

private fun String.isoDate(): String = LocalDate.parse(trim().required("date")).toString()

private fun String.required(field: String): String {
    require(isNotBlank()) { "$field must not be blank" }
    return this
}

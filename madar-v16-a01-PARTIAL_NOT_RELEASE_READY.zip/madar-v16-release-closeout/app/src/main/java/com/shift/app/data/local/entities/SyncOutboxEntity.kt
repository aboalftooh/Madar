package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Durable wake-up queue for synchronization.
 *
 * Business data remains in its owning Room table. This row only records that a
 * local operation still needs a complete, idempotent synchronization cycle.
 */
@Entity(
    tableName = "sync_outbox",
    indices = [
        Index(value = ["state", "nextAttemptAt", "createdAt"]),
        Index(value = ["operationId"]),
    ],
)
data class SyncOutboxEntity(
    @PrimaryKey val eventId: String,
    val entityType: String,
    val entityId: String,
    val operationId: String,
    val createdAt: Long,
    val updatedAt: Long,
    val state: String = SyncOutboxState.Pending.dbValue,
    val attemptCount: Int = 0,
    val nextAttemptAt: Long = createdAt,
    val lastError: String? = null,
    val revision: Long = 1L,
) {
    init {
        require(eventId.isNotBlank())
        require(entityType.isNotBlank())
        require(entityId.isNotBlank())
        require(operationId.isNotBlank())
        require(attemptCount >= 0)
        require(revision >= 0L)
    }
}

enum class SyncOutboxState(val dbValue: String) {
    Pending("pending"),
    Failed("failed"),
}

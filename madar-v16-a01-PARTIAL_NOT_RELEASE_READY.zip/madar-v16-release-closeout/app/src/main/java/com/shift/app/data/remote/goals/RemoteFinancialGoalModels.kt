package com.shift.app.data.remote.goals

import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteFinancialGoal(
    val id: String,
    @SerialName("user_id") val userId: String,
    val name: String,
    val type: GoalType,
    @SerialName("lifecycle_status") val lifecycleStatus: GoalLifecycleStatus,
    @SerialName("health_status") val healthStatus: GoalHealthStatus,
    @SerialName("currency_code") val currencyCode: String,
    @SerialName("start_date") val startDate: String,
    val deadline: String,
    @SerialName("timezone_id") val timezoneId: String,
    @SerialName("target_decimal") val targetDecimal: String,
    @SerialName("baseline_decimal") val baselineDecimal: String? = null,
    @SerialName("target_percent_decimal") val targetPercentDecimal: String? = null,
    @SerialName("confirmation_periods") val confirmationPeriods: Int,
    @SerialName("cost_threshold") val costThreshold: CostThreshold? = null,
    @SerialName("config_json") val configJson: String,
    val revision: Long,
    @SerialName("ready_at") val readyAt: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    @SerialName("cancelled_at") val cancelledAt: String? = null,
    @SerialName("archived_at") val archivedAt: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalMetric(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("metric_type") val metricType: MetricType,
    @SerialName("window_type") val windowType: String,
    @SerialName("window_size") val windowSize: Int,
    @SerialName("baseline_decimal") val baselineDecimal: String? = null,
    @SerialName("config_json") val configJson: String,
    val ordinal: Int,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalCondition(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("metric_id") val metricId: String? = null,
    val kind: ConditionKind,
    val operator: String,
    @SerialName("value_decimal") val valueDecimal: String? = null,
    val required: Boolean,
    @SerialName("config_json") val configJson: String,
    val ordinal: Int,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalScope(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    val dimension: ScopeDimension,
    @SerialName("reference_id") val referenceId: String,
    val mode: String,
    val reason: String,
    @SerialName("effective_from") val effectiveFrom: String,
    @SerialName("effective_to") val effectiveTo: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalFundingTransaction(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("operation_id") val operationId: String,
    val kind: FundingKind,
    @SerialName("amount_decimal") val amountDecimal: String,
    @SerialName("currency_code") val currencyCode: String,
    @SerialName("balance_transaction_id") val balanceTransactionId: String? = null,
    @SerialName("related_funding_transaction_id") val relatedFundingTransactionId: String? = null,
    val note: String,
    @SerialName("occurred_at") val occurredAt: String,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalCostEstimate(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("operation_id") val operationId: String,
    @SerialName("min_decimal") val minDecimal: String? = null,
    @SerialName("expected_decimal") val expectedDecimal: String,
    @SerialName("safe_decimal") val safeDecimal: String,
    @SerialName("currency_code") val currencyCode: String,
    val source: String,
    val note: String,
    @SerialName("effective_at") val effectiveAt: String,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalEvaluation(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("as_of") val asOf: String,
    @SerialName("engine_version") val engineVersion: String,
    @SerialName("input_fingerprint") val inputFingerprint: String,
    @SerialName("lifecycle_status") val lifecycleStatus: GoalLifecycleStatus,
    @SerialName("health_status") val healthStatus: GoalHealthStatus,
    @SerialName("measured_decimal") val measuredDecimal: String? = null,
    @SerialName("target_decimal") val targetDecimal: String? = null,
    @SerialName("progress_decimal") val progressDecimal: String? = null,
    @SerialName("result_json") val resultJson: String,
    @SerialName("correction_of_id") val correctionOfId: String? = null,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class RemoteGoalActivity(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("goal_id") val goalId: String,
    @SerialName("operation_id") val operationId: String,
    val type: String,
    @SerialName("occurred_at") val occurredAt: String,
    @SerialName("effective_date") val effectiveDate: String? = null,
    @SerialName("details_json") val detailsJson: String,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("deleted_at") val deletedAt: String? = null
)

@Serializable
data class FinancialGoalSyncBundle(
    @SerialName("operation_id") val operationId: String,
    @SerialName("expected_revision") val expectedRevision: Long? = null,
    val goals: List<RemoteFinancialGoal> = emptyList(),
    val metrics: List<RemoteGoalMetric> = emptyList(),
    val conditions: List<RemoteGoalCondition> = emptyList(),
    val scopes: List<RemoteGoalScope> = emptyList(),
    @SerialName("funding_transactions") val fundingTransactions: List<RemoteGoalFundingTransaction> = emptyList(),
    @SerialName("cost_estimates") val costEstimates: List<RemoteGoalCostEstimate> = emptyList(),
    val evaluations: List<RemoteGoalEvaluation> = emptyList(),
    val activities: List<RemoteGoalActivity> = emptyList()
) {
    val isComplete: Boolean
        get() {
            val goalIds = goals.map { it.id }.toSet()
            val metricIds = metrics.map { it.id }.toSet()
            val fundingIds = fundingTransactions.map { it.id }.toSet()
            val evaluationIds = evaluations.map { it.id }.toSet()
            val users = (
                goals.map { it.userId } + metrics.map { it.userId } + conditions.map { it.userId } +
                    scopes.map { it.userId } + fundingTransactions.map { it.userId } +
                    costEstimates.map { it.userId } + evaluations.map { it.userId } + activities.map { it.userId }
                ).toSet()
            return operationId.isNotBlank() && users.size <= 1 &&
                metrics.all { it.goalId in goalIds } &&
                conditions.all { it.goalId in goalIds && (it.metricId == null || it.metricId in metricIds) } &&
                scopes.all { it.goalId in goalIds } &&
                fundingTransactions.all {
                    it.goalId in goalIds &&
                        (it.relatedFundingTransactionId == null || it.relatedFundingTransactionId in fundingIds)
                } &&
                costEstimates.all { it.goalId in goalIds } &&
                evaluations.all { it.goalId in goalIds && (it.correctionOfId == null || it.correctionOfId in evaluationIds) } &&
                activities.all { it.goalId in goalIds }
        }

    val incompleteReason: String?
        get() = if (isComplete) null else "IncompleteRemote financial goal bundle: ownership, operation, or FK dependency mismatch"
}

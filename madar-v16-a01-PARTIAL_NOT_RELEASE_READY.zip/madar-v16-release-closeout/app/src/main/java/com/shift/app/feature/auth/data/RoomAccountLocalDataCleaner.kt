package com.shift.app.feature.auth.data

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.repository.AssetRepository
import com.shift.app.data.repository.DebtRepository
import com.shift.app.data.repository.ExpenseBeneficiaryRepository
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.IncomeSourceRepository
import com.shift.app.data.repository.LegacyHistoryMigrationRepository
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.feature.auth.domain.AccountLocalDataCleaner
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RoomAccountLocalDataCleaner @Inject constructor(
    private val database: MadarDatabase,
    private val transactionRepository: TransactionRepository,
    private val incomeSourceRepository: IncomeSourceRepository,
    private val expenseBeneficiaryRepository: ExpenseBeneficiaryRepository,
    private val debtRepository: DebtRepository,
    private val financialLedgerRepository: FinancialLedgerRepository,
    private val legacyHistoryMigrationRepository: LegacyHistoryMigrationRepository,
    private val assetRepository: AssetRepository,
) : AccountLocalDataCleaner {
    override suspend fun clearAccountData() {
        database.withTransaction {
            database.debtLinkDao().deleteAll()
            database.debtScheduleDao().deleteAll()
            database.debtTransactionDao().deleteAll()
            database.debtMigrationReviewDao().deleteAll()
            database.debtAccountDao().deleteAll()
            database.goalActivityDao().deleteAll()
            database.goalEvaluationDao().deleteAll()
            database.goalCostEstimateDao().deleteAll()
            database.goalFundingTransactionDao().deleteAll()
            database.goalScopeDao().deleteAll()
            database.goalConditionDao().deleteAll()
            database.goalMetricDao().deleteAll()
            database.financialGoalDao().deleteAll()
            database.financialChangeOutboxDao().deleteAll()
            database.syncOutboxDao().deleteAll()
            assetRepository.deleteAllLocalData()
            legacyHistoryMigrationRepository.deleteAllLocalData()
            financialLedgerRepository.deleteAllLocalData()
            transactionRepository.deleteAll()
            incomeSourceRepository.deleteAll()
            expenseBeneficiaryRepository.deleteAll()
            debtRepository.deleteAll()
        }
    }
}

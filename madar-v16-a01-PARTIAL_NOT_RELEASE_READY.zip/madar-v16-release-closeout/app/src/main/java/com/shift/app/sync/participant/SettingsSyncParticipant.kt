package com.shift.app.sync.participant

import com.shift.app.sync.remote.SettingsRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import com.shift.app.utils.PreferencesManager
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

@Singleton
class SettingsSyncParticipant @Inject constructor(
    private val preferences: PreferencesManager,
    private val remote: SettingsRemoteSync,
) : SyncParticipant {
    override val key: String = "settings"
    override val order: Int = 60

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_settings", SyncCheckpointKey.Settings) { remote.pullSettings() },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> = buildList {
        if (preferences.settingsUpdatedAt.first() > lastSuccessfulSync) {
            add(SyncOperation("push_settings") { remote.pushSettings() })
        }
    }
}

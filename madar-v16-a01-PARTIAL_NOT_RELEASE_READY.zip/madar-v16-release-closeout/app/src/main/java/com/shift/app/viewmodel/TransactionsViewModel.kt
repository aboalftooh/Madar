package com.shift.app.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.remote.SyncManager
import com.shift.app.data.repository.ExpenseBeneficiaryRepository
import com.shift.app.data.repository.FinancialGoalRepository
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.IncomeSourceRepository
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.domain.goals.funding.ActiveGoalAllocation
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.utils.ErrorMessages
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import io.sentry.Sentry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ExpenseAllocationDecision(
    val shortfallDecimal: String,
    val availableBeforeDecimal: String,
    val availableAfterWithoutReleaseDecimal: String,
    val allocations: List<ActiveGoalAllocation>,
)

private data class PendingExpense(
    val transaction: Transaction,
    val impact: com.shift.app.domain.goals.funding.AvailableSpendingImpact,
    val onComplete: () -> Unit,
)

@HiltViewModel
class TransactionsViewModel @Inject constructor(
    private val transactionRepository: TransactionRepository,
    private val incomeSourceRepository: IncomeSourceRepository,
    private val expenseBeneficiaryRepository: ExpenseBeneficiaryRepository,
    private val financialLedgerRepository: FinancialLedgerRepository,
    private val financialGoalRepository: FinancialGoalRepository,
    private val database: MadarDatabase,
    private val preferences: PreferencesManager,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : ViewModel() {
    val transactions = transactionRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val balanceTransactions = financialLedgerRepository.balanceTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val payments = financialLedgerRepository.payments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val migratedLegacyExpenseIds = financialLedgerRepository.migratedLegacyTransactionIds()
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())
    val incomeSources = incomeSourceRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val paymentMethodSuggestions = incomeSourceRepository.paymentMethodSuggestions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val expenseBeneficiaries = expenseBeneficiaryRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val expensePurposeSuggestions = transactionRepository.expensePurposeSuggestions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val budgetLimit = preferences.budgetLimit
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 5_000f)

    private val _expenseAllocationDecision = MutableStateFlow<ExpenseAllocationDecision?>(null)
    val expenseAllocationDecision = _expenseAllocationDecision.asStateFlow()
    private var pendingExpense: PendingExpense? = null

    private fun queueBackgroundSync(reason: String = "transactions-viewmodel") = viewModelScope.launch {
        runCatching { syncQueue.requestSync(reason) }
            .onFailure { error ->
                Log.e("TransactionsViewModel", "Failed to enqueue durable sync", error)
                Sentry.captureException(error)
            }
    }

    private fun sessionMutation(block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { syncManager.executeSessionOperation(block) }
            .onFailure { error ->
                Log.e("TransactionsViewModel", "Session mutation failed", error)
                Sentry.captureException(error)
                ErrorMessages.userMessage(error)
            }
    }

    fun updateTransaction(transaction: Transaction) = sessionMutation {
        transactionRepository.updateWithLinkedIncome(
            transaction.copy(updatedAt = System.currentTimeMillis(), deletedAt = null),
        )
        queueBackgroundSync()
    }

    fun deleteTransaction(id: String) = sessionMutation {
        if (transactionRepository.getById(id) == null) return@sessionMutation
        transactionRepository.softDeleteWithLinkedIncome(id, System.currentTimeMillis())
        queueBackgroundSync()
    }

    fun addIncomeSource(source: IncomeSource) = sessionMutation {
        incomeSourceRepository.insert(source)
        queueBackgroundSync()
    }

    fun addIncomeSourceIfMissing(
        name: String,
        paymentMethod: String = "",
        onReady: (IncomeSource) -> Unit,
    ) = sessionMutation {
        val normalizedName = normalizeIncomeSourceName(name)
        if (normalizedName.isBlank()) return@sessionMutation

        val existing = incomeSourceRepository.getActiveOnce().firstOrNull {
            normalizeIncomeSourceName(it.name).lowercase() == normalizedName.lowercase()
        }
        if (existing != null) {
            onReady(existing)
            return@sessionMutation
        }

        val source = IncomeSource(name = normalizedName, paymentMethod = paymentMethod)
        incomeSourceRepository.insert(source)
        queueBackgroundSync()
        onReady(source)
    }

    fun addIncomeTransactionWithSource(
        transaction: Transaction,
        sourceName: String,
        onComplete: () -> Unit = {},
    ) = sessionMutation {
        val normalizedName = normalizeIncomeSourceName(sourceName)
        if (normalizedName.isBlank()) return@sessionMutation

        val existing = incomeSourceRepository.getActiveOnce().firstOrNull {
            normalizeIncomeSourceName(it.name).lowercase() == normalizedName.lowercase()
        }
        val source = existing ?: IncomeSource(name = normalizedName, paymentMethod = "").also {
            incomeSourceRepository.insert(it)
            queueBackgroundSync()
        }
        transactionRepository.insertNew(
            transaction.copy(
                type = "income",
                category = source.name,
                group = "",
                incomeSourceId = source.id,
                incomeSourceNameSnapshot = source.name,
                paymentMethodSnapshot = source.paymentMethod,
            ),
            linkIncomeToBalance = preferences.balanceActivated.first(),
        )
        queueBackgroundSync()
        onComplete()
    }

    fun updateIncomeSource(source: IncomeSource) = sessionMutation {
        incomeSourceRepository.update(
            source.copy(updatedAt = System.currentTimeMillis(), deletedAt = null),
        )
        queueBackgroundSync()
    }

    fun deleteIncomeSource(id: String) = sessionMutation {
        val now = System.currentTimeMillis()
        val deleted = incomeSourceRepository.getById(id)?.copy(updatedAt = now, deletedAt = now)
            ?: return@sessionMutation
        incomeSourceRepository.update(deleted)
        queueBackgroundSync()
    }

    fun addExpenseBeneficiary(beneficiary: ExpenseBeneficiary) = sessionMutation {
        val normalized = ExpenseTextNormalizer.displayText(beneficiary.name)
        if (normalized.isBlank()) return@sessionMutation
        expenseBeneficiaryRepository.insert(
            beneficiary.copy(
                name = normalized,
                updatedAt = System.currentTimeMillis(),
                deletedAt = null,
            ),
        )
        queueBackgroundSync()
    }

    fun updateExpenseBeneficiary(beneficiary: ExpenseBeneficiary) = sessionMutation {
        val normalized = ExpenseTextNormalizer.displayText(beneficiary.name)
        if (normalized.isBlank()) return@sessionMutation
        expenseBeneficiaryRepository.update(
            beneficiary.copy(
                name = normalized,
                updatedAt = System.currentTimeMillis(),
                deletedAt = null,
            ),
        )
        queueBackgroundSync()
    }

    fun deleteExpenseBeneficiary(id: String) = sessionMutation {
        val now = System.currentTimeMillis()
        val deleted = expenseBeneficiaryRepository.getById(id)?.copy(updatedAt = now, deletedAt = now)
            ?: return@sessionMutation
        expenseBeneficiaryRepository.update(deleted)
        queueBackgroundSync()
    }

    fun addExpenseBeneficiaryIfMissing(
        name: String,
        onReady: (ExpenseBeneficiary) -> Unit,
    ) = sessionMutation {
        val displayName = ExpenseTextNormalizer.displayText(name)
        if (displayName.isBlank()) return@sessionMutation

        val key = ExpenseTextNormalizer.key(displayName)
        val existing = expenseBeneficiaryRepository.getActiveOnce().firstOrNull {
            ExpenseTextNormalizer.key(it.name) == key
        }
        if (existing != null) {
            onReady(existing)
            return@sessionMutation
        }

        val beneficiary = ExpenseBeneficiary(name = displayName)
        expenseBeneficiaryRepository.insert(beneficiary)
        queueBackgroundSync()
        onReady(beneficiary)
    }

    fun addExpenseTransactionWithBeneficiary(
        transaction: Transaction,
        beneficiaryName: String,
        purposeInput: String,
        onComplete: () -> Unit = {},
    ) = sessionMutation {
        val displayPurpose = ExpenseTextNormalizer.displayText(purposeInput)
        val displayBeneficiaryName = ExpenseTextNormalizer.displayText(beneficiaryName)
        val beneficiary = if (displayBeneficiaryName.isBlank()) {
            null
        } else {
            val beneficiaryKey = ExpenseTextNormalizer.key(displayBeneficiaryName)
            expenseBeneficiaryRepository.getActiveOnce().firstOrNull {
                ExpenseTextNormalizer.key(it.name) == beneficiaryKey
            } ?: ExpenseBeneficiary(name = displayBeneficiaryName).also {
                expenseBeneficiaryRepository.insert(it)
                queueBackgroundSync()
            }
        }

        val expenseTransaction = transaction.copy(
            type = "expense",
            purpose = displayPurpose,
            purposeKey = ExpenseTextNormalizer.key(displayPurpose),
            category = displayPurpose,
            group = "",
            expenseBeneficiaryId = beneficiary?.id,
            expenseBeneficiaryNameSnapshot = beneficiary?.name.orEmpty(),
            incomeSourceId = null,
            incomeSourceNameSnapshot = "",
            paymentMethodSnapshot = "",
        )
        if (preferences.balanceActivated.first()) {
            val impact = financialGoalRepository.spendingImpact(
                com.shift.app.domain.finance.DecimalText.moneyFromLegacyDouble(expenseTransaction.amount),
            )
            if (impact.requiresAllocationDecision) {
                pendingExpense = PendingExpense(expenseTransaction, impact, onComplete)
                _expenseAllocationDecision.value = ExpenseAllocationDecision(
                    shortfallDecimal = impact.shortfallDecimal,
                    availableBeforeDecimal = impact.availableBeforeDecimal,
                    availableAfterWithoutReleaseDecimal = impact.availableAfterWithoutReleaseDecimal,
                    allocations = financialGoalRepository.activeAllocationChoices(),
                )
                return@sessionMutation
            }
        }
        commitExpense(expenseTransaction, emptyList(), null, onComplete)
    }

    fun confirmExpenseAllocationDecision(selectedFundingTransactionIds: Set<String>) = sessionMutation {
        val pending = pendingExpense ?: return@sessionMutation
        commitExpense(
            transaction = pending.transaction,
            selectedFundingTransactionIds = selectedFundingTransactionIds.toList(),
            shortfallDecimal = pending.impact.shortfallDecimal,
            onComplete = pending.onComplete,
        )
        pendingExpense = null
        _expenseAllocationDecision.value = null
    }

    fun cancelExpenseAllocationDecision() {
        pendingExpense = null
        _expenseAllocationDecision.value = null
    }

    fun setBudgetLimit(value: Float) = sessionMutation {
        preferences.setBudgetLimit(value)
        queueBackgroundSync()
    }

    private suspend fun commitExpense(
        transaction: Transaction,
        selectedFundingTransactionIds: List<String>,
        shortfallDecimal: String?,
        onComplete: () -> Unit,
    ) {
        val now = System.currentTimeMillis()
        database.withTransaction {
            if (selectedFundingTransactionIds.isNotEmpty() && shortfallDecimal != null) {
                financialGoalRepository.releaseAllocationsForOverspend(
                    selectedFundingTransactionIds = selectedFundingTransactionIds,
                    shortfallDecimal = shortfallDecimal,
                    operationId = transaction.id,
                    balanceTransactionId = null,
                    now = now,
                )
            }
            transactionRepository.insertNew(transaction, linkIncomeToBalance = true)
        }
        queueBackgroundSync()
        onComplete()
    }

    private fun normalizeIncomeSourceName(name: String): String =
        name.trim().replace(Regex("\\s+"), " ")
}

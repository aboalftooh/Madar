package com.shift.app.feature.assets.presentation

import com.shift.app.domain.finance.AssetStatus

internal enum class AssetCreateMode { PREEXISTING, PURCHASE }
internal enum class AssetCommand { IMPROVE, MAINTAIN, VALUE, SELL }
internal val currentAssetStatuses = setOf(AssetStatus.Active.dbValue)

internal data class AssetCreateErrors(
    val name: String = "",
    val amount: String = "",
    val currencyCode: String = "",
    val quantity: String = "",
    val exchangeRate: String = "",
    val date: String = ""
)

internal data class AssetCommandErrors(
    val amount: String = "",
    val purpose: String = "",
    val date: String = ""
)

internal fun englishDigitsOnly(value: String): String = value.filter { it in '0'..'9' }
internal fun moneyTextToWholeDigits(value: String): String = englishDigitsOnly(value.substringBefore('.'))

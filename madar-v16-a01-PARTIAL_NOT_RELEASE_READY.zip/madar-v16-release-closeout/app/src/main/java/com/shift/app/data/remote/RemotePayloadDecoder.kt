package com.shift.app.data.remote

import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class RemotePayloadDecoder(
    private val json: Json,
    private val legacyKeySalt: String = "madar-app-v1"
) {
    fun isPlainJsonPayload(payload: String): Boolean = payload.trimStart().startsWith("{")

    fun payloadText(payload: String, userId: String): String =
        if (isPlainJsonPayload(payload)) payload else legacyDecrypt(payload, userId)

    fun <T> decodePayload(
        payload: String,
        userId: String,
        deserializer: DeserializationStrategy<T>
    ): T = json.decodeFromString(deserializer, payloadText(payload, userId))

    private fun legacyDecrypt(encoded: String, userId: String): String {
        val data = Base64.getDecoder().decode(encoded)
        val iv = data.copyOfRange(0, 12)
        val ciphertext = data.copyOfRange(12, data.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, legacySecretKey(userId), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    private fun legacySecretKey(userId: String): SecretKeySpec {
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest("$legacyKeySalt:$userId".toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyBytes, "AES")
    }
}

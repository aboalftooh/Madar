package com.shift.app.feature.goals.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.usecase.GoalLifecycleStateMachine
import com.shift.app.domain.goals.usecase.specializedCompletionTypes
import com.shift.app.ui.theme.AccentCyan
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.utils.FinancialInput
import com.shift.app.feature.goals.presentation.GoalActionResult
import com.shift.app.feature.goals.presentation.GoalFundingUiSummary
import com.shift.app.feature.goals.presentation.GoalsViewModel
import com.shift.app.feature.goals.presentation.arabicLabel
import java.math.BigDecimal

@Composable
fun GoalDetailsScreen(
    goal: FinancialGoal?,
    funding: GoalFundingUiSummary,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onSpecializedComplete: (FinancialGoal) -> Unit,
    viewModel: GoalsViewModel,
) {
    val actionResult by viewModel.actionResult.collectAsState()
    val latestEvaluation by viewModel.selectedEvaluation.collectAsState()
    LaunchedEffect(actionResult) {
        if (actionResult is GoalActionResult.Success) viewModel.clearActionResult()
    }
    if (goal == null) {
        Column(
            modifier = Modifier.fillMaxSize().background(BackgroundDark).padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("جاري تحميل الهدف", color = TextMuted)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
            }
            Column(Modifier.weight(1f)) {
                Text(goal.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(goal.type.arabicLabel(), color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = onEdit, enabled = goal.lifecycleStatus in setOf(GoalLifecycleStatus.DRAFT, GoalLifecycleStatus.ACTIVE, GoalLifecycleStatus.PAUSED)) {
                Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = GoldPrimary)
            }
        }
        DetailsCard("ملخص") {
            DetailRow("الحالة", goal.lifecycleStatus.arabicLabel())
            DetailRow("الصحة", goal.healthStatus.arabicLabel())
            DetailRow("الهدف", NumberDisplayFormatter.format(BigDecimal(goal.targetDecimal), useGrouping = true))
            DetailRow("الموعد", goal.deadline)
            DetailRow("العملة", goal.currencyCode)
        }
        DetailsCard("الشروط المستقلة") {
            DetailRow("القيمة المطلوبة", NumberDisplayFormatter.format(BigDecimal(goal.targetDecimal), useGrouping = true))
            DetailRow("فترات التأكيد", goal.confirmationPeriods.toString())
            DetailRow("عتبة التكلفة", goal.costThreshold?.name ?: "غير محددة")
        }
        latestEvaluation?.let { evaluation ->
            DetailsCard("آخر قياس") {
                DetailRow(
                    "القيمة المقاسة",
                    evaluation.measuredDecimal?.let { NumberDisplayFormatter.format(BigDecimal(it), useGrouping = true) } ?: "غير متاحة",
                )
                DetailRow("وقت القياس", java.time.Instant.ofEpochMilli(evaluation.asOf).toString())
                if (evaluation.estimated) {
                    Text("هذه القيمة مقدرة لأن بعض الأصول لا تملك تقييماً صالحاً حتى تاريخ القياس.", color = GoldPrimary, fontSize = 12.sp)
                }
                evaluation.correctionOfId?.let { reference ->
                    Text("تصحيح رجعي لتقييم سابق: $reference", color = GoldPrimary, fontSize = 12.sp)
                }
            }
        }
        DetailsCard("التمويل والسحب") {
            FundingSection(
                goal = goal,
                funding = funding,
                onAllocate = { amount, note -> viewModel.allocate(goal, amount, note) },
                onRelease = { amount, reason -> viewModel.release(goal, amount, reason) },
                onReverse = { viewModel.reverse(goal, it) },
            )
        }
        DetailsCard("النشاط") {
            Text("آخر تحديث: ${java.time.Instant.ofEpochMilli(goal.updatedAt)}", color = TextSecondary, fontSize = 13.sp)
            Text("Revision ${goal.revision}", color = TextMuted, fontSize = 12.sp)
        }
        val error = actionResult as? GoalActionResult.Error
        error?.let { Text(it.message, color = ExpenseRed, fontSize = 13.sp) }
        if (
            goal.type == GoalType.DEBT_PAYOFF &&
            goal.lifecycleStatus in setOf(GoalLifecycleStatus.ACTIVE, GoalLifecycleStatus.READY)
        ) {
            Button(onClick = { onSpecializedComplete(goal) }, modifier = Modifier.fillMaxWidth()) {
                Text("تسجيل دفعة ضمن هدف السداد")
            }
        }
        LifecycleActions(
            goal = goal,
            onTransition = { viewModel.transition(goal, it) },
            onSpecializedComplete = { onSpecializedComplete(goal) },
        )
    }
}

@Composable
internal fun FundingSection(
    goal: FinancialGoal,
    funding: GoalFundingUiSummary,
    onAllocate: (String, String) -> Unit,
    onRelease: (String, String) -> Unit,
    onReverse: (GoalFundingTransaction) -> Unit,
) {
    var amount by remember(goal.id) { mutableStateOf("") }
    var note by remember(goal.id) { mutableStateOf("") }
    DetailRow(
        "المخصص الحالي",
        "${NumberDisplayFormatter.format(BigDecimal(funding.allocatedDecimal), useGrouping = true)} ${goal.currencyCode}",
    )
    OutlinedTextField(
        value = amount,
        onValueChange = { amount = FinancialInput.englishDigitsOnly(it) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text("المبلغ") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
    OutlinedTextField(
        value = note,
        onValueChange = { note = it },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(if (goal.type.name == "EMERGENCY_FUND") "السبب" else "ملاحظة") },
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = { onAllocate(amount, note) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BackgroundDark),
        ) {
            Text("تخصيص")
        }
        OutlinedButton(
            onClick = { onRelease(amount, note) },
            modifier = Modifier.weight(1f),
        ) {
            Text("سحب", color = TextPrimary)
        }
    }
    funding.transactions.takeLast(3).reversed().forEach { transaction ->
        FundingTransactionRow(transaction = transaction, currencyCode = goal.currencyCode, onReverse = onReverse)
    }
}

@Composable
private fun FundingTransactionRow(
    transaction: GoalFundingTransaction,
    currencyCode: String,
    onReverse: (GoalFundingTransaction) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(transaction.kind.arabicLabel(), color = TextSecondary, fontSize = 12.sp)
            Text(
                "${NumberDisplayFormatter.format(BigDecimal(transaction.amountDecimal), useGrouping = true)} $currencyCode",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (transaction.kind != FundingKind.REVERSAL) {
            OutlinedButton(onClick = { onReverse(transaction) }) {
                Text("عكس", color = ExpenseRed)
            }
        }
    }
}

@Composable
private fun DetailsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextMuted, fontSize = 13.sp)
        Text(value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun LifecycleActions(
    goal: FinancialGoal,
    onTransition: (GoalLifecycleStatus) -> Unit,
    onSpecializedComplete: () -> Unit,
) {
    val candidates = listOf(
        GoalLifecycleStatus.ACTIVE,
        GoalLifecycleStatus.PAUSED,
        GoalLifecycleStatus.COMPLETED,
        GoalLifecycleStatus.CANCELLED,
        GoalLifecycleStatus.ARCHIVED,
    ).filter { GoalLifecycleStateMachine.isAllowed(goal.lifecycleStatus, it) }
    if (candidates.isEmpty()) return

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        candidates.forEach { target ->
            val destructive = target == GoalLifecycleStatus.CANCELLED || target == GoalLifecycleStatus.ARCHIVED
            if (destructive) {
                OutlinedButton(onClick = { onTransition(target) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(target.actionIcon(), contentDescription = null, tint = ExpenseRed)
                    Text(target.actionLabel(), color = ExpenseRed)
                }
            } else {
                Button(
                    onClick = {
                        if (target == GoalLifecycleStatus.COMPLETED && goal.type in specializedCompletionTypes) {
                            onSpecializedComplete()
                        } else {
                            onTransition(target)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (target == GoalLifecycleStatus.COMPLETED) IncomeGreen else GoldPrimary,
                        contentColor = BackgroundDark,
                    ),
                ) {
                    Icon(target.actionIcon(), contentDescription = null)
                    Text(
                        if (target == GoalLifecycleStatus.COMPLETED && goal.type in specializedCompletionTypes) {
                            "فتح الإكمال المحاسبي"
                        } else {
                            target.actionLabel()
                        },
                    )
                }
            }
        }
    }
}

private fun GoalLifecycleStatus.actionLabel(): String = when (this) {
    GoalLifecycleStatus.ACTIVE -> "تفعيل / استئناف"
    GoalLifecycleStatus.PAUSED -> "إيقاف مؤقت"
    GoalLifecycleStatus.COMPLETED -> "إكمال"
    GoalLifecycleStatus.CANCELLED -> "إلغاء"
    GoalLifecycleStatus.ARCHIVED -> "أرشفة"
    else -> arabicLabel()
}

private fun GoalLifecycleStatus.actionIcon() = when (this) {
    GoalLifecycleStatus.ACTIVE -> Icons.Default.PlayArrow
    GoalLifecycleStatus.PAUSED -> Icons.Default.Pause
    GoalLifecycleStatus.COMPLETED -> Icons.Default.CheckCircle
    GoalLifecycleStatus.CANCELLED -> Icons.Default.Cancel
    GoalLifecycleStatus.ARCHIVED -> Icons.Default.Archive
    else -> Icons.Default.PlayArrow
}

private fun FundingKind.arabicLabel(): String = when (this) {
    FundingKind.ALLOCATE -> "تخصيص"
    FundingKind.RELEASE -> "سحب"
    FundingKind.CONSUME -> "استهلاك"
    FundingKind.REVERSAL -> "عكس"
}

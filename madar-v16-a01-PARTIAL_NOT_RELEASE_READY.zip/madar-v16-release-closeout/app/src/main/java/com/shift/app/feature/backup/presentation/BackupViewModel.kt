package com.shift.app.feature.backup.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.feature.backup.domain.model.BackupInspection
import com.shift.app.feature.backup.domain.model.BackupImportMode
import com.shift.app.feature.backup.domain.model.BackupPlanSummary
import com.shift.app.feature.backup.domain.model.RestoreReport
import com.shift.app.feature.backup.domain.repository.BackupGateway
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BackupUiState(
    val preparing: Boolean = false,
    val restoring: Boolean = false,
    val inspection: BackupInspection? = null,
    val mergePlan: BackupPlanSummary? = null,
    val replacePlan: BackupPlanSummary? = null,
    val errorMessage: String? = null,
)

@HiltViewModel
class BackupViewModel @Inject constructor(
    private val gateway: BackupGateway,
) : ViewModel() {
    private val mutableState = MutableStateFlow(BackupUiState())
    val state: StateFlow<BackupUiState> = mutableState.asStateFlow()

    private var pendingSourceJson: String? = null

    fun exportBackup(onResult: (Result<String>) -> Unit) = viewModelScope.launch {
        onResult(runCatching { gateway.exportJson() })
    }

    fun prepareImport(sourceJson: String) = viewModelScope.launch {
        mutableState.update { it.copy(preparing = true, errorMessage = null) }
        val result = runCatching {
            val inspection = gateway.inspect(sourceJson)
            val merge = gateway.plan(sourceJson, BackupImportMode.MERGE)
            val replace = runCatching { gateway.plan(sourceJson, BackupImportMode.REPLACE) }.getOrNull()
            Triple(inspection, merge, replace)
        }
        result.onSuccess { (inspection, merge, replace) ->
            pendingSourceJson = sourceJson
            mutableState.value = BackupUiState(
                preparing = false,
                inspection = inspection,
                mergePlan = merge,
                replacePlan = replace,
            )
        }.onFailure { error ->
            pendingSourceJson = null
            mutableState.value = BackupUiState(
                errorMessage = error.message ?: "تعذر التحقق من النسخة الاحتياطية",
            )
        }
    }

    fun restore(
        mode: BackupImportMode,
        onResult: (RestoreReport) -> Unit = {},
    ) = viewModelScope.launch {
        val source = pendingSourceJson
        if (source == null) {
            val report = RestoreReport.Failure(
                code = com.shift.app.feature.backup.domain.model.RestoreFailureCode.STALE_INSPECTION,
                userMessage = "انتهت معاينة النسخة؛ أعد اختيار الملف",
                reference = "StaleInspection",
            )
            onResult(report)
            return@launch
        }
        mutableState.update { it.copy(restoring = true, errorMessage = null) }
        val report = gateway.restore(source, mode)
        if (report is RestoreReport.Success) {
            pendingSourceJson = null
            mutableState.value = BackupUiState()
        } else {
            mutableState.update { it.copy(restoring = false) }
        }
        onResult(report)
    }

    fun clearImport() {
        pendingSourceJson = null
        mutableState.value = BackupUiState()
    }
}

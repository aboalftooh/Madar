package com.shift.app.feature.goals.data

import com.shift.app.data.local.dao.goals.FinancialGoalDao
import com.shift.app.data.repository.FinancialGoalRepository
import com.shift.app.domain.goals.funding.AvailableSpendingImpact
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.feature.goals.domain.model.ActiveGoalAllocation
import com.shift.app.feature.goals.domain.model.FinancialChangeEvent
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalActivity
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalCostEstimate
import com.shift.app.feature.goals.domain.model.GoalEvaluation
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.feature.goals.domain.model.GoalScope
import com.shift.app.feature.goals.domain.repository.GoalGateway
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class GoalGatewayAdapter @Inject constructor(
    private val repository: FinancialGoalRepository,
    private val goalDao: FinancialGoalDao,
) : GoalGateway {
    override fun observeActiveGoals(): Flow<List<FinancialGoal>> =
        goalDao.observeActive().map { rows -> rows.map { it.toDomain() } }

    override suspend fun getAggregate(goalId: String): GoalAggregate? = repository.getAggregate(goalId)?.toDomain()
    override suspend fun getLiveAggregates(): List<GoalAggregate> = repository.getLiveAggregates().map { it.toDomain() }
    override suspend fun createAggregate(aggregate: GoalAggregate, operationId: String) = repository.createAggregate(aggregate.toEntityAggregate(), operationId)
    override suspend fun updateAggregate(aggregate: GoalAggregate, expectedRevision: Long, now: Long, operationId: String): GoalAggregate =
        repository.updateAggregate(aggregate.toEntityAggregate(), expectedRevision, now, operationId).toDomain()
    override suspend fun softDelete(goalId: String, expectedRevision: Long, now: Long, operationId: String) = repository.softDelete(goalId, expectedRevision, now, operationId)
    override suspend fun transition(goalId: String, expectedRevision: Long, to: GoalLifecycleStatus, operationId: String, now: Long, activityType: String): FinancialGoal =
        repository.transition(goalId, expectedRevision, to, operationId, now, activityType).toDomain()

    override suspend fun recordFundingTransaction(
        goalId: String,
        operationId: String,
        kind: FundingKind,
        amountDecimal: String,
        currencyCode: String,
        note: String,
        now: Long,
        relatedFundingTransactionId: String?,
        balanceTransactionId: String?,
    ): GoalFundingTransaction = repository.recordFundingTransaction(
        goalId, operationId, kind, amountDecimal, currencyCode, note, now,
        relatedFundingTransactionId, balanceTransactionId,
    ).toDomain()

    override suspend fun recordCostEstimate(
        goalId: String,
        operationId: String,
        expectedDecimal: String,
        safeDecimal: String,
        currencyCode: String,
        source: String,
        note: String,
        now: Long,
        minDecimal: String?,
    ): GoalCostEstimate = repository.recordCostEstimate(
        goalId, operationId, expectedDecimal, safeDecimal, currencyCode, source, note, now, minDecimal,
    ).toDomain()

    override suspend fun recordNewDebtPayoffDecision(debtAccountId: String, include: Boolean, operationId: String, now: Long): List<GoalScope> =
        repository.recordNewDebtPayoffDecision(debtAccountId, include, operationId, now).map { it.toDomain() }

    override suspend fun spendingImpact(expenseAmountDecimal: String): AvailableSpendingImpact = repository.spendingImpact(expenseAmountDecimal)
    override suspend fun activeAllocationChoices(): List<ActiveGoalAllocation> = repository.activeAllocationChoices().map {
        ActiveGoalAllocation(it.fundingTransactionId, it.goalId, it.goalName, it.availableDecimal)
    }
    override suspend fun releaseAllocationsForOverspend(selectedFundingTransactionIds: List<String>, shortfallDecimal: String, operationId: String, balanceTransactionId: String?, now: Long): List<GoalFundingTransaction> =
        repository.releaseAllocationsForOverspend(selectedFundingTransactionIds, shortfallDecimal, operationId, balanceTransactionId, now).map { it.toDomain() }

    override suspend fun pendingChanges(limit: Int): List<FinancialChangeEvent> = repository.pendingOutbox(limit).map { it.toDomain() }
    override suspend fun saveEvaluation(evaluation: GoalEvaluation, activity: GoalActivity, expectedRevision: Long): Boolean =
        repository.saveEvaluation(evaluation.toEntity(), activity.toEntity(), expectedRevision)
    override suspend fun markChangeProcessed(eventId: String, processedAt: Long) = repository.markOutboxProcessed(eventId, processedAt)
    override suspend fun markChangeFailed(event: FinancialChangeEvent, error: String) = repository.markOutboxFailed(event.toEntity(), error)
}

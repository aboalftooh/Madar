package com.shift.app.data.local.dao

import androidx.room.*
import com.shift.app.data.local.entities.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE deletedAt IS NULL ORDER BY date DESC")
    fun getAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllIncludingDeleted(): Flow<List<Transaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(t: Transaction)

    @Update
    suspend fun update(t: Transaction)

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Transaction?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<Transaction>)

    @Query("SELECT * FROM transactions")
    suspend fun getAllOnce(): List<Transaction>

    @Query("SELECT * FROM transactions WHERE operationId IS NOT NULL AND balanceTransactionId IS NOT NULL ORDER BY id ASC")
    suspend fun getLedgerLinkedOnce(): List<Transaction>

    @Query("UPDATE transactions SET operationId = NULL, balanceTransactionId = NULL, updatedAt = :restoredUpdatedAt WHERE id = :id")
    suspend fun clearLedgerLink(id: String, restoredUpdatedAt: Long)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()

    @Query("SELECT DISTINCT purpose FROM transactions WHERE type = 'expense' AND deletedAt IS NULL AND purpose != '' ORDER BY purpose COLLATE NOCASE ASC")
    fun expensePurposeSuggestions(): Flow<List<String>>
}

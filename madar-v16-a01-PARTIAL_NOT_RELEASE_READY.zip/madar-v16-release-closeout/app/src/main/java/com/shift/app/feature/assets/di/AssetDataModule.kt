package com.shift.app.feature.assets.di

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object AssetDataModule {
    @Provides fun provideAssetDao(database: MadarDatabase): AssetDao = database.assetDao()
    @Provides fun provideAssetTransactionDao(database: MadarDatabase): AssetTransactionDao = database.assetTransactionDao()
    @Provides fun provideAssetValuationDao(database: MadarDatabase): AssetValuationDao = database.assetValuationDao()
    @Provides fun provideCurrencyAssetLotDao(database: MadarDatabase): CurrencyAssetLotDao = database.currencyAssetLotDao()
    @Provides fun provideCurrencyAssetSaleAllocationDao(database: MadarDatabase): CurrencyAssetSaleAllocationDao = database.currencyAssetSaleAllocationDao()
}

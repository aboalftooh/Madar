package com.shift.app.data.remote

import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable internal data class TxPayload(
    val type: String, val amount: Double, val category: String,
    val date: String, val note: String, val txGroup: String,
    val incomeSourceId: String? = null,
    val incomeSourceNameSnapshot: String = "",
    val paymentMethodSnapshot: String = "",
    val purpose: String = "",
    val purposeKey: String = "",
    val expenseBeneficiaryId: String? = null,
    val expenseBeneficiaryNameSnapshot: String = "",
    val operationId: String? = null,
    val balanceTransactionId: String? = null
)

@Serializable internal data class IncomeSourcePayload(
    val name: String,
    val paymentMethod: String,
    val createdAt: Long
)

@Serializable internal data class ExpenseBeneficiaryPayload(
    val name: String,
    val createdAt: Long
)

@Serializable internal data class DebtPayload(
    val name: String, val amount: Double, val type: String,
    val dueDate: String, val note: String, val isSettled: Boolean
)

@Serializable internal data class BalanceTransactionPayload(
    val operationId: String,
    val direction: String,
    val kind: String,
    val amountDecimal: String,
    val currencyCode: String,
    val date: String,
    val note: String,
    val sourceType: String,
    val sourceId: String? = null,
    val legacyTransactionId: String? = null,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class PaymentPayload(
    val operationId: String,
    val kind: String,
    val amountDecimal: String,
    val currencyCode: String,
    val date: String,
    val purpose: String,
    val purposeKey: String,
    val beneficiaryId: String? = null,
    val beneficiaryNameSnapshot: String,
    val assetId: String? = null,
    val assetNameSnapshot: String,
    val balanceTransactionId: String? = null,
    val legacyTransactionId: String? = null,
    val note: String,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class LedgerHistoryMigrationPayload(
    val plannerVersion: Int,
    val status: String,
    val sourceFingerprint: String,
    val commitFingerprint: String,
    val candidateCount: Int,
    val incomeCount: Int,
    val expenseCount: Int,
    val historicalIncomeDecimal: String,
    val historicalExpenseDecimal: String,
    val targetBalanceDecimal: String,
    val adjustmentDecimal: String,
    val adjustmentBalanceTransactionId: String? = null,
    val confirmedAt: Long,
    val completedAt: Long? = null,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class AssetPayload(
    val operationId: String? = null,
    val type: String,
    val name: String,
    val status: String,
    val acquisitionMode: String,
    val acquisitionAmountDecimal: String,
    val currencyCode: String,
    val purchasePaymentId: String? = null,
    val purchaseBalanceTransactionId: String? = null,
    val currentValueCacheDecimal: String? = null,
    val currentValueCacheValuationId: String? = null,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class AssetTransactionPayload(
    val operationId: String,
    val assetId: String,
    val kind: String,
    val amountDecimal: String? = null,
    val currencyQuantityDeltaDecimal: String? = null,
    val paymentId: String? = null,
    val balanceTransactionId: String? = null,
    val date: String,
    val note: String,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class AssetValuationPayload(
    val operationId: String,
    val assetId: String,
    val valueDecimal: String,
    val date: String,
    val note: String,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class CurrencyAssetLotPayload(
    val operationId: String,
    val assetId: String,
    val purchaseAssetTransactionId: String,
    val foreignCurrencyCode: String,
    val quantityPurchasedDecimal: String,
    val purchaseExchangeRateDecimal: String,
    val localCostDecimal: String,
    val purchaseDate: String,
    val syncState: String,
    val createdAt: Long
)

@Serializable internal data class CurrencyAssetSaleAllocationPayload(
    val operationId: String,
    val assetId: String,
    val saleAssetTransactionId: String,
    val lotId: String,
    val quantitySoldDecimal: String,
    val allocatedLocalCostDecimal: String,
    val syncState: String,
    val createdAt: Long
)

internal const val ASSET_OPERATION_RPC_FUNCTION = "upsert_asset_operation"
internal const val DEBT_OPERATION_RPC_FUNCTION = "upsert_debt_operation"
internal const val FINANCIAL_GOAL_OPERATION_RPC_FUNCTION = "apply_financial_goal_operation"

internal val SYNC_ORCHESTRATED_REMOTE_TABLES = listOf(
    "income_sources",
    "expense_beneficiaries",
    "transactions",
    "balance_transactions",
    "payments",
    "ledger_history_migrations",
    "assets",
    "asset_transactions",
    "asset_valuations",
    "currency_asset_lots",
    "currency_asset_sale_allocations",
    "debts",
    "financial_goals",
    "goal_metrics",
    "goal_conditions",
    "goal_scopes",
    "goal_funding_transactions",
    "goal_cost_estimates",
    "goal_evaluations",
    "goal_activities",
    "user_settings"
)

@Serializable
internal data class AssetOperationRpcParams(
    @SerialName("p_balance_transactions") val balanceTransactions: List<RemoteBalanceTransaction>,
    @SerialName("p_payments") val payments: List<RemotePayment>,
    @SerialName("p_assets") val assets: List<RemoteAsset>,
    @SerialName("p_asset_transactions") val assetTransactions: List<RemoteAssetTransaction>,
    @SerialName("p_asset_valuations") val assetValuations: List<RemoteAssetValuation>,
    @SerialName("p_currency_asset_lots") val currencyAssetLots: List<RemoteCurrencyAssetLot>,
    @SerialName("p_currency_asset_sale_allocations")
    val currencyAssetSaleAllocations: List<RemoteCurrencyAssetSaleAllocation>,
    @SerialName("p_transactions") val legacyTransactions: List<RemoteTransaction>,
    @SerialName("p_ledger_history_migrations")
    val ledgerHistoryMigrations: List<RemoteLedgerHistoryMigration>
)

@Serializable
internal data class DebtOperationRpcParams(
    @SerialName("p_operation") val operation: DebtSyncBundle
)

@Serializable
internal data class FinancialGoalOperationRpcParams(
    @SerialName("p_operation") val operation: FinancialGoalSyncBundle
)

@Serializable internal data class SettingsPayload(
    val budgetLimit: Float,
    val incomeSources: List<String>,
    val expenseGroups: List<String>,
    val userName: String,
    val workType: String,
    val balanceActivated: Boolean = false,
    val balanceActivatedAt: Long = 0L,
    val localCurrencyCode: String = "SDG"
)


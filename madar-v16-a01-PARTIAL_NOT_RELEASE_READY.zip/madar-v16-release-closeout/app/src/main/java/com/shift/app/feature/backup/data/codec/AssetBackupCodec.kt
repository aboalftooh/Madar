package com.shift.app.feature.backup.data.codec

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.repository.AssetRepository
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.feature.backup.data.BackupSectionCodec
import com.shift.app.feature.backup.data.BackupSectionPlan
import com.shift.app.feature.backup.data.BackupSectionSnapshot
import com.shift.app.feature.backup.domain.model.BackupImportMode
import java.util.UUID
import javax.inject.Inject
import org.json.JSONArray
import org.json.JSONObject

internal data class AssetBackupSnapshot(
    val assets: List<Asset> = emptyList(),
    val transactions: List<AssetTransaction> = emptyList(),
    val valuations: List<AssetValuation> = emptyList(),
    val lots: List<CurrencyAssetLot> = emptyList(),
    val allocations: List<CurrencyAssetSaleAllocation> = emptyList(),
    val included: Boolean = true,
) : BackupSectionSnapshot {
    override val rowCount: Int = assets.size + transactions.size + valuations.size + lots.size + allocations.size
}

internal data class AssetBackupPlan(
    val assets: List<Asset>,
    val transactions: List<AssetTransaction>,
    val valuations: List<AssetValuation>,
    val lots: List<CurrencyAssetLot>,
    val allocations: List<CurrencyAssetSaleAllocation>,
    override val importedRowCount: Int,
    override val affectedRowCount: Int,
    override val deleteCount: Int,
) : BackupSectionPlan

internal class AssetBackupCodec @Inject constructor(
    private val repository: AssetRepository,
) : BackupSectionCodec {
    override val id: String = "assets"

    override suspend fun writeExport(root: JSONObject) {
        val current = currentSnapshot()
        root.put("assets", JSONArray(current.assets.map { it.toJson() }))
        root.put("assetTransactions", JSONArray(current.transactions.map { it.toJson() }))
        root.put("assetValuations", JSONArray(current.valuations.map { it.toJson() }))
        root.put("currencyAssetLots", JSONArray(current.lots.map { it.toJson() }))
        root.put("currencyAssetSaleAllocations", JSONArray(current.allocations.map { it.toJson() }))
    }

    override fun decode(root: JSONObject, now: Long): BackupSectionSnapshot = AssetBackupSnapshot(
        assets = root.optJSONArray("assets").toAssets(now),
        transactions = root.optJSONArray("assetTransactions").toAssetTransactions(now),
        valuations = root.optJSONArray("assetValuations").toAssetValuations(now),
        lots = root.optJSONArray("currencyAssetLots").toCurrencyAssetLots(now),
        allocations = root.optJSONArray("currencyAssetSaleAllocations").toCurrencyAssetSaleAllocations(now),
        included = root.has("assets") || root.has("assetTransactions") || root.has("assetValuations") ||
            root.has("currencyAssetLots") || root.has("currencyAssetSaleAllocations"),
    ).also(::validate)

    override suspend fun plan(
        imported: BackupSectionSnapshot,
        mode: BackupImportMode,
        now: Long,
    ): BackupSectionPlan {
        imported as AssetBackupSnapshot
        val current = currentSnapshot()
        if (!imported.included) {
            return AssetBackupPlan(
                assets = current.assets,
                transactions = current.transactions,
                valuations = current.valuations,
                lots = current.lots,
                allocations = current.allocations,
                importedRowCount = 0,
                affectedRowCount = 0,
                deleteCount = 0,
            )
        }
        val deleteAssets = tombstones(current.assets, imported.assets, mode, now) { it.id }
        val deleteTransactions = tombstones(current.transactions, imported.transactions, mode, now) { it.id }
        val deleteValuations = tombstones(current.valuations, imported.valuations, mode, now) { it.id }
        val deleteLots = tombstones(current.lots, imported.lots, mode, now) { it.id }
        val deleteAllocations = tombstones(current.allocations, imported.allocations, mode, now) { it.id }
        val plan = AssetBackupPlan(
            assets = imported.assets + deleteAssets.map { it.copy(updatedAt = now, deletedAt = now) },
            transactions = imported.transactions + deleteTransactions.map { it.copy(updatedAt = now, deletedAt = now) },
            valuations = imported.valuations + deleteValuations.map { it.copy(updatedAt = now, deletedAt = now) },
            lots = imported.lots + deleteLots.map { it.copy(updatedAt = now, deletedAt = now) },
            allocations = imported.allocations + deleteAllocations.map { it.copy(updatedAt = now, deletedAt = now) },
            importedRowCount = imported.rowCount,
            affectedRowCount = imported.rowCount + deleteAssets.size + deleteTransactions.size +
                deleteValuations.size + deleteLots.size + deleteAllocations.size,
            deleteCount = deleteAssets.size + deleteTransactions.size + deleteValuations.size +
                deleteLots.size + deleteAllocations.size,
        )
        validate(AssetBackupSnapshot(plan.assets, plan.transactions, plan.valuations, plan.lots, plan.allocations))
        return plan
    }

    override suspend fun apply(plan: BackupSectionPlan) {
        plan as AssetBackupPlan
        repository.upsertAssetBackupBundle(
            assets = plan.assets,
            assetTransactions = plan.transactions,
            assetValuations = plan.valuations,
            currencyLots = plan.lots,
            currencySaleAllocations = plan.allocations,
        )
    }

    private suspend fun currentSnapshot() = AssetBackupSnapshot(
        assets = repository.getAssetsOnce(),
        transactions = repository.getAssetTransactionsOnce(),
        valuations = repository.getAssetValuationsOnce(),
        lots = repository.getCurrencyLotsOnce(),
        allocations = repository.getCurrencySaleAllocationsOnce(),
    )

    private fun validate(snapshot: AssetBackupSnapshot) {
        val assetIds = snapshot.assets.mapTo(hashSetOf()) { it.id }
        val transactionIds = snapshot.transactions.mapTo(hashSetOf()) { it.id }
        val lotIds = snapshot.lots.mapTo(hashSetOf()) { it.id }
        require(snapshot.transactions.all { it.assetId in assetIds }) { "Asset backup has orphan transactions" }
        require(snapshot.valuations.all { it.assetId in assetIds }) { "Asset backup has orphan valuations" }
        require(snapshot.lots.all {
            it.assetId in assetIds && it.purchaseAssetTransactionId in transactionIds
        }) { "Currency lot backup contains a missing asset or purchase event" }
        require(snapshot.allocations.all {
            it.assetId in assetIds && it.saleAssetTransactionId in transactionIds && it.lotId in lotIds
        }) { "Currency allocation backup contains a missing asset, sale event, or lot" }
    }

    private fun <T> tombstones(
        current: List<T>,
        imported: List<T>,
        mode: BackupImportMode,
        now: Long,
        id: (T) -> String,
    ): List<T> {
        @Suppress("UNUSED_VARIABLE") val timestamp = now
        if (mode != BackupImportMode.REPLACE) return emptyList()
        val importedIds = imported.mapTo(hashSetOf(), id)
        return current.filterNot { id(it) in importedIds }
    }

    private fun Asset.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("type", type); put("name", name); put("status", status)
        put("acquisitionMode", acquisitionMode); put("acquisitionAmountDecimal", acquisitionAmountDecimal)
        put("currencyCode", currencyCode); put("purchasePaymentId", purchasePaymentId)
        put("purchaseBalanceTransactionId", purchaseBalanceTransactionId)
        put("currentValueCacheDecimal", currentValueCacheDecimal)
        put("currentValueCacheValuationId", currentValueCacheValuationId)
        put("syncState", syncState); put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun AssetTransaction.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("assetId", assetId); put("kind", kind)
        put("amountDecimal", amountDecimal); put("currencyQuantityDeltaDecimal", currencyQuantityDeltaDecimal)
        put("paymentId", paymentId); put("balanceTransactionId", balanceTransactionId); put("date", date); put("note", note)
        put("syncState", syncState); put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun AssetValuation.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("assetId", assetId); put("valueDecimal", valueDecimal)
        put("date", date); put("note", note); put("syncState", syncState); put("createdAt", createdAt)
        put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun CurrencyAssetLot.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("assetId", assetId)
        put("purchaseAssetTransactionId", purchaseAssetTransactionId); put("foreignCurrencyCode", foreignCurrencyCode)
        put("quantityPurchasedDecimal", quantityPurchasedDecimal); put("purchaseExchangeRateDecimal", purchaseExchangeRateDecimal)
        put("localCostDecimal", localCostDecimal); put("purchaseDate", purchaseDate); put("syncState", syncState)
        put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun CurrencyAssetSaleAllocation.toJson() = JSONObject().apply {
        put("id", id); put("operationId", operationId); put("assetId", assetId)
        put("saleAssetTransactionId", saleAssetTransactionId); put("lotId", lotId)
        put("quantitySoldDecimal", quantitySoldDecimal); put("allocatedLocalCostDecimal", allocatedLocalCostDecimal)
        put("syncState", syncState); put("createdAt", createdAt); put("updatedAt", updatedAt); put("deletedAt", deletedAt)
    }

    private fun JSONArray?.toAssets(now: Long): List<Asset> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        Asset(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.optStringOrNull("operationId"),
            type = o.getString("type"),
            name = o.getString("name"),
            status = o.optString("status", "active").ifBlank { "active" },
            acquisitionMode = o.getString("acquisitionMode"),
            acquisitionAmountDecimal = DecimalText.canonicalNonNegative(o.getString("acquisitionAmountDecimal"), DecimalTextScale.Money),
            currencyCode = o.optString("currencyCode", "SDG").ifBlank { "SDG" },
            purchasePaymentId = o.optStringOrNull("purchasePaymentId"),
            purchaseBalanceTransactionId = o.optStringOrNull("purchaseBalanceTransactionId"),
            currentValueCacheDecimal = o.optStringOrNull("currentValueCacheDecimal"),
            currentValueCacheValuationId = o.optStringOrNull("currentValueCacheValuationId"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toAssetTransactions(now: Long): List<AssetTransaction> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        AssetTransaction(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            assetId = o.getString("assetId"),
            kind = o.getString("kind"),
            amountDecimal = o.optStringOrNull("amountDecimal"),
            currencyQuantityDeltaDecimal = o.optStringOrNull("currencyQuantityDeltaDecimal"),
            paymentId = o.optStringOrNull("paymentId"),
            balanceTransactionId = o.optStringOrNull("balanceTransactionId"),
            date = normalizedDateOrToday(o.optString("date")),
            note = o.optString("note"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toAssetValuations(now: Long): List<AssetValuation> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        AssetValuation(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            assetId = o.getString("assetId"),
            valueDecimal = DecimalText.canonicalNonNegative(o.getString("valueDecimal"), DecimalTextScale.Money),
            date = normalizedDateOrToday(o.optString("date")),
            note = o.optString("note"),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toCurrencyAssetLots(now: Long): List<CurrencyAssetLot> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        CurrencyAssetLot(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            assetId = o.getString("assetId"),
            purchaseAssetTransactionId = o.getString("purchaseAssetTransactionId"),
            foreignCurrencyCode = o.getString("foreignCurrencyCode").trim().uppercase().also {
                require(it.matches(Regex("[A-Z]{3}")) && it != "SDG") { "Invalid foreign currency code" }
            },
            quantityPurchasedDecimal = DecimalText.canonicalPositive(o.getString("quantityPurchasedDecimal"), DecimalTextScale.Quantity),
            purchaseExchangeRateDecimal = DecimalText.canonicalPositive(o.getString("purchaseExchangeRateDecimal"), DecimalTextScale.ExchangeRate),
            localCostDecimal = DecimalText.canonicalPositive(o.getString("localCostDecimal"), DecimalTextScale.Money),
            purchaseDate = normalizedDateOrToday(o.optString("purchaseDate")),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }

    private fun JSONArray?.toCurrencyAssetSaleAllocations(now: Long): List<CurrencyAssetSaleAllocation> = mapObjects { o ->
        val updatedAt = o.optLongOrNull("updatedAt") ?: now
        CurrencyAssetSaleAllocation(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            operationId = o.getString("operationId"),
            assetId = o.getString("assetId"),
            saleAssetTransactionId = o.getString("saleAssetTransactionId"),
            lotId = o.getString("lotId"),
            quantitySoldDecimal = DecimalText.canonicalPositive(o.getString("quantitySoldDecimal"), DecimalTextScale.Quantity),
            allocatedLocalCostDecimal = DecimalText.canonicalNonNegative(o.getString("allocatedLocalCostDecimal"), DecimalTextScale.Money),
            syncState = o.optString("syncState", "pending").ifBlank { "pending" },
            createdAt = o.optLongOrNull("createdAt") ?: updatedAt,
            updatedAt = updatedAt,
            deletedAt = o.optLongOrNull("deletedAt"),
        )
    }
}

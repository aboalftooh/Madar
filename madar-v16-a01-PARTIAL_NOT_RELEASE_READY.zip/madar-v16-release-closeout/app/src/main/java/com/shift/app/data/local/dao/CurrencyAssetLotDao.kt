package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.CurrencyAssetLot
import kotlinx.coroutines.flow.Flow

@Dao
interface CurrencyAssetLotDao {
    @Query("SELECT * FROM currency_asset_lots WHERE deletedAt IS NULL ORDER BY purchaseDate ASC, createdAt ASC, id ASC")
    fun getAll(): Flow<List<CurrencyAssetLot>>

    @Query("SELECT * FROM currency_asset_lots")
    suspend fun getAllOnce(): List<CurrencyAssetLot>

    @Query("SELECT * FROM currency_asset_lots WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY purchaseDate ASC, createdAt ASC, id ASC")
    suspend fun getActiveByAssetId(assetId: String): List<CurrencyAssetLot>

    @Query("SELECT * FROM currency_asset_lots WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<CurrencyAssetLot>

    @Query("SELECT * FROM currency_asset_lots WHERE operationId = :operationId AND deletedAt IS NULL")
    suspend fun getActiveByOperationId(operationId: String): List<CurrencyAssetLot>

    @Query("SELECT * FROM currency_asset_lots WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CurrencyAssetLot?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CurrencyAssetLot)

    @Update
    suspend fun update(item: CurrencyAssetLot)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<CurrencyAssetLot>)

    @Query("DELETE FROM currency_asset_lots")
    suspend fun deleteAll()
}

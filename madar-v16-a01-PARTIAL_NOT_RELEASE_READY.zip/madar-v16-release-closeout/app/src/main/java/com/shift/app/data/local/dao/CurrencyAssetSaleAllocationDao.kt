package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import kotlinx.coroutines.flow.Flow

@Dao
interface CurrencyAssetSaleAllocationDao {
    @Query("SELECT * FROM currency_asset_sale_allocations WHERE deletedAt IS NULL ORDER BY createdAt ASC, id ASC")
    fun getAll(): Flow<List<CurrencyAssetSaleAllocation>>

    @Query("SELECT * FROM currency_asset_sale_allocations")
    suspend fun getAllOnce(): List<CurrencyAssetSaleAllocation>

    @Query("SELECT * FROM currency_asset_sale_allocations WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY createdAt ASC, id ASC")
    suspend fun getActiveByAssetId(assetId: String): List<CurrencyAssetSaleAllocation>

    @Query("SELECT * FROM currency_asset_sale_allocations WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<CurrencyAssetSaleAllocation>

    @Query("SELECT * FROM currency_asset_sale_allocations WHERE operationId = :operationId AND deletedAt IS NULL")
    suspend fun getActiveByOperationId(operationId: String): List<CurrencyAssetSaleAllocation>

    @Query("SELECT * FROM currency_asset_sale_allocations WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CurrencyAssetSaleAllocation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CurrencyAssetSaleAllocation)

    @Update
    suspend fun update(item: CurrencyAssetSaleAllocation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<CurrencyAssetSaleAllocation>)

    @Query("DELETE FROM currency_asset_sale_allocations")
    suspend fun deleteAll()
}

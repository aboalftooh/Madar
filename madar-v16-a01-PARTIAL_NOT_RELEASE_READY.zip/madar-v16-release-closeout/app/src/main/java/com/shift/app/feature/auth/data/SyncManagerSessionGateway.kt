package com.shift.app.feature.auth.data

import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.SyncRunResult
import com.shift.app.feature.auth.domain.SessionSyncGateway
import com.shift.app.feature.auth.domain.SessionSyncResult
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncManagerSessionGateway @Inject constructor(
    private val syncManager: SyncManager,
) : SessionSyncGateway {
    override suspend fun synchronizePendingChanges(): SessionSyncResult =
        when (val result = syncManager.syncAll()) {
            is SyncRunResult.Success -> SessionSyncResult.Success
            is SyncRunResult.PartialFailure -> SessionSyncResult.PartialFailure(result.failedSteps)
            SyncRunResult.AuthenticationRequired -> SessionSyncResult.AuthenticationRequired
        }

    override suspend fun <T> withExclusiveSession(block: suspend () -> T): T {
        var value: Result<T>? = null
        syncManager.runSessionCleanup {
            value = runCatching { block() }
        }
        return requireNotNull(value).getOrThrow()
    }
}

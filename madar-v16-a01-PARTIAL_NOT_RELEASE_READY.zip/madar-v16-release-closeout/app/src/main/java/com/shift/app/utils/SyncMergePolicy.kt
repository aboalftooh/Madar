package com.shift.app.utils

enum class SyncMergeDecision {
    APPLY_REMOTE,
    KEEP_LOCAL_DIRTY,
    KEEP_LOCAL_NEWER,
}

object SyncMergePolicy {
    /**
     * Resolves one remote row against one local row without trusting the device clock when the
     * local entity is explicitly pending, failed, or in conflict.
     */
    fun decideRemote(
        localUpdatedAt: Long?,
        remoteUpdatedAt: Long,
        lastSuccessfulSync: Long? = null,
        localSyncState: String? = null,
    ): SyncMergeDecision {
        if (localUpdatedAt == null) return SyncMergeDecision.APPLY_REMOTE
        if (localSyncState != null) {
            if (!localSyncState.equals("synced", ignoreCase = true)) {
                return SyncMergeDecision.KEEP_LOCAL_DIRTY
            }
            return if (localUpdatedAt <= remoteUpdatedAt) {
                SyncMergeDecision.APPLY_REMOTE
            } else {
                SyncMergeDecision.KEEP_LOCAL_NEWER
            }
        }
        if (lastSuccessfulSync != null && localUpdatedAt > lastSuccessfulSync) {
            return SyncMergeDecision.KEEP_LOCAL_DIRTY
        }
        return if (localUpdatedAt <= remoteUpdatedAt) {
            SyncMergeDecision.APPLY_REMOTE
        } else {
            SyncMergeDecision.KEEP_LOCAL_NEWER
        }
    }

    fun shouldApplyRemote(
        localUpdatedAt: Long?,
        remoteUpdatedAt: Long,
        lastSuccessfulSync: Long? = null,
        localSyncState: String? = null,
    ): Boolean = decideRemote(
        localUpdatedAt = localUpdatedAt,
        remoteUpdatedAt = remoteUpdatedAt,
        lastSuccessfulSync = lastSuccessfulSync,
        localSyncState = localSyncState,
    ) == SyncMergeDecision.APPLY_REMOTE
}

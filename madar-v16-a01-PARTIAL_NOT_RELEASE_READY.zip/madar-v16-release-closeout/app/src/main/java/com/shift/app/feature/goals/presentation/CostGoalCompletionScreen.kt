package com.shift.app.feature.goals.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.usecase.CompleteCostGoalRequest
import com.shift.app.domain.goals.usecase.CostGoalCompletionMode
import java.time.LocalDate

@Composable
fun CostGoalCompletionScreen(
    summary: String,
    onKeepAllocated: () -> Unit,
    onConsume: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إكمال هدف تكلفة")
        Text(summary)
        Button(onClick = onConsume, modifier = Modifier.fillMaxWidth()) { Text("استهلاك التخصيص") }
        OutlinedButton(onClick = onKeepAllocated, modifier = Modifier.fillMaxWidth()) { Text("إبقاء المال مخصصًا") }
    }
}

@Composable
fun CostGoalCompletionScreen(
    goal: FinancialGoal,
    onSubmit: (CompleteCostGoalRequest) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var amount by remember(goal.id) { mutableStateOf(goal.targetDecimal) }
    var purpose by remember(goal.id) { mutableStateOf(goal.name) }
    var date by remember(goal.id) { mutableStateOf(LocalDate.now().toString()) }
    var note by remember(goal.id) { mutableStateOf("") }
    fun submit(mode: CostGoalCompletionMode) = onSubmit(
        CompleteCostGoalRequest(goal.id, amount, date, purpose, note, mode),
    )
    Column(modifier = modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إكمال هدف التكلفة")
        OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ الفعلي") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(purpose, { purpose = it }, label = { Text("الغرض / اسم المشروع") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(date, { date = it }, label = { Text("التاريخ") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { submit(CostGoalCompletionMode.ORDINARY_EXPENSE) }, modifier = Modifier.fillMaxWidth()) {
            Text("تسجيل مصروف واستهلاك التخصيص")
        }
        if (goal.type == GoalType.PROJECT_FUNDING) {
            Button(onClick = { submit(CostGoalCompletionMode.PROJECT_ASSET) }, modifier = Modifier.fillMaxWidth()) {
                Text("إنشاء أصل مشروع واستهلاك التخصيص")
            }
        }
        OutlinedButton(onClick = { submit(CostGoalCompletionMode.KEEP_ALLOCATED) }, modifier = Modifier.fillMaxWidth()) {
            Text("إكمال مع إبقاء المال مخصصًا")
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}

package com.shift.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.shift.app.data.local.dao.*
import com.shift.app.data.local.dao.goals.*
import com.shift.app.data.local.entities.*
import com.shift.app.data.local.entities.goals.*
import com.shift.app.data.local.migration.Migration17To18Plan
import com.shift.app.data.local.migration.SqlMigrationExecutor

@Database(
    entities = [
        Transaction::class,
        Debt::class,
        IncomeSource::class,
        ExpenseBeneficiary::class,
        BalanceTransaction::class,
        Payment::class,
        Asset::class,
        AssetTransaction::class,
        AssetValuation::class,
        CurrencyAssetLot::class,
        CurrencyAssetSaleAllocation::class,
        LedgerHistoryMigration::class,
        DebtAccount::class,
        DebtTransaction::class,
        DebtLink::class,
        DebtSchedule::class,
        DebtMigrationReview::class,
        FinancialGoalEntity::class,
        GoalMetricEntity::class,
        GoalConditionEntity::class,
        GoalScopeEntity::class,
        GoalFundingTransactionEntity::class,
        GoalCostEstimateEntity::class,
        GoalEvaluationEntity::class,
        GoalActivityEntity::class,
        FinancialChangeOutboxEntity::class,
        SyncOutboxEntity::class
    ],
    version = 18,
    exportSchema = true
)
abstract class MadarDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun balanceTransactionDao(): BalanceTransactionDao
    abstract fun paymentDao(): PaymentDao
    abstract fun assetDao(): AssetDao
    abstract fun assetTransactionDao(): AssetTransactionDao
    abstract fun assetValuationDao(): AssetValuationDao
    abstract fun currencyAssetLotDao(): CurrencyAssetLotDao
    abstract fun currencyAssetSaleAllocationDao(): CurrencyAssetSaleAllocationDao
    abstract fun ledgerHistoryMigrationDao(): LedgerHistoryMigrationDao
    abstract fun debtDao(): DebtDao
    abstract fun incomeSourceDao(): IncomeSourceDao
    abstract fun expenseBeneficiaryDao(): ExpenseBeneficiaryDao
    abstract fun debtAccountDao(): DebtAccountDao
    abstract fun debtTransactionDao(): DebtTransactionDao
    abstract fun debtLinkDao(): DebtLinkDao
    abstract fun debtScheduleDao(): DebtScheduleDao
    abstract fun debtMigrationReviewDao(): DebtMigrationReviewDao
    abstract fun financialGoalDao(): FinancialGoalDao
    abstract fun goalMetricDao(): GoalMetricDao
    abstract fun goalConditionDao(): GoalConditionDao
    abstract fun goalScopeDao(): GoalScopeDao
    abstract fun goalFundingTransactionDao(): GoalFundingTransactionDao
    abstract fun goalCostEstimateDao(): GoalCostEstimateDao
    abstract fun goalEvaluationDao(): GoalEvaluationDao
    abstract fun goalActivityDao(): GoalActivityDao
    abstract fun financialChangeOutboxDao(): FinancialChangeOutboxDao
    abstract fun syncOutboxDao(): SyncOutboxDao

    companion object {
        val MIGRATION_2_3 = object : Migration(2, 3) {  // kept for backward compat
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN tx_group TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // transactions
                db.execSQL("""
                    CREATE TABLE transactions_new (
                        id TEXT NOT NULL PRIMARY KEY,
                        type TEXT NOT NULL,
                        amount REAL NOT NULL,
                        category TEXT NOT NULL,
                        date TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        tx_group TEXT NOT NULL DEFAULT ''
                    )
                """.trimIndent())
                db.execSQL("INSERT INTO transactions_new (id, type, amount, category, date, note, tx_group) SELECT CAST(id AS TEXT), type, amount, category, date, note, tx_group FROM transactions")
                db.execSQL("DROP TABLE transactions")
                db.execSQL("ALTER TABLE transactions_new RENAME TO transactions")

                // goals
                db.execSQL("""
                    CREATE TABLE goals_new (
                        id TEXT NOT NULL PRIMARY KEY,
                        type TEXT NOT NULL,
                        title TEXT NOT NULL,
                        target REAL NOT NULL,
                        current REAL NOT NULL DEFAULT 0.0,
                        deadline TEXT NOT NULL DEFAULT ''
                    )
                """.trimIndent())
                db.execSQL("INSERT INTO goals_new (id, type, title, target, current, deadline) SELECT CAST(id AS TEXT), type, title, target, current, deadline FROM goals")
                db.execSQL("DROP TABLE goals")
                db.execSQL("ALTER TABLE goals_new RENAME TO goals")

                // debts
                db.execSQL("""
                    CREATE TABLE debts_new (
                        id TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        amount REAL NOT NULL,
                        type TEXT NOT NULL,
                        dueDate TEXT NOT NULL DEFAULT '',
                        note TEXT NOT NULL DEFAULT '',
                        isSettled INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
                db.execSQL("INSERT INTO debts_new (id, name, amount, type, dueDate, note, isSettled) SELECT CAST(id AS TEXT), name, amount, type, dueDate, note, isSettled FROM debts")
                db.execSQL("DROP TABLE debts")
                db.execSQL("ALTER TABLE debts_new RENAME TO debts")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                listOf("transactions", "goals", "debts").forEach { t ->
                    db.execSQL("ALTER TABLE $t ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                    db.execSQL("ALTER TABLE $t ADD COLUMN deletedAt INTEGER")
                }
            }

        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE goals ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE debts ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE goals SET createdAt = updatedAt WHERE createdAt = 0")
                db.execSQL("UPDATE debts SET createdAt = updatedAt WHERE createdAt = 0")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("UPDATE goals SET updatedAt = createdAt WHERE updatedAt = 0 AND createdAt > 0")
                db.execSQL("UPDATE debts SET updatedAt = createdAt WHERE updatedAt = 0 AND createdAt > 0")
                db.execSQL("UPDATE transactions SET updatedAt = CAST(strftime('%s', 'now') AS INTEGER) * 1000 WHERE updatedAt = 0")
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS income_sources (
                        id TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        paymentMethod TEXT NOT NULL DEFAULT '',
                        createdAt INTEGER NOT NULL DEFAULT 0,
                        updatedAt INTEGER NOT NULL DEFAULT 0,
                        deletedAt INTEGER
                    )
                """.trimIndent())

                db.execSQL("ALTER TABLE transactions ADD COLUMN incomeSourceId TEXT")
                db.execSQL("ALTER TABLE transactions ADD COLUMN incomeSourceNameSnapshot TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE transactions ADD COLUMN paymentMethodSnapshot TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE transactions SET incomeSourceNameSnapshot = category WHERE type = 'income' AND incomeSourceNameSnapshot = ''")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS expense_beneficiaries (
                        id TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER
                    )
                """.trimIndent())

                db.execSQL("ALTER TABLE transactions ADD COLUMN purpose TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE transactions ADD COLUMN purposeKey TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE transactions ADD COLUMN expenseBeneficiaryId TEXT")
                db.execSQL("ALTER TABLE transactions ADD COLUMN expenseBeneficiaryNameSnapshot TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE transactions SET purpose = category WHERE type = 'expense' AND purpose = ''")
                db.execSQL("UPDATE transactions SET purposeKey = lower(trim(category)) WHERE type = 'expense' AND purposeKey = ''")
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS balance_transactions (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        direction TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        date TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        sourceType TEXT NOT NULL DEFAULT '',
                        sourceId TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        CHECK(length(operationId) > 0),
                        CHECK(direction IN ('inflow', 'outflow')),
                        CHECK(kind IN (
                            'income',
                            'manual_add',
                            'asset_sale',
                            'opening_balance',
                            'expense_payment',
                            'asset_purchase',
                            'asset_improvement',
                            'asset_maintenance',
                            'manual_withdrawal'
                        )),
                        CHECK(syncState IN (
                            'pending',
                            'synced',
                            'failed',
                            'conflict',
                            'incomplete_remote'
                        )),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS payments (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        date TEXT NOT NULL,
                        purpose TEXT NOT NULL DEFAULT '',
                        purposeKey TEXT NOT NULL DEFAULT '',
                        beneficiaryId TEXT,
                        beneficiaryNameSnapshot TEXT NOT NULL DEFAULT '',
                        assetId TEXT,
                        assetNameSnapshot TEXT NOT NULL DEFAULT '',
                        balanceTransactionId TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(balanceTransactionId) REFERENCES balance_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(kind IN (
                            'ordinary_expense',
                            'asset_purchase',
                            'asset_improvement',
                            'asset_maintenance',
                            'balance_withdrawal'
                        )),
                        CHECK(syncState IN (
                            'pending',
                            'synced',
                            'failed',
                            'conflict',
                            'incomplete_remote'
                        )),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_balance_transactions_operationId ON balance_transactions(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_balance_transactions_date_deletedAt ON balance_transactions(date, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_balance_transactions_sourceType_sourceId ON balance_transactions(sourceType, sourceId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_operationId ON payments(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_balanceTransactionId ON payments(balanceTransactionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_date_kind_deletedAt ON payments(date, kind, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_assetId ON payments(assetId)")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS assets (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT,
                        type TEXT NOT NULL,
                        name TEXT NOT NULL,
                        status TEXT NOT NULL DEFAULT 'active',
                        acquisitionMode TEXT NOT NULL,
                        acquisitionAmountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        purchasePaymentId TEXT,
                        purchaseBalanceTransactionId TEXT,
                        currentValueCacheDecimal TEXT,
                        currentValueCacheValuationId TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        CHECK(length(type) > 0),
                        CHECK(length(name) > 0),
                        CHECK(status IN ('active','sold','lost','damaged','disposed','transferred','archived')),
                        CHECK(acquisitionMode IN ('purchased_in_app','preexisting')),
                        CHECK(length(acquisitionAmountDecimal) > 0),
                        CHECK(length(currencyCode) > 0)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS asset_transactions (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        assetId TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT,
                        currencyQuantityDeltaDecimal TEXT,
                        paymentId TEXT,
                        balanceTransactionId TEXT,
                        date TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(assetId) REFERENCES assets(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(kind IN ('purchase','preexisting_add','improvement','maintenance','sale_full','sale_partial','lost','damaged','disposed','transferred','archived','reversal')),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS asset_valuations (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        assetId TEXT NOT NULL,
                        valueDecimal TEXT NOT NULL,
                        date TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(assetId) REFERENCES assets(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(length(valueDecimal) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_assets_operationId ON assets(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assets_status_deletedAt ON assets(status, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_assets_type ON assets(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_transactions_operationId ON asset_transactions(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_transactions_assetId_deletedAt ON asset_transactions(assetId, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_transactions_kind ON asset_transactions(kind)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_valuations_operationId ON asset_valuations(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_valuations_assetId_deletedAt ON asset_valuations(assetId, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_valuations_date_createdAt ON asset_valuations(date, createdAt)")
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS currency_asset_lots (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        assetId TEXT NOT NULL,
                        purchaseAssetTransactionId TEXT NOT NULL,
                        foreignCurrencyCode TEXT NOT NULL,
                        quantityPurchasedDecimal TEXT NOT NULL,
                        purchaseExchangeRateDecimal TEXT NOT NULL,
                        localCostDecimal TEXT NOT NULL,
                        purchaseDate TEXT NOT NULL,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(assetId) REFERENCES assets(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        FOREIGN KEY(purchaseAssetTransactionId) REFERENCES asset_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(length(foreignCurrencyCode) > 0),
                        CHECK(length(quantityPurchasedDecimal) > 0),
                        CHECK(length(purchaseExchangeRateDecimal) > 0),
                        CHECK(length(localCostDecimal) > 0),
                        CHECK(length(purchaseDate) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS currency_asset_sale_allocations (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        assetId TEXT NOT NULL,
                        saleAssetTransactionId TEXT NOT NULL,
                        lotId TEXT NOT NULL,
                        quantitySoldDecimal TEXT NOT NULL,
                        allocatedLocalCostDecimal TEXT NOT NULL,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(assetId) REFERENCES assets(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        FOREIGN KEY(saleAssetTransactionId) REFERENCES asset_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        FOREIGN KEY(lotId) REFERENCES currency_asset_lots(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(length(quantitySoldDecimal) > 0),
                        CHECK(length(allocatedLocalCostDecimal) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_currency_asset_lots_operationId ON currency_asset_lots(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_currency_asset_lots_assetId_purchaseDate_createdAt ON currency_asset_lots(assetId, purchaseDate, createdAt)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_currency_asset_lots_purchaseAssetTransactionId ON currency_asset_lots(purchaseAssetTransactionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_currency_asset_sale_allocations_operationId ON currency_asset_sale_allocations(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_currency_asset_sale_allocations_assetId_lotId ON currency_asset_sale_allocations(assetId, lotId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_currency_asset_sale_allocations_lotId ON currency_asset_sale_allocations(lotId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_currency_asset_sale_allocations_saleAssetTransactionId_lotId ON currency_asset_sale_allocations(saleAssetTransactionId, lotId)")
            }
        }

        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN operationId TEXT")
                db.execSQL("ALTER TABLE transactions ADD COLUMN balanceTransactionId TEXT")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_transactions_operationId ON transactions(operationId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_transactions_balanceTransactionId ON transactions(balanceTransactionId)")
            }
        }

        val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE balance_transactions_v14 (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        direction TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        date TEXT NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        sourceType TEXT NOT NULL DEFAULT '',
                        sourceId TEXT,
                        legacyTransactionId TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        CHECK(length(operationId) > 0),
                        CHECK(direction IN ('inflow', 'outflow')),
                        CHECK(kind IN (
                            'income','manual_add','asset_sale','opening_balance','opening_balance_adjustment',
                            'expense_payment','asset_purchase','asset_improvement','asset_maintenance','manual_withdrawal'
                        )),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote')),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO balance_transactions_v14 (
                        id, operationId, direction, kind, amountDecimal, currencyCode, date, note,
                        sourceType, sourceId, legacyTransactionId, syncState, createdAt, updatedAt, deletedAt
                    )
                    SELECT id, operationId, direction, kind, amountDecimal, currencyCode, date, note,
                        sourceType, sourceId, NULL, syncState, createdAt, updatedAt, deletedAt
                    FROM balance_transactions
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE payments_v14 (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        date TEXT NOT NULL,
                        purpose TEXT NOT NULL DEFAULT '',
                        purposeKey TEXT NOT NULL DEFAULT '',
                        beneficiaryId TEXT,
                        beneficiaryNameSnapshot TEXT NOT NULL DEFAULT '',
                        assetId TEXT,
                        assetNameSnapshot TEXT NOT NULL DEFAULT '',
                        balanceTransactionId TEXT NOT NULL,
                        legacyTransactionId TEXT,
                        note TEXT NOT NULL DEFAULT '',
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(balanceTransactionId) REFERENCES balance_transactions_v14(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(kind IN ('ordinary_expense','asset_purchase','asset_improvement','asset_maintenance','balance_withdrawal')),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote')),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO payments_v14 (
                        id, operationId, kind, amountDecimal, currencyCode, date, purpose, purposeKey,
                        beneficiaryId, beneficiaryNameSnapshot, assetId, assetNameSnapshot,
                        balanceTransactionId, legacyTransactionId, note, syncState, createdAt, updatedAt, deletedAt
                    )
                    SELECT id, operationId, kind, amountDecimal, currencyCode, date, purpose, purposeKey,
                        beneficiaryId, beneficiaryNameSnapshot, assetId, assetNameSnapshot,
                        balanceTransactionId, NULL, note, syncState, createdAt, updatedAt, deletedAt
                    FROM payments
                """.trimIndent())

                db.execSQL("DROP TABLE payments")
                db.execSQL("DROP TABLE balance_transactions")
                db.execSQL("ALTER TABLE balance_transactions_v14 RENAME TO balance_transactions")
                db.execSQL("ALTER TABLE payments_v14 RENAME TO payments")

                db.execSQL("CREATE INDEX index_balance_transactions_operationId ON balance_transactions(operationId)")
                db.execSQL("CREATE INDEX index_balance_transactions_date_deletedAt ON balance_transactions(date, deletedAt)")
                db.execSQL("CREATE INDEX index_balance_transactions_sourceType_sourceId ON balance_transactions(sourceType, sourceId)")
                db.execSQL("CREATE UNIQUE INDEX index_balance_transactions_legacyTransactionId ON balance_transactions(legacyTransactionId)")
                db.execSQL("CREATE INDEX index_payments_operationId ON payments(operationId)")
                db.execSQL("CREATE INDEX index_payments_balanceTransactionId ON payments(balanceTransactionId)")
                db.execSQL("CREATE UNIQUE INDEX index_payments_legacyTransactionId ON payments(legacyTransactionId)")
                db.execSQL("CREATE INDEX index_payments_date_kind_deletedAt ON payments(date, kind, deletedAt)")
                db.execSQL("CREATE INDEX index_payments_assetId ON payments(assetId)")

                db.execSQL("""
                    CREATE TABLE ledger_history_migrations (
                        migrationKey TEXT NOT NULL PRIMARY KEY,
                        plannerVersion INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        sourceFingerprint TEXT NOT NULL,
                        commitFingerprint TEXT NOT NULL,
                        candidateCount INTEGER NOT NULL,
                        incomeCount INTEGER NOT NULL,
                        expenseCount INTEGER NOT NULL,
                        historicalIncomeDecimal TEXT NOT NULL,
                        historicalExpenseDecimal TEXT NOT NULL,
                        targetBalanceDecimal TEXT NOT NULL,
                        adjustmentDecimal TEXT NOT NULL,
                        adjustmentBalanceTransactionId TEXT,
                        confirmedAt INTEGER NOT NULL,
                        completedAt INTEGER,
                        syncState TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX index_ledger_history_migrations_status_deletedAt ON ledger_history_migrations(status, deletedAt)")
                db.execSQL("CREATE INDEX index_ledger_history_migrations_updatedAt ON ledger_history_migrations(updatedAt)")
            }
        }

        val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS debt_accounts (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        direction TEXT NOT NULL,
                        partyName TEXT NOT NULL,
                        partyKey TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        description TEXT NOT NULL DEFAULT '',
                        dueDate TEXT,
                        confirmed INTEGER NOT NULL DEFAULT 1,
                        archivedAt INTEGER,
                        closedAt INTEGER,
                        closeReason TEXT,
                        legacyDebtId TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        CHECK(length(operationId) > 0),
                        CHECK(direction IN ('payable','receivable')),
                        CHECK(length(partyName) > 0),
                        CHECK(length(partyKey) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS debt_transactions (
                        id TEXT NOT NULL PRIMARY KEY,
                        accountId TEXT NOT NULL,
                        operationId TEXT NOT NULL,
                        type TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        occurredAt INTEGER NOT NULL,
                        note TEXT NOT NULL DEFAULT '',
                        reason TEXT,
                        originalTransactionId TEXT,
                        sourceType TEXT NOT NULL DEFAULT '',
                        sourceId TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(accountId) REFERENCES debt_accounts(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(accountId) > 0),
                        CHECK(length(operationId) > 0),
                        CHECK(type IN ('opening','increase','payment','collection','waiver','write_off','gift_conversion','offset','asset_settlement','split_out','split_in','merge_out','merge_in','transfer_out','transfer_in','reversal','correction')),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS debt_links (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        accountId TEXT NOT NULL,
                        debtTransactionId TEXT NOT NULL,
                        targetType TEXT NOT NULL,
                        targetId TEXT NOT NULL,
                        role TEXT NOT NULL,
                        amountDecimal TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(accountId) REFERENCES debt_accounts(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        FOREIGN KEY(debtTransactionId) REFERENCES debt_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(length(targetType) > 0),
                        CHECK(length(targetId) > 0),
                        CHECK(length(role) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS debt_schedules (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        accountId TEXT NOT NULL,
                        installmentNo INTEGER NOT NULL,
                        dueDate TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        status TEXT NOT NULL DEFAULT 'planned',
                        reminderBeforeDue INTEGER NOT NULL DEFAULT 1,
                        reminderOnDue INTEGER NOT NULL DEFAULT 1,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(accountId) REFERENCES debt_accounts(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(installmentNo > 0),
                        CHECK(length(dueDate) > 0),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(status IN ('planned','paid','skipped','cancelled')),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS debt_migration_reviews (
                        id TEXT NOT NULL PRIMARY KEY,
                        legacyDebtId TEXT NOT NULL,
                        proposedAccountId TEXT,
                        status TEXT NOT NULL DEFAULT 'pending',
                        reason TEXT NOT NULL,
                        legacyPayloadJson TEXT NOT NULL,
                        resolutionNote TEXT,
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        CHECK(length(legacyDebtId) > 0),
                        CHECK(status IN ('pending','approved','rejected','resolved')),
                        CHECK(length(reason) > 0),
                        CHECK(length(legacyPayloadJson) > 0),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote'))
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_accounts_direction_deletedAt ON debt_accounts(direction, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_accounts_partyKey ON debt_accounts(partyKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_accounts_operationId ON debt_accounts(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_accounts_syncState_updatedAt ON debt_accounts(syncState, updatedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_transactions_accountId_deletedAt ON debt_transactions(accountId, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_transactions_operationId ON debt_transactions(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_transactions_type ON debt_transactions(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_transactions_originalTransactionId ON debt_transactions(originalTransactionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_transactions_syncState_updatedAt ON debt_transactions(syncState, updatedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_links_accountId ON debt_links(accountId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_links_debtTransactionId ON debt_links(debtTransactionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_links_operationId ON debt_links(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_links_targetType_targetId ON debt_links(targetType, targetId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_links_syncState_updatedAt ON debt_links(syncState, updatedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_schedules_accountId_dueDate ON debt_schedules(accountId, dueDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_schedules_operationId ON debt_schedules(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_schedules_status_dueDate ON debt_schedules(status, dueDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_schedules_syncState_updatedAt ON debt_schedules(syncState, updatedAt)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_debt_migration_reviews_legacyDebtId ON debt_migration_reviews(legacyDebtId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_migration_reviews_status_updatedAt ON debt_migration_reviews(status, updatedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_debt_migration_reviews_syncState_updatedAt ON debt_migration_reviews(syncState, updatedAt)")
            }
        }

        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE payments_v16 (
                        id TEXT NOT NULL PRIMARY KEY,
                        operationId TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        amountDecimal TEXT NOT NULL,
                        currencyCode TEXT NOT NULL DEFAULT 'SDG',
                        date TEXT NOT NULL,
                        purpose TEXT NOT NULL DEFAULT '',
                        purposeKey TEXT NOT NULL DEFAULT '',
                        beneficiaryId TEXT,
                        beneficiaryNameSnapshot TEXT NOT NULL DEFAULT '',
                        assetId TEXT,
                        assetNameSnapshot TEXT NOT NULL DEFAULT '',
                        balanceTransactionId TEXT,
                        legacyTransactionId TEXT,
                        note TEXT NOT NULL DEFAULT '',
                        syncState TEXT NOT NULL DEFAULT 'pending',
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(balanceTransactionId) REFERENCES balance_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                        CHECK(length(operationId) > 0),
                        CHECK(kind IN ('ordinary_expense','asset_purchase','asset_improvement','asset_maintenance','balance_withdrawal','debt_gift')),
                        CHECK(syncState IN ('pending','synced','failed','conflict','incomplete_remote')),
                        CHECK(length(amountDecimal) > 0),
                        CHECK(length(currencyCode) > 0),
                        CHECK(length(date) > 0)
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO payments_v16 (
                        id, operationId, kind, amountDecimal, currencyCode, date, purpose, purposeKey,
                        beneficiaryId, beneficiaryNameSnapshot, assetId, assetNameSnapshot,
                        balanceTransactionId, legacyTransactionId, note, syncState, createdAt, updatedAt, deletedAt
                    )
                    SELECT id, operationId, kind, amountDecimal, currencyCode, date, purpose, purposeKey,
                        beneficiaryId, beneficiaryNameSnapshot, assetId, assetNameSnapshot,
                        balanceTransactionId, legacyTransactionId, note, syncState, createdAt, updatedAt, deletedAt
                    FROM payments
                """.trimIndent())
                db.execSQL("DROP TABLE payments")
                db.execSQL("ALTER TABLE payments_v16 RENAME TO payments")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_operationId ON payments(operationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_balanceTransactionId ON payments(balanceTransactionId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payments_legacyTransactionId ON payments(legacyTransactionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_date_kind_deletedAt ON payments(date, kind, deletedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_assetId ON payments(assetId)")
            }
        }

        val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP TABLE goals")

                financialGoalSchemaStatements.forEach(db::execSQL)
            }
        }

        val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val executor = SqlMigrationExecutor { sql, bindArgs ->
                    if (bindArgs.isEmpty()) db.execSQL(sql) else db.execSQL(sql, bindArgs)
                }
                Migration17To18Plan.migrate(executor, System.currentTimeMillis())
            }
        }

        val ALL_MIGRATIONS: Array<Migration> = arrayOf(
            MIGRATION_2_3,
            MIGRATION_3_4,
            MIGRATION_4_5,
            MIGRATION_5_6,
            MIGRATION_6_7,
            MIGRATION_7_8,
            MIGRATION_8_9,
            MIGRATION_9_10,
            MIGRATION_10_11,
            MIGRATION_11_12,
            MIGRATION_12_13,
            MIGRATION_13_14,
            MIGRATION_14_15,
            MIGRATION_15_16,
            MIGRATION_16_17,
            MIGRATION_17_18,
        )

        internal val financialGoalSchemaStatements = listOf(
            """
                CREATE TABLE IF NOT EXISTS financial_goals (
                    id TEXT NOT NULL PRIMARY KEY,
                    name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    lifecycleStatus TEXT NOT NULL,
                    healthStatus TEXT NOT NULL,
                    currencyCode TEXT NOT NULL,
                    startDate TEXT NOT NULL,
                    deadline TEXT NOT NULL,
                    timezoneId TEXT NOT NULL,
                    targetDecimal TEXT NOT NULL,
                    baselineDecimal TEXT,
                    targetPercentDecimal TEXT,
                    confirmationPeriods INTEGER NOT NULL,
                    costThreshold TEXT,
                    configJson TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    readyAt INTEGER,
                    completedAt INTEGER,
                    cancelledAt INTEGER,
                    archivedAt INTEGER,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_metrics (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    metricType TEXT NOT NULL,
                    windowType TEXT NOT NULL,
                    windowSize INTEGER NOT NULL,
                    baselineDecimal TEXT,
                    configJson TEXT NOT NULL,
                    ordinal INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_conditions (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    metricId TEXT,
                    kind TEXT NOT NULL,
                    operator TEXT NOT NULL,
                    valueDecimal TEXT,
                    required INTEGER NOT NULL,
                    configJson TEXT NOT NULL,
                    ordinal INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                    FOREIGN KEY(metricId) REFERENCES goal_metrics(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_scopes (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    dimension TEXT NOT NULL,
                    referenceId TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    effectiveFrom TEXT NOT NULL,
                    effectiveTo TEXT,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_funding_transactions (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    operationId TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    amountDecimal TEXT NOT NULL,
                    currencyCode TEXT NOT NULL,
                    balanceTransactionId TEXT,
                    relatedFundingTransactionId TEXT,
                    note TEXT NOT NULL,
                    occurredAt INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                    FOREIGN KEY(balanceTransactionId) REFERENCES balance_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                    FOREIGN KEY(relatedFundingTransactionId) REFERENCES goal_funding_transactions(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_cost_estimates (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    operationId TEXT NOT NULL,
                    minDecimal TEXT,
                    expectedDecimal TEXT NOT NULL,
                    safeDecimal TEXT NOT NULL,
                    currencyCode TEXT NOT NULL,
                    source TEXT NOT NULL,
                    note TEXT NOT NULL,
                    effectiveAt INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_evaluations (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    asOf INTEGER NOT NULL,
                    engineVersion TEXT NOT NULL,
                    inputFingerprint TEXT NOT NULL,
                    lifecycleStatus TEXT NOT NULL,
                    healthStatus TEXT NOT NULL,
                    measuredDecimal TEXT,
                    targetDecimal TEXT,
                    progressDecimal TEXT,
                    resultJson TEXT NOT NULL,
                    correctionOfId TEXT,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION,
                    FOREIGN KEY(correctionOfId) REFERENCES goal_evaluations(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS goal_activities (
                    id TEXT NOT NULL PRIMARY KEY,
                    goalId TEXT NOT NULL,
                    operationId TEXT NOT NULL,
                    type TEXT NOT NULL,
                    occurredAt INTEGER NOT NULL,
                    effectiveDate TEXT,
                    detailsJson TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    deletedAt INTEGER,
                    syncState TEXT NOT NULL,
                    FOREIGN KEY(goalId) REFERENCES financial_goals(id) ON UPDATE NO ACTION ON DELETE NO ACTION
                )
            """.trimIndent(),
            """
                CREATE TABLE IF NOT EXISTS financial_change_outbox (
                    eventId TEXT NOT NULL PRIMARY KEY,
                    sourceType TEXT NOT NULL,
                    sourceId TEXT NOT NULL,
                    operationId TEXT NOT NULL,
                    effectiveDate TEXT NOT NULL,
                    changedFields TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    processedAt INTEGER,
                    attemptCount INTEGER NOT NULL,
                    lastError TEXT
                )
            """.trimIndent(),
            "CREATE INDEX IF NOT EXISTS index_financial_goals_lifecycleStatus_deletedAt ON financial_goals(lifecycleStatus, deletedAt)",
            "CREATE INDEX IF NOT EXISTS index_goal_metrics_goalId_updatedAt ON goal_metrics(goalId, updatedAt)",
            "CREATE INDEX IF NOT EXISTS index_goal_conditions_goalId_updatedAt ON goal_conditions(goalId, updatedAt)",
            "CREATE INDEX IF NOT EXISTS index_goal_conditions_metricId ON goal_conditions(metricId)",
            "CREATE INDEX IF NOT EXISTS index_goal_scopes_goalId_updatedAt ON goal_scopes(goalId, updatedAt)",
            "CREATE INDEX IF NOT EXISTS index_goal_scopes_dimension_referenceId ON goal_scopes(dimension, referenceId)",
            "CREATE UNIQUE INDEX IF NOT EXISTS index_goal_scopes_goalId_dimension_referenceId_effectiveFrom ON goal_scopes(goalId, dimension, referenceId, effectiveFrom)",
            "CREATE INDEX IF NOT EXISTS index_goal_funding_transactions_goalId_updatedAt ON goal_funding_transactions(goalId, updatedAt)",
            "CREATE UNIQUE INDEX IF NOT EXISTS index_goal_funding_transactions_operationId ON goal_funding_transactions(operationId)",
            "CREATE INDEX IF NOT EXISTS index_goal_funding_transactions_balanceTransactionId ON goal_funding_transactions(balanceTransactionId)",
            "CREATE INDEX IF NOT EXISTS index_goal_funding_transactions_relatedFundingTransactionId ON goal_funding_transactions(relatedFundingTransactionId)",
            "CREATE INDEX IF NOT EXISTS index_goal_cost_estimates_goalId_updatedAt ON goal_cost_estimates(goalId, updatedAt)",
            "CREATE UNIQUE INDEX IF NOT EXISTS index_goal_cost_estimates_operationId ON goal_cost_estimates(operationId)",
            "CREATE INDEX IF NOT EXISTS index_goal_evaluations_goalId_updatedAt ON goal_evaluations(goalId, updatedAt)",
            "CREATE INDEX IF NOT EXISTS index_goal_evaluations_goalId_asOf ON goal_evaluations(goalId, asOf)",
            "CREATE UNIQUE INDEX IF NOT EXISTS index_goal_evaluations_goalId_inputFingerprint_engineVersion ON goal_evaluations(goalId, inputFingerprint, engineVersion)",
            "CREATE INDEX IF NOT EXISTS index_goal_evaluations_correctionOfId ON goal_evaluations(correctionOfId)",
            "CREATE INDEX IF NOT EXISTS index_goal_activities_goalId_updatedAt ON goal_activities(goalId, updatedAt)",
            "CREATE UNIQUE INDEX IF NOT EXISTS index_goal_activities_goalId_operationId_type ON goal_activities(goalId, operationId, type)",
            "CREATE INDEX IF NOT EXISTS index_financial_change_outbox_processedAt_createdAt ON financial_change_outbox(processedAt, createdAt)",
        )
    }
}

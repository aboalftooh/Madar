package com.shift.app.feature.session.domain

import kotlinx.coroutines.flow.Flow

enum class AppSessionSyncStatus {
    SUCCESS,
    PARTIAL_FAILURE,
    AUTHENTICATION_REQUIRED,
}

data class AppSessionSyncResult(
    val status: AppSessionSyncStatus,
    val failedSteps: List<String> = emptyList(),
)

interface AppSessionGateway {
    val lastSync: Flow<Long>
    val pendingSyncCount: Flow<Int>
    val failedSyncCount: Flow<Int>

    suspend fun initialSync(): AppSessionSyncResult?
    suspend fun syncNow(): AppSessionSyncResult
}

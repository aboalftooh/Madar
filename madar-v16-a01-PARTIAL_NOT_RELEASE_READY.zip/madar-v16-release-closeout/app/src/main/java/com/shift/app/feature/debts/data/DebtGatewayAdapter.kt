package com.shift.app.feature.debts.data

import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtMigrationReviewDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.remote.SyncManager
import com.shift.app.data.repository.DebtLedgerRepository
import com.shift.app.data.repository.DebtOrganizationRepository
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.feature.debts.domain.model.AccruedIncomeRequest
import com.shift.app.feature.debts.domain.model.AdjustDebtRequest
import com.shift.app.feature.debts.domain.model.ArchiveDebtRequest
import com.shift.app.feature.debts.domain.model.AssetSaleOnCreditRequest
import com.shift.app.feature.debts.domain.model.AssetSettlementRequest
import com.shift.app.feature.debts.domain.model.CashPrincipalRequest
import com.shift.app.feature.debts.domain.model.DebtCommandReceipt
import com.shift.app.feature.debts.domain.model.DebtSessionExpiredException
import com.shift.app.feature.debts.domain.model.DeferredExpenseRequest
import com.shift.app.feature.debts.domain.model.FinancedAssetPurchaseRequest
import com.shift.app.feature.debts.domain.model.OffsetDebtRequest
import com.shift.app.feature.debts.domain.model.OpenDebtRequest
import com.shift.app.feature.debts.domain.model.ReduceDebtRequest
import com.shift.app.feature.debts.domain.model.ReverseDebtTransactionRequest
import com.shift.app.feature.debts.domain.model.TransferDebtRequest
import com.shift.app.feature.debts.domain.model.WriteDebtScheduleRequest
import com.shift.app.feature.debts.domain.repository.DebtGateway
import com.shift.app.feature.debts.domain.repository.DebtGoalScopePort
import com.shift.app.feature.debts.domain.repository.DebtSettlementAssetQuery
import com.shift.app.sync.SyncQueueGateway
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.map

@Singleton
class DebtGatewayAdapter @Inject constructor(
    private val accountDao: DebtAccountDao,
    private val transactionDao: DebtTransactionDao,
    private val reviewDao: DebtMigrationReviewDao,
    private val settlementAssetQuery: DebtSettlementAssetQuery,
    private val ledgerRepository: DebtLedgerRepository,
    private val organizationRepository: DebtOrganizationRepository,
    private val goalScopePort: DebtGoalScopePort,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : DebtGateway {
    override fun observeAccounts() = accountDao.getActiveAccounts().map { rows -> rows.map(DebtEntityMapper::account) }
    override fun observeTransactions() = transactionDao.getActiveTransactions().map { rows -> rows.map(DebtEntityMapper::transaction) }
    override fun observeMigrationReviews() = reviewDao.getActiveReviews().map { rows -> rows.map(DebtEntityMapper::review) }
    override fun observeSettlementAssets() = settlementAssetQuery.observeAvailableAssets()

    override suspend fun open(request: OpenDebtRequest): DebtCommandReceipt = execute(request.operationId) {
        val records = ledgerRepository.openAccount(
            operationId = request.operationId,
            accountId = request.accountId,
            direction = request.direction,
            partyName = request.partyName,
            amountDecimal = request.amountDecimal,
            dueDate = request.dueDate?.takeIf(String::isNotBlank),
        )
        if (request.direction == DebtDirection.Payable) {
            goalScopePort.recordNewDebtDecision(
                accountId = records.account.id,
                include = request.includeInActivePayoffGoal,
                operationId = "debt-open-scope:${request.operationId}",
                now = System.currentTimeMillis(),
            )
        }
        records.account.id
    }

    override suspend fun recordCashPrincipal(request: CashPrincipalRequest) = execute(request.operationId) {
        ledgerRepository.recordCashPrincipal(
            operationId = request.operationId,
            accountId = request.accountId?.takeIf(String::isNotBlank) ?: request.newAccountId,
            direction = request.direction,
            partyName = request.partyName,
            amountDecimal = request.amountDecimal,
            cashSource = request.cashSource,
        ).account.id
    }

    override suspend fun recordDeferredExpense(request: DeferredExpenseRequest) = execute(request.operationId) {
        ledgerRepository.recordDeferredExpense(
            request.operationId, request.accountId, request.partyName, request.amountDecimal, request.purpose, note = request.note,
        ).account.id
    }

    override suspend fun recordAccruedIncome(request: AccruedIncomeRequest) = execute(request.operationId) {
        ledgerRepository.recordAccruedIncome(
            request.operationId, request.accountId, request.partyName, request.amountDecimal, request.incomeCategory, note = request.note,
        ).account.id
    }

    override suspend fun recordFinancedAssetPurchase(request: FinancedAssetPurchaseRequest) = execute(request.operationId) {
        ledgerRepository.recordFinancedAssetPurchase(
            operationId = request.operationId,
            accountId = request.accountId,
            assetId = request.assetId,
            partyName = request.partyName,
            assetType = request.assetType,
            assetName = request.assetName,
            financedAmountDecimal = request.financedAmountDecimal,
            assetValueDecimal = request.assetValueDecimal,
            cashPaidDecimal = request.cashPaidDecimal,
        ).account.id
    }

    override suspend fun recordAssetSaleOnCredit(request: AssetSaleOnCreditRequest) = execute(request.operationId) {
        ledgerRepository.recordAssetSaleOnCredit(
            operationId = request.operationId,
            accountId = request.accountId,
            assetId = request.assetId,
            buyerName = request.buyerName,
            saleAmountDecimal = request.saleAmountDecimal,
            cashCollectedDecimal = request.cashCollectedDecimal,
        ).account.id
    }

    override suspend fun reduce(request: ReduceDebtRequest) = execute(request.operationId) {
        ledgerRepository.recordReduction(request.operationId, request.accountId, request.amountDecimal, request.cashSource).account.id
    }

    override suspend fun adjust(request: AdjustDebtRequest) = execute(request.operationId) {
        ledgerRepository.recordAdjustment(request.operationId, request.accountId, request.type, request.amountDecimal, request.reason).account.id
    }

    override suspend fun settleWithAsset(request: AssetSettlementRequest) = execute(request.operationId) {
        ledgerRepository.recordAssetSettlement(
            request.operationId, request.accountId, request.assetId, request.amountDecimal, request.assetValueDecimal, reason = request.reason,
        ).account.id
    }

    override suspend fun offset(request: OffsetDebtRequest) = execute(request.operationId) {
        ledgerRepository.recordOffset(
            request.operationId, request.payableAccountId, request.receivableAccountId, request.amountDecimal, request.reason,
        )
        request.payableAccountId
    }

    override suspend fun reverse(request: ReverseDebtTransactionRequest) = execute(request.operationId) {
        ledgerRepository.reverseDebtTransaction(request.operationId, request.originalTransactionId, request.reason).account.id
    }

    override suspend fun transfer(request: TransferDebtRequest) = execute(request.operationId) {
        organizationRepository.transferToNewParty(
            request.operationId, request.accountId, request.targetAccountId, request.newPartyName, request.amountDecimal, reason = request.reason,
        )
        request.targetAccountId
    }

    override suspend fun writeSchedule(request: WriteDebtScheduleRequest) = execute(request.operationId) {
        organizationRepository.writeSchedule(
            request.operationId, request.accountId, request.totalAmountDecimal, request.firstDueDate, request.count,
        )
        request.accountId
    }

    override suspend fun archive(request: ArchiveDebtRequest) = execute(request.operationId) {
        organizationRepository.archiveAccount(request.accountId, request.reason).id
    }

    private suspend fun execute(operationId: String, block: suspend () -> String?): DebtCommandReceipt {
        val accountId = syncManager.executeSessionOperation(block) ?: throw DebtSessionExpiredException()
        val syncRequested = runCatching {
            syncQueue.requestSync(reason = "debt:$operationId", operationId = operationId)
        }.isSuccess
        return DebtCommandReceipt(operationId, accountId, syncRequested)
    }
}

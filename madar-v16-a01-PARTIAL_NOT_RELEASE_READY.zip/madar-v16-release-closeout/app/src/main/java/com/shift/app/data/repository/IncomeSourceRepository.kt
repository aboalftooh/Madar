package com.shift.app.data.repository

import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.domain.finance.SyncState
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class IncomeSourceRepository @Inject constructor(private val dao: IncomeSourceDao) {
    fun getAll(): Flow<List<IncomeSource>> = dao.getAll()
    suspend fun getAllOnce(): List<IncomeSource> = dao.getAllOnce()
    suspend fun getActiveOnce(): List<IncomeSource> = dao.getActiveOnce()
    suspend fun getById(id: String): IncomeSource? = dao.getById(id)
    suspend fun insert(source: IncomeSource) = dao.insert(source.copy(syncState = SyncState.Pending.dbValue))
    suspend fun update(source: IncomeSource) = dao.update(source.copy(syncState = SyncState.Pending.dbValue))
    suspend fun upsertAll(items: List<IncomeSource>) = dao.upsertAll(items.map { it.copy(syncState = SyncState.Pending.dbValue) })
    suspend fun deleteAll() = dao.deleteAll()
    fun paymentMethodSuggestions(): Flow<List<String>> = dao.paymentMethodSuggestions()
}

package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.LedgerHistoryMigration
import kotlinx.coroutines.flow.Flow

@Dao
interface LedgerHistoryMigrationDao {
    @Query("SELECT * FROM ledger_history_migrations WHERE migrationKey = :key LIMIT 1")
    fun observe(key: String): Flow<LedgerHistoryMigration?>

    @Query("SELECT * FROM ledger_history_migrations WHERE migrationKey = :key LIMIT 1")
    suspend fun getByKey(key: String): LedgerHistoryMigration?

    @Query("SELECT * FROM ledger_history_migrations")
    suspend fun getAllOnce(): List<LedgerHistoryMigration>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: LedgerHistoryMigration)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<LedgerHistoryMigration>)

    @Update
    suspend fun update(item: LedgerHistoryMigration)

    @Query("DELETE FROM ledger_history_migrations WHERE migrationKey = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM ledger_history_migrations")
    suspend fun deleteAll()
}

package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.DebtAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtAccountDao {
    @Query("SELECT * FROM debt_accounts WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun getActiveAccounts(): Flow<List<DebtAccount>>

    @Query("SELECT * FROM debt_accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DebtAccount?

    @Query("SELECT * FROM debt_accounts WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<DebtAccount>

    @Query("SELECT * FROM debt_accounts WHERE legacyDebtId = :legacyDebtId LIMIT 1")
    suspend fun getByLegacyDebtId(legacyDebtId: String): DebtAccount?

    @Query("SELECT * FROM debt_accounts WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<DebtAccount>

    @Query("SELECT * FROM debt_accounts WHERE legacyDebtId IS NOT NULL ORDER BY legacyDebtId ASC")
    suspend fun getLegacyMigrationAccounts(): List<DebtAccount>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: DebtAccount)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(accounts: List<DebtAccount>)

    @Update
    suspend fun update(account: DebtAccount)

    @Query("DELETE FROM debt_accounts WHERE id = :id")
    suspend fun hardDeleteById(id: String)

    @Query("DELETE FROM debt_accounts")
    suspend fun deleteAll()
}

package com.shift.app.feature.session.data

import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.SyncRunResult
import com.shift.app.feature.session.domain.AppSessionGateway
import com.shift.app.feature.session.domain.AppSessionSyncResult
import com.shift.app.feature.session.domain.AppSessionSyncStatus
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.utils.PreferencesManager
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppSessionGatewayAdapter @Inject constructor(
    private val preferences: PreferencesManager,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
    private val legacyIncomeSourceMigrator: LegacyIncomeSourceMigrator,
) : AppSessionGateway {
    override val lastSync: Flow<Long> = preferences.lastSync
    override val pendingSyncCount: Flow<Int> = syncQueue.pendingCount
    override val failedSyncCount: Flow<Int> = syncQueue.failedCount

    override suspend fun initialSync(): AppSessionSyncResult? =
        syncManager.initialSyncOnce { legacyIncomeSourceMigrator.migrateIfNeeded() }?.toSessionResult()

    override suspend fun syncNow(): AppSessionSyncResult = syncManager.syncAll().toSessionResult()

    private fun SyncRunResult.toSessionResult(): AppSessionSyncResult = when (this) {
        is SyncRunResult.Success -> AppSessionSyncResult(AppSessionSyncStatus.SUCCESS)
        is SyncRunResult.PartialFailure -> AppSessionSyncResult(
            status = AppSessionSyncStatus.PARTIAL_FAILURE,
            failedSteps = failedSteps.map { it.toString() },
        )
        SyncRunResult.AuthenticationRequired -> AppSessionSyncResult(AppSessionSyncStatus.AUTHENTICATION_REQUIRED)
    }
}

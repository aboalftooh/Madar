package com.shift.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.data.local.entities.Payment
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.ui.theme.*
import com.shift.app.utils.FinancialInput
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.feature.assets.presentation.AssetsViewModel
import com.shift.app.viewmodel.PaymentsViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset

@Composable
fun PaymentsDetails(
    vm: PaymentsViewModel = hiltViewModel(),
    assetsVm: AssetsViewModel = hiltViewModel(),
    month: YearMonth,
    openEditorSignal: Int = 0,
    onEditorConsumed: () -> Unit = {}
) {
    val payments by vm.payments.collectAsState()
    val paymentActionState by vm.actionState.collectAsState()
    val assets by assetsVm.assets.collectAsState()
    val assetActionState by assetsVm.actionState.collectAsState()
    var editing by remember { mutableStateOf<Payment?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var awaitingPaymentSave by remember { mutableStateOf(false) }
    var awaitingAssetSave by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(openEditorSignal) {
        if (openEditorSignal > 0) {
            editing = null
            showEditor = true
            onEditorConsumed()
        }
    }

    LaunchedEffect(paymentActionState.message, paymentActionState.error) {
        val feedback = paymentActionState.error ?: paymentActionState.message ?: return@LaunchedEffect
        if (awaitingPaymentSave && paymentActionState.message != null) {
            showEditor = false
            awaitingPaymentSave = false
        } else if (paymentActionState.error != null) {
            awaitingPaymentSave = false
        }
        snackbarHostState.showSnackbar(feedback)
        vm.clearActionMessage()
    }

    LaunchedEffect(assetActionState.message, assetActionState.error) {
        val feedback = assetActionState.error ?: assetActionState.message ?: return@LaunchedEffect
        if (awaitingAssetSave && assetActionState.message != null) {
            showEditor = false
            awaitingAssetSave = false
        } else if (assetActionState.error != null) {
            awaitingAssetSave = false
        }
        snackbarHostState.showSnackbar(feedback)
        assetsVm.clearActionMessage()
    }

    val saving = awaitingPaymentSave || awaitingAssetSave || paymentActionState.busy || assetActionState.busy
    val visiblePayments = remember(payments, month) {
        payments
            .filter {
                runCatching { YearMonth.from(LocalDate.parse(it.date)) }.getOrNull() == month
            }
            .distinctBy { it.operationId }
    }

    Box(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (visiblePayments.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    Text("لا توجد مدفوعات في هذا الشهر", color = TextMuted, fontFamily = CairoFamily)
                }
            }

            visiblePayments.forEach { payment ->
                key(payment.id) {
                    PaymentRow(
                        payment = payment,
                        onEdit = if (
                            payment.kind == PaymentKind.AssetPurchase.dbValue &&
                            assets.firstOrNull { it.id == payment.assetId }?.type == FOREIGN_CURRENCY_ASSET_TYPE
                        ) null else ({
                            editing = payment
                            showEditor = true
                        }),
                        onDelete = {
                            if (payment.kind in assetPaymentKinds) assetsVm.deleteOperation(payment.operationId)
                            else vm.deletePayment(payment)
                        }
                    )
                }
            }
        }

        SnackbarHost(snackbarHostState, Modifier.align(Alignment.TopCenter).padding(16.dp))
        if ((paymentActionState.busy || assetActionState.busy) && !showEditor) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = GoldPrimary)
        }
    }

    if (showEditor) {
        PaymentEditorDialog(
            payment = editing,
            assets = assets.filter { it.status == AssetStatus.Active.dbValue },
            saving = saving,
            onDismiss = {
                if (!saving) showEditor = false
            },
            onSave = { result ->
                if (saving) return@PaymentEditorDialog
                val current = editing
                val usesAssetOperation = result.kind in setOf(
                    PaymentKind.AssetPurchase,
                    PaymentKind.AssetImprovement,
                    PaymentKind.AssetMaintenance
                )
                if (usesAssetOperation) awaitingAssetSave = true else awaitingPaymentSave = true

                if (current == null) {
                    when (result.kind) {
                        PaymentKind.AssetPurchase -> if (result.assetType == FOREIGN_CURRENCY_ASSET_TYPE) {
                            assetsVm.purchaseCurrencyAsset(
                                result.assetName,
                                result.currencyCode,
                                result.quantity,
                                result.exchangeRate,
                                result.amount,
                                result.date,
                                result.note
                            )
                        } else {
                            assetsVm.purchaseAsset(
                                result.assetName,
                                result.assetType,
                                result.amount,
                                result.date,
                                result.note
                            )
                        }
                        PaymentKind.AssetImprovement -> {
                            val asset = assets.firstOrNull { it.id == result.assetId }
                            if (asset == null) {
                                awaitingAssetSave = false
                            } else {
                                assetsVm.improveAsset(asset, result.amount, result.purpose, result.date, result.note)
                            }
                        }
                        PaymentKind.AssetMaintenance -> {
                            val asset = assets.firstOrNull { it.id == result.assetId }
                            if (asset == null) {
                                awaitingAssetSave = false
                            } else {
                                assetsVm.maintainAsset(asset, result.amount, result.purpose, result.date, result.note)
                            }
                        }
                        else -> vm.addPayment(result.kind, result.amount, result.purpose, result.note, result.date)
                    }
                } else {
                    when (result.kind) {
                        PaymentKind.AssetPurchase -> {
                            val asset = assets.firstOrNull { it.id == current.assetId }
                            if (asset == null) {
                                awaitingAssetSave = false
                            } else {
                                assetsVm.updateAcquisition(
                                    asset,
                                    result.assetName.ifBlank { asset.name },
                                    result.assetType.ifBlank { asset.type },
                                    result.amount
                                )
                            }
                        }
                        PaymentKind.AssetImprovement,
                        PaymentKind.AssetMaintenance -> assetsVm.updatePaymentEvent(
                            current.operationId,
                            result.amount,
                            result.purpose,
                            result.date,
                            result.note
                        )
                        else -> vm.replacePayment(
                            current,
                            result.kind,
                            result.amount,
                            result.purpose,
                            result.note,
                            result.date
                        )
                    }
                }
            }
        )
    }
}

private data class PaymentStyle(val color: Color, val pointsUp: Boolean)

@Composable
private fun PaymentRow(payment: Payment, onEdit: (() -> Unit)?, onDelete: () -> Unit) {
    val style = paymentStyle(payment.kind)
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .background(style.color.copy(alpha = 0.15f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (style.pointsUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = style.color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(paymentKindLabel(payment.kind), color = TextPrimary, fontWeight = FontWeight.SemiBold, fontFamily = CairoFamily)
                if (payment.purpose.isNotBlank()) {
                    Text(payment.purpose, color = TextMuted, fontSize = 12.sp, fontFamily = CairoFamily)
                }
                Text(payment.date, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                if (payment.note.isNotBlank()) {
                    Text(payment.note, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                }
            }
            Text(
                "${NumberDisplayFormatter.formatDecimalText(payment.amountDecimal, useGrouping = true, absolute = true)} ${payment.currencyCode}",
                color = style.color,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily
            )
            onEdit?.let {
                IconButton(onClick = it) { Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = TextMuted) }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextMuted) }
        }
    }
}

private fun paymentStyle(kind: String): PaymentStyle = when (kind) {
    PaymentKind.AssetPurchase.dbValue,
    PaymentKind.AssetImprovement.dbValue -> PaymentStyle(AccentBlue, true)
    PaymentKind.OrdinaryExpense.dbValue,
    PaymentKind.AssetMaintenance.dbValue,
    PaymentKind.BalanceWithdrawal.dbValue -> PaymentStyle(ExpenseRed, false)
    else -> PaymentStyle(ExpenseRed, false)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaymentEditorDialog(
    payment: Payment?,
    assets: List<Asset>,
    saving: Boolean,
    onDismiss: () -> Unit,
    onSave: (PaymentEditorResult) -> Unit
) {
    var kind by remember(payment) { mutableStateOf(payment?.kind.toPaymentKind()) }
    var amount by remember(payment) { mutableStateOf(payment?.amountDecimal?.substringBefore('.').orEmpty()) }
    var purpose by remember(payment) { mutableStateOf(payment?.purpose.orEmpty()) }
    var note by remember(payment) { mutableStateOf(payment?.note.orEmpty()) }
    var date by remember(payment) { mutableStateOf(payment?.date ?: LocalDate.now().toString()) }
    var assetId by remember(payment) { mutableStateOf(payment?.assetId) }
    val linkedAsset = assets.firstOrNull { it.id == payment?.assetId }
    var assetName by remember(payment) { mutableStateOf(linkedAsset?.name ?: payment?.assetNameSnapshot.orEmpty()) }
    var assetType by remember(payment) { mutableStateOf(linkedAsset?.type ?: "other") }
    var currencyCode by remember(payment) {
        mutableStateOf(linkedAsset?.currencyCode?.takeIf { linkedAsset.type == FOREIGN_CURRENCY_ASSET_TYPE } ?: "USD")
    }
    var quantity by remember(payment) { mutableStateOf("") }
    var exchangeRate by remember(payment) { mutableStateOf("") }
    var assetMenu by remember { mutableStateOf(false) }
    var typeMenu by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var amountError by remember { mutableStateOf("") }
    var purposeError by remember { mutableStateOf("") }
    var assetError by remember { mutableStateOf("") }
    var assetNameError by remember { mutableStateOf("") }
    var currencyError by remember { mutableStateOf("") }
    var quantityError by remember { mutableStateOf("") }
    var exchangeRateError by remember { mutableStateOf("") }
    var dateError by remember { mutableStateOf("") }
    val canChangeKind = payment == null
    val focusManager = LocalFocusManager.current
    val assetNameFocus = remember { FocusRequester() }
    val currencyFocus = remember { FocusRequester() }
    val quantityFocus = remember { FocusRequester() }
    val exchangeRateFocus = remember { FocusRequester() }
    val purposeFocus = remember { FocusRequester() }
    val noteFocus = remember { FocusRequester() }
    val initialDateMillis = remember(date) {
        runCatching { LocalDate.parse(date).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
    }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialDateMillis)

    fun openDatePicker() {
        focusManager.clearFocus()
        showDatePicker = true
    }

    fun submit() {
        if (saving) return
        amountError = if (FinancialInput.isPositiveEnglishAmount(amount)) "" else "أدخل مبلغاً أكبر من صفر"
        assetNameError = if (kind == PaymentKind.AssetPurchase && assetName.trim().isEmpty()) "اسم الأصل مطلوب" else ""
        assetError = if (
            (kind == PaymentKind.AssetImprovement || kind == PaymentKind.AssetMaintenance) && assetId == null
        ) "اختر الأصل" else ""
        purposeError = if (
            kind in setOf(PaymentKind.OrdinaryExpense, PaymentKind.AssetImprovement, PaymentKind.AssetMaintenance) && purpose.trim().isEmpty()
        ) "الغرض أو الوصف مطلوب" else ""
        currencyError = if (
            kind == PaymentKind.AssetPurchase && assetType == FOREIGN_CURRENCY_ASSET_TYPE &&
            (currencyCode.length !in 3..4 || !currencyCode.all { it in 'A'..'Z' })
        ) "أدخل رمز عملة إنجليزي صحيح" else ""
        quantityError = if (
            kind == PaymentKind.AssetPurchase && assetType == FOREIGN_CURRENCY_ASSET_TYPE &&
            !FinancialInput.isPositiveEnglishAmount(quantity)
        ) "أدخل كمية أكبر من صفر" else ""
        exchangeRateError = if (
            kind == PaymentKind.AssetPurchase && assetType == FOREIGN_CURRENCY_ASSET_TYPE &&
            !FinancialInput.isPositiveEnglishAmount(exchangeRate)
        ) "أدخل سعر صرف أكبر من صفر" else ""
        dateError = if (runCatching { LocalDate.parse(date) }.isSuccess) "" else "اختر تاريخاً صحيحاً"

        if (listOf(
                amountError,
                assetNameError,
                assetError,
                purposeError,
                currencyError,
                quantityError,
                exchangeRateError,
                dateError
            ).all { it.isEmpty() }
        ) {
            focusManager.clearFocus()
            onSave(
                PaymentEditorResult(
                    kind = kind,
                    amount = amount,
                    purpose = purpose.trim(),
                    note = note.trim(),
                    date = date,
                    assetId = assetId,
                    assetName = assetName.trim(),
                    assetType = assetType,
                    currencyCode = currencyCode,
                    quantity = quantity,
                    exchangeRate = exchangeRate
                )
            )
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .imePadding()
                .heightIn(max = 700.dp),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceDark
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (payment == null) "إضافة مدفوعة" else "تعديل المدفوعة",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = CairoFamily
                )

                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = kind == PaymentKind.OrdinaryExpense,
                            enabled = canChangeKind && !saving,
                            onClick = { kind = PaymentKind.OrdinaryExpense },
                            label = { Text("مصروف") }
                        )
                        FilterChip(
                            selected = kind == PaymentKind.BalanceWithdrawal,
                            enabled = canChangeKind && !saving,
                            onClick = { kind = PaymentKind.BalanceWithdrawal },
                            label = { Text("سحب") }
                        )
                        FilterChip(
                            selected = kind == PaymentKind.AssetPurchase,
                            enabled = canChangeKind && !saving,
                            onClick = { kind = PaymentKind.AssetPurchase },
                            label = { Text("شراء أصل") }
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = kind == PaymentKind.AssetImprovement,
                            enabled = canChangeKind && !saving,
                            onClick = { kind = PaymentKind.AssetImprovement },
                            label = { Text("تحسين") }
                        )
                        FilterChip(
                            selected = kind == PaymentKind.AssetMaintenance,
                            enabled = canChangeKind && !saving,
                            onClick = { kind = PaymentKind.AssetMaintenance },
                            label = { Text("صيانة") }
                        )
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = {
                            amount = FinancialInput.englishDigitsOnly(it)
                            amountError = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = {
                            Text(
                                if (assetType == FOREIGN_CURRENCY_ASSET_TYPE && kind == PaymentKind.AssetPurchase) {
                                    "التكلفة المحلية (SDG)"
                                } else {
                                    "المبلغ"
                                }
                            )
                        },
                        singleLine = true,
                        enabled = !saving,
                        isError = amountError.isNotEmpty(),
                        supportingText = if (amountError.isNotEmpty()) {{ Text(amountError) }} else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = {
                            when (kind) {
                                PaymentKind.AssetPurchase -> assetNameFocus.requestFocus()
                                PaymentKind.OrdinaryExpense,
                                PaymentKind.AssetImprovement,
                                PaymentKind.AssetMaintenance,
                                PaymentKind.DebtGift -> purposeFocus.requestFocus()
                                PaymentKind.BalanceWithdrawal -> openDatePicker()
                            }
                        })
                    )

                    if (kind == PaymentKind.AssetPurchase) {
                        OutlinedTextField(
                            value = assetName,
                            onValueChange = { assetName = it; assetNameError = "" },
                            modifier = Modifier.fillMaxWidth().focusRequester(assetNameFocus),
                            label = { Text("اسم الأصل") },
                            singleLine = true,
                            enabled = !saving,
                            isError = assetNameError.isNotEmpty(),
                            supportingText = if (assetNameError.isNotEmpty()) {{ Text(assetNameError) }} else null,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(onNext = {
                                if (assetType == FOREIGN_CURRENCY_ASSET_TYPE) currencyFocus.requestFocus() else openDatePicker()
                            })
                        )
                        Box {
                            TextButton(onClick = { typeMenu = true }, enabled = !saving) {
                                Text("نوع الأصل: ${assetTypeLabel(assetType)}")
                            }
                            DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                                listOf("car", "real_estate", "gold", "foreign_currency", "laptop", "phone", "other").forEach { type ->
                                    DropdownMenuItem(
                                        text = { Text(assetTypeLabel(type)) },
                                        onClick = { assetType = type; typeMenu = false }
                                    )
                                }
                            }
                        }
                        if (assetType == FOREIGN_CURRENCY_ASSET_TYPE) {
                            OutlinedTextField(
                                value = currencyCode,
                                onValueChange = {
                                    currencyCode = it.uppercase().filter { char -> char in 'A'..'Z' }.take(4)
                                    currencyError = ""
                                },
                                modifier = Modifier.fillMaxWidth().focusRequester(currencyFocus),
                                label = { Text("رمز العملة الأجنبية") },
                                singleLine = true,
                                enabled = !saving,
                                isError = currencyError.isNotEmpty(),
                                supportingText = if (currencyError.isNotEmpty()) {{ Text(currencyError) }} else null,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { quantityFocus.requestFocus() })
                            )
                            OutlinedTextField(
                                value = quantity,
                                onValueChange = {
                                    quantity = FinancialInput.englishDigitsOnly(it)
                                    quantityError = ""
                                },
                                modifier = Modifier.fillMaxWidth().focusRequester(quantityFocus),
                                label = { Text("الكمية المشتراة") },
                                singleLine = true,
                                enabled = !saving,
                                isError = quantityError.isNotEmpty(),
                                supportingText = if (quantityError.isNotEmpty()) {{ Text(quantityError) }} else null,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { exchangeRateFocus.requestFocus() })
                            )
                            OutlinedTextField(
                                value = exchangeRate,
                                onValueChange = {
                                    exchangeRate = FinancialInput.englishDigitsOnly(it)
                                    exchangeRateError = ""
                                },
                                modifier = Modifier.fillMaxWidth().focusRequester(exchangeRateFocus),
                                label = { Text("سعر الصرف عند الشراء") },
                                singleLine = true,
                                enabled = !saving,
                                isError = exchangeRateError.isNotEmpty(),
                                supportingText = if (exchangeRateError.isNotEmpty()) {{ Text(exchangeRateError) }} else null,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { openDatePicker() })
                            )
                            Text("تغير سعر الصرف لا يسجل دخلاً أو مصروفاً", color = TextMuted, fontSize = 11.sp)
                        }
                    }

                    if (kind == PaymentKind.AssetImprovement || kind == PaymentKind.AssetMaintenance) {
                        Box {
                            TextButton(onClick = { assetMenu = true }, enabled = !saving) {
                                Text("الأصل: ${assets.firstOrNull { it.id == assetId }?.name ?: "اختر أصلاً"}")
                            }
                            DropdownMenu(expanded = assetMenu, onDismissRequest = { assetMenu = false }) {
                                assets.forEach { asset ->
                                    DropdownMenuItem(
                                        text = { Text(asset.name) },
                                        onClick = { assetId = asset.id; assetError = ""; assetMenu = false }
                                    )
                                }
                            }
                        }
                        if (assetError.isNotEmpty()) Text(assetError, color = ExpenseRed, fontSize = 12.sp)
                    }

                    if (kind != PaymentKind.AssetPurchase && kind != PaymentKind.BalanceWithdrawal) {
                        OutlinedTextField(
                            value = purpose,
                            onValueChange = { purpose = it; purposeError = "" },
                            modifier = Modifier.fillMaxWidth().focusRequester(purposeFocus),
                            label = { Text("الغرض") },
                            singleLine = true,
                            enabled = !saving,
                            isError = purposeError.isNotEmpty(),
                            supportingText = if (purposeError.isNotEmpty()) {{ Text(purposeError) }} else null,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(onNext = { openDatePicker() })
                        )
                    }

                    Box {
                        OutlinedTextField(
                            value = date,
                            onValueChange = {},
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("التاريخ") },
                            readOnly = true,
                            enabled = !saving,
                            isError = dateError.isNotEmpty(),
                            supportingText = if (dateError.isNotEmpty()) {{ Text(dateError) }} else null,
                            trailingIcon = { Icon(Icons.Default.DateRange, contentDescription = "اختر التاريخ") }
                        )
                        Box(
                            Modifier
                                .matchParentSize()
                                .clickable(enabled = !saving) { showDatePicker = true }
                        )
                    }

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        modifier = Modifier.fillMaxWidth().focusRequester(noteFocus),
                        label = { Text("ملاحظات (اختياري)") },
                        enabled = !saving,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { submit() })
                    )

                    if (kind == PaymentKind.AssetMaintenance) {
                        Text("يُسجل الأصل تلقائياً كمرجع المستفيد", color = TextMuted, fontSize = 11.sp)
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, enabled = !saving) { Text("إلغاء", color = TextMuted) }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { submit() }, enabled = !saving) {
                        if (saving) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Text("حفظ")
                        }
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        date = Instant.ofEpochMilli(millis).atZone(ZoneId.of("UTC")).toLocalDate().toString()
                        dateError = ""
                    }
                    showDatePicker = false
                    noteFocus.requestFocus()
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

private fun String?.toPaymentKind(): PaymentKind = when (this) {
    PaymentKind.BalanceWithdrawal.dbValue -> PaymentKind.BalanceWithdrawal
    PaymentKind.AssetPurchase.dbValue -> PaymentKind.AssetPurchase
    PaymentKind.AssetImprovement.dbValue -> PaymentKind.AssetImprovement
    PaymentKind.AssetMaintenance.dbValue -> PaymentKind.AssetMaintenance
    else -> PaymentKind.OrdinaryExpense
}

private data class PaymentEditorResult(
    val kind: PaymentKind,
    val amount: String,
    val purpose: String,
    val note: String,
    val date: String,
    val assetId: String?,
    val assetName: String,
    val assetType: String,
    val currencyCode: String,
    val quantity: String,
    val exchangeRate: String
)

private val assetPaymentKinds = setOf(
    PaymentKind.AssetPurchase.dbValue,
    PaymentKind.AssetImprovement.dbValue,
    PaymentKind.AssetMaintenance.dbValue
)

private fun paymentKindLabel(kind: String): String = when (kind) {
    PaymentKind.OrdinaryExpense.dbValue -> "مصروف"
    PaymentKind.BalanceWithdrawal.dbValue -> "سحب رصيد يدوي"
    PaymentKind.AssetPurchase.dbValue -> "شراء أصل"
    PaymentKind.AssetImprovement.dbValue -> "تحسين أصل"
    PaymentKind.AssetMaintenance.dbValue -> "صيانة أصل"
    else -> kind
}

package com.shift.app.feature.backup.data

import com.shift.app.feature.backup.domain.model.BackupImportMode
import org.json.JSONObject

internal interface BackupSectionSnapshot {
    val rowCount: Int
}

internal interface BackupSectionPlan {
    val importedRowCount: Int
    val affectedRowCount: Int
    val deleteCount: Int
}

internal interface BackupSectionCodec {
    val id: String

    suspend fun writeExport(root: JSONObject)

    /** Decodes and validates only this feature-owned section. */
    fun decode(root: JSONObject, now: Long): BackupSectionSnapshot

    /** Reads current storage and produces an immutable restore plan. */
    suspend fun plan(
        imported: BackupSectionSnapshot,
        mode: BackupImportMode,
        now: Long,
    ): BackupSectionPlan

    /** Called only inside the application restore transaction. */
    suspend fun apply(plan: BackupSectionPlan)

    /** Optional non-Room state used for compensating rollback. */
    suspend fun captureExternalState(): Any? = null

    suspend fun applyExternal(plan: BackupSectionPlan) = Unit

    suspend fun rollbackExternal(snapshot: Any?) = Unit
}

internal data class DecodedBackupDocument(
    val manifest: com.shift.app.feature.backup.domain.model.BackupManifest,
    val sections: Map<String, BackupSectionSnapshot>,
    val fingerprint: String,
)

internal data class PlannedBackupDocument(
    val decoded: DecodedBackupDocument,
    val mode: BackupImportMode,
    val sections: Map<String, BackupSectionPlan>,
) {
    val importedRowCount: Int = sections.values.sumOf { it.importedRowCount }
    val affectedRowCount: Int = sections.values.sumOf { it.affectedRowCount }
    val deleteCount: Int = sections.values.sumOf { it.deleteCount }
}

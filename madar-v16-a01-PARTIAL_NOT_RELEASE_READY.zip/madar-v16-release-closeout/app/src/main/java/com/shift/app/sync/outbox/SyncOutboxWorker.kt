package com.shift.app.sync.outbox

import android.content.Context
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface SyncOutboxWorkerEntryPoint {
    fun processor(): SyncOutboxProcessor
}

class SyncOutboxWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val processor = EntryPointAccessors.fromApplication(
            applicationContext,
            SyncOutboxWorkerEntryPoint::class.java,
        ).processor()

        return when (processor.processReady()) {
            SyncOutboxProcessResult.NoWork,
            is SyncOutboxProcessResult.Completed -> Result.success()

            is SyncOutboxProcessResult.Retry -> Result.retry()
            // Keep the durable rows and let login/periodic recovery wake them later.
            SyncOutboxProcessResult.AuthenticationRequired -> Result.success()
        }
    }
}

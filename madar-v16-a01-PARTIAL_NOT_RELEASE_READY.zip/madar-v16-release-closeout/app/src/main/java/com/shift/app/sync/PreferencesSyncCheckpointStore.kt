package com.shift.app.sync

import com.shift.app.utils.PreferencesManager
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

@Singleton
class PreferencesSyncCheckpointStore @Inject constructor(
    private val preferences: PreferencesManager,
) : SyncCheckpointStore {
    override suspend fun lastSuccessfulSync(): Long = preferences.lastSync.first()
    override suspend fun setLastSuccessfulSync(value: Long) = preferences.setLastSync(value)
    override suspend fun setParticipantCheckpoint(key: String, value: Long) =
        preferences.setSyncCheckpoint(key, value)
}

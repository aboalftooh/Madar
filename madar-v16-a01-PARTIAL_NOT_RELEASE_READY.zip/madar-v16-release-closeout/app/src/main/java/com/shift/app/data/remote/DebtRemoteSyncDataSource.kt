package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.DebtRemoteSync

@Singleton
class DebtRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
    private val debtDao: DebtDao,
) : DebtRemoteSync {
    // ─── Debts ──────────────────────────────────────────────────

    override suspend fun pushDebts(debts: List<Debt>) = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        if (debts.isEmpty()) return@withContext
        context.client.from("debts").upsert(debts.map { it.toRemote(uid) })
        debtDao.upsertAll(debts.map { it.copy(syncState = SyncState.Synced.dbValue) })
    }

    override suspend fun pullDebts() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.LegacyDebts.key)
        val remote = context.fetchAllOrdered<RemoteDebt>("debts", uid, context.remoteUpdatedSince(SyncCheckpointKey.LegacyDebts))

        val localById = debtDao.getAllOnce().associateBy { it.id }
        val skipped = mutableListOf<String>()
        val merged = remote.mapNotNull { item ->
            val remoteUpdatedAt = item.updatedAt.toLocalTime()
            val local = localById[item.id]
            if (!SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) return@mapNotNull null
            context.decodeRemoteRow("debts", item.id, skipped) {
                val p = context.payloadDecoder.decodePayload(item.payload, uid, DebtPayload.serializer())
                Debt(
                    id = item.id, name = p.name, amount = p.amount,
                    type = p.type, dueDate = p.dueDate, note = p.note, isSettled = p.isSettled,
                    createdAt = local?.createdAt ?: remoteUpdatedAt,
                    updatedAt = remoteUpdatedAt,
                    syncState = SyncState.Synced.dbValue,
                    deletedAt = item.deletedAt.toLocalTime().takeIf { ts -> ts > 0L }
                )
            }
        }
        context.logSkippedRows("debts", skipped)
        debtDao.upsertAll(merged)
        merged.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges("debts", it.id, it.dueDate, it.updatedAt)
        }
    }

    // ─── Debt ledger v2 ─────────────────────────────────────────

    override suspend fun pullDebtLedger() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.DebtLedger.key)
        val updatedSince = context.remoteUpdatedSince(SyncCheckpointKey.DebtLedger)
        // Parent-first fetch and transactionally ordered writes preserve every FK.
        val remoteAccounts = context.fetchAllOrdered<RemoteDebtAccount>("debt_accounts", uid, updatedSince)
        val remoteTransactions = context.fetchAllOrdered<RemoteDebtTransaction>("debt_transactions", uid, updatedSince)
        val remoteLinks = context.fetchAllOrdered<RemoteDebtLink>("debt_links", uid, updatedSince)
        val remoteSchedules = context.fetchAllOrdered<RemoteDebtSchedule>("debt_schedules", uid, updatedSince)
        val remoteReviews = context.fetchAllOrdered<RemoteDebtMigrationReview>("debt_migration_reviews", uid, updatedSince)

        val accountDao = context.database.debtAccountDao()
        val transactionDao = context.database.debtTransactionDao()
        val linkDao = context.database.debtLinkDao()
        val scheduleDao = context.database.debtScheduleDao()
        val reviewDao = context.database.debtMigrationReviewDao()
        val pendingLinks = linkDao.getPendingSync().associateBy { it.id }
        val pendingSchedules = scheduleDao.getPendingSync().associateBy { it.id }

        val accounts = remoteAccounts.mapNotNull { remote ->
            val remoteUpdatedAt = remote.updatedAt.toLocalTime()
            val local = accountDao.getById(remote.id)
            if (SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) {
                remote.toLocal(remoteUpdatedAt)
            } else null
        }
        val transactions = remoteTransactions.mapNotNull { remote ->
            val remoteUpdatedAt = remote.updatedAt.toLocalTime()
            val local = transactionDao.getById(remote.id)
            if (SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) {
                remote.toLocal(remoteUpdatedAt)
            } else null
        }
        val links = remoteLinks.mapNotNull { remote ->
            val remoteUpdatedAt = remote.updatedAt.toLocalTime()
            if (SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = pendingLinks[remote.id]?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = pendingLinks[remote.id]?.syncState,
            )) {
                remote.toLocal(remoteUpdatedAt)
            } else null
        }
        val schedules = remoteSchedules.mapNotNull { remote ->
            val remoteUpdatedAt = remote.updatedAt.toLocalTime()
            if (SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = pendingSchedules[remote.id]?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = pendingSchedules[remote.id]?.syncState,
            )) {
                remote.toLocal(remoteUpdatedAt)
            } else null
        }
        val reviews = remoteReviews.mapNotNull { remote ->
            val remoteUpdatedAt = remote.updatedAt.toLocalTime()
            val local = reviewDao.getByLegacyDebtId(remote.legacyDebtId)
            if (SyncMergePolicy.shouldApplyRemote(
                localUpdatedAt = local?.updatedAt,
                remoteUpdatedAt = remoteUpdatedAt,
                lastSuccessfulSync = lastSuccessfulSync,
                localSyncState = local?.syncState,
            )) {
                remote.toLocal(remoteUpdatedAt)
            } else null
        }

        context.database.withTransaction {
            if (accounts.isNotEmpty()) accountDao.upsertAll(accounts)
            if (transactions.isNotEmpty()) transactionDao.upsertAll(transactions)
            if (links.isNotEmpty()) linkDao.upsertAll(links)
            if (schedules.isNotEmpty()) scheduleDao.upsertAll(schedules)
            if (reviews.isNotEmpty()) reviewDao.upsertAll(reviews)
        }
        (transactions.maxByOrNull { it.updatedAt } ?: accounts.maxByOrNull { it.updatedAt })?.let {
            context.invalidatePulledChanges(
                sourceType = "debts",
                sourceId = when (it) {
                    is DebtTransaction -> it.accountId
                    is DebtAccount -> it.id
                    else -> "debt-ledger"
                },
                effectiveDate = null,
                updatedAt = when (it) {
                    is DebtTransaction -> it.updatedAt
                    is DebtAccount -> it.updatedAt
                    else -> System.currentTimeMillis()
                },
            )
        }
    }

    override suspend fun pushPendingDebtLedger() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val accountDao = context.database.debtAccountDao()
        val transactionDao = context.database.debtTransactionDao()
        val linkDao = context.database.debtLinkDao()
        val scheduleDao = context.database.debtScheduleDao()
        val reviewDao = context.database.debtMigrationReviewDao()
        val pendingAccounts = accountDao.getPendingSync()
        val pendingTransactions = transactionDao.getPendingSync()
        val pendingLinks = linkDao.getPendingSync()
        val pendingSchedules = scheduleDao.getPendingSync()
        val pendingReviews = reviewDao.getPendingSync()

        val operationIds = buildSet {
            addAll(pendingAccounts.map { it.operationId })
            addAll(pendingTransactions.map { it.operationId })
            addAll(pendingLinks.map { it.operationId })
            addAll(pendingSchedules.map { it.operationId })
        }.filter { it.isNotBlank() }.sorted()

        operationIds.forEach { operationId ->
            val operationTransactions = pendingTransactions.filter { it.operationId == operationId }.toMutableList()
            val operationLinks = pendingLinks.filter { it.operationId == operationId }
            val operationSchedules = pendingSchedules.filter { it.operationId == operationId }
            operationLinks.map { it.debtTransactionId }.distinct().forEach { transactionId ->
                if (operationTransactions.none { it.id == transactionId }) {
                    transactionDao.getById(transactionId)?.let(operationTransactions::add)
                }
            }
            val accountIds = buildSet {
                addAll(operationTransactions.map { it.accountId })
                addAll(operationLinks.map { it.accountId })
                addAll(operationSchedules.map { it.accountId })
                addAll(pendingAccounts.filter { it.operationId == operationId }.map { it.id })
            }
            val operationAccounts = accountIds.mapNotNull { accountDao.getById(it) }
            pushDebtOperation(
                DebtSyncBundle(
                    operationId = operationId,
                    accounts = operationAccounts.map { it.toRemoteDebt(uid) },
                    transactions = operationTransactions.map { it.toRemoteDebt(uid) },
                    links = operationLinks.map { it.toRemoteDebt(uid) },
                    schedules = operationSchedules.map { it.toRemoteDebt(uid) }
                )
            )
        }

        pendingReviews.forEach { review ->
            val accounts = review.proposedAccountId?.let { accountDao.getById(it) }?.let(::listOf).orEmpty()
            pushDebtOperation(
                DebtSyncBundle(
                    operationId = "review:${review.id}",
                    accounts = accounts.map { it.toRemoteDebt(uid) },
                    reviews = listOf(review.toRemoteDebt(uid))
                )
            )
        }
    }

    private suspend fun pushDebtOperation(bundle: DebtSyncBundle) = withContext(Dispatchers.IO) {
        if (!bundle.isComplete) throw IllegalArgumentException(requireNotNull(bundle.incompleteReason))
        if (bundle.accounts.isEmpty() && bundle.transactions.isEmpty() && bundle.links.isEmpty() &&
            bundle.schedules.isEmpty() && bundle.reviews.isEmpty()) return@withContext
        context.client.postgrest.rpc(
            function = DEBT_OPERATION_RPC_FUNCTION,
            parameters = DebtOperationRpcParams(bundle)
        )
        context.database.withTransaction {
            if (bundle.accounts.isNotEmpty()) context.database.debtAccountDao().upsertAll(
                bundle.accounts.map { it.toLocal(it.updatedAt.toLocalTime()).copy(syncState = SyncState.Synced.dbValue) }
            )
            if (bundle.transactions.isNotEmpty()) context.database.debtTransactionDao().upsertAll(
                bundle.transactions.map { it.toLocal(it.updatedAt.toLocalTime()).copy(syncState = SyncState.Synced.dbValue) }
            )
            if (bundle.links.isNotEmpty()) context.database.debtLinkDao().upsertAll(
                bundle.links.map { it.toLocal(it.updatedAt.toLocalTime()).copy(syncState = SyncState.Synced.dbValue) }
            )
            if (bundle.schedules.isNotEmpty()) context.database.debtScheduleDao().upsertAll(
                bundle.schedules.map { it.toLocal(it.updatedAt.toLocalTime()).copy(syncState = SyncState.Synced.dbValue) }
            )
            if (bundle.reviews.isNotEmpty()) context.database.debtMigrationReviewDao().upsertAll(
                bundle.reviews.map { it.toLocal(it.updatedAt.toLocalTime()).copy(syncState = SyncState.Synced.dbValue) }
            )
        }
    }


    private fun Debt.toRemote(uid: String): RemoteDebt {
        val payload = context.json.encodeToString(DebtPayload.serializer(),
            DebtPayload(name, amount, type, dueDate, note, isSettled))
        return RemoteDebt(
            id = id,
            userId = uid,
            payload = payload,
            updatedAt = updatedAt.toRemoteTime(),
            deletedAt = deletedAt?.toRemoteTime()
        )
    }

    private fun DebtAccount.toRemoteDebt(uid: String) = RemoteDebtAccount(
        id = id,
        userId = uid,
        operationId = operationId,
        direction = direction,
        partyName = partyName,
        partyKey = partyKey,
        currencyCode = currencyCode,
        description = description,
        dueDate = dueDate,
        confirmed = confirmed,
        archivedAt = archivedAt,
        closedAt = closedAt,
        closeReason = closeReason,
        legacyDebtId = legacyDebtId,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = updatedAt.toRemoteTime(),
        deletedAt = deletedAt?.toRemoteTime()
    )

    private fun DebtTransaction.toRemoteDebt(uid: String) = RemoteDebtTransaction(
        id = id,
        userId = uid,
        accountId = accountId,
        operationId = operationId,
        type = type,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        occurredAt = occurredAt,
        note = note,
        reason = reason,
        originalTransactionId = originalTransactionId,
        sourceType = sourceType,
        sourceId = sourceId,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = updatedAt.toRemoteTime(),
        deletedAt = deletedAt?.toRemoteTime()
    )

    private fun DebtLink.toRemoteDebt(uid: String) = RemoteDebtLink(
        id = id,
        userId = uid,
        operationId = operationId,
        accountId = accountId,
        debtTransactionId = debtTransactionId,
        targetType = targetType,
        targetId = targetId,
        role = role,
        amountDecimal = amountDecimal,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = updatedAt.toRemoteTime(),
        deletedAt = deletedAt?.toRemoteTime()
    )

    private fun DebtSchedule.toRemoteDebt(uid: String) = RemoteDebtSchedule(
        id = id,
        userId = uid,
        operationId = operationId,
        accountId = accountId,
        installmentNo = installmentNo,
        dueDate = dueDate,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        status = status,
        reminderBeforeDue = reminderBeforeDue,
        reminderOnDue = reminderOnDue,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = updatedAt.toRemoteTime(),
        deletedAt = deletedAt?.toRemoteTime()
    )

    private fun DebtMigrationReview.toRemoteDebt(uid: String) = RemoteDebtMigrationReview(
        id = id,
        userId = uid,
        legacyDebtId = legacyDebtId,
        proposedAccountId = proposedAccountId,
        status = status,
        reason = reason,
        legacyPayloadJson = legacyPayloadJson,
        resolutionNote = resolutionNote,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = updatedAt.toRemoteTime(),
        deletedAt = deletedAt?.toRemoteTime()
    )

    private fun RemoteDebtAccount.toLocal(remoteUpdatedAt: Long) = DebtAccount(
        id = id,
        operationId = operationId,
        direction = direction,
        partyName = partyName,
        partyKey = partyKey,
        currencyCode = currencyCode,
        description = description,
        dueDate = dueDate ?: "",
        confirmed = confirmed,
        archivedAt = archivedAt,
        closedAt = closedAt,
        closeReason = closeReason,
        legacyDebtId = legacyDebtId,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = remoteUpdatedAt.takeIf { it > 0L } ?: createdAt,
        deletedAt = deletedAt.toLocalTime().takeIf { it > 0L }
    )

    private fun RemoteDebtTransaction.toLocal(remoteUpdatedAt: Long) = DebtTransaction(
        id = id,
        accountId = accountId,
        operationId = operationId,
        type = type,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        occurredAt = occurredAt,
        note = note,
        reason = reason,
        originalTransactionId = originalTransactionId,
        sourceType = sourceType,
        sourceId = sourceId,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = remoteUpdatedAt.takeIf { it > 0L } ?: createdAt,
        deletedAt = deletedAt.toLocalTime().takeIf { it > 0L }
    )

    private fun RemoteDebtLink.toLocal(remoteUpdatedAt: Long) = DebtLink(
        id = id,
        operationId = operationId,
        accountId = accountId,
        debtTransactionId = debtTransactionId,
        targetType = targetType,
        targetId = targetId,
        role = role,
        amountDecimal = amountDecimal,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = remoteUpdatedAt.takeIf { it > 0L } ?: createdAt,
        deletedAt = deletedAt.toLocalTime().takeIf { it > 0L }
    )

    private fun RemoteDebtSchedule.toLocal(remoteUpdatedAt: Long) = DebtSchedule(
        id = id,
        operationId = operationId,
        accountId = accountId,
        installmentNo = installmentNo,
        dueDate = dueDate,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        status = status,
        reminderBeforeDue = reminderBeforeDue,
        reminderOnDue = reminderOnDue,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = remoteUpdatedAt.takeIf { it > 0L } ?: createdAt,
        deletedAt = deletedAt.toLocalTime().takeIf { it > 0L }
    )

    private fun RemoteDebtMigrationReview.toLocal(remoteUpdatedAt: Long) = DebtMigrationReview(
        id = id,
        legacyDebtId = legacyDebtId,
        proposedAccountId = proposedAccountId,
        status = status,
        reason = reason,
        legacyPayloadJson = legacyPayloadJson,
        resolutionNote = resolutionNote,
        syncState = SyncState.Synced.dbValue,
        createdAt = createdAt,
        updatedAt = remoteUpdatedAt.takeIf { it > 0L } ?: createdAt,
        deletedAt = deletedAt.toLocalTime().takeIf { it > 0L }
    )

}

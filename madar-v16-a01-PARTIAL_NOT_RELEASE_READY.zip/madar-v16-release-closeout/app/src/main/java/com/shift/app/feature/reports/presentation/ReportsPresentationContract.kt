package com.shift.app.feature.reports.presentation

import com.shift.app.feature.reports.domain.model.ReportsDateRange
import com.shift.app.feature.reports.domain.model.ReportsReadModel
import java.time.LocalDate
import java.time.YearMonth

data class ReportsUiState(
    val readModel: ReportsReadModel = ReportsReadModel.empty(
        ReportsDateRange(YearMonth.now().atDay(1), LocalDate.now())
    ),
)

sealed interface ReportsUiEvent {
    data class DateFromChanged(val value: LocalDate) : ReportsUiEvent
    data class DateToChanged(val value: LocalDate) : ReportsUiEvent
}

package com.shift.app.data.migration

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.repository.LegacyHistoryMigrationCommit
import com.shift.app.data.repository.LegacyHistoryMigrationRepository
import com.shift.app.data.repository.LegacyHistoryMigrationVerification
import com.shift.app.data.repository.LegacyHistoryRollbackResult
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.finance.LegacyFinancialAmountRow
import com.shift.app.domain.finance.LegacyFinancialCutoverPlan
import com.shift.app.domain.finance.LegacyFinancialCutoverPlanner
import com.shift.app.domain.finance.LegacyFinancialRowKind
import com.shift.app.domain.finance.LegacyHistoryMigrationPreview
import javax.inject.Inject

data class LegacyFinancialCutoverPreview(
    val plan: LegacyFinancialCutoverPlan,
    val history: LegacyHistoryMigrationPreview?,
    val debts: LegacyDebtMigrationPreview,
    val historyAlreadyCompleted: Boolean,
)

data class LegacyFinancialCutoverResult(
    val fingerprint: String,
    val historyApplied: Boolean,
    val debtResult: LegacyDebtMigrationResult,
    val historyVerification: LegacyHistoryMigrationVerification,
    val debtVerification: LegacyDebtMigrationVerification,
)

data class LegacyFinancialCutoverRollbackResult(
    val history: LegacyHistoryRollbackResult,
    val debts: LegacyDebtRollbackResult,
)

/**
 * Coordinates the one-time cutover without deleting legacy source rows.
 *
 * History and debt steps are independently idempotent and share one outer Room transaction.
 * A retry after a process death completes the missing step and verifies parity before success.
 */
class LegacyFinancialCutoverCoordinator @Inject constructor(
    private val db: MadarDatabase,
    private val debtDao: DebtDao,
    private val historyRepository: LegacyHistoryMigrationRepository,
    private val debtMigrator: LegacyDebtMigrator,
) {
    suspend fun preview(
        localCurrencyCode: String,
        targetBalanceInput: String,
    ): LegacyFinancialCutoverPreview {
        val marker = historyRepository.getMarker()
        val history = if (marker == null) {
            historyRepository.preview(localCurrencyCode, targetBalanceInput)
        } else {
            null
        }
        val debts = debtMigrator.preview(debtDao.getAllOnce(), localCurrencyCode)

        val historicalIncome = marker?.historicalIncomeDecimal ?: requireNotNull(history).historicalIncomeDecimal
        val historicalExpense = marker?.historicalExpenseDecimal ?: requireNotNull(history).historicalExpenseDecimal
        val sourceRows = buildList {
            addAggregateHistoryRows(historicalIncome, historicalExpense)
            debts.plans.filterIsInstance<LegacyDebtMigrationPlan.Opening>()
                .filterNot { it.archived }
                .forEach { plan ->
                    add(
                        LegacyFinancialAmountRow(
                            sourceId = plan.legacyDebt.id,
                            kind = plan.direction.toFinancialKind(),
                            amountDecimal = plan.amountDecimal,
                        ),
                    )
                }
        }
        val canonicalRows = buildList {
            addAggregateHistoryRows(historicalIncome, historicalExpense)
            debts.plans.filterIsInstance<LegacyDebtMigrationPlan.Opening>()
                .filterNot { it.archived }
                .forEach { plan ->
                    add(
                        LegacyFinancialAmountRow(
                            sourceId = plan.legacyDebt.id,
                            kind = plan.direction.toFinancialKind(),
                            amountDecimal = plan.amountDecimal,
                        ),
                    )
                }
        }
        val historyFingerprint = marker?.commitFingerprint ?: requireNotNull(history).commitFingerprint
        val historyCount = marker?.candidateCount ?: requireNotNull(history).candidateCount
        val plan = LegacyFinancialCutoverPlanner.plan(
            historyCommitFingerprint = historyFingerprint,
            debtSourceFingerprint = debts.sourceFingerprint,
            transactionCandidateCount = historyCount,
            debtCandidateCount = debts.candidateCount,
            debtReviewCount = debts.reviewCount,
            sourceRows = sourceRows,
            canonicalRows = canonicalRows,
        )
        plan.parity.requireExact()
        return LegacyFinancialCutoverPreview(
            plan = plan,
            history = history,
            debts = debts,
            historyAlreadyCompleted = marker != null,
        )
    }

    suspend fun commit(
        expectedCutoverFingerprint: String,
        localCurrencyCode: String,
        targetBalanceInput: String,
        now: Long = System.currentTimeMillis(),
    ): LegacyFinancialCutoverResult {
        val current = preview(localCurrencyCode, targetBalanceInput)
        require(current.plan.fingerprint == expectedCutoverFingerprint) {
            "Financial data changed since cutover preview"
        }
        current.plan.parity.requireExact()

        return db.withTransaction {
            val historyApplied = if (current.historyAlreadyCompleted) {
                false
            } else {
                val commit: LegacyHistoryMigrationCommit = historyRepository.prepareCommit(
                    expectedCommitFingerprint = current.plan.historyCommitFingerprint,
                    localCurrencyCode = localCurrencyCode,
                    targetBalanceInput = targetBalanceInput,
                    now = now,
                )
                historyRepository.applyLocally(commit)
            }
            val debtResult = debtMigrator.migrate(
                debts = debtDao.getAllOnce(),
                expectedSourceFingerprint = current.plan.debtSourceFingerprint,
                localCurrencyCode = localCurrencyCode,
            )
            val historyVerification = historyRepository.verifyCommittedParity()
            val debtVerification = debtMigrator.verify(current.debts)
            historyVerification.requireExact()
            debtVerification.requireExact()
            LegacyFinancialCutoverResult(
                fingerprint = current.plan.fingerprint,
                historyApplied = historyApplied,
                debtResult = debtResult,
                historyVerification = historyVerification,
                debtVerification = debtVerification,
            )
        }
    }

    suspend fun rollbackPending(
        expectedCutoverFingerprint: String,
        localCurrencyCode: String,
        targetBalanceInput: String,
    ): LegacyFinancialCutoverRollbackResult {
        val current = preview(localCurrencyCode, targetBalanceInput)
        require(current.plan.fingerprint == expectedCutoverFingerprint) {
            "Financial data changed since cutover preview"
        }
        return db.withTransaction {
            val debtRollback = debtMigrator.rollbackPending(
                debts = debtDao.getAllOnce(),
                expectedSourceFingerprint = current.plan.debtSourceFingerprint,
                localCurrencyCode = localCurrencyCode,
            )
            val historyRollback = historyRepository.rollbackPending(current.plan.historyCommitFingerprint)
            LegacyFinancialCutoverRollbackResult(historyRollback, debtRollback)
        }
    }

    private fun MutableList<LegacyFinancialAmountRow>.addAggregateHistoryRows(
        incomeDecimal: String,
        expenseDecimal: String,
    ) {
        add(LegacyFinancialAmountRow("history-income", LegacyFinancialRowKind.Income, incomeDecimal))
        add(LegacyFinancialAmountRow("history-expense", LegacyFinancialRowKind.Expense, expenseDecimal))
    }

    private fun DebtDirection.toFinancialKind(): LegacyFinancialRowKind = when (this) {
        DebtDirection.Receivable -> LegacyFinancialRowKind.Receivable
        DebtDirection.Payable -> LegacyFinancialRowKind.Payable
    }
}

package com.shift.app.data.remote


import com.shift.app.sync.SyncCheckpointKey
import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.DebtDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.remote.goals.FinancialGoalSyncBundle
import com.shift.app.data.remote.goals.GoalSyncMapper
import com.shift.app.data.remote.goals.RemoteFinancialGoal
import com.shift.app.data.remote.goals.RemoteGoalActivity
import com.shift.app.data.remote.goals.RemoteGoalCondition
import com.shift.app.data.remote.goals.RemoteGoalCostEstimate
import com.shift.app.data.remote.goals.RemoteGoalEvaluation
import com.shift.app.data.remote.goals.RemoteGoalFundingTransaction
import com.shift.app.data.remote.goals.RemoteGoalMetric
import com.shift.app.data.remote.goals.RemoteGoalScope
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.PreferencesManager
import com.shift.app.utils.SyncMergePolicy
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import android.util.Log
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import com.shift.app.sync.remote.GoalRemoteSync

@Singleton
class GoalRemoteSyncDataSource @Inject constructor(
    private val context: RemoteSyncContext,
) : GoalRemoteSync {
    // ─── Financial goals phase 1 ────────────────────────────────

    override suspend fun pullFinancialGoals() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val lastSuccessfulSync = context.preferences.getSyncCheckpoint(SyncCheckpointKey.FinancialGoals.key)
        val updatedSince = context.remoteUpdatedSince(SyncCheckpointKey.FinancialGoals)
        val remoteGoals = context.fetchAllOrdered<RemoteFinancialGoal>("financial_goals", uid, updatedSince)
        val remoteMetrics = context.fetchAllOrdered<RemoteGoalMetric>("goal_metrics", uid, updatedSince)
        val remoteConditions = context.fetchAllOrdered<RemoteGoalCondition>("goal_conditions", uid, updatedSince)
        val remoteScopes = context.fetchAllOrdered<RemoteGoalScope>("goal_scopes", uid, updatedSince)
        val remoteFunding = context.fetchAllOrdered<RemoteGoalFundingTransaction>("goal_funding_transactions", uid, updatedSince)
        val remoteCosts = context.fetchAllOrdered<RemoteGoalCostEstimate>("goal_cost_estimates", uid, updatedSince)
        val remoteEvaluations = context.fetchAllOrdered<RemoteGoalEvaluation>("goal_evaluations", uid, updatedSince)
        val remoteActivities = context.fetchAllOrdered<RemoteGoalActivity>("goal_activities", uid, updatedSince)

        val goalDao = context.database.financialGoalDao()
        val metricDao = context.database.goalMetricDao()
        val conditionDao = context.database.goalConditionDao()
        val scopeDao = context.database.goalScopeDao()
        val fundingDao = context.database.goalFundingTransactionDao()
        val costDao = context.database.goalCostEstimateDao()
        val evaluationDao = context.database.goalEvaluationDao()
        val activityDao = context.database.goalActivityDao()

        val goals = with(GoalSyncMapper) {
            remoteGoals.mapNotNull {
                val local = goalDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val metrics = with(GoalSyncMapper) {
            remoteMetrics.mapNotNull {
                val local = metricDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val conditions = with(GoalSyncMapper) {
            remoteConditions.mapNotNull {
                val local = conditionDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val scopes = with(GoalSyncMapper) {
            remoteScopes.mapNotNull {
                val local = scopeDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val funding = with(GoalSyncMapper) {
            remoteFunding.mapNotNull {
                val local = fundingDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val costs = with(GoalSyncMapper) {
            remoteCosts.mapNotNull {
                val local = costDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }
        val evaluations = with(GoalSyncMapper) {
            remoteEvaluations.mapNotNull {
                val local = evaluationDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                )) it.toLocal() else null
            }
        }
        val activities = with(GoalSyncMapper) {
            remoteActivities.mapNotNull {
                val local = activityDao.getById(it.id)
                val remoteUpdatedAt = it.updatedAt.toLocalTime()
                if (SyncMergePolicy.shouldApplyRemote(
                    localUpdatedAt = local?.updatedAt,
                    remoteUpdatedAt = remoteUpdatedAt,
                    lastSuccessfulSync = lastSuccessfulSync,
                    localSyncState = local?.syncState,
                )) it.toLocal() else null
            }
        }

        context.database.withTransaction {
            if (goals.isNotEmpty()) goalDao.upsertAll(goals)
            if (metrics.isNotEmpty()) metricDao.upsertAll(metrics)
            if (conditions.isNotEmpty()) conditionDao.upsertAll(conditions)
            if (scopes.isNotEmpty()) scopeDao.upsertAll(scopes)
            if (funding.isNotEmpty()) fundingDao.upsertAll(funding)
            if (costs.isNotEmpty()) costDao.upsertAll(costs)
            if (evaluations.isNotEmpty()) evaluationDao.upsertAll(evaluations)
            if (activities.isNotEmpty()) activityDao.upsertAll(activities)
        }
        val definitionGoalIds = (
            goals.map { it.id } + metrics.map { it.goalId } + conditions.map { it.goalId } +
                scopes.map { it.goalId } + costs.map { it.goalId }
            ).distinct()
        definitionGoalIds.forEach { goalId ->
            val goal = goalDao.getById(goalId) ?: return@forEach
            context.invalidatePulledChanges("financial_goals", goalId, goal.startDate, goal.updatedAt)
        }
        funding.maxByOrNull { it.updatedAt }?.let {
            context.invalidatePulledChanges(
                "goal_funding_transactions",
                it.id,
                Instant.ofEpochMilli(it.occurredAt).atZone(ZoneOffset.UTC).toLocalDate().toString(),
                it.updatedAt,
            )
        }
    }

    override suspend fun pushPendingFinancialGoals() = withContext(Dispatchers.IO) {
        val uid = context.authenticatedUserId ?: return@withContext
        val goalDao = context.database.financialGoalDao()
        val metricDao = context.database.goalMetricDao()
        val conditionDao = context.database.goalConditionDao()
        val scopeDao = context.database.goalScopeDao()
        val fundingDao = context.database.goalFundingTransactionDao()
        val costDao = context.database.goalCostEstimateDao()
        val activityDao = context.database.goalActivityDao()
        val evaluationDao = context.database.goalEvaluationDao()

        val allGoals = goalDao.getAllOnce()
        val allMetrics = metricDao.getAllOnce()
        val allConditions = conditionDao.getAllOnce()
        val allScopes = scopeDao.getAllOnce()
        val allEvaluations = evaluationDao.getAllOnce()
        val pendingGoals = goalDao.getPendingSync()
        val pendingMetrics = metricDao.getPendingSync()
        val pendingConditions = conditionDao.getPendingSync()
        val pendingScopes = scopeDao.getPendingSync()
        val pendingFunding = fundingDao.getPendingSync()
        val pendingCosts = costDao.getPendingSync()
        val pendingActivities = activityDao.getPendingSync()

        val changedDefinitionGoalIds = buildSet {
            addAll(pendingGoals.map { it.id })
            addAll(pendingMetrics.map { it.goalId })
            addAll(pendingConditions.map { it.goalId })
            addAll(pendingScopes.map { it.goalId })
        }
        changedDefinitionGoalIds.sorted().forEach { goalId ->
            val goal = allGoals.singleOrNull { it.id == goalId } ?: return@forEach
            pushFinancialGoalOperation(
                FinancialGoalSyncBundle(
                    operationId = "goal:${goal.id}:${goal.revision}",
                    expectedRevision = (goal.revision - 1L).coerceAtLeast(0L),
                    goals = with(GoalSyncMapper) { listOf(goal.toRemote(uid)) },
                    metrics = with(GoalSyncMapper) { allMetrics.filter { it.goalId == goalId }.map { it.toRemote(uid) } },
                    conditions = with(GoalSyncMapper) { allConditions.filter { it.goalId == goalId }.map { it.toRemote(uid) } },
                    scopes = with(GoalSyncMapper) { allScopes.filter { it.goalId == goalId }.map { it.toRemote(uid) } }
                )
            )
        }

        val appendOnlyOperationIds = buildSet {
            addAll(pendingFunding.map { it.operationId })
            addAll(pendingCosts.map { it.operationId })
            addAll(pendingActivities.map { it.operationId })
        }.filter { it.isNotBlank() }.sorted()
        appendOnlyOperationIds.forEach { operationId ->
            val funding = pendingFunding.filter { it.operationId == operationId }.toMutableList()
            funding.mapNotNull { it.relatedFundingTransactionId }.forEach { relatedId ->
                if (funding.none { it.id == relatedId }) fundingDao.getById(relatedId)?.let(funding::add)
            }
            val costs = pendingCosts.filter { it.operationId == operationId }
            val activities = pendingActivities.filter { it.operationId == operationId }
            val evaluations = allEvaluations.filter { evaluation ->
                activities.any { activity ->
                    activity.goalId == evaluation.goalId && activity.operationId == evaluation.inputFingerprint
                }
            }.toMutableList()
            evaluations.mapNotNull { it.correctionOfId }.forEach { relatedId ->
                if (evaluations.none { it.id == relatedId }) evaluationDao.getById(relatedId)?.let(evaluations::add)
            }
            val goalIds = (funding.map { it.goalId } + costs.map { it.goalId } + activities.map { it.goalId }).toSet()
            val goals = goalIds.mapNotNull { goalDao.getById(it) }
            pushFinancialGoalOperation(
                FinancialGoalSyncBundle(
                    operationId = operationId,
                    expectedRevision = goals.singleOrNull()?.revision,
                    goals = with(GoalSyncMapper) { goals.map { it.toRemote(uid) } },
                    fundingTransactions = with(GoalSyncMapper) { funding.map { it.toRemote(uid) } },
                    costEstimates = with(GoalSyncMapper) { costs.map { it.toRemote(uid) } },
                    evaluations = with(GoalSyncMapper) { evaluations.map { it.toRemote(uid) } },
                    activities = with(GoalSyncMapper) { activities.map { it.toRemote(uid) } }
                )
            )
        }
    }

    private suspend fun pushFinancialGoalOperation(bundle: FinancialGoalSyncBundle) = withContext(Dispatchers.IO) {
        if (!bundle.isComplete) throw IllegalArgumentException(requireNotNull(bundle.incompleteReason))
        if (bundle.goals.isEmpty() && bundle.metrics.isEmpty() && bundle.conditions.isEmpty() &&
            bundle.scopes.isEmpty() && bundle.fundingTransactions.isEmpty() && bundle.costEstimates.isEmpty() &&
            bundle.evaluations.isEmpty() && bundle.activities.isEmpty()) return@withContext
        context.client.postgrest.rpc(
            function = FINANCIAL_GOAL_OPERATION_RPC_FUNCTION,
            parameters = FinancialGoalOperationRpcParams(bundle)
        )
        context.database.withTransaction {
            with(GoalSyncMapper) {
                if (bundle.goals.isNotEmpty()) context.database.financialGoalDao().upsertAll(bundle.goals.map { it.toLocal() })
                if (bundle.metrics.isNotEmpty()) context.database.goalMetricDao().upsertAll(bundle.metrics.map { it.toLocal() })
                if (bundle.conditions.isNotEmpty()) context.database.goalConditionDao().upsertAll(bundle.conditions.map { it.toLocal() })
                if (bundle.scopes.isNotEmpty()) context.database.goalScopeDao().upsertAll(bundle.scopes.map { it.toLocal() })
                if (bundle.fundingTransactions.isNotEmpty()) context.database.goalFundingTransactionDao().upsertAll(
                    bundle.fundingTransactions.map { it.toLocal() }
                )
                if (bundle.costEstimates.isNotEmpty()) context.database.goalCostEstimateDao().upsertAll(bundle.costEstimates.map { it.toLocal() })
                if (bundle.evaluations.isNotEmpty()) context.database.goalEvaluationDao().upsertAll(bundle.evaluations.map { it.toLocal() })
                if (bundle.activities.isNotEmpty()) context.database.goalActivityDao().upsertAll(bundle.activities.map { it.toLocal() })
            }
        }
    }
}

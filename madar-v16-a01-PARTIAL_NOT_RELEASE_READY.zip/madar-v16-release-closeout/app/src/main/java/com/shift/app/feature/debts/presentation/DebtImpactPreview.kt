package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.shift.app.domain.debt.DebtFinancialImpact

@Composable
fun DebtImpactPreview(impact: DebtFinancialImpact) {
    Column {
        Text("معاينة الأثر")
        Text("الرصيد: ${impact.balanceDeltaDecimal}")
        Text("الأصول: ${impact.assetDeltaDecimal}")
        Text("المستحقات: ${impact.receivableDeltaDecimal}")
        Text("الالتزامات: ${impact.payableDeltaDecimal}")
    }
}

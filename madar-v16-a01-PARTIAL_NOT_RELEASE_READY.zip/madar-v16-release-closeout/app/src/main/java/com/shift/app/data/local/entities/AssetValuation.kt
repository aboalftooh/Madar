package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "asset_valuations",
    foreignKeys = [
        ForeignKey(entity = Asset::class, parentColumns = ["id"], childColumns = ["assetId"], onDelete = ForeignKey.NO_ACTION)
    ],
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["assetId", "deletedAt"]),
        Index(value = ["date", "createdAt"])
    ]
)
data class AssetValuation(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val assetId: String,
    val valueDecimal: String,
    val date: String,
    val note: String = "",
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.PaymentKind
import java.math.BigDecimal
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

data class BalanceTransactionRequest(
    val operationId: String,
    val kind: BalanceTransactionKind,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val date: String,
    val note: String = "",
    val sourceType: String = "",
    val sourceId: String? = null
)

data class PaymentRequest(
    val operationId: String,
    val kind: PaymentKind,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val date: String,
    val purpose: String = "",
    val beneficiaryId: String? = null,
    val beneficiaryNameSnapshot: String = "",
    val assetId: String? = null,
    val assetNameSnapshot: String = "",
    val note: String = ""
)

data class RecordedPayment(
    val payment: Payment,
    val balanceTransaction: BalanceTransaction
)

data class ReplacedPayment(
    val deletedPayments: List<Payment>,
    val deletedBalanceTransactions: List<BalanceTransaction>,
    val replacement: RecordedPayment
)

class FinancialLedgerRepository @Inject constructor(
    private val db: MadarDatabase,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val changePublisher: FinancialChangePublisher,
) {
    fun balanceTransactions(): Flow<List<BalanceTransaction>> = balanceDao.getAll()
    fun payments(): Flow<List<Payment>> = paymentDao.getAll()
    fun balanceTransactionsIncludingDeleted(): Flow<List<BalanceTransaction>> = balanceDao.getAllIncludingDeleted()
    fun paymentsIncludingDeleted(): Flow<List<Payment>> = paymentDao.getAllIncludingDeleted()
    fun migratedLegacyTransactionIds(): Flow<List<String>> = paymentDao.getAllLegacyTransactionIds()
    fun expenseReportablePayments(): Flow<List<Payment>> = paymentDao.getExpenseReportable()
    suspend fun getBalanceTransactionsOnce(): List<BalanceTransaction> = balanceDao.getAllOnce()
    suspend fun getPaymentsOnce(): List<Payment> = paymentDao.getAllOnce()
    suspend fun upsertBalanceTransactions(items: List<BalanceTransaction>) = balanceDao.upsertAll(items)
    suspend fun upsertPayments(items: List<Payment>) = paymentDao.upsertAll(items)

    suspend fun deleteAllLocalData() = db.withTransaction {
        paymentDao.deleteAll()
        balanceDao.deleteAll()
    }

    suspend fun recordBalanceTransaction(request: BalanceTransactionRequest): BalanceTransaction =
        db.withTransaction {
            ensureOperationDoesNotExist(request.operationId)
            val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
            val item = BalanceTransaction(
                operationId = request.operationId.requireNotBlank("operationId"),
                kind = request.kind,
                amountDecimal = amount,
                currencyCode = request.currencyCode.requireNotBlank("currencyCode"),
                date = request.date.requireNotBlank("date"),
                note = request.note,
                sourceType = request.sourceType,
                sourceId = request.sourceId
            )
            balanceDao.insert(item)
            changePublisher.publish(
                sourceType = "balance_transactions",
                sourceId = item.id,
                operationId = request.operationId,
                effectiveDate = item.date,
                changedFields = "balance",
                createdAt = item.updatedAt,
            )
            item
        }

    suspend fun recordOpeningBalance(
        operationId: String,
        amountDecimal: String,
        currencyCode: String = "SDG",
        date: String,
        note: String = ""
    ): BalanceTransaction =
        db.withTransaction {
            balanceDao.getActiveOpeningBalance()?.let { return@withTransaction it }
            ensureOperationDoesNotExist(operationId)
            val canonical = DecimalText.canonical(amountDecimal, DecimalTextScale.Money)
            val value = DecimalText.toBigDecimal(canonical)
            val item = BalanceTransaction(
                operationId = operationId.requireNotBlank("operationId"),
                direction = if (value < BigDecimal.ZERO) {
                    BalanceDirection.Outflow.dbValue
                } else {
                    BalanceDirection.Inflow.dbValue
                },
                kind = BalanceTransactionKind.OpeningBalance.dbValue,
                amountDecimal = value.abs().toPlainString(),
                currencyCode = currencyCode.requireNotBlank("currencyCode"),
                date = date.requireNotBlank("date"),
                note = note,
                sourceType = "balance_activation"
            )
            balanceDao.insert(item)
            changePublisher.publish(
                sourceType = "balance_transactions",
                sourceId = item.id,
                operationId = operationId,
                effectiveDate = item.date,
                changedFields = "openingBalance",
                createdAt = item.updatedAt,
            )
            item
        }

    suspend fun recordPayment(request: PaymentRequest): RecordedPayment =
        db.withTransaction {
            ensureOperationDoesNotExist(request.operationId)
            val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
            val balanceTransaction = BalanceTransaction(
                operationId = request.operationId.requireNotBlank("operationId"),
                kind = request.kind.toBalanceTransactionKind(),
                amountDecimal = amount,
                currencyCode = request.currencyCode.requireNotBlank("currencyCode"),
                date = request.date.requireNotBlank("date"),
                note = request.note,
                sourceType = "payment"
            )
            balanceDao.insert(balanceTransaction)

            val payment = Payment(
                operationId = request.operationId,
                kind = request.kind,
                amountDecimal = amount,
                currencyCode = request.currencyCode,
                date = request.date,
                purpose = request.purpose,
                purposeKey = request.purpose.trim().lowercase(),
                beneficiaryId = request.beneficiaryId,
                beneficiaryNameSnapshot = request.beneficiaryNameSnapshot,
                assetId = request.assetId,
                assetNameSnapshot = request.assetNameSnapshot,
                balanceTransactionId = balanceTransaction.id,
                note = request.note
            )
            paymentDao.insert(payment)
            changePublisher.publish(
                sourceType = "payments",
                sourceId = payment.id,
                operationId = request.operationId,
                effectiveDate = payment.date,
                changedFields = "kind,amount,date,purpose",
                createdAt = payment.updatedAt,
            )
            RecordedPayment(payment = payment, balanceTransaction = balanceTransaction)
        }

    suspend fun softDeleteOperation(operationId: String, deletedAt: Long = System.currentTimeMillis()): Pair<List<Payment>, List<BalanceTransaction>> =
        db.withTransaction {
            val payments = paymentDao.getActiveByOperationId(operationId).map {
                it.copy(updatedAt = deletedAt, deletedAt = deletedAt)
            }
            val balances = balanceDao.getActiveByOperationId(operationId).map {
                it.copy(updatedAt = deletedAt, deletedAt = deletedAt)
            }
            if (payments.isNotEmpty()) paymentDao.upsertAll(payments)
            if (balances.isNotEmpty()) balanceDao.upsertAll(balances)
            (payments.firstOrNull()?.date ?: balances.firstOrNull()?.date)?.let { effectiveDate ->
                changePublisher.publish(
                    sourceType = "payments",
                    sourceId = payments.firstOrNull()?.id ?: balances.first().id,
                    operationId = "delete:$operationId:$deletedAt",
                    effectiveDate = effectiveDate,
                    changedFields = "deletedAt",
                    createdAt = deletedAt,
                )
            }
            payments to balances
        }

    suspend fun replacePayment(operationId: String, request: PaymentRequest): ReplacedPayment =
        db.withTransaction {
            val deletedAt = System.currentTimeMillis()
            val deletedPayments = paymentDao.getActiveByOperationId(operationId).map {
                it.copy(updatedAt = deletedAt, deletedAt = deletedAt)
            }
            val deletedBalances = balanceDao.getActiveByOperationId(operationId).map {
                it.copy(updatedAt = deletedAt, deletedAt = deletedAt)
            }
            if (deletedPayments.isNotEmpty()) paymentDao.upsertAll(deletedPayments)
            if (deletedBalances.isNotEmpty()) balanceDao.upsertAll(deletedBalances)

            val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
            val balanceTransaction = BalanceTransaction(
                operationId = request.operationId.requireNotBlank("operationId"),
                kind = request.kind.toBalanceTransactionKind(),
                amountDecimal = amount,
                currencyCode = request.currencyCode.requireNotBlank("currencyCode"),
                date = request.date.requireNotBlank("date"),
                note = request.note,
                sourceType = "payment"
            )
            balanceDao.insert(balanceTransaction)
            val payment = Payment(
                operationId = request.operationId,
                kind = request.kind,
                amountDecimal = amount,
                currencyCode = request.currencyCode,
                date = request.date,
                purpose = request.purpose,
                purposeKey = request.purpose.trim().lowercase(),
                beneficiaryId = request.beneficiaryId,
                beneficiaryNameSnapshot = request.beneficiaryNameSnapshot,
                assetId = request.assetId,
                assetNameSnapshot = request.assetNameSnapshot,
                balanceTransactionId = balanceTransaction.id,
                note = request.note
            )
            paymentDao.insert(payment)
            changePublisher.publish(
                sourceType = "payments",
                sourceId = payment.id,
                operationId = "replace:$operationId:${request.operationId}",
                effectiveDate = payment.date,
                changedFields = "kind,amount,date,purpose,deletedAt",
                createdAt = payment.updatedAt,
            )
            ReplacedPayment(
                deletedPayments = deletedPayments,
                deletedBalanceTransactions = deletedBalances,
                replacement = RecordedPayment(payment, balanceTransaction)
            )
        }

    private suspend fun ensureOperationDoesNotExist(operationId: String) {
        val id = operationId.requireNotBlank("operationId")
        require(balanceDao.getActiveByOperationId(id).isEmpty()) {
            "Balance records already exist for operationId"
        }
        require(paymentDao.getActiveByOperationId(id).isEmpty()) {
            "Payment records already exist for operationId"
        }
    }
}

fun PaymentKind.toBalanceTransactionKind(): BalanceTransactionKind =
    when (this) {
        PaymentKind.OrdinaryExpense -> BalanceTransactionKind.ExpensePayment
        PaymentKind.AssetPurchase -> BalanceTransactionKind.AssetPurchase
        PaymentKind.AssetImprovement -> BalanceTransactionKind.AssetImprovement
        PaymentKind.AssetMaintenance -> BalanceTransactionKind.AssetMaintenance
        PaymentKind.BalanceWithdrawal -> BalanceTransactionKind.ManualWithdrawal
        PaymentKind.DebtGift -> BalanceTransactionKind.ManualWithdrawal
    }

private fun String.requireNotBlank(fieldName: String): String {
    require(isNotBlank()) { "$fieldName must not be blank" }
    return this
}

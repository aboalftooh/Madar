package com.shift.app.feature.backup.data

/** Pure transaction contract used by the Room adapter and by atomicity tests. */
internal fun interface RestoreTransactionBoundary {
    suspend fun run(block: suspend () -> Unit)
}

/** Deterministic fault points used to prove rollback behavior without Room or Android. */
internal enum class RestoreFaultPoint {
    BEFORE_CAPTURE,
    AFTER_CAPTURE,
    BEFORE_DATABASE_APPLY,
    AFTER_DATABASE_APPLY,
    BEFORE_EXTERNAL_APPLY,
    AFTER_EXTERNAL_APPLY,
    BEFORE_ROLLBACK,
    AFTER_ROLLBACK,
}

internal fun interface RestoreFaultInjector {
    fun hit(point: RestoreFaultPoint, sectionId: String)

    companion object {
        val None = RestoreFaultInjector { _, _ -> Unit }
    }
}

internal class RestoreAtomicityGuard(
    private val boundary: RestoreTransactionBoundary,
    private val faultInjector: RestoreFaultInjector = RestoreFaultInjector.None,
) {
    suspend fun apply(
        ordered: List<Pair<BackupSectionCodec, BackupSectionPlan>>,
    ) {
        val externalSnapshots = linkedMapOf<BackupSectionCodec, Any?>()
        ordered.forEach { (codec, _) ->
            faultInjector.hit(RestoreFaultPoint.BEFORE_CAPTURE, codec.id)
            externalSnapshots[codec] = codec.captureExternalState()
            faultInjector.hit(RestoreFaultPoint.AFTER_CAPTURE, codec.id)
        }

        try {
            boundary.run {
                ordered.forEach { (codec, plan) ->
                    faultInjector.hit(RestoreFaultPoint.BEFORE_DATABASE_APPLY, codec.id)
                    codec.apply(plan)
                    faultInjector.hit(RestoreFaultPoint.AFTER_DATABASE_APPLY, codec.id)
                }
                ordered.forEach { (codec, plan) ->
                    faultInjector.hit(RestoreFaultPoint.BEFORE_EXTERNAL_APPLY, codec.id)
                    codec.applyExternal(plan)
                    faultInjector.hit(RestoreFaultPoint.AFTER_EXTERNAL_APPLY, codec.id)
                }
            }
        } catch (error: Throwable) {
            externalSnapshots.entries.reversed().forEach { (codec, snapshot) ->
                runCatching {
                    faultInjector.hit(RestoreFaultPoint.BEFORE_ROLLBACK, codec.id)
                    codec.rollbackExternal(snapshot)
                    faultInjector.hit(RestoreFaultPoint.AFTER_ROLLBACK, codec.id)
                }
            }
            throw error
        }
    }
}

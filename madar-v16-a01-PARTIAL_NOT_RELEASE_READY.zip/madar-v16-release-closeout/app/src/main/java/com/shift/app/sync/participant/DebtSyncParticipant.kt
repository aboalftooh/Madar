package com.shift.app.sync.participant

import com.shift.app.data.local.dao.DebtDao
import com.shift.app.sync.remote.DebtRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.data.remote.shouldPushFinancialRecord
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DebtSyncParticipant @Inject constructor(
    private val legacyDebtDao: DebtDao,
    private val remote: DebtRemoteSync,
) : SyncParticipant {
    override val key: String = "debts"
    override val order: Int = 40

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_debt_ledger", SyncCheckpointKey.DebtLedger) { remote.pullDebtLedger() },
        SyncOperation("pull_debts", SyncCheckpointKey.LegacyDebts) { remote.pullDebts() },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> = buildList {
        val changedLegacyDebts = legacyDebtDao.getAllOnce().filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        if (changedLegacyDebts.isNotEmpty()) {
            add(SyncOperation("push_debts") { remote.pushDebts(changedLegacyDebts) })
        }
        add(SyncOperation("push_debt_ledger") { remote.pushPendingDebtLedger() })
    }
}

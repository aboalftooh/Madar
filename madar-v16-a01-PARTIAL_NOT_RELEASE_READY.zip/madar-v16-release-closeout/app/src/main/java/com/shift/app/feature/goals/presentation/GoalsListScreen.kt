package com.shift.app.feature.goals.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.ui.theme.AccentCyan
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.SurfaceVariant
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.feature.goals.presentation.GoalListFilter
import com.shift.app.feature.goals.presentation.GoalListItem
import com.shift.app.feature.goals.presentation.GoalsViewModel
import com.shift.app.feature.goals.presentation.arabicLabel
import java.math.BigDecimal

@Composable
fun GoalsListScreen(
    financialGoalsEnabled: Boolean,
    viewModel: GoalsViewModel = hiltViewModel(),
) {
    if (!financialGoalsEnabled) {
        GoalsDisabledState()
        return
    }

    val goals by viewModel.goals.collectAsState()
    var filter by remember { mutableStateOf(GoalListFilter.ACTIVE) }
    var mode by remember { mutableStateOf<GoalsMode>(GoalsMode.List) }
    val selectedGoal by viewModel.selectedGoal.collectAsState()
    val selectedFunding by viewModel.selectedFunding.collectAsState()

    when (val currentMode = mode) {
        GoalsMode.List -> GoalsListContent(
            goals = goals.filter { it.lifecycleStatus in filter.statuses },
            filter = filter,
            onFilterChange = { filter = it },
            onCreate = { mode = GoalsMode.Editor(null) },
            onOpen = {
                viewModel.selectGoal(it)
                mode = GoalsMode.Details(it)
            },
        )
        is GoalsMode.Editor -> GoalEditorScreen(
            goalId = currentMode.goalId,
            onClose = { savedGoalId ->
                if (savedGoalId != null) {
                    viewModel.selectGoal(savedGoalId)
                    mode = GoalsMode.Details(savedGoalId)
                } else {
                    mode = GoalsMode.List
                }
            },
        )
        is GoalsMode.Details -> GoalDetailsScreen(
            goal = selectedGoal,
            funding = selectedFunding,
            onBack = { mode = GoalsMode.List },
            onEdit = { mode = GoalsMode.Editor(currentMode.goalId) },
            onSpecializedComplete = { goal ->
                mode = when (goal.type) {
                    GoalType.HOUSE_PURCHASE, GoalType.CAR_PURCHASE -> GoalsMode.AssetCompletion(goal.id)
                    GoalType.PROJECT_FUNDING, GoalType.TRIP_FUNDING -> GoalsMode.CostCompletion(goal.id)
                    GoalType.DEBT_PAYOFF -> GoalsMode.DebtPayment(goal.id)
                    else -> GoalsMode.Details(goal.id)
                }
            },
            viewModel = viewModel,
        )
        is GoalsMode.AssetCompletion -> selectedGoal?.let { goal ->
            AssetGoalCompletionScreen(
                goal = goal,
                onSubmit = {
                    viewModel.completeAsset(it)
                    mode = GoalsMode.Details(goal.id)
                },
                onBack = { mode = GoalsMode.Details(goal.id) },
            )
        }
        is GoalsMode.CostCompletion -> selectedGoal?.let { goal ->
            CostGoalCompletionScreen(
                goal = goal,
                onSubmit = {
                    viewModel.completeCost(it)
                    mode = GoalsMode.Details(goal.id)
                },
                onBack = { mode = GoalsMode.Details(goal.id) },
            )
        }
        is GoalsMode.DebtPayment -> selectedGoal?.let { goal ->
            DebtGoalPaymentScreen(
                goal = goal,
                onSubmit = {
                    viewModel.recordDebtPayment(it)
                    mode = GoalsMode.Details(goal.id)
                },
                onBack = { mode = GoalsMode.Details(goal.id) },
            )
        }
    }
}

private sealed class GoalsMode {
    object List : GoalsMode()
    data class Editor(val goalId: String?) : GoalsMode()
    data class Details(val goalId: String) : GoalsMode()
    data class AssetCompletion(val goalId: String) : GoalsMode()
    data class CostCompletion(val goalId: String) : GoalsMode()
    data class DebtPayment(val goalId: String) : GoalsMode()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun GoalsListContent(
    goals: List<GoalListItem>,
    filter: GoalListFilter,
    onFilterChange: (GoalListFilter) -> Unit,
    onCreate: () -> Unit,
    onOpen: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("الأهداف المالية", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Button(
                onClick = onCreate,
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BackgroundDark),
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("هدف")
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GoalListFilter.entries.forEach { option ->
                FilterChip(
                    selected = filter == option,
                    onClick = { onFilterChange(option) },
                    label = { Text(option.label()) },
                )
            }
        }
        if (goals.isEmpty()) {
            EmptyGoalsState(onCreate = onCreate)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(goals, key = { it.id }) { goal ->
                    GoalCard(goal = goal, onOpen = { onOpen(goal.id) })
                }
            }
        }
    }
}

@Composable
private fun GoalCard(goal: GoalListItem, onOpen: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(goal.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(goal.type.arabicLabel(), color = TextMuted, fontSize = 12.sp)
                }
                StatusBadge(goal.lifecycleStatus)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الهدف ${NumberDisplayFormatter.format(BigDecimal(goal.targetDecimal), useGrouping = true)}", color = TextSecondary, fontSize = 12.sp)
                Text(goal.deadline, color = AccentCyan, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EmptyGoalsState(onCreate: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = SurfaceDark,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Default.Flag, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(34.dp))
            Text("لا توجد أهداف في هذا التصنيف", color = TextPrimary, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = onCreate) { Text("إنشاء هدف") }
        }
    }
}

@Composable
private fun GoalsDisabledState() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
            Text("الأهداف المالية غير مفعلة حاليًا", color = TextPrimary, fontWeight = FontWeight.Bold)
            Text("سيبقى تبويب الميزانية يعمل كالمعتاد حتى تفعيل المرحلة.", color = TextMuted, fontSize = 13.sp)
        }
    }
}

@Composable
fun StatusBadge(status: GoalLifecycleStatus) {
    val tint = when (status) {
        GoalLifecycleStatus.ACTIVE, GoalLifecycleStatus.READY -> IncomeGreen
        GoalLifecycleStatus.PAUSED -> AccentCyan
        GoalLifecycleStatus.COMPLETED -> GoldPrimary
        GoalLifecycleStatus.ARCHIVED, GoalLifecycleStatus.CANCELLED -> TextMuted
        GoalLifecycleStatus.DRAFT -> TextSecondary
    }
    AssistChip(
        onClick = {},
        label = { Text(status.arabicLabel(), color = tint, fontSize = 12.sp) },
        leadingIcon = { Icon(status.icon(), contentDescription = null, tint = tint, modifier = Modifier.size(16.dp)) },
    )
}

private fun GoalLifecycleStatus.icon(): ImageVector = when (this) {
    GoalLifecycleStatus.ACTIVE -> Icons.Default.Flag
    GoalLifecycleStatus.PAUSED -> Icons.Default.PauseCircle
    GoalLifecycleStatus.READY, GoalLifecycleStatus.COMPLETED -> Icons.Default.CheckCircle
    GoalLifecycleStatus.CANCELLED, GoalLifecycleStatus.ARCHIVED -> Icons.Default.Archive
    GoalLifecycleStatus.DRAFT -> Icons.Default.Flag
}

private fun GoalListFilter.label(): String = when (this) {
    GoalListFilter.ACTIVE -> "نشطة وجاهزة"
    GoalListFilter.PAUSED -> "متوقفة"
    GoalListFilter.COMPLETED -> "مكتملة"
    GoalListFilter.ARCHIVED -> "الأرشيف"
}

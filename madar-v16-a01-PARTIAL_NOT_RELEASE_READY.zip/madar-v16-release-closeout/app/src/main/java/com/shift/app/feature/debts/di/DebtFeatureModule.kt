package com.shift.app.feature.debts.di

import com.shift.app.feature.debts.data.AssetDebtSettlementQueryAdapter
import com.shift.app.feature.debts.data.DebtGatewayAdapter
import com.shift.app.feature.debts.data.FinancialGoalDebtScopeAdapter
import com.shift.app.feature.debts.domain.repository.DebtGateway
import com.shift.app.feature.debts.domain.repository.DebtGoalScopePort
import com.shift.app.feature.debts.domain.repository.DebtSettlementAssetQuery
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class DebtFeatureModule {
    @Binds
    @Singleton
    abstract fun bindDebtGateway(impl: DebtGatewayAdapter): DebtGateway

    @Binds
    @Singleton
    abstract fun bindDebtSettlementAssetQuery(impl: AssetDebtSettlementQueryAdapter): DebtSettlementAssetQuery

    @Binds
    @Singleton
    abstract fun bindDebtGoalScopePort(impl: FinancialGoalDebtScopeAdapter): DebtGoalScopePort
}

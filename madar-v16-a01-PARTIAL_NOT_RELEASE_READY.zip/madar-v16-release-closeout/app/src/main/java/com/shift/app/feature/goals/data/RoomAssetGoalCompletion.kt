package com.shift.app.feature.goals.data

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.repository.AssetRepository
import com.shift.app.data.repository.DebtLedgerRepository
import com.shift.app.data.repository.FinancialGoalRepository
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import java.util.UUID
import javax.inject.Inject
import com.shift.app.domain.goals.usecase.AssetGoalCompletionRequest

internal class RoomAssetGoalCompletion @Inject constructor(
    private val database: MadarDatabase,
    private val goalRepository: FinancialGoalRepository,
    private val assetRepository: AssetRepository,
    private val debtLedgerRepository: DebtLedgerRepository,
) {
    suspend fun complete(request: AssetGoalCompletionRequest) = database.withTransaction {
        val aggregate = requireNotNull(goalRepository.getAggregate(request.goalId)) { "Goal not found" }
        require(aggregate.goal.type == GoalType.HOUSE_PURCHASE || aggregate.goal.type == GoalType.CAR_PURCHASE)
        require(aggregate.goal.lifecycleStatus == GoalLifecycleStatus.READY) { "Asset purchase goal must be READY" }
        val balanceTransactionId = if (request.financed) {
            val records = debtLedgerRepository.recordFinancedAssetPurchase(
                operationId = request.operationId,
                accountId = request.debtAccountId,
                assetId = UUID.randomUUID().toString(),
                partyName = request.lenderName.ifBlank { "ممّول" },
                assetType = request.assetType,
                assetName = request.assetName,
                financedAmountDecimal = request.financedAmountDecimal,
                assetValueDecimal = request.amountDecimal,
                cashPaidDecimal = request.cashPaidDecimal,
                occurredAt = request.now,
                note = request.note,
            )
            records.balanceTransaction?.id
        } else {
            val records = assetRepository.purchaseAsset(
                PurchaseAssetRequest(
                    name = request.assetName,
                    type = request.assetType,
                    amountDecimal = request.amountDecimal,
                    date = request.date,
                    note = request.note,
                    operationId = request.operationId,
                ),
            )
            records.balanceTransactions.single().id
        }
        val consumeAmount = if (request.financed) request.cashPaidDecimal else request.amountDecimal
        goalRepository.recordFundingTransaction(
            goalId = request.goalId,
            operationId = "${request.operationId}:consume",
            kind = FundingKind.CONSUME,
            amountDecimal = consumeAmount,
            currencyCode = aggregate.goal.currencyCode,
            note = "إكمال شراء أصل: ${request.assetName}",
            now = request.now,
            balanceTransactionId = balanceTransactionId,
        )
        goalRepository.transition(
            goalId = request.goalId,
            expectedRevision = aggregate.goal.revision,
            to = GoalLifecycleStatus.COMPLETED,
            operationId = request.operationId,
            now = request.now,
            activityType = "ASSET_PURCHASE_COMPLETED",
        )
    }
}

package com.shift.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.domain.finance.SyncState

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = BalanceTransaction::class,
            parentColumns = ["id"],
            childColumns = ["balanceTransactionId"],
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [
        Index(value = ["operationId"]),
        Index(value = ["balanceTransactionId"]),
        Index(value = ["legacyTransactionId"], unique = true),
        Index(value = ["date", "kind", "deletedAt"]),
        Index(value = ["assetId"])
    ]
)
data class Payment(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val operationId: String,
    val kind: String,
    val amountDecimal: String,
    val currencyCode: String = "SDG",
    val date: String,
    val purpose: String = "",
    val purposeKey: String = "",
    val beneficiaryId: String? = null,
    val beneficiaryNameSnapshot: String = "",
    val assetId: String? = null,
    val assetNameSnapshot: String = "",
    val balanceTransactionId: String?,
    val legacyTransactionId: String? = null,
    val note: String = "",
    val syncState: String = SyncState.Pending.dbValue,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
) {
    constructor(
        operationId: String,
        kind: PaymentKind,
        amountDecimal: String,
        currencyCode: String = "SDG",
        date: String,
        purpose: String = "",
        purposeKey: String = "",
        beneficiaryId: String? = null,
        beneficiaryNameSnapshot: String = "",
        assetId: String? = null,
        assetNameSnapshot: String = "",
        balanceTransactionId: String?,
        note: String = ""
    ) : this(
        operationId = operationId,
        kind = kind.dbValue,
        amountDecimal = amountDecimal,
        currencyCode = currencyCode,
        date = date,
        purpose = purpose,
        purposeKey = purposeKey,
        beneficiaryId = beneficiaryId,
        beneficiaryNameSnapshot = beneficiaryNameSnapshot,
        assetId = assetId,
        assetNameSnapshot = assetNameSnapshot,
        balanceTransactionId = balanceTransactionId,
        note = note
    )
}

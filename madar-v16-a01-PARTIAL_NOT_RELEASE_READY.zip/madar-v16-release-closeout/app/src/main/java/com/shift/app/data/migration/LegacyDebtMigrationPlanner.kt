package com.shift.app.data.migration

import com.shift.app.data.local.entities.Debt
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest

sealed class LegacyDebtMigrationPlan {
    data class Opening(
        val legacyDebt: Debt,
        val direction: DebtDirection,
        val amountDecimal: String,
        val archived: Boolean,
    ) : LegacyDebtMigrationPlan()

    data class Review(
        val legacyDebt: Debt,
        val reason: String,
    ) : LegacyDebtMigrationPlan()
}

data class LegacyDebtMigrationPreview(
    val sourceFingerprint: String,
    val currencyCode: String,
    val plans: List<LegacyDebtMigrationPlan>,
    val candidateCount: Int,
    val reviewCount: Int,
    val receivableDecimal: String,
    val payableDecimal: String,
) {
    init {
        require(sourceFingerprint.matches(Regex("[0-9a-f]{64}")))
        require(currencyCode.matches(Regex("[A-Z]{3}")))
        require(candidateCount >= 0)
        require(reviewCount >= 0)
    }
}

object LegacyDebtMigrationPlanner {
    fun plan(debt: Debt): LegacyDebtMigrationPlan {
        if (debt.deletedAt != null) return LegacyDebtMigrationPlan.Review(debt, "legacy debt is deleted")
        if (debt.name.isBlank()) return LegacyDebtMigrationPlan.Review(debt, "missing party")
        if (!debt.amount.isFinite() || debt.amount <= 0.0) {
            return LegacyDebtMigrationPlan.Review(debt, "invalid amount")
        }
        val direction = when (debt.type.trim().lowercase()) {
            "borrow", "payable" -> DebtDirection.Payable
            "lend", "receivable" -> DebtDirection.Receivable
            else -> return LegacyDebtMigrationPlan.Review(debt, "unknown legacy type")
        }
        return LegacyDebtMigrationPlan.Opening(
            legacyDebt = debt,
            direction = direction,
            amountDecimal = DecimalText.moneyFromLegacyDouble(debt.amount),
            archived = debt.isSettled,
        )
    }

    fun preview(
        debts: List<Debt>,
        localCurrencyCode: String = "SDG",
    ): LegacyDebtMigrationPreview {
        val currency = localCurrencyCode.trim().uppercase()
        require(currency.matches(Regex("[A-Z]{3}"))) { "Invalid local currency code" }
        val plans = debts.sortedBy { it.id }.map(::plan)
        val openings = plans.filterIsInstance<LegacyDebtMigrationPlan.Opening>()
        val activeOpenings = openings.filterNot { it.archived }
        val receivable = activeOpenings.asSequence()
            .filter { it.direction == DebtDirection.Receivable }
            .fold(BigDecimal.ZERO) { total, plan ->
                total.add(DecimalText.toBigDecimal(plan.amountDecimal))
            }
            .moneyText()
        val payable = activeOpenings.asSequence()
            .filter { it.direction == DebtDirection.Payable }
            .fold(BigDecimal.ZERO) { total, plan ->
                total.add(DecimalText.toBigDecimal(plan.amountDecimal))
            }
            .moneyText()
        val fingerprint = fingerprint(
            buildList {
                add("legacy-debt-migration-v2")
                add("currency=$currency")
                debts.sortedBy { it.id }.forEach { debt ->
                    add(
                        listOf(
                            debt.id,
                            debt.name.trim(),
                            debt.amount.toString(),
                            debt.type.trim().lowercase(),
                            debt.dueDate,
                            debt.note,
                            debt.isSettled.toString(),
                            debt.createdAt.toString(),
                            debt.updatedAt.toString(),
                            debt.deletedAt?.toString().orEmpty(),
                        ).joinToString("|"),
                    )
                }
            },
        )
        return LegacyDebtMigrationPreview(
            sourceFingerprint = fingerprint,
            currencyCode = currency,
            plans = plans,
            candidateCount = openings.size,
            reviewCount = plans.count { it is LegacyDebtMigrationPlan.Review },
            receivableDecimal = receivable,
            payableDecimal = payable,
        )
    }

    fun legacyPayload(debt: Debt): String = buildString {
        append('{')
        append("\"id\":\"").append(debt.id.jsonEscape()).append("\",")
        append("\"name\":\"").append(debt.name.jsonEscape()).append("\",")
        append("\"amount\":").append(debt.amount).append(',')
        append("\"type\":\"").append(debt.type.jsonEscape()).append("\",")
        append("\"isSettled\":").append(debt.isSettled)
        append('}')
    }

    private fun fingerprint(parts: List<String>): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(parts.joinToString("\n").toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun String.jsonEscape(): String = buildString(length) {
        this@jsonEscape.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(ch)
            }
        }
    }

    private fun BigDecimal.moneyText(): String =
        setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()
}

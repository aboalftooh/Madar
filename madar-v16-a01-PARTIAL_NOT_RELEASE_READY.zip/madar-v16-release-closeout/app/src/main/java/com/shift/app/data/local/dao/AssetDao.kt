package com.shift.app.data.local.dao

import androidx.room.*
import com.shift.app.data.local.entities.Asset
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Asset>>

    @Query("SELECT * FROM assets")
    suspend fun getAllOnce(): List<Asset>

    @Query("SELECT * FROM assets WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Asset?

    @Query("SELECT * FROM assets WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<Asset?>

    @Query("SELECT * FROM assets WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<Asset>

    @Query("SELECT * FROM assets WHERE operationId = :operationId AND deletedAt IS NULL")
    suspend fun getActiveByOperationId(operationId: String): List<Asset>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: Asset)

    @Update
    suspend fun update(item: Asset)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<Asset>)

    @Query("DELETE FROM assets")
    suspend fun deleteAll()
}

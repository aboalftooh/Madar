package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteDebtTransaction(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("account_id") val accountId: String,
    @SerialName("operation_id") val operationId: String,
    val type: String,
    @SerialName("amount_decimal") val amountDecimal: String,
    @SerialName("currency_code") val currencyCode: String,
    @SerialName("occurred_at") val occurredAt: Long,
    val note: String = "",
    val reason: String? = null,
    @SerialName("original_transaction_id") val originalTransactionId: String? = null,
    @SerialName("source_type") val sourceType: String = "",
    @SerialName("source_id") val sourceId: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null
)

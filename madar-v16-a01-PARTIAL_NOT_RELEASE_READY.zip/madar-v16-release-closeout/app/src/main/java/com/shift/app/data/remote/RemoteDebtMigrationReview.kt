package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteDebtMigrationReview(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("legacy_debt_id") val legacyDebtId: String,
    @SerialName("proposed_account_id") val proposedAccountId: String? = null,
    val status: String,
    val reason: String,
    @SerialName("legacy_payload_json") val legacyPayloadJson: String,
    @SerialName("resolution_note") val resolutionNote: String? = null,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null
)

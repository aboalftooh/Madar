package com.shift.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.finance.FinancialReportCalculator
import com.shift.app.ui.components.AddTransactionSheet
import com.shift.app.ui.theme.*
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.viewmodel.TransactionsViewModel
import java.math.BigDecimal
import java.time.YearMonth
import kotlinx.coroutines.launch

enum class DashboardSection { INCOME, PAYMENTS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    vm: TransactionsViewModel,
    selectedSection: DashboardSection,
    onSectionSelected: (DashboardSection) -> Unit,
    openPaymentsEditorSignal: Int,
    onPaymentsEditorConsumed: () -> Unit
) {
    val transactions by vm.transactions.collectAsState()
    val balanceTransactions by vm.balanceTransactions.collectAsState()
    val payments by vm.payments.collectAsState()
    val migratedLegacyExpenseIds by vm.migratedLegacyExpenseIds.collectAsState()
    var editTx        by remember { mutableStateOf<Transaction?>(null) }

    val currentMonth = YearMonth.now()
    val previousMonth = currentMonth.minusMonths(1)
    var selectedMonth by remember { mutableStateOf(currentMonth) }

    // ── Snackbar + undo + confirm delete ─────────────────────────
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var pendingDeleteId by remember { mutableStateOf<String?>(null) }
    var txToDelete      by remember { mutableStateOf<Transaction?>(null) }

    // ── Filtered data ─────────────────────────────────────────────
    val monthReport = remember(transactions, balanceTransactions, payments, migratedLegacyExpenseIds, selectedMonth) {
        FinancialReportCalculator.month(
            transactions,
            balanceTransactions,
            payments,
            selectedMonth,
            migratedLegacyExpenseIds,
        )
    }
    val filteredList = remember(transactions, selectedMonth, pendingDeleteId) {
        transactions.filter { tx ->
            tx.deletedAt == null && tx.type == "income" && tx.id != pendingDeleteId &&
                runCatching { YearMonth.from(java.time.LocalDate.parse(tx.date)) }.getOrNull() == selectedMonth
        }
    }

    Scaffold(
        snackbarHost   = { SnackbarHost(snackbarHostState) },
        containerColor = BackgroundDark
    ) { innerPadding ->
        LazyColumn(
            modifier            = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding      = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── Header ──────────────────────────────────────────────
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text(
                        "لوحة التحكم",
                        fontSize   = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color      = TextPrimary,
                        fontFamily = CairoFamily
                    )
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(GoldGlow)
                            .clickable {
                                selectedMonth = if (selectedMonth == currentMonth) previousMonth else currentMonth
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "${monthName(selectedMonth.monthValue)} ${selectedMonth.year}",
                            color = GoldLight, fontSize = 12.sp, fontFamily = CairoFamily
                        )
                    }
                }
            }

            // ── البطاقتان الرئيسيتان ─────────────────────────────────
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LuxurySummaryCard(
                        label    = "الدخل",
                        amount   = monthReport.income,
                        subtitle = "خلال الشهر",
                        color    = IncomeGreen,
                        selected = selectedSection == DashboardSection.INCOME,
                        modifier = Modifier.weight(1f).height(145.dp)
                    ) { onSectionSelected(DashboardSection.INCOME) }

                    LuxurySummaryCard(
                        label    = "المدفوعات",
                        amount   = monthReport.payments,
                        subtitle = "كل الأموال الخارجة",
                        color    = ExpenseRed,
                        selected = selectedSection == DashboardSection.PAYMENTS,
                        modifier = Modifier.weight(1f).height(145.dp)
                    ) { onSectionSelected(DashboardSection.PAYMENTS) }
                }
            }

            if (selectedSection == DashboardSection.INCOME) {
                // ── قائمة فارغة ──────────────────────────────────────────
                if (filteredList.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.TrendingUp,
                                    contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "لا توجد إيرادات في هذا الشهر",
                                    color = TextMuted, fontSize = 14.sp, fontFamily = CairoFamily
                                )
                            }
                        }
                    }
                }

                // ── قائمة المعاملات ───────────────────────────────────────
                items(filteredList, key = { it.id }) { tx ->
                    LuxuryTxRow(
                        tx     = tx,
                        onEdit = { editTx = tx },
                        onDelete = { txToDelete = tx }
                    )
                }
            } else {
                item {
                    PaymentsDetails(
                        month = selectedMonth,
                        openEditorSignal = openPaymentsEditorSignal,
                        onEditorConsumed = onPaymentsEditorConsumed
                    )
                }
            }
        }
    }

    // ── Confirm delete dialog ─────────────────────────────────────
    txToDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            containerColor   = SurfaceDark,
            title = { Text("تأكيد الحذف", color = ExpenseRed, fontWeight = FontWeight.Bold) },
            text  = { Text("هل تريد حذف هذه المعاملة؟", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        txToDelete = null
                        pendingDeleteId?.let { id -> vm.deleteTransaction(id) }
                        pendingDeleteId = tx.id
                        scope.launch {
                            val result = snackbarHostState.showSnackbar(
                                message     = "تم حذف المعاملة",
                                actionLabel = "تراجع",
                                duration    = SnackbarDuration.Long
                            )
                            if (result == SnackbarResult.ActionPerformed) {
                                if (pendingDeleteId == tx.id) pendingDeleteId = null
                            } else {
                                if (pendingDeleteId == tx.id) {
                                    vm.deleteTransaction(tx.id)
                                    pendingDeleteId = null
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { txToDelete = null }) { Text("إلغاء", color = TextMuted) }
            }
        )
    }



    if (editTx != null) {
        AddTransactionSheet(vm = vm, editItem = editTx, onDismiss = { editTx = null })
    }
}

// ── بطاقة دخل / مصروف ────────────────────────────────────────────────
@Composable
private fun LuxurySummaryCard(
    label: String, amount: BigDecimal, subtitle: String,
    color: Color, selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg by animateColorAsState(
        targetValue   = if (selected) color else Color(0xFF1E1E2A),
        animationSpec = tween(250), label = "bg"
    )
    val labelColor by animateColorAsState(
        targetValue   = if (selected) Color.White.copy(alpha = 0.85f) else TextMuted,
        animationSpec = tween(250), label = "label"
    )
    val numColor by animateColorAsState(
        targetValue   = if (selected) Color.White else TextPrimary,
        animationSpec = tween(250), label = "num"
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = labelColor, fontSize = 13.sp, fontWeight = FontWeight.Normal)
        Text(
            text  = NumberDisplayFormatter.format(amount, useGrouping = true),
            color = numColor,
            style = NumberStyleLarge
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.CalendarToday, contentDescription = null,
                tint = if (selected) Color.White.copy(0.6f) else TextMuted, modifier = Modifier.size(11.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                subtitle,
                color    = if (selected) Color.White.copy(0.6f) else TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

// ── صف معاملة ────────────────────────────────────────────────────────
@Composable
private fun LuxuryTxRow(tx: Transaction, onDelete: () -> Unit, onEdit: () -> Unit) {
    val color = if (tx.type == "income") IncomeGreen else ExpenseRed
    val icon  = if (tx.type == "income") Icons.Default.TrendingUp else Icons.Default.TrendingDown

    Card(
        shape    = RoundedCornerShape(18.dp),
        colors   = CardDefaults.cardColors(containerColor = SurfaceDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                val title = if (tx.type == "income") {
                    tx.incomeSourceNameSnapshot.ifBlank { tx.category.ifBlank { "أخرى" } }
                } else {
                    tx.purpose.ifBlank { tx.category.ifBlank { "أخرى" } }
                }
                Text(
                    title,
                    color = TextPrimary, fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp, fontFamily = CairoFamily
                )
                if (tx.type == "income" && tx.paymentMethodSnapshot.isNotBlank())
                    Text(tx.paymentMethodSnapshot, color = AccentCyan, fontSize = 10.sp, fontFamily = CairoFamily)
                if (tx.type == "expense" && tx.expenseBeneficiaryNameSnapshot.isNotBlank())
                    Text(tx.expenseBeneficiaryNameSnapshot, color = AccentCyan, fontSize = 10.sp, fontFamily = CairoFamily)
                Text(tx.date, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
                if (tx.note.isNotBlank())
                    Text(tx.note, color = TextMuted, fontSize = 11.sp, fontFamily = CairoFamily)
            }

            Text(
                "${if (tx.type == "income") "+" else "-"}${NumberDisplayFormatter.format(kotlin.math.abs(tx.amount), useGrouping = true)}",
                color = color, style = NumberStyleMedium
            )

            IconButton(onClick = onEdit,   modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Edit,   contentDescription = "تعديل", tint = TextMuted, modifier = Modifier.size(16.dp))
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "حذف",   tint = TextMuted, modifier = Modifier.size(16.dp))
            }
        }
    }
}

fun monthName(m: Int) = listOf("","يناير","فبراير","مارس","أبريل","مايو","يونيو",
    "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر")[m]

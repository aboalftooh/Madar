package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

data class DebtReasonedActionState(
    val amountDecimal: String = "",
    val reason: String = "",
    val submitted: Boolean = false
) {
    fun error(): String? = when {
        amountDecimal.isBlank() -> "المبلغ مطلوب"
        reason.isBlank() -> "السبب مطلوب"
        else -> null
    }
}

@Composable
fun DebtSettlementRoute(state: DebtReasonedActionState, onSubmit: () -> Unit) {
    Column {
        Text("تسوية / إعفاء / إسقاط")
        Text("تأكيد إضافي: قد يتغير صافي الثروة")
        Button(enabled = state.error() == null && !state.submitted, onClick = onSubmit) { Text("حفظ التسوية") }
    }
}

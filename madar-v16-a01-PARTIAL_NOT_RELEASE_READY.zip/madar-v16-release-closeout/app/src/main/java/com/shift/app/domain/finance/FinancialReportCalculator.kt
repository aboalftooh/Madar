package com.shift.app.domain.finance

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth

data class PeriodFinancialReport(
    val income: BigDecimal,
    val payments: BigDecimal,
    val actualExpenses: BigDecimal
) {
    val net: BigDecimal get() = income.subtract(actualExpenses).asMoney()
    val savingRatePercent: Int
        get() = if (income.signum() > 0) {
            net.multiply(BigDecimal(100))
                .divide(income, 0, RoundingMode.DOWN)
                .toInt()
        } else {
            0
        }
}

data class ReportCategoryAmount(val name: String, val amount: BigDecimal)

data class WealthSnapshot(
    val balance: BigDecimal,
    val assetsValue: BigDecimal,
    val receivables: BigDecimal = BigDecimal.ZERO.setScale(DecimalTextScale.Money.places),
    val payables: BigDecimal = BigDecimal.ZERO.setScale(DecimalTextScale.Money.places),
) {
    val netWorth: BigDecimal get() = balance.add(assetsValue).add(receivables).subtract(payables).asMoney()
}

/**
 * The one source of truth for dashboard, reports and budget figures.
 *
 * Linked financial rows always use Decimal values from [BalanceTransaction] and [Payment].
 * [Transaction.amount] is only a compatibility projection for rows that have not crossed
 * over yet and is never allowed to override an existing ledger link.
 */
object FinancialReportCalculator {
    /**
     * Canonical report path. Linked transactions take their amounts exclusively from
     * Decimal ledger rows. Legacy Double is used only for rows that have not crossed over yet.
     */
    fun period(
        transactions: List<Transaction>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate,
        migratedLegacyExpenseIds: Set<String> = emptySet(),
    ): PeriodFinancialReport {
        if (from.isAfter(to)) return PeriodFinancialReport(ZERO_MONEY, ZERO_MONEY, ZERO_MONEY)

        val visibleBalances = activeLogicalBalances(balanceTransactions)
            .filter { it.date.inRange(from, to) }
        val visiblePayments = activeLogicalPayments(payments)
            .filter { it.date.inRange(from, to) }
        val linkedTransactionIds = buildSet {
            addAll(visibleBalances.mapNotNull { it.legacyTransactionId })
            addAll(visibleBalances.filter { it.sourceType == "transaction" }.mapNotNull { it.sourceId })
            addAll(visiblePayments.mapNotNull { it.legacyTransactionId })
        }
        val allMigratedLegacyExpenseIds = migratedLegacyExpenseIds + linkedTransactionIds
        val visibleTransactions = transactions.asSequence()
            .filter { it.deletedAt == null && it.date.inRange(from, to) }
            .toList()

        val canonicalIncome = visibleBalances.asSequence()
            .filter { it.kind == BalanceTransactionKind.Income.dbValue }
            .sumMoney { DecimalText.toBigDecimal(it.amountDecimal) }
        val legacyIncomeFallback = visibleTransactions.asSequence()
            .filter { it.type == "income" && it.id !in linkedTransactionIds }
            .sumMoney { BigDecimal.valueOf(it.amount) }
        val legacyExpenses = visibleTransactions.asSequence()
            .filter { it.type == "expense" && it.id !in allMigratedLegacyExpenseIds }
            .sumMoney { BigDecimal.valueOf(it.amount) }
        val allPayments = visiblePayments.asSequence().sumMoney { it.moneyAmount() }
        val reportablePayments = visiblePayments.asSequence()
            .filter { it.kind.toPaymentKind()?.let(FinancialRules::entersExpenseReports) == true }
            .sumMoney { it.moneyAmount() }

        return PeriodFinancialReport(
            income = canonicalIncome.add(legacyIncomeFallback).asMoney(),
            payments = allPayments,
            actualExpenses = legacyExpenses.add(reportablePayments).asMoney(),
        )
    }

    @Deprecated("Use the ledger-aware overload")
    fun period(
        transactions: List<Transaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate,
        migratedLegacyExpenseIds: Set<String> = emptySet(),
    ): PeriodFinancialReport = period(
        transactions = transactions,
        balanceTransactions = emptyList(),
        payments = payments,
        from = from,
        to = to,
        migratedLegacyExpenseIds = migratedLegacyExpenseIds,
    )

    fun month(
        transactions: List<Transaction>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        month: YearMonth,
        migratedLegacyExpenseIds: Set<String> = emptySet(),
    ): PeriodFinancialReport = period(
        transactions = transactions,
        balanceTransactions = balanceTransactions,
        payments = payments,
        from = month.atDay(1),
        to = month.atEndOfMonth(),
        migratedLegacyExpenseIds = migratedLegacyExpenseIds,
    )

    @Deprecated("Use the ledger-aware overload")
    fun month(
        transactions: List<Transaction>,
        payments: List<Payment>,
        month: YearMonth,
        migratedLegacyExpenseIds: Set<String> = emptySet(),
    ): PeriodFinancialReport = month(
        transactions = transactions,
        balanceTransactions = emptyList(),
        payments = payments,
        month = month,
        migratedLegacyExpenseIds = migratedLegacyExpenseIds,
    )

    fun incomeBySource(
        transactions: List<Transaction>,
        balanceTransactions: List<BalanceTransaction>,
        from: LocalDate,
        to: LocalDate,
    ): List<ReportCategoryAmount> {
        val amountByTransactionId = activeLogicalBalances(balanceTransactions).asSequence()
            .filter { it.kind == BalanceTransactionKind.Income.dbValue }
            .mapNotNull { balance ->
                val id = balance.legacyTransactionId
                    ?: balance.sourceId?.takeIf { balance.sourceType == "transaction" }
                id?.let { it to DecimalText.toBigDecimal(balance.amountDecimal) }
            }
            .toMap()
        return transactions.asSequence()
            .filter { it.deletedAt == null && it.type == "income" && it.date.inRange(from, to) }
            .groupBy { it.incomeSourceNameSnapshot.ifBlank { it.category.ifBlank { "أخرى" } } }
            .map { (name, items) ->
                ReportCategoryAmount(
                    name,
                    items.asSequence().sumMoney { tx ->
                        amountByTransactionId[tx.id] ?: BigDecimal.valueOf(tx.amount)
                    },
                )
            }
            .sortedByDescending { it.amount }
    }

    @Deprecated("Use the ledger-aware overload")
    fun incomeBySource(
        transactions: List<Transaction>,
        from: LocalDate,
        to: LocalDate,
    ): List<ReportCategoryAmount> = incomeBySource(transactions, emptyList(), from, to)

    fun expensesByPurpose(
        transactions: List<Transaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate,
        migratedLegacyExpenseIds: Set<String> = emptySet()
    ): List<ReportCategoryAmount> = actualExpenseCategories(
        transactions,
        payments,
        from,
        to,
        migratedLegacyExpenseIds,
        legacyName = { it.purpose.ifBlank { it.category.ifBlank { "أخرى" } } },
        paymentName = { it.purpose.ifBlank { "أخرى" } }
    )

    fun expensesByBeneficiary(
        transactions: List<Transaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate,
        migratedLegacyExpenseIds: Set<String> = emptySet()
    ): List<ReportCategoryAmount> = actualExpenseCategories(
        transactions,
        payments,
        from,
        to,
        migratedLegacyExpenseIds,
        legacyName = { it.expenseBeneficiaryNameSnapshot.ifBlank { "غير محدد" } },
        paymentName = { it.beneficiaryNameSnapshot.ifBlank { it.assetNameSnapshot.ifBlank { "غير محدد" } } }
    )

    fun currentAssetsValue(
        assets: List<Asset>,
        valuations: List<AssetValuation>
    ): BigDecimal {
        val eligibleAssetIds = assets.asSequence()
            .filter { it.deletedAt == null }
            .filter { it.status == AssetStatus.Active.dbValue }
            .map { it.id }
            .toSet()

        return eligibleAssetIds.asSequence().sumMoney { assetId ->
            latestValidValuation(assetId, valuations)?.second ?: BigDecimal.ZERO
        }
    }

    fun latestCurrentValues(
        assets: List<Asset>,
        valuations: List<AssetValuation>
    ): Map<String, BigDecimal> = assets.asSequence()
        .filter { it.deletedAt == null }
        .filter { it.status == AssetStatus.Active.dbValue }
        .mapNotNull { asset -> latestValidValuation(asset.id, valuations)?.second?.let { asset.id to it } }
        .toMap()

    fun wealth(
        balanceTransactions: List<BalanceTransaction>,
        assets: List<Asset>,
        valuations: List<AssetValuation>,
        debtAccounts: List<DebtAccount> = emptyList(),
        debtTransactions: List<DebtTransaction> = emptyList(),
    ): WealthSnapshot = WealthSnapshot(
        balance = BalanceCalculator.currentBalance(balanceTransactions).asMoney(),
        assetsValue = currentAssetsValue(assets, valuations),
        receivables = confirmedDebtRemainder(debtAccounts, debtTransactions, DebtDirection.Receivable),
        payables = confirmedDebtRemainder(debtAccounts, debtTransactions, DebtDirection.Payable),
    )

    private fun confirmedDebtRemainder(
        accounts: List<DebtAccount>,
        transactions: List<DebtTransaction>,
        direction: DebtDirection,
    ): BigDecimal {
        val remainingByAccount = transactions.asSequence()
            .filter { it.deletedAt == null }
            .groupBy { it.accountId }
            .mapValues { (_, rows) ->
                rows.fold(BigDecimal.ZERO) { total, tx ->
                    total.add(
                        DecimalText.toBigDecimal(tx.amountDecimal)
                            .multiply(BigDecimal(DebtTransactionType.fromDb(tx.type).remainingSign))
                    )
                }.max(BigDecimal.ZERO).asMoney()
            }
        return accounts.asSequence()
            .filter { it.deletedAt == null && it.confirmed && it.direction == direction.dbValue }
            .sumMoney { remainingByAccount[it.id] ?: BigDecimal.ZERO }
    }

    private fun actualExpenseCategories(
        transactions: List<Transaction>,
        payments: List<Payment>,
        from: LocalDate,
        to: LocalDate,
        migratedLegacyExpenseIds: Set<String>,
        legacyName: (Transaction) -> String,
        paymentName: (Payment) -> String
    ): List<ReportCategoryAmount> {
        if (from.isAfter(to)) return emptyList()
        val allMigratedLegacyExpenseIds = migratedLegacyExpenseIds +
            payments.mapNotNull { it.legacyTransactionId }
        val values = mutableListOf<Pair<String, BigDecimal>>()
        transactions.asSequence()
            .filter {
                it.deletedAt == null && it.type == "expense" &&
                    it.id !in allMigratedLegacyExpenseIds && it.date.inRange(from, to)
            }
            .forEach { values += legacyName(it) to BigDecimal.valueOf(it.amount).asMoney() }
        activeLogicalPayments(payments).asSequence()
            .filter { it.date.inRange(from, to) }
            .filter { it.kind.toPaymentKind()?.let(FinancialRules::entersExpenseReports) == true }
            .forEach { values += paymentName(it) to it.moneyAmount() }

        return values.groupBy { it.first }
            .map { (name, entries) ->
                ReportCategoryAmount(name, entries.asSequence().sumMoney { it.second })
            }
            .sortedByDescending { it.amount }
    }

    private fun activeLogicalBalances(balanceTransactions: List<BalanceTransaction>): List<BalanceTransaction> =
        balanceTransactions.asSequence()
            .filter { it.deletedAt == null }
            .groupBy { it.id }
            .values
            .map { duplicates ->
                duplicates.maxWith(
                    compareBy<BalanceTransaction> { it.updatedAt }
                        .thenBy { it.createdAt }
                        .thenBy { it.id },
                )
            }

    private fun activeLogicalPayments(payments: List<Payment>): List<Payment> = payments.asSequence()
        .filter { it.deletedAt == null }
        .groupBy { it.operationId.ifBlank { it.id } }
        .values
        .map { duplicates ->
            duplicates.maxWith(compareBy<Payment> { it.updatedAt }.thenBy { it.createdAt }.thenBy { it.id })
        }

    private fun latestValidValuation(
        assetId: String,
        valuations: List<AssetValuation>
    ): Pair<AssetValuation, BigDecimal>? = valuations.asSequence()
        .filter { it.assetId == assetId && it.deletedAt == null }
        .mapNotNull { valuation ->
            val date = runCatching { LocalDate.parse(valuation.date) }.getOrNull() ?: return@mapNotNull null
            val value = runCatching { DecimalText.toBigDecimal(valuation.valueDecimal) }.getOrNull()
                ?.takeIf { it.signum() >= 0 }
                ?: return@mapNotNull null
            Triple(valuation, date, value)
        }
        .maxWithOrNull(
            compareBy<Triple<AssetValuation, LocalDate, BigDecimal>> { it.second }
                .thenBy { it.first.createdAt }
                .thenBy { it.first.id }
        )
        ?.let { it.first to it.third.asMoney() }

    private fun Payment.moneyAmount(): BigDecimal =
        runCatching { DecimalText.toBigDecimal(amountDecimal).asMoney() }.getOrDefault(BigDecimal.ZERO)

    private fun String.toPaymentKind(): PaymentKind? =
        PaymentKind.entries.firstOrNull { it.dbValue == this }

    private fun String.inRange(from: LocalDate, to: LocalDate): Boolean {
        val value = runCatching { LocalDate.parse(this) }.getOrNull() ?: return false
        return !value.isBefore(from) && !value.isAfter(to)
    }

    private inline fun <T> Sequence<T>.sumMoney(value: (T) -> BigDecimal): BigDecimal =
        fold(BigDecimal.ZERO) { total, item -> total.add(value(item)) }.asMoney()

    private val ZERO_MONEY = BigDecimal.ZERO.setScale(DecimalTextScale.Money.places)
}

private fun BigDecimal.asMoney(): BigDecimal =
    setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP)

package com.shift.app.feature.backup.data

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.remote.SyncManager
import com.shift.app.feature.backup.data.codec.AssetBackupCodec
import com.shift.app.feature.backup.data.codec.DebtBackupCodec
import com.shift.app.feature.backup.data.codec.FinanceBackupCodec
import com.shift.app.feature.backup.data.codec.GoalBackupCodec
import com.shift.app.feature.backup.domain.model.BackupCompatibility
import com.shift.app.feature.backup.domain.model.BackupInspection
import com.shift.app.feature.backup.domain.model.BackupImportMode
import com.shift.app.feature.backup.domain.model.BackupPlanSummary
import com.shift.app.feature.backup.domain.model.CorruptBackupException
import com.shift.app.feature.backup.domain.model.IncompatibleBackupException
import com.shift.app.feature.backup.domain.model.RestoreFailureCode
import com.shift.app.feature.backup.domain.model.RestoreReport
import com.shift.app.feature.backup.domain.model.compatibility
import com.shift.app.feature.backup.domain.repository.BackupGateway
import com.shift.app.sync.SyncQueueGateway
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException

@Singleton
internal class BackupGatewayAdapter @Inject constructor(
    private val database: MadarDatabase,
    private val syncManager: SyncManager,
    private val syncQueue: SyncQueueGateway,
    financeCodec: FinanceBackupCodec,
    assetCodec: AssetBackupCodec,
    debtCodec: DebtBackupCodec,
    goalCodec: GoalBackupCodec,
) : BackupGateway {
    private val orderedCodecs: List<BackupSectionCodec> = listOf(
        financeCodec,
        assetCodec,
        debtCodec,
        goalCodec,
    )
    private val documentCodec = BackupDocumentCodec(orderedCodecs)
    private val atomicityGuard = RestoreAtomicityGuard(
        RestoreTransactionBoundary { block -> database.withTransaction { block() } }
    )

    override suspend fun exportJson(): String = documentCodec.encode(System.currentTimeMillis())

    override suspend fun inspect(sourceJson: String): BackupInspection {
        val decoded = documentCodec.decode(sourceJson, System.currentTimeMillis())
        return BackupInspection(
            fingerprint = decoded.fingerprint,
            manifest = decoded.manifest,
            compatibility = decoded.manifest.compatibility(),
            sectionIds = decoded.sections.filterValues { it.rowCount > 0 }.keys.sorted(),
            importedRowCount = decoded.sections.values.sumOf { it.rowCount },
            warnings = legacyWarnings(decoded),
        )
    }

    override suspend fun plan(sourceJson: String, mode: BackupImportMode): BackupPlanSummary {
        val planned = planDocument(sourceJson, mode)
        return planned.toSummary()
    }

    override suspend fun restore(sourceJson: String, mode: BackupImportMode): RestoreReport {
        val sourceFingerprint = BackupRedactor.fingerprint(sourceJson)
        return try {
            val planned = planDocument(sourceJson, mode)
            val applied = syncManager.executeSessionOperation {
                val orderedPlans = orderedCodecs.map { codec ->
                    codec to requireNotNull(planned.sections[codec.id]) { "Missing restore plan for ${codec.id}" }
                }
                atomicityGuard.apply(orderedPlans)
            }
            if (applied == null) {
                RestoreReport.Failure(
                    code = RestoreFailureCode.SESSION_EXPIRED,
                    userMessage = "انتهت جلسة الحساب قبل اكتمال الاستيراد",
                    reference = "SessionExpired:$sourceFingerprint",
                )
            } else {
                val syncScheduled = runCatching {
                    syncQueue.requestSync("backup-import")
                    true
                }.getOrDefault(false)
                RestoreReport.Success(
                    fingerprint = planned.decoded.fingerprint,
                    affectedRowCount = planned.affectedRowCount,
                    sectionCount = planned.sections.size,
                    syncScheduled = syncScheduled,
                    warnings = buildList {
                        addAll(legacyWarnings(planned.decoded))
                        if (!syncScheduled) add("تمت الاستعادة محليًا، وستُعاد محاولة جدولة المزامنة لاحقًا")
                    },
                )
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            val code = when (error) {
                is CorruptBackupException -> RestoreFailureCode.CORRUPT_BACKUP
                is IncompatibleBackupException -> RestoreFailureCode.INCOMPATIBLE_BACKUP
                else -> RestoreFailureCode.RESTORE_FAILED
            }
            RestoreReport.Failure(
                code = code,
                userMessage = when (code) {
                    RestoreFailureCode.CORRUPT_BACKUP -> "ملف النسخة الاحتياطية تالف أو غير مكتمل"
                    RestoreFailureCode.INCOMPATIBLE_BACKUP -> "إصدار النسخة الاحتياطية غير متوافق مع هذا التطبيق"
                    else -> "تعذر استعادة النسخة الاحتياطية دون تغيير البيانات الحالية"
                },
                reference = BackupRedactor.reference(error, sourceFingerprint),
            )
        }
    }

    private suspend fun planDocument(
        sourceJson: String,
        mode: BackupImportMode,
    ): PlannedBackupDocument {
        val now = System.currentTimeMillis()
        val decoded = documentCodec.decode(sourceJson, now)
        require(decoded.manifest.compatibility() == BackupCompatibility.COMPATIBLE)
        val planned = linkedMapOf<String, BackupSectionPlan>()
        orderedCodecs.forEach { codec ->
            val imported = requireNotNull(decoded.sections[codec.id]) { "Missing decoded section ${codec.id}" }
            planned[codec.id] = codec.plan(imported, mode, now)
        }
        return PlannedBackupDocument(decoded, mode, planned)
    }

    private fun PlannedBackupDocument.toSummary() = BackupPlanSummary(
        fingerprint = decoded.fingerprint,
        mode = mode,
        importedRowCount = importedRowCount,
        affectedRowCount = affectedRowCount,
        deleteCount = deleteCount,
        sectionCounts = sections.mapValues { it.value.affectedRowCount },
        warnings = legacyWarnings(decoded),
    )

    private fun legacyWarnings(decoded: DecodedBackupDocument): List<String> = buildList {
        if (decoded.manifest.formatVersion == 1) {
            add("نسخة قديمة بلا Manifest؛ ستُقرأ بوضع التوافق")
        }
        if (decoded.manifest.databaseSchemaVersion < 18) {
            add("النسخة أُنشئت من مخطط أقدم وسيُطبّق التوافق أثناء الاستعادة")
        }
    }
}

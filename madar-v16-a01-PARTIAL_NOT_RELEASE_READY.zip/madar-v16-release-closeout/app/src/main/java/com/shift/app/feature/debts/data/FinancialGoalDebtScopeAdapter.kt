package com.shift.app.feature.debts.data

import com.shift.app.feature.debts.domain.repository.DebtGoalScopePort
import com.shift.app.feature.goals.domain.repository.GoalGateway
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FinancialGoalDebtScopeAdapter @Inject constructor(
    private val goalGateway: GoalGateway,
) : DebtGoalScopePort {
    override suspend fun recordNewDebtDecision(accountId: String, include: Boolean, operationId: String, now: Long) {
        goalGateway.recordNewDebtPayoffDecision(accountId, include, operationId, now)
    }
}

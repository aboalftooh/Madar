package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.dao.SyncOutboxDao
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.domain.finance.LEGACY_HISTORY_MIGRATION_KEY
import com.shift.app.domain.finance.LEGACY_HISTORY_PLANNER_VERSION
import com.shift.app.domain.finance.LEGACY_HISTORY_STATUS_COMPLETED
import com.shift.app.domain.finance.LegacyHistoryMigrationOperation
import com.shift.app.domain.finance.LegacyHistoryMigrationPlanner
import com.shift.app.domain.finance.LegacyHistoryMigrationPreview
import com.shift.app.domain.finance.LegacyHistoryExecutionDecision
import com.shift.app.domain.finance.legacyHistoryExecutionDecision
import com.shift.app.domain.finance.SyncState
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import java.math.BigDecimal
import java.math.RoundingMode
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

data class LegacyHistoryMigrationCommit(
    val preview: LegacyHistoryMigrationPreview,
    val marker: LedgerHistoryMigration,
    val operations: List<LegacyHistoryMigrationOperation>,
    val localCurrencyCode: String,
    val alreadyCompleted: Boolean = false
)


data class LegacyHistoryMigrationVerification(
    val expectedIncomeDecimal: String,
    val actualIncomeDecimal: String,
    val expectedExpenseDecimal: String,
    val actualExpenseDecimal: String,
) {
    val exact: Boolean = expectedIncomeDecimal == actualIncomeDecimal &&
        expectedExpenseDecimal == actualExpenseDecimal

    fun requireExact() {
        require(exact) {
            "Legacy history parity mismatch: income=$actualIncomeDecimal/$expectedIncomeDecimal, " +
                "expense=$actualExpenseDecimal/$expectedExpenseDecimal"
        }
    }
}

data class LegacyHistoryRollbackResult(
    val restoredTransactions: Int,
    val deletedBalanceRows: Int,
    val deletedPayments: Int,
)

class LegacyHistoryMigrationRepository @Inject constructor(
    private val db: MadarDatabase,
    private val transactionDao: TransactionDao,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val markerDao: LedgerHistoryMigrationDao,
    private val outboxDao: SyncOutboxDao,
) {
    fun marker(): Flow<LedgerHistoryMigration?> = markerDao.observe(LEGACY_HISTORY_MIGRATION_KEY)

    suspend fun getMarker(): LedgerHistoryMigration? = markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)

    suspend fun getAllMarkers(): List<LedgerHistoryMigration> = markerDao.getAllOnce()

    suspend fun upsertMarkers(items: List<LedgerHistoryMigration>) = markerDao.upsertAll(items)

    suspend fun deleteAllLocalData() = markerDao.deleteAll()

    suspend fun preview(localCurrencyCode: String, targetBalanceInput: String): LegacyHistoryMigrationPreview =
        run {
            val balances = balanceDao.getAllOnce()
            val payments = paymentDao.getAllOnce()
            if (markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY) == null) {
                require(
                    balances.none {
                        it.legacyTransactionId != null || it.sourceType == "legacy_history_migration"
                    } && payments.none { it.legacyTransactionId != null }
                ) { "History migration links exist without their completion marker" }
            }
            LegacyHistoryMigrationPlanner.preview(
                transactions = transactionDao.getAllOnce(),
                balanceTransactions = balances,
                payments = payments,
                localCurrencyCode = localCurrencyCode,
                targetBalanceInput = targetBalanceInput
            )
        }

    suspend fun prepareCommit(
        expectedCommitFingerprint: String,
        localCurrencyCode: String,
        targetBalanceInput: String,
        now: Long = System.currentTimeMillis()
    ): LegacyHistoryMigrationCommit {
        markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)?.let { existing ->
            require(existing.status == LEGACY_HISTORY_STATUS_COMPLETED) { "History migration marker is invalid" }
            require(
                legacyHistoryExecutionDecision(existing.commitFingerprint, expectedCommitFingerprint) ==
                    LegacyHistoryExecutionDecision.AlreadyCompleted
            ) { "History migration was already completed with different data" }
            return LegacyHistoryMigrationCommit(
                preview = emptyCompletedPreview(existing),
                marker = existing,
                operations = emptyList(),
                localCurrencyCode = localCurrencyCode,
                alreadyCompleted = true
            )
        }
        val preview = preview(localCurrencyCode, targetBalanceInput)
        require(preview.commitFingerprint == expectedCommitFingerprint) {
            "تغيرت البيانات منذ المعاينة؛ راجع المعاينة الجديدة"
        }
        val operations = preview.operations.map { operation ->
            operation.copy(
                transaction = operation.transaction.copy(updatedAt = now, deletedAt = null),
                balanceTransaction = operation.balanceTransaction.copy(
                    syncState = SyncState.Pending.dbValue,
                    updatedAt = now,
                    deletedAt = null
                ),
                payment = operation.payment?.copy(
                    syncState = SyncState.Pending.dbValue,
                    updatedAt = now,
                    deletedAt = null
                )
            )
        }
        val adjustment = preview.adjustmentBalanceTransaction?.copy(
            syncState = SyncState.Pending.dbValue,
            createdAt = now,
            updatedAt = now,
            deletedAt = null
        )
        val committedPreview = preview.copy(
            operations = operations,
            adjustmentBalanceTransaction = adjustment
        )
        val marker = LedgerHistoryMigration(
            migrationKey = LEGACY_HISTORY_MIGRATION_KEY,
            plannerVersion = LEGACY_HISTORY_PLANNER_VERSION,
            status = LEGACY_HISTORY_STATUS_COMPLETED,
            sourceFingerprint = preview.sourceFingerprint,
            commitFingerprint = preview.commitFingerprint,
            candidateCount = preview.candidateCount,
            incomeCount = preview.incomeCount,
            expenseCount = preview.expenseCount,
            historicalIncomeDecimal = preview.historicalIncomeDecimal,
            historicalExpenseDecimal = preview.historicalExpenseDecimal,
            targetBalanceDecimal = preview.targetBalanceDecimal,
            adjustmentDecimal = preview.adjustmentDecimal,
            adjustmentBalanceTransactionId = adjustment?.id,
            confirmedAt = now,
            completedAt = now,
            syncState = SyncState.Pending.dbValue,
            createdAt = now,
            updatedAt = now
        )
        return LegacyHistoryMigrationCommit(committedPreview, marker, operations, localCurrencyCode)
    }

    /** Commits the migration locally; durable outbox triggers schedule the idempotent remote RPC. */
    suspend fun applyLocally(commit: LegacyHistoryMigrationCommit): Boolean = db.withTransaction {
        val existing = markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)
        if (existing != null) {
            require(existing.status == LEGACY_HISTORY_STATUS_COMPLETED) { "History migration marker is invalid" }
            require(existing.commitFingerprint == commit.marker.commitFingerprint) {
                "History migration was already completed with different data"
            }
            return@withTransaction false
        }

        val fresh = LegacyHistoryMigrationPlanner.preview(
            transactions = transactionDao.getAllOnce(),
            balanceTransactions = balanceDao.getAllOnce(),
            payments = paymentDao.getAllOnce(),
            localCurrencyCode = commit.localCurrencyCode,
            targetBalanceInput = commit.preview.targetBalanceDecimal
        )
        require(fresh.commitFingerprint == commit.marker.commitFingerprint) {
            "تغيرت البيانات قبل إكمال الترحيل المحلي"
        }

        commit.operations.forEach { operation ->
            balanceDao.insert(operation.balanceTransaction)
            operation.payment?.let { paymentDao.insert(it) }
            transactionDao.update(operation.transaction)
        }
        commit.preview.adjustmentBalanceTransaction?.let { balanceDao.insert(it) }
        markerDao.upsert(commit.marker)
        true
    }


    suspend fun verifyCommittedParity(): LegacyHistoryMigrationVerification =
        verifyCommittedParity(requireNotNull(getMarker()))

    suspend fun verifyCommittedParity(marker: LedgerHistoryMigration): LegacyHistoryMigrationVerification {
        val balances = balanceDao.getLegacyMigrationRows().filter { it.deletedAt == null }
        val payments = paymentDao.getLegacyMigrationRows().filter { it.deletedAt == null }
        val actualIncome = balances.asSequence()
            .filter { it.kind == BalanceTransactionKind.Income.dbValue }
            .fold(BigDecimal.ZERO) { total, row ->
                total.add(DecimalText.toBigDecimal(row.amountDecimal))
            }
            .moneyText()
        val actualExpense = payments.asSequence()
            .fold(BigDecimal.ZERO) { total, row ->
                total.add(DecimalText.toBigDecimal(row.amountDecimal))
            }
            .moneyText()
        return LegacyHistoryMigrationVerification(
            expectedIncomeDecimal = marker.historicalIncomeDecimal,
            actualIncomeDecimal = actualIncome,
            expectedExpenseDecimal = marker.historicalExpenseDecimal,
            actualExpenseDecimal = actualExpense,
        )
    }

    /**
     * Local rollback is allowed only before any migration row is synchronized or edited.
     * The legacy transaction rows remain the recovery source and are relinked on a retry.
     */
    suspend fun rollbackPending(expectedCommitFingerprint: String): LegacyHistoryRollbackResult =
        db.withTransaction {
            val marker = requireNotNull(markerDao.getByKey(LEGACY_HISTORY_MIGRATION_KEY)) {
                "No legacy history migration to rollback"
            }
            require(marker.commitFingerprint == expectedCommitFingerprint) {
                "History migration fingerprint changed"
            }
            require(marker.syncState == SyncState.Pending.dbValue) {
                "Cannot rollback a synchronized history migration"
            }
            val balances = balanceDao.getLegacyMigrationRows()
            val payments = paymentDao.getLegacyMigrationRows()
            val linkedBalances = balances.filter { it.legacyTransactionId != null }
            val completedAt = requireNotNull(marker.completedAt)
            val linkedTransactions = linkedBalances.map { balance ->
                val legacyId = requireNotNull(balance.legacyTransactionId)
                val transaction = requireNotNull(transactionDao.getById(legacyId)) {
                    "Linked legacy transaction is missing"
                }
                require(transaction.operationId == balance.operationId &&
                    transaction.balanceTransactionId == balance.id) {
                    "Legacy transaction link changed after migration"
                }
                require(transaction.updatedAt == completedAt && balance.updatedAt == completedAt) {
                    "Cannot rollback history after a migrated transaction was edited"
                }
                transaction to balance
            }
            val allPending = balances.all { it.syncState == SyncState.Pending.dbValue } &&
                payments.all { it.syncState == SyncState.Pending.dbValue }
            require(allPending) { "Cannot rollback history rows that were already synchronized" }

            payments.forEach { payment ->
                paymentDao.hardDeleteById(payment.id)
                outboxDao.deleteForEntity("payments", payment.id)
                outboxDao.deleteForOperation(payment.operationId)
            }
            linkedTransactions.forEach { (transaction, balance) ->
                transactionDao.clearLedgerLink(transaction.id, balance.createdAt)
                outboxDao.deleteForEntity("transactions", transaction.id)
                outboxDao.deleteForOperation(balance.operationId)
            }
            balances.forEach { balance ->
                balanceDao.hardDeleteById(balance.id)
                outboxDao.deleteForEntity("balance_transactions", balance.id)
                outboxDao.deleteForOperation(balance.operationId)
            }
            markerDao.deleteByKey(LEGACY_HISTORY_MIGRATION_KEY)
            outboxDao.deleteForEntity("ledger_history_migrations", LEGACY_HISTORY_MIGRATION_KEY)
            LegacyHistoryRollbackResult(
                restoredTransactions = linkedTransactions.size,
                deletedBalanceRows = balances.size,
                deletedPayments = payments.size,
            )
        }

    private fun BigDecimal.moneyText(): String =
        setScale(DecimalTextScale.Money.places, RoundingMode.HALF_UP).toPlainString()


    private fun emptyCompletedPreview(marker: LedgerHistoryMigration): LegacyHistoryMigrationPreview =
        LegacyHistoryMigrationPreview(
            sourceFingerprint = marker.sourceFingerprint,
            commitFingerprint = marker.commitFingerprint,
            candidateCount = marker.candidateCount,
            incomeCount = marker.incomeCount,
            expenseCount = marker.expenseCount,
            historicalIncomeDecimal = marker.historicalIncomeDecimal,
            historicalExpenseDecimal = marker.historicalExpenseDecimal,
            historicalNetDecimal = "0.00",
            currentBalanceDecimal = marker.targetBalanceDecimal,
            projectedBalanceDecimal = marker.targetBalanceDecimal,
            targetBalanceDecimal = marker.targetBalanceDecimal,
            adjustmentDecimal = marker.adjustmentDecimal,
            operations = emptyList(),
            adjustmentBalanceTransaction = null
        )
}

package com.shift.app.feature.assets.data

import com.shift.app.feature.assets.domain.model.Asset as DomainAsset
import com.shift.app.feature.assets.domain.model.AssetTransaction as DomainAssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation as DomainAssetValuation
import com.shift.app.feature.assets.domain.model.CurrencyAssetLot as DomainCurrencyAssetLot
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleAllocation as DomainCurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Asset as EntityAsset
import com.shift.app.data.local.entities.AssetTransaction as EntityAssetTransaction
import com.shift.app.data.local.entities.AssetValuation as EntityAssetValuation
import com.shift.app.data.local.entities.CurrencyAssetLot as EntityCurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation as EntityCurrencyAssetSaleAllocation

internal object AssetEntityMapper {
    fun asset(entity: EntityAsset) = DomainAsset(
        id = entity.id,
        operationId = entity.operationId,
        type = entity.type,
        name = entity.name,
        status = entity.status,
        acquisitionMode = entity.acquisitionMode,
        acquisitionAmountDecimal = entity.acquisitionAmountDecimal,
        currencyCode = entity.currencyCode,
        purchasePaymentId = entity.purchasePaymentId,
        purchaseBalanceTransactionId = entity.purchaseBalanceTransactionId,
        currentValueCacheDecimal = entity.currentValueCacheDecimal,
        currentValueCacheValuationId = entity.currentValueCacheValuationId,
        createdAt = entity.createdAt,
        updatedAt = entity.updatedAt,
        deletedAt = entity.deletedAt,
    )

    fun transaction(entity: EntityAssetTransaction) = DomainAssetTransaction(
        id = entity.id,
        operationId = entity.operationId,
        assetId = entity.assetId,
        kind = entity.kind,
        amountDecimal = entity.amountDecimal,
        currencyQuantityDeltaDecimal = entity.currencyQuantityDeltaDecimal,
        paymentId = entity.paymentId,
        balanceTransactionId = entity.balanceTransactionId,
        date = entity.date,
        note = entity.note,
        createdAt = entity.createdAt,
        updatedAt = entity.updatedAt,
        deletedAt = entity.deletedAt,
    )

    fun valuation(entity: EntityAssetValuation) = DomainAssetValuation(
        id = entity.id,
        operationId = entity.operationId,
        assetId = entity.assetId,
        valueDecimal = entity.valueDecimal,
        date = entity.date,
        note = entity.note,
        createdAt = entity.createdAt,
        updatedAt = entity.updatedAt,
        deletedAt = entity.deletedAt,
    )

    fun lot(entity: EntityCurrencyAssetLot) = DomainCurrencyAssetLot(
        id = entity.id,
        operationId = entity.operationId,
        assetId = entity.assetId,
        purchaseAssetTransactionId = entity.purchaseAssetTransactionId,
        foreignCurrencyCode = entity.foreignCurrencyCode,
        quantityPurchasedDecimal = entity.quantityPurchasedDecimal,
        purchaseExchangeRateDecimal = entity.purchaseExchangeRateDecimal,
        localCostDecimal = entity.localCostDecimal,
        purchaseDate = entity.purchaseDate,
        createdAt = entity.createdAt,
        updatedAt = entity.updatedAt,
        deletedAt = entity.deletedAt,
    )

    fun allocation(entity: EntityCurrencyAssetSaleAllocation) = DomainCurrencyAssetSaleAllocation(
        id = entity.id,
        operationId = entity.operationId,
        assetId = entity.assetId,
        saleAssetTransactionId = entity.saleAssetTransactionId,
        lotId = entity.lotId,
        quantitySoldDecimal = entity.quantitySoldDecimal,
        allocatedLocalCostDecimal = entity.allocatedLocalCostDecimal,
        createdAt = entity.createdAt,
        updatedAt = entity.updatedAt,
        deletedAt = entity.deletedAt,
    )
}

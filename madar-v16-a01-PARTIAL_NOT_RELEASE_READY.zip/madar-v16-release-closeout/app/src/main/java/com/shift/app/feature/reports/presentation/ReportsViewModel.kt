package com.shift.app.feature.reports.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.feature.reports.domain.model.ReportsDateRange
import com.shift.app.feature.reports.domain.model.ReportsReadModel
import com.shift.app.feature.reports.domain.usecase.ObserveReportsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.time.YearMonth
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class ReportsViewModel @Inject constructor(
    observeReports: ObserveReportsUseCase,
) : ViewModel() {
    private val initialRange = ReportsDateRange(YearMonth.now().atDay(1), LocalDate.now())
    private val selectedRange = MutableStateFlow(initialRange)

    val uiState: StateFlow<ReportsUiState> = observeReports(selectedRange)
        .map(::ReportsUiState)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ReportsUiState(ReportsReadModel.empty(initialRange)),
        )

    fun onEvent(event: ReportsUiEvent) {
        when (event) {
            is ReportsUiEvent.DateFromChanged -> setDateFrom(event.value)
            is ReportsUiEvent.DateToChanged -> setDateTo(event.value)
        }
    }

    fun setDateFrom(value: LocalDate) {
        selectedRange.value = selectedRange.value.copy(from = value)
    }

    fun setDateTo(value: LocalDate) {
        selectedRange.value = selectedRange.value.copy(to = value)
    }
}

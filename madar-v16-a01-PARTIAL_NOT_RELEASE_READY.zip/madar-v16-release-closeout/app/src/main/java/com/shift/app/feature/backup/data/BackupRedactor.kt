package com.shift.app.feature.backup.data

import java.security.MessageDigest

internal object BackupRedactor {
    private val sensitiveKeys = Regex(
        "(?i)(token|password|secret|pin|answer|email|phone|note|partyName|nameSnapshot|legacyPayloadJson)"
    )

    fun fingerprint(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
        .take(16)

    fun reference(error: Throwable, sourceFingerprint: String): String {
        val type = error::class.java.simpleName.ifBlank { "BackupError" }
        return "$type:$sourceFingerprint"
    }

    fun safeMessage(error: Throwable): String {
        val raw = error.message.orEmpty().take(240)
        if (raw.isBlank()) return "Backup operation failed"
        return raw
            .replace(Regex("(?i)(bearer\\s+)[^\\s,;]+"), "$1[REDACTED]")
            .replace(Regex("(?i)([\\w.+-]+)@([\\w.-]+)"), "[REDACTED_EMAIL]")
            .replace(Regex("(?i)(\\+?\\d[\\d -]{7,}\\d)"), "[REDACTED_PHONE]")
            .replace(Regex("(?i)\\\"([^\\\"]+)\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"")) { match ->
                val key = match.groupValues[1]
                if (sensitiveKeys.containsMatchIn(key)) "\"$key\":\"[REDACTED]\"" else match.value
            }
    }
}

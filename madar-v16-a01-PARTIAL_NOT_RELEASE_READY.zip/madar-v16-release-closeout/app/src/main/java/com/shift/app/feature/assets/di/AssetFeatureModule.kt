package com.shift.app.feature.assets.di

import com.shift.app.feature.assets.data.AssetGatewayAdapter
import com.shift.app.feature.assets.domain.repository.AssetGateway
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AssetFeatureModule {
    @Binds
    @Singleton
    abstract fun bindAssetGateway(impl: AssetGatewayAdapter): AssetGateway
}

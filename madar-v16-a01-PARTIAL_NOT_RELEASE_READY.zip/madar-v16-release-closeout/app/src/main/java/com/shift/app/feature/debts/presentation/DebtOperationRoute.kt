package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.input.ImeAction

@Composable
fun DebtOperationRoute(
    state: DebtOperationWizardState,
    amount: String,
    onAmountChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column {
        DebtMoneyField(
            value = amount,
            onValueChange = onAmountChange,
            label = "المبلغ",
            imeAction = ImeAction.Done,
            onDone = { if (state.validate().isEmpty() && !state.submitted) onSubmit() }
        )
        val preview = runCatching { state.preview(System.currentTimeMillis()) }.getOrNull()
        if (preview != null) {
            DebtImpactPreview(preview)
        } else {
            Text("أدخل مبلغاً صحيحاً لعرض المعاينة")
        }
    }
}

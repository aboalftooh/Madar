package com.shift.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.googlefonts.Font as GoogleFontLoader
import androidx.compose.ui.unit.sp
import com.shift.app.R

// ── Google Fonts Provider (fallback إذا كان الجهاز متصلاً) ──────────────
private val provider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage   = "com.google.android.gms",
    certificates      = R.array.com_google_android_gms_fonts_certs
)

// ── Cairo من ملفات محلية (الأساس) + Google Fonts كـ fallback ────────────
// 👇 تأكد إن الملفات دي موجودة في res/font/
val CairoFamily = FontFamily(
    Font(resId = R.font.cairo_regular,   weight = FontWeight.Normal),
    Font(resId = R.font.cairo_semibold,  weight = FontWeight.SemiBold),
    Font(resId = R.font.cairo_bold,      weight = FontWeight.Bold),
    Font(resId = R.font.cairo_extrabold, weight = FontWeight.ExtraBold),
)

// ── Typography الأساسي ────────────────────────────────────────────────────
val MadarTypography = Typography(
    displayLarge   = TextStyle(fontFamily = CairoFamily, fontSize = 57.sp),
    displayMedium  = TextStyle(fontFamily = CairoFamily, fontSize = 45.sp),
    displaySmall   = TextStyle(fontFamily = CairoFamily, fontSize = 36.sp),
    headlineLarge  = TextStyle(fontFamily = CairoFamily, fontSize = 32.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontFamily = CairoFamily, fontSize = 28.sp, fontWeight = FontWeight.SemiBold),
    headlineSmall  = TextStyle(fontFamily = CairoFamily, fontSize = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge      = TextStyle(fontFamily = CairoFamily, fontSize = 16.sp),
    bodyMedium     = TextStyle(fontFamily = CairoFamily, fontSize = 14.sp),
    bodySmall      = TextStyle(fontFamily = CairoFamily, fontSize = 12.sp),
    titleLarge     = TextStyle(fontFamily = CairoFamily, fontSize = 22.sp, fontWeight = FontWeight.Bold),
    titleMedium    = TextStyle(fontFamily = CairoFamily, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    titleSmall     = TextStyle(fontFamily = CairoFamily, fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelLarge     = TextStyle(fontFamily = CairoFamily, fontSize = 14.sp, fontWeight = FontWeight.Medium),
    labelMedium    = TextStyle(fontFamily = CairoFamily, fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall     = TextStyle(fontFamily = CairoFamily, fontSize = 11.sp),
)

// ── أنماط الأرقام (NumberStyles) ─────────────────────────────────────────
val NumberStyleLarge = TextStyle(
    fontFamily = CairoFamily,
    fontSize   = 28.sp,
    fontWeight = FontWeight.Bold,
)

val NumberStyleMedium = TextStyle(
    fontFamily = CairoFamily,
    fontSize   = 20.sp,
    fontWeight = FontWeight.Bold,
)

val NumberStyleSmall = TextStyle(
    fontFamily = CairoFamily,
    fontSize   = 14.sp,
    fontWeight = FontWeight.SemiBold,
)
package com.shift.app.domain.debt.reminders

data class DebtReminderRunResult(
    val plannedKeys: List<String>,
    val notifications: List<DebtNotificationPayload>,
    val permissionDenied: Boolean
)

class DebtReminderWorker(
    private val scheduler: DebtReminderScheduler = DebtReminderScheduler(),
    private val notificationFactory: DebtNotificationFactory = DebtNotificationFactory
) {
    fun run(snapshot: DebtReminderSnapshot, today: String, notificationPermissionGranted: Boolean): DebtReminderRunResult {
        val work = scheduler.plannedWork(snapshot, today)
        return DebtReminderRunResult(
            plannedKeys = work.map { it.key },
            notifications = if (notificationPermissionGranted) work.map(notificationFactory::create) else emptyList(),
            permissionDenied = !notificationPermissionGranted
        )
    }
}

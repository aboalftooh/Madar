package com.shift.app.data.repository

import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.debt.DebtFinancialImpact

data class DebtOperationRecords(
    val account: DebtAccount,
    val debtTransaction: DebtTransaction,
    val balanceTransaction: BalanceTransaction? = null,
    val payment: Payment? = null,
    val incomeTransaction: Transaction? = null,
    val asset: Asset? = null,
    val assetTransaction: AssetTransaction? = null,
    val assetValuation: AssetValuation? = null,
    val links: List<DebtLink> = emptyList(),
    val impact: DebtFinancialImpact
) {
    val operationId: String = debtTransaction.operationId
}

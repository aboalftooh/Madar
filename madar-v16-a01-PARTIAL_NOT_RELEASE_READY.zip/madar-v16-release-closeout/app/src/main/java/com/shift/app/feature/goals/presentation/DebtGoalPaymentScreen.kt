package com.shift.app.feature.goals.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.domain.goals.usecase.GoalDebtPaymentRequest

@Composable
fun DebtGoalPaymentScreen(
    goal: FinancialGoal,
    onSubmit: (GoalDebtPaymentRequest) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var accountId by remember(goal.id) { mutableStateOf("") }
    var partyName by remember(goal.id) { mutableStateOf("") }
    var amount by remember(goal.id) { mutableStateOf("") }
    var fromBalance by remember(goal.id) { mutableStateOf(true) }
    var complete by remember(goal.id) { mutableStateOf(true) }
    Column(modifier = modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("تسجيل سداد هدف الدين")
        OutlinedTextField(accountId, { accountId = it }, label = { Text("معرف حساب الدين") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(partyName, { partyName = it }, label = { Text("اسم الدائن") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("مبلغ السداد") }, modifier = Modifier.fillMaxWidth())
        Row { Checkbox(fromBalance, { fromBalance = it }); Text("الدفع من رصيد مدار") }
        Row { Checkbox(complete, { complete = it }); Text("إكمال الهدف إذا أصبحت ديون نطاقه صفرًا") }
        Button(
            onClick = {
                onSubmit(
                    GoalDebtPaymentRequest(
                        goalId = goal.id,
                        accountId = accountId,
                        partyName = partyName,
                        amountDecimal = amount,
                        fromMadarBalance = fromBalance,
                        completeGoalWhenPaidOff = complete,
                    ),
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("تسجيل السداد") }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}

package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.shift.app.data.local.entities.DebtSchedule
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtScheduleDao {
    @Query("SELECT * FROM debt_schedules WHERE accountId = :accountId AND deletedAt IS NULL ORDER BY dueDate ASC, installmentNo ASC")
    fun getActiveForAccount(accountId: String): Flow<List<DebtSchedule>>

    @Query("SELECT * FROM debt_schedules WHERE deletedAt IS NULL AND status = 'planned' AND dueDate <= :date ORDER BY dueDate ASC")
    suspend fun getDueOnOrBefore(date: String): List<DebtSchedule>

    @Query("SELECT * FROM debt_schedules WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<DebtSchedule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(schedule: DebtSchedule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(schedules: List<DebtSchedule>)

    @Query("DELETE FROM debt_schedules")
    suspend fun deleteAll()
}

package com.shift.app.sync.remote

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Debt
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction

interface SyncSessionRemote { val authenticatedUserId: String? }

interface ReferenceDataRemoteSync {
    suspend fun pushIncomeSources(sources: List<IncomeSource>)
    suspend fun pullIncomeSources()
    suspend fun pushExpenseBeneficiaries(sources: List<ExpenseBeneficiary>)
    suspend fun pullExpenseBeneficiaries()
}

interface LedgerRemoteSync {
    suspend fun pushTransactions(transactions: List<Transaction>)
    suspend fun pullTransactions()
    suspend fun pullBalanceTransactions(forceFull: Boolean = false)
    suspend fun pullPayments(forceFull: Boolean = false, repairAfterPull: Boolean = true)
    suspend fun pullLedgerHistoryMigrations(forceFull: Boolean = false)
    suspend fun repairIncompletePaymentOperationsForSync()
}

interface AssetRemoteSync {
    suspend fun pushAssets(items: List<Asset>)
    suspend fun pushAssetOperation(
        assets: List<Asset>,
        transactions: List<AssetTransaction>,
        valuations: List<AssetValuation>,
        balanceTransactions: List<BalanceTransaction>,
        payments: List<Payment>,
        currencyLots: List<CurrencyAssetLot> = emptyList(),
        currencySaleAllocations: List<CurrencyAssetSaleAllocation> = emptyList(),
        legacyTransactions: List<Transaction> = emptyList(),
        ledgerHistoryMigrations: List<LedgerHistoryMigration> = emptyList(),
    )
    suspend fun pullAssets(forceFull: Boolean = false)
    suspend fun pullAssetTransactions(forceFull: Boolean = false)
    suspend fun pullAssetValuations()
    suspend fun pullCurrencyAssetLots(forceFull: Boolean = false)
    suspend fun pullCurrencyAssetSaleAllocations(forceFull: Boolean = false)
}

interface DebtRemoteSync {
    suspend fun pushDebts(debts: List<Debt>)
    suspend fun pullDebts()
    suspend fun pullDebtLedger()
    suspend fun pushPendingDebtLedger()
}

interface GoalRemoteSync {
    suspend fun pullFinancialGoals()
    suspend fun pushPendingFinancialGoals()
}

interface SettingsRemoteSync {
    suspend fun pushSettings()
    suspend fun pullSettings()
}

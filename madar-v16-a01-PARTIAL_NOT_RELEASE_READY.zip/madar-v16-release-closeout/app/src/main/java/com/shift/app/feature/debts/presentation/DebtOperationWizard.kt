package com.shift.app.feature.debts.presentation

import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtFinancialImpact
import com.shift.app.domain.debt.DebtOperationFactory

data class DebtOperationWizardState(
    val operationId: String,
    val accountId: String,
    val direction: DebtDirection,
    val partyName: String,
    val amountDecimal: String,
    val cashSource: DebtCashSource = DebtCashSource.External,
    val submitted: Boolean = false
) {
    fun validate(): List<String> = buildList {
        if (operationId.isBlank()) add("operationId مطلوب")
        if (accountId.isBlank()) add("accountId مطلوب")
        if (partyName.isBlank()) add("الطرف مطلوب")
        if (amountDecimal.isBlank()) add("المبلغ مطلوب")
    }

    fun preview(now: Long): DebtFinancialImpact =
        DebtOperationFactory.cashPrincipal(operationId, accountId, direction, partyName, amountDecimal, cashSource, now).impact
}

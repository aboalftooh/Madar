package com.shift.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.BuildConfig
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.ui.components.ExpenseBeneficiaryEditorSheet
import com.shift.app.ui.components.IncomeSourceEditorSheet
import com.shift.app.ui.components.LegacyHistoryMigrationWizard
import com.shift.app.ui.components.shiftTextFieldColors
import com.shift.app.ui.theme.*
import com.shift.app.feature.backup.domain.model.BackupImportMode
import com.shift.app.feature.backup.domain.model.RestoreReport
import com.shift.app.feature.backup.presentation.BackupViewModel
import com.shift.app.feature.session.presentation.AppSessionViewModel
import com.shift.app.viewmodel.SettingsViewModel
import com.shift.app.viewmodel.TransactionsViewModel
import com.shift.app.viewmodel.LegacyHistoryMigrationViewModel
import com.shift.app.viewmodel.PinViewModel
import com.shift.app.feature.session.presentation.SyncState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onLogout: (onBlocked: () -> Unit) -> Unit = {},
    onForceLogout: () -> Unit = {},
    settingsVm: SettingsViewModel = hiltViewModel(),
    backupVm: BackupViewModel = hiltViewModel(),
    sessionVm: AppSessionViewModel = hiltViewModel(),
    transactionsVm: TransactionsViewModel = hiltViewModel(),
    pinVm: PinViewModel = hiltViewModel(),
    historyMigrationVm: LegacyHistoryMigrationViewModel = hiltViewModel()
) {
    val userName     by settingsVm.userName.collectAsState()
    val workType     by settingsVm.workType.collectAsState()
    val incomeSources by transactionsVm.incomeSources.collectAsState()
    val expenseBeneficiaries by transactionsVm.expenseBeneficiaries.collectAsState()
    val syncState    by sessionVm.syncState.collectAsState()
    val lastSync     by sessionVm.lastSync.collectAsState()
    val balanceActivated by settingsVm.balanceActivated.collectAsState()
    val balanceActivatedAt by settingsVm.balanceActivatedAt.collectAsState()
    val localCurrencyCode by settingsVm.localCurrencyCode.collectAsState()
    val backupState   by backupVm.state.collectAsState()
    val pinEnabled    by pinVm.pinEnabled.collectAsState()
    val pinHash       by pinVm.pin.collectAsState()
    val secQuestion   by pinVm.secQuestion.collectAsState()
    val context       = LocalContext.current
    val scope         = rememberCoroutineScope()
    val focusManager  = LocalFocusManager.current
    var backupMsg     by remember { mutableStateOf("") }
    var showUnsyncedLogoutDialog by remember { mutableStateOf(false) }
    // ── Export launcher ────────────────────────────────────────────
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        backupVm.exportBackup { result ->
            result.onSuccess { json ->
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write(json.toByteArray())
                    } ?: error("تعذر فتح ملف التصدير")
                }.onSuccess {
                    backupMsg = "✅ تم التصدير بنجاح"
                }.onFailure { error ->
                    backupMsg = "❌ فشل التصدير: ${error.message ?: "خطأ غير معروف"}"
                }
            }.onFailure { error ->
                backupMsg = "❌ فشل التصدير: ${error.message ?: "خطأ غير معروف"}"
            }
        }
    }

    // ── Import launcher ────────────────────────────────────────────
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                backupVm.prepareImport(text)
            } catch (e: Exception) {
                backupMsg = "❌ فشل الاستيراد: ${e.message}"
            }
        }
    }

    // الأكوردين — أي قسم مفتوح
    var expanded by remember { mutableStateOf("profile") }

    // profile state
    var nameInput          by remember(userName)   { mutableStateOf(userName) }
    var workInput          by remember(workType)   { mutableStateOf(workType) }
    var showIncomeSourceEditor by remember { mutableStateOf(false) }
    var editingIncomeSource by remember { mutableStateOf<IncomeSource?>(null) }
    var showExpenseBeneficiaryEditor by remember { mutableStateOf(false) }
    var editingExpenseBeneficiary by remember { mutableStateOf<ExpenseBeneficiary?>(null) }

    var showLogoutDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var secQuestionInput by remember(secQuestion) { mutableStateOf(secQuestion) }
    var secAnswerInput by remember { mutableStateOf("") }
    var securityMsg by remember { mutableStateOf("") }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor = SurfaceDark,
            title = { Text("تسجيل الخروج", color = TextPrimary) },
            text = { Text("هل أنت متأكد من تسجيل الخروج؟", color = TextMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        onLogout { showUnsyncedLogoutDialog = true }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) { Text("خروج", color = TextPrimary) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("إلغاء", color = TextMuted)
                }
            }
        )
    }

    backupState.errorMessage?.let { errorMessage ->
        AlertDialog(
            onDismissRequest = backupVm::clearImport,
            containerColor = SurfaceDark,
            title = { Text("ملف النسخة غير صالح", color = ExpenseRed) },
            text = { Text(errorMessage, color = TextMuted) },
            confirmButton = {
                TextButton(onClick = backupVm::clearImport) { Text("إغلاق", color = AccentBlue) }
            }
        )
    }

    backupState.inspection?.let {
        val replacePlan = backupState.replacePlan
        val mergePlan = backupState.mergePlan
        val importInProgress = backupState.restoring
        fun applyImport(mode: BackupImportMode) {
            if (importInProgress) return
            backupVm.restore(mode) { report ->
                when (report) {
                    is RestoreReport.Success -> {
                        backupMsg = if (report.syncScheduled) {
                            "✅ تم الاستيراد بنجاح"
                        } else {
                            "✅ تم الاستيراد محليًا؛ المزامنة ستُعاد لاحقًا"
                        }
                    }
                    is RestoreReport.Failure -> {
                        backupMsg = "❌ ${report.userMessage} (${report.reference})"
                    }
                }
            }
        }
        AlertDialog(
            onDismissRequest = { if (!importInProgress) backupVm.clearImport() },
            containerColor = SurfaceDark,
            title = { Text("استيراد البيانات", color = TextPrimary) },
            text = {
                Text(
                    if (importInProgress) "جارٍ استيراد البيانات…" else
                        if (replacePlan != null) {
                            "اختر طريقة الاستيراد. الدمج لا يحذف بيانات، والاستبدال سيحذف ${replacePlan.deleteCount} عنصرًا غير موجود في الملف."
                        } else {
                            "الاستبدال غير آمن لهذه النسخة؛ استخدم الدمج."
                        },
                    color = TextMuted
                )
            },
            confirmButton = {
                Button(
                    onClick = { applyImport(BackupImportMode.REPLACE) },
                    enabled = !importInProgress && replacePlan != null,
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) { Text("استبدال", color = TextPrimary) }
            },
            dismissButton = {
                TextButton(
                    onClick = { applyImport(BackupImportMode.MERGE) },
                    enabled = !importInProgress && mergePlan != null
                ) { Text("دمج", color = AccentBlue) }
            }
        )
    }

    if (showUnsyncedLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showUnsyncedLogoutDialog = false },
            containerColor = SurfaceDark,
            title = { Text("بيانات غير مزامنة", color = TextPrimary) },
            text = { Text("لديك بيانات غير مزامنة. أعد المحاولة أو اخرج مع فقدانها.", color = TextMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        showUnsyncedLogoutDialog = false
                        onForceLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) { Text("الخروج مع فقدانها", color = TextPrimary) }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showUnsyncedLogoutDialog = false
                        onLogout { showUnsyncedLogoutDialog = true }
                    }
                ) { Text("إعادة المحاولة", color = AccentBlue) }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .imePadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("الإعدادات ️", fontSize = 22.sp, fontWeight = FontWeight.Bold,
            color = TextPrimary, modifier = Modifier.statusBarsPadding(), fontFamily = CairoFamily)

        // ══════════════ الملف الشخصي ══════════════
        AccordionSection(
            title    = "👤 الملف الشخصي",
            icon     = Icons.Default.Person,
            expanded = expanded == "profile",
            onToggle = { expanded = if (expanded == "profile") "" else "profile" }
        ) {
            OutlinedTextField(
                value = nameInput, onValueChange = { nameInput = it },
                label = { Text("الاسم", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(), colors = shiftTextFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
            )
            OutlinedTextField(
                value         = workInput,
                onValueChange = { workInput = it },
                label         = { Text("نوع العمل", color = TextMuted) },
                modifier      = Modifier.fillMaxWidth(),
                colors        = shiftTextFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )
            Button(
                onClick = {
                    settingsVm.setProfileSettings(nameInput, workInput)
                },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("حفظ الملف", fontWeight = FontWeight.Bold) }
        }

        AccordionSection(
            title    = "مصادر الدخل",
            icon     = Icons.Default.AttachMoney,
            expanded = expanded == "income_sources",
            onToggle = { expanded = if (expanded == "income_sources") "" else "income_sources" }
        ) {
            Button(
                onClick = {
                    editingIncomeSource = null
                    showIncomeSourceEditor = true
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("إضافة مصدر دخل", fontWeight = FontWeight.Bold)
            }
            if (incomeSources.isEmpty()) {
                Text("لا توجد مصادر دخل محفوظة", color = TextMuted, fontSize = 13.sp)
            }
            incomeSources.forEach { source ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = IncomeGreen, modifier = Modifier.size(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(source.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text(source.paymentMethod, color = TextMuted, fontSize = 12.sp)
                    }
                    IconButton(
                        onClick = {
                            editingIncomeSource = source
                            showIncomeSourceEditor = true
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = AccentBlue, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = { transactionsVm.deleteIncomeSource(source.id) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = ExpenseRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        AccordionSection(
            title    = "المستفيدون",
            icon     = Icons.Default.Groups,
            expanded = expanded == "expense_beneficiaries",
            onToggle = { expanded = if (expanded == "expense_beneficiaries") "" else "expense_beneficiaries" }
        ) {
            Button(
                onClick = {
                    editingExpenseBeneficiary = null
                    showExpenseBeneficiaryEditor = true
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("إضافة مستفيد", fontWeight = FontWeight.Bold)
            }
            if (expenseBeneficiaries.isEmpty()) {
                Text("لا يوجد مستفيدون محفوظون", color = TextMuted, fontSize = 13.sp)
            }
            expenseBeneficiaries.forEach { beneficiary ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Groups, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(18.dp))
                    Text(
                        beneficiary.name,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            editingExpenseBeneficiary = beneficiary
                            showExpenseBeneficiaryEditor = true
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = AccentBlue, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = { transactionsVm.deleteExpenseBeneficiary(beneficiary.id) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = ExpenseRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        AccordionSection(
            title = "ترحيل التاريخ الكامل",
            icon = Icons.Default.History,
            expanded = expanded == "history_migration",
            onToggle = { expanded = if (expanded == "history_migration") "" else "history_migration" }
        ) {
            LegacyHistoryMigrationWizard(historyMigrationVm)
        }

        // ══════════════ البيانات ══════════════
        AccordionSection(
            title    = "💾 النسخة الاحتياطية",
            icon     = Icons.Default.Backup,
            expanded = expanded == "backup",
            onToggle = { expanded = if (expanded == "backup") "" else "backup" }
        ) {
            if (backupMsg.isNotBlank()) {
                Text(
                    backupMsg,
                    color    = if (backupMsg.startsWith("✅")) IncomeGreen else ExpenseRed,
                    fontSize = 13.sp,
                    fontFamily = CairoFamily
                )
            }
            Button(
                onClick  = { exportLauncher.launch("madar_backup_${System.currentTimeMillis()}.json") },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("تصدير البيانات", fontWeight = FontWeight.Bold, fontFamily = CairoFamily)
            }
            Button(
                onClick  = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = SurfaceVariant)
            ) {
                Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(18.dp), tint = TextPrimary)
                Spacer(Modifier.width(8.dp))
                Text("استيراد البيانات", color = TextPrimary, fontFamily = CairoFamily)
            }
        }

        // ══════════════ المزامنة ══════════════
        AccordionSection(
            title    = "🔄 المزامنة",
            icon     = Icons.Default.Sync,
            expanded = expanded == "sync",
            onToggle = { expanded = if (expanded == "sync") "" else "sync" }
        ) {
            val lastSyncText = if (lastSync == 0L) "لم تتم المزامنة بعد"
            else SimpleDateFormat("dd/MM/yyyy  hh:mm a", Locale.getDefault()).format(Date(lastSync))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("آخر مزامنة", color = TextSecondary, fontSize = 13.sp)
                    Text(lastSyncText, color = TextMuted, fontSize = 12.sp)
                }
                when (syncState) {
                    is SyncState.Success -> Icon(Icons.Default.CheckCircle, contentDescription = null, tint = IncomeGreen, modifier = Modifier.size(22.dp))
                    is SyncState.Error   -> Icon(Icons.Default.Error, contentDescription = null, tint = ExpenseRed, modifier = Modifier.size(22.dp))
                    else -> {}
                }
            }

            if (syncState is SyncState.Error) {
                Text(
                    (syncState as SyncState.Error).message,
                    color = ExpenseRed, fontSize = 12.sp
                )
            }

            Button(
                onClick  = { sessionVm.syncNow() },
                enabled  = syncState !is SyncState.Loading,
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(12.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                if (syncState is SyncState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = TextPrimary, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("جاري المزامنة...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("مزامنة الآن", fontWeight = FontWeight.Bold)
                }
            }
        }

        // ══════════════ الأمان ══════════════
        AccordionSection(
            title    = "🔒 الأمان",
            icon     = Icons.Default.Lock,
            expanded = expanded == "security",
            onToggle = { expanded = if (expanded == "security") "" else "security" }
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("قفل PIN", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (pinHash.isBlank()) "اضبط رمزاً من 4 أرقام لتفعيل القفل" else "القفل جاهز للاستخدام",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
                Switch(
                    checked = pinEnabled == true && pinHash.isNotBlank(),
                    onCheckedChange = { enabled ->
                        if (enabled && pinHash.isBlank()) {
                            securityMsg = "أدخل PIN من 4 أرقام أولاً"
                        } else {
                            pinVm.setPinEnabled(enabled)
                            securityMsg = if (enabled) "تم تفعيل القفل" else "تم تعطيل القفل"
                        }
                    }
                )
            }
            OutlinedTextField(
                value = pinInput,
                onValueChange = { value -> pinInput = value.filter { it.isDigit() }.take(4) },
                label = { Text("PIN جديد", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
            )
            OutlinedTextField(
                value = secQuestionInput,
                onValueChange = { secQuestionInput = it },
                label = { Text("سؤال الاستعادة", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
            )
            OutlinedTextField(
                value = secAnswerInput,
                onValueChange = { secAnswerInput = it },
                label = { Text("إجابة الاستعادة", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                colors = shiftTextFieldColors(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )
            if (securityMsg.isNotBlank()) {
                Text(securityMsg, color = if (securityMsg.startsWith("تم")) IncomeGreen else ExpenseRed, fontSize = 12.sp)
            }
            Button(
                onClick = {
                    when {
                        pinInput.length != 4 -> securityMsg = "يجب أن يكون PIN من 4 أرقام"
                        secAnswerInput.isBlank() -> securityMsg = "أدخل إجابة الاستعادة"
                        else -> {
                            pinVm.setPin(pinInput)
                            pinVm.setSecQuestion(secQuestionInput.ifBlank { "سؤال الاستعادة" })
                            pinVm.setSecAnswer(secAnswerInput)
                            pinVm.setPinEnabled(true)
                            pinInput = ""
                            secAnswerInput = ""
                            securityMsg = "تم حفظ وتفعيل PIN"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("حفظ وتفعيل PIN", fontWeight = FontWeight.Bold) }
        }

        // ══════════════ عن التطبيق ══════════════
        AccordionSection(
            title    = "ℹ️ عن التطبيق",
            icon     = Icons.Default.Info,
            expanded = expanded == "about",
            onToggle = { expanded = if (expanded == "about") "" else "about" }
        ) {
            Text("madar - متتبع أموالك الشخصي", color = TextSecondary)
            Text("الإصدار: ${BuildConfig.VERSION_NAME}", color = TextMuted, fontSize = 13.sp)
            Text("© 2024 جميع الحقوق محفوظة", color = TextMuted, fontSize = 12.sp)
            HorizontalDivider(color = SurfaceVariant)
            Text("تواصل معنا", color = AccentCyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            // ايميل
            Row(
                Modifier.fillMaxWidth().clickable {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:aboalftooh@gmail.com")
                    }
                    context.startActivity(intent)
                }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Email, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(20.dp))
                Text("aboalftooh@gmail.com", color = TextPrimary, fontSize = 13.sp)
            }
            // واتساب
            Row(
                Modifier.fillMaxWidth().clickable {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse("https://wa.me/249123142758")
                    }
                    context.startActivity(intent)
                }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Phone, contentDescription = null, tint = IncomeGreen, modifier = Modifier.size(20.dp))
                Text("00249123142758", color = TextPrimary, fontSize = 13.sp)
            }
        }

        Button(
            onClick  = { showLogoutDialog = true },
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(14.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = ExpenseRed.copy(alpha = 0.15f))
        ) {
            Icon(Icons.Default.Logout, contentDescription = null, tint = ExpenseRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("تسجيل الخروج", color = ExpenseRed, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(8.dp))
    }

    if (showIncomeSourceEditor) {
        IncomeSourceEditorSheet(
            vm = transactionsVm,
            editItem = editingIncomeSource,
            onDismiss = {
                showIncomeSourceEditor = false
                editingIncomeSource = null
            }
        )
    }

    if (showExpenseBeneficiaryEditor) {
        ExpenseBeneficiaryEditorSheet(
            vm = transactionsVm,
            editItem = editingExpenseBeneficiary,
            onDismiss = {
                showExpenseBeneficiaryEditor = false
                editingExpenseBeneficiary = null
            }
        )
    }
}

@Composable
private fun AccordionSection(
    title: String, icon: ImageVector,
    expanded: Boolean, onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape  = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column {
            // Header قابل للضغط
            Row(
                Modifier.fillMaxWidth().clickable { onToggle() }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(icon, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp))
                    Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = CairoFamily)
                }
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null, tint = TextMuted
                )
            }
            // محتوى قابل للطي
            AnimatedVisibility(
                visible = expanded,
                enter   = expandVertically() + fadeIn(),
                exit    = shrinkVertically() + fadeOut()
            ) {
                Column(
                    Modifier.padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content
                )
            }
        }
    }
}

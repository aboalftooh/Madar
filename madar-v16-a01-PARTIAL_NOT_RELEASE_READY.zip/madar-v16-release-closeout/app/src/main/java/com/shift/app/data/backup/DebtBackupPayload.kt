package com.shift.app.data.backup

import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtMigrationReview
import com.shift.app.data.local.entities.DebtSchedule
import com.shift.app.data.local.entities.DebtTransaction
import kotlinx.serialization.Serializable

@Serializable
data class DebtBackupPayload(
    val schemaVersion: Int = 16,
    val accounts: List<DebtAccountBackup> = emptyList(),
    val transactions: List<DebtTransactionBackup> = emptyList(),
    val links: List<DebtLinkBackup> = emptyList(),
    val schedules: List<DebtScheduleBackup> = emptyList(),
    val reviews: List<DebtMigrationReviewBackup> = emptyList()
) {
    fun validateForRestore() {
        val accountIds = accounts.map { it.id }.toSet()
        val transactionIds = transactions.map { it.id }.toSet()
        require(transactions.all { it.accountId in accountIds }) { "Debt backup has orphan transactions" }
        require(links.all { it.accountId in accountIds && it.debtTransactionId in transactionIds }) { "Debt backup has orphan links" }
        require(schedules.all { it.accountId in accountIds }) { "Debt backup has orphan schedules" }
        require(accounts.map { it.id }.distinct().size == accounts.size) { "Duplicate debt account id" }
        require(transactions.map { it.id }.distinct().size == transactions.size) { "Duplicate debt transaction id" }
    }
}

@Serializable data class DebtAccountBackup(val id: String, val operationId: String, val direction: String, val partyName: String, val partyKey: String, val currencyCode: String, val confirmed: Boolean, val syncState: String, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class DebtTransactionBackup(val id: String, val accountId: String, val operationId: String, val type: String, val amountDecimal: String, val currencyCode: String, val occurredAt: Long, val syncState: String, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class DebtLinkBackup(val id: String, val operationId: String, val accountId: String, val debtTransactionId: String, val targetType: String, val targetId: String, val role: String, val amountDecimal: String? = null, val syncState: String, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class DebtScheduleBackup(val id: String, val operationId: String, val accountId: String, val installmentNo: Int, val dueDate: String, val amountDecimal: String, val currencyCode: String, val status: String, val syncState: String, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class DebtMigrationReviewBackup(val id: String, val legacyDebtId: String, val status: String, val reason: String, val legacyPayloadJson: String, val syncState: String, val updatedAt: Long, val deletedAt: Long? = null)

object DebtBackupMapper {
    fun fromEntities(
        accounts: List<DebtAccount>,
        transactions: List<DebtTransaction>,
        links: List<DebtLink>,
        schedules: List<DebtSchedule>,
        reviews: List<DebtMigrationReview>
    ): DebtBackupPayload = DebtBackupPayload(
        accounts = accounts.map { DebtAccountBackup(it.id, it.operationId, it.direction, it.partyName, it.partyKey, it.currencyCode, it.confirmed, it.syncState, it.updatedAt, it.deletedAt) },
        transactions = transactions.map { DebtTransactionBackup(it.id, it.accountId, it.operationId, it.type, it.amountDecimal, it.currencyCode, it.occurredAt, it.syncState, it.updatedAt, it.deletedAt) },
        links = links.map { DebtLinkBackup(it.id, it.operationId, it.accountId, it.debtTransactionId, it.targetType, it.targetId, it.role, it.amountDecimal, it.syncState, it.updatedAt, it.deletedAt) },
        schedules = schedules.map { DebtScheduleBackup(it.id, it.operationId, it.accountId, it.installmentNo, it.dueDate, it.amountDecimal, it.currencyCode, it.status, it.syncState, it.updatedAt, it.deletedAt) },
        reviews = reviews.map { DebtMigrationReviewBackup(it.id, it.legacyDebtId, it.status, it.reason, it.legacyPayloadJson, it.syncState, it.updatedAt, it.deletedAt) }
    )

    val restoreOrder: List<String> = listOf("debt_accounts", "debt_transactions", "debt_links", "debt_schedules", "debt_migration_reviews")
}

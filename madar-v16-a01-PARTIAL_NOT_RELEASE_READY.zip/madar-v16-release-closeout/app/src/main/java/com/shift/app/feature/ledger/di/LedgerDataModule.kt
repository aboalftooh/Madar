package com.shift.app.feature.ledger.di

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.data.local.dao.LedgerHistoryMigrationDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object LedgerDataModule {
    @Provides fun provideTransactionDao(database: MadarDatabase): TransactionDao = database.transactionDao()
    @Provides fun provideBalanceTransactionDao(database: MadarDatabase): BalanceTransactionDao = database.balanceTransactionDao()
    @Provides fun providePaymentDao(database: MadarDatabase): PaymentDao = database.paymentDao()
    @Provides fun provideIncomeSourceDao(database: MadarDatabase): IncomeSourceDao = database.incomeSourceDao()
    @Provides fun provideExpenseBeneficiaryDao(database: MadarDatabase): ExpenseBeneficiaryDao = database.expenseBeneficiaryDao()
    @Provides fun provideLedgerHistoryMigrationDao(database: MadarDatabase): LedgerHistoryMigrationDao = database.ledgerHistoryMigrationDao()
}

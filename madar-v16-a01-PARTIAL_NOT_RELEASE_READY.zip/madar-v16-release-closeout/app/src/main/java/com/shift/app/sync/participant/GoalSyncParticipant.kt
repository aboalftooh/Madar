package com.shift.app.sync.participant

import com.shift.app.sync.remote.GoalRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalSyncParticipant @Inject constructor(
    private val remote: GoalRemoteSync,
) : SyncParticipant {
    override val key: String = "financial_goals"
    override val order: Int = 50

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_financial_goals", SyncCheckpointKey.FinancialGoals) {
            remote.pullFinancialGoals()
        },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> = listOf(
        SyncOperation("push_financial_goals") { remote.pushPendingFinancialGoals() },
    )
}

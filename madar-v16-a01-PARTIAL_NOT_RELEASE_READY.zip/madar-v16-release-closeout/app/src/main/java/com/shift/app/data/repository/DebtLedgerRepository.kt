package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtLinkDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.dao.TransactionDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.DebtAccount
import com.shift.app.data.local.entities.DebtLink
import com.shift.app.data.local.entities.DebtTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.local.entities.Transaction
import com.shift.app.domain.debt.DebtAccountSnapshot
import com.shift.app.domain.debt.DebtCalculator
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtMoney
import com.shift.app.domain.debt.DebtOperationDraft
import com.shift.app.domain.debt.DebtOperationFactory
import com.shift.app.domain.debt.DebtTransactionInput
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.PaymentKind
import java.time.Instant
import java.time.ZoneOffset
import javax.inject.Inject
import kotlin.math.absoluteValue

class DebtLedgerRepository @Inject constructor(
    private val db: MadarDatabase,
    private val accountDao: DebtAccountDao,
    private val transactionDao: DebtTransactionDao,
    private val linkDao: DebtLinkDao,
    private val balanceDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val legacyTransactionDao: TransactionDao,
    private val assetDao: AssetDao,
    private val assetTransactionDao: AssetTransactionDao,
    private val assetValuationDao: AssetValuationDao,
    private val changePublisher: FinancialChangePublisher,
) {
    suspend fun openAccount(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        amountDecimal: String,
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis(),
        description: String = "",
        dueDate: String? = null,
        confirmed: Boolean = true
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val draft = DebtOperationFactory.opening(operationId, accountId, direction, partyName, amountDecimal, occurredAt)
        val account = DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = direction.dbValue,
            partyName = partyName.trim(),
            partyKey = partyName.trim().lowercase(),
            currencyCode = currencyCode,
            description = description,
            dueDate = dueDate,
            confirmed = confirmed,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val debtTransaction = draft.toEntity(currencyCode)
        accountDao.upsert(account)
        transactionDao.upsert(debtTransaction)
        publishAndReturn(DebtOperationRecords(account, debtTransaction, impact = draft.impact))
    }

    suspend fun recordDeferredExpense(
        operationId: String,
        accountId: String,
        partyName: String,
        amountDecimal: String,
        purpose: String,
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis(),
        note: String = ""
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val draft = DebtOperationFactory.deferredExpense(operationId, accountId, partyName, amountDecimal, occurredAt)
        val account = accountDao.getById(accountId) ?: DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = DebtDirection.Payable.dbValue,
            partyName = partyName.trim(),
            partyKey = partyName.trim().lowercase(),
            currencyCode = currencyCode,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val debtTransaction = draft.toEntity(currencyCode)
        val payment = Payment(
            operationId = operationId,
            kind = PaymentKind.OrdinaryExpense,
            amountDecimal = draft.transaction.amount.decimalText,
            currencyCode = currencyCode,
            date = dateFromMillis(occurredAt),
            purpose = purpose,
            purposeKey = purpose.trim().lowercase(),
            balanceTransactionId = null,
            note = note
        )
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        transactionDao.upsert(debtTransaction)
        paymentDao.insert(payment)
        val link = writeLink(operationId, account.id, debtTransaction.id, "payment", payment.id, "deferred_expense", amountDecimal)
        publishAndReturn(DebtOperationRecords(account, debtTransaction, payment = payment, links = listOf(link), impact = draft.impact))
    }

    suspend fun recordAccruedIncome(
        operationId: String,
        accountId: String,
        partyName: String,
        amountDecimal: String,
        incomeCategory: String,
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis(),
        note: String = ""
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val draft = DebtOperationFactory.accruedIncome(operationId, accountId, partyName, amountDecimal, occurredAt)
        val account = accountDao.getById(accountId) ?: DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = DebtDirection.Receivable.dbValue,
            partyName = partyName.trim(),
            partyKey = partyName.trim().lowercase(),
            currencyCode = currencyCode,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val debtTransaction = draft.toEntity(currencyCode)
        val income = Transaction(
            type = "income",
            amount = draft.transaction.amount.value.toDouble(),
            category = incomeCategory,
            date = dateFromMillis(occurredAt),
            note = note,
            operationId = operationId,
            balanceTransactionId = null,
            updatedAt = occurredAt
        )
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        transactionDao.upsert(debtTransaction)
        legacyTransactionDao.insert(income)
        val link = writeLink(operationId, account.id, debtTransaction.id, "transaction", income.id, "accrued_income", amountDecimal)
        publishAndReturn(DebtOperationRecords(account, debtTransaction, incomeTransaction = income, links = listOf(link), impact = draft.impact))
    }

    suspend fun recordFinancedAssetPurchase(
        operationId: String,
        accountId: String,
        assetId: String,
        partyName: String,
        assetType: String,
        assetName: String,
        financedAmountDecimal: String,
        assetValueDecimal: String,
        cashPaidDecimal: String = "0.00",
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis(),
        note: String = ""
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val draft = DebtOperationFactory.financedAsset(
            operationId = operationId,
            accountId = accountId,
            partyName = partyName,
            financedAmount = financedAmountDecimal,
            assetValue = assetValueDecimal,
            cashPaid = cashPaidDecimal,
            occurredAtEpochMillis = occurredAt
        )
        if (draft.impact.requiresBalanceEnabled) requireBalanceActivated()
        val account = accountDao.getById(accountId) ?: DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = DebtDirection.Payable.dbValue,
            partyName = partyName.trim(),
            partyKey = partyName.trim().lowercase(),
            currencyCode = currencyCode,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val asset = Asset(
            id = assetId,
            operationId = operationId,
            type = assetType,
            name = assetName,
            acquisitionMode = "purchased_in_app",
            acquisitionAmountDecimal = assetValueDecimal,
            currencyCode = currencyCode,
            currentValueCacheDecimal = assetValueDecimal,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val debtTransaction = draft.toEntity(currencyCode)
        val assetTransaction = AssetTransaction(
            operationId = operationId,
            assetId = assetId,
            kind = AssetTransactionKind.Purchase.dbValue,
            amountDecimal = assetValueDecimal,
            date = dateFromMillis(occurredAt),
            note = note,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val valuation = AssetValuation(
            operationId = operationId,
            assetId = assetId,
            valueDecimal = assetValueDecimal,
            date = dateFromMillis(occurredAt),
            note = "Initial debt-financed valuation",
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        assetDao.insert(asset)
        assetTransactionDao.insert(assetTransaction)
        assetValuationDao.insert(valuation)
        transactionDao.upsert(debtTransaction)
        val links = mutableListOf<DebtLink>()
        links += writeLink(operationId, account.id, debtTransaction.id, "asset", asset.id, "financed_asset", financedAmountDecimal)
        links += writeLink(operationId, account.id, debtTransaction.id, "asset_transaction", assetTransaction.id, "asset_purchase", assetValueDecimal)
        links += writeLink(operationId, account.id, debtTransaction.id, "asset_valuation", valuation.id, "initial_valuation", assetValueDecimal)
        val balance = if (draft.impact.balanceDeltaDecimal != "0.00") {
            writeBalanceLeg(draft, debtTransaction, currencyCode).also {
                links += writeLink(operationId, account.id, debtTransaction.id, "balance_transaction", it.id, "cash_paid", cashPaidDecimal)
            }
        } else {
            null
        }
        publishAndReturn(DebtOperationRecords(
            account = account,
            debtTransaction = debtTransaction,
            balanceTransaction = balance,
            asset = asset,
            assetTransaction = assetTransaction,
            assetValuation = valuation,
            links = links,
            impact = draft.impact
        ))
    }

    suspend fun recordAssetSettlement(
        operationId: String,
        accountId: String,
        assetId: String,
        settlementAmountDecimal: String,
        assetValueDecimal: String,
        occurredAt: Long = System.currentTimeMillis(),
        reason: String,
        note: String = ""
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        require(reason.isNotBlank()) { "Asset settlement reason is required" }
        val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
        val asset = assetDao.getById(assetId) ?: throw IllegalArgumentException("Asset not found")
        require(asset.deletedAt == null) { "Deleted asset cannot settle debt" }
        val snapshot = account.snapshot(transactionDao.getAllForAccountOnce(accountId))
        DebtCalculator.assertCanReduce(snapshot, DebtMoney.of(settlementAmountDecimal))
        val draft = DebtOperationFactory.assetSettlement(
            operationId = operationId,
            accountId = accountId,
            direction = DebtDirection.fromDb(account.direction),
            partyName = account.partyName,
            amount = settlementAmountDecimal,
            assetValue = assetValueDecimal,
            occurredAtEpochMillis = occurredAt
        )
        val debtTransaction = draft.toEntity(account.currencyCode).copy(reason = reason)
        val assetTransaction = AssetTransaction(
            operationId = operationId,
            assetId = assetId,
            kind = if (account.direction == DebtDirection.Payable.dbValue) AssetTransactionKind.Transferred.dbValue else AssetTransactionKind.Purchase.dbValue,
            amountDecimal = assetValueDecimal,
            date = dateFromMillis(occurredAt),
            note = note,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        transactionDao.upsert(debtTransaction)
        assetTransactionDao.insert(assetTransaction)
        val updatedAsset = if (account.direction == DebtDirection.Payable.dbValue) {
            asset.copy(status = com.shift.app.domain.finance.AssetStatus.Transferred.dbValue, updatedAt = occurredAt)
        } else {
            asset.copy(currentValueCacheDecimal = assetValueDecimal, updatedAt = occurredAt)
        }
        assetDao.update(updatedAsset)
        val links = listOf(
            writeLink(operationId, account.id, debtTransaction.id, "asset", asset.id, "asset_settlement", settlementAmountDecimal),
            writeLink(operationId, account.id, debtTransaction.id, "asset_transaction", assetTransaction.id, "asset_settlement_transaction", assetValueDecimal)
        )
        publishAndReturn(DebtOperationRecords(
            account = account,
            debtTransaction = debtTransaction,
            asset = updatedAsset,
            assetTransaction = assetTransaction,
            links = links,
            impact = draft.impact
        ))
    }

    suspend fun recordAssetSaleOnCredit(
        operationId: String,
        accountId: String,
        assetId: String,
        buyerName: String,
        saleAmountDecimal: String,
        cashCollectedDecimal: String = "0.00",
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis(),
        note: String = ""
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val asset = assetDao.getById(assetId) ?: throw IllegalArgumentException("Asset not found")
        require(asset.deletedAt == null) { "Deleted asset cannot be sold" }
        require(asset.status == com.shift.app.domain.finance.AssetStatus.Active.dbValue) { "Only active assets can be sold on credit" }
        val receivable = DebtMoney.of(saleAmountDecimal) - DebtMoney.of(cashCollectedDecimal)
        require(receivable.value >= java.math.BigDecimal.ZERO) { "Cash collected cannot exceed sale amount" }
        if (cashCollectedDecimal != "0.00") requireBalanceActivated()
        val draft = DebtOperationFactory.opening(
            operationId = operationId,
            accountId = accountId,
            direction = DebtDirection.Receivable,
            partyName = buyerName,
            amount = receivable.decimalText,
            occurredAtEpochMillis = occurredAt
        )
        val account = DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = DebtDirection.Receivable.dbValue,
            partyName = buyerName.trim(),
            partyKey = buyerName.trim().lowercase(),
            currencyCode = currencyCode,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val debtTransaction = draft.toEntity(currencyCode)
        val assetTransaction = AssetTransaction(
            operationId = operationId,
            assetId = assetId,
            kind = AssetTransactionKind.SaleFull.dbValue,
            amountDecimal = saleAmountDecimal,
            date = dateFromMillis(occurredAt),
            note = note,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        val soldAsset = asset.copy(status = com.shift.app.domain.finance.AssetStatus.Sold.dbValue, updatedAt = occurredAt)
        accountDao.upsert(account)
        transactionDao.upsert(debtTransaction)
        assetDao.update(soldAsset)
        assetTransactionDao.insert(assetTransaction)
        val links = mutableListOf(
            writeLink(operationId, account.id, debtTransaction.id, "asset", asset.id, "credit_sale_asset", saleAmountDecimal),
            writeLink(operationId, account.id, debtTransaction.id, "asset_transaction", assetTransaction.id, "credit_sale_transaction", saleAmountDecimal)
        )
        val balance = if (cashCollectedDecimal != "0.00") {
            val cashDraft = DebtOperationFactory.cashPrincipal(operationId, accountId, DebtDirection.Payable, buyerName, cashCollectedDecimal, DebtCashSource.MadarBalance, occurredAt)
            writeBalanceLeg(cashDraft, debtTransaction, currencyCode).also {
                links += writeLink(operationId, account.id, debtTransaction.id, "balance_transaction", it.id, "credit_sale_cash", cashCollectedDecimal)
            }
        } else null
        publishAndReturn(DebtOperationRecords(
            account = account,
            debtTransaction = debtTransaction,
            balanceTransaction = balance,
            asset = soldAsset,
            assetTransaction = assetTransaction,
            links = links,
            impact = draft.impact
        ))
    }

    suspend fun recordAdjustment(
        operationId: String,
        accountId: String,
        type: DebtTransactionType,
        amountDecimal: String,
        reason: String,
        occurredAt: Long = System.currentTimeMillis()
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
        val snapshot = account.snapshot(transactionDao.getAllForAccountOnce(accountId))
        val draft = DebtOperationFactory.adjustment(
            operationId = operationId,
            account = snapshot,
            type = type,
            amount = amountDecimal,
            reason = reason,
            occurredAtEpochMillis = occurredAt
        )
        val tx = draft.toEntity(account.currencyCode)
        transactionDao.upsert(tx)
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        publishAndReturn(DebtOperationRecords(account = account, debtTransaction = tx, impact = draft.impact))
    }

    suspend fun recordOffset(
        operationId: String,
        payableAccountId: String,
        receivableAccountId: String,
        amountDecimal: String,
        reason: String,
        occurredAt: Long = System.currentTimeMillis()
    ): Pair<DebtOperationRecords, DebtOperationRecords> = db.withTransaction {
        require(reason.isNotBlank()) { "Offset reason is required" }
        val payable = accountDao.getById(payableAccountId) ?: throw IllegalArgumentException("Payable account not found")
        val receivable = accountDao.getById(receivableAccountId) ?: throw IllegalArgumentException("Receivable account not found")
        require(payable.direction == DebtDirection.Payable.dbValue && receivable.direction == DebtDirection.Receivable.dbValue) {
            "Offset requires one payable and one receivable"
        }
        require(payable.currencyCode == receivable.currencyCode) { "Offset requires one currency" }
        val payableDraft = DebtOperationFactory.adjustment(
            "$operationId:payable",
            payable.snapshot(transactionDao.getAllForAccountOnce(payable.id)),
            DebtTransactionType.Offset,
            amountDecimal,
            reason,
            occurredAt
        )
        val receivableDraft = DebtOperationFactory.adjustment(
            "$operationId:receivable",
            receivable.snapshot(transactionDao.getAllForAccountOnce(receivable.id)),
            DebtTransactionType.Offset,
            amountDecimal,
            reason,
            occurredAt
        )
        val payableTx = payableDraft.toEntity(payable.currencyCode)
        val receivableTx = receivableDraft.toEntity(receivable.currencyCode)
        transactionDao.upsert(payableTx)
        transactionDao.upsert(receivableTx)
        val pLink = writeLink(operationId, payable.id, payableTx.id, "debt_transaction", receivableTx.id, "offset_counterparty", amountDecimal)
        val rLink = writeLink(operationId, receivable.id, receivableTx.id, "debt_transaction", payableTx.id, "offset_counterparty", amountDecimal)
        val payableRecords = DebtOperationRecords(payable, payableTx, links = listOf(pLink), impact = payableDraft.impact)
        val receivableRecords = DebtOperationRecords(receivable, receivableTx, links = listOf(rLink), impact = receivableDraft.impact)
        publishDebtChange(payableRecords)
        payableRecords to receivableRecords
    }

    suspend fun reverseDebtTransaction(
        operationId: String,
        originalTransactionId: String,
        reason: String,
        occurredAt: Long = System.currentTimeMillis()
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        require(reason.isNotBlank()) { "Reversal reason is required" }
        val original = findDebtTransactionById(originalTransactionId)
        require(transactionDao.getByOperationId(operationId).isEmpty()) { "Duplicate reversal operation" }
        require(transactionDao.getAllForAccountOnce(original.accountId).none { it.originalTransactionId == originalTransactionId && it.type == DebtTransactionType.Reversal.dbValue }) {
            "Debt transaction is already reversed"
        }
        val account = accountDao.getById(original.accountId) ?: throw IllegalArgumentException("Debt account not found")
        val draft = DebtOperationFactory.reversal(operationId, account.snapshot(transactionDao.getAllForAccountOnce(account.id)), originalTransactionId, original.amountDecimal, reason, occurredAt)
        val reversal = draft.toEntity(account.currencyCode).copy(originalTransactionId = originalTransactionId, reason = reason)
        transactionDao.upsert(reversal)
        val link = writeLink(operationId, account.id, reversal.id, "debt_transaction", original.id, "reversal_of", original.amountDecimal)
        publishAndReturn(DebtOperationRecords(account = account, debtTransaction = reversal, links = listOf(link), impact = draft.impact))
    }

    private suspend fun findDebtTransactionById(id: String): DebtTransaction =
        transactionDao.getById(id) ?: throw IllegalArgumentException("Original debt transaction not found")

    suspend fun recordCashPrincipal(
        operationId: String,
        accountId: String,
        direction: DebtDirection,
        partyName: String,
        amountDecimal: String,
        cashSource: DebtCashSource,
        currencyCode: String = "SDG",
        occurredAt: Long = System.currentTimeMillis()
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        if (cashSource == DebtCashSource.MadarBalance) requireBalanceActivated()
        val draft = DebtOperationFactory.cashPrincipal(
            operationId = operationId,
            accountId = accountId,
            direction = direction,
            partyName = partyName,
            amount = amountDecimal,
            cashSource = cashSource,
            occurredAtEpochMillis = occurredAt
        )
        val account = accountDao.getById(accountId) ?: DebtAccount(
            id = accountId,
            operationId = operationId,
            direction = direction.dbValue,
            partyName = partyName.trim(),
            partyKey = partyName.trim().lowercase(),
            currencyCode = currencyCode,
            createdAt = occurredAt,
            updatedAt = occurredAt
        )
        require(account.direction == direction.dbValue) { "Debt account direction cannot change" }
        require(account.currencyCode == currencyCode) { "Debt operations require a single local currency" }
        val debtTransaction = draft.toEntity(currencyCode)
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        transactionDao.upsert(debtTransaction)
        val balance = if (cashSource == DebtCashSource.MadarBalance) {
            writeBalanceLeg(draft, debtTransaction, currencyCode)
        } else {
            null
        }
        val links = balance?.let {
            listOf(writeLink(operationId, account.id, debtTransaction.id, "balance_transaction", it.id, "cash_leg", amountDecimal))
        }.orEmpty()
        publishAndReturn(DebtOperationRecords(account, debtTransaction, balanceTransaction = balance, links = links, impact = draft.impact))
    }

    suspend fun recordReduction(
        operationId: String,
        accountId: String,
        amountDecimal: String,
        cashSource: DebtCashSource,
        occurredAt: Long = System.currentTimeMillis()
    ): DebtOperationRecords = db.withTransaction {
        existing(operationId)?.let { return@withTransaction it }
        if (cashSource == DebtCashSource.MadarBalance) requireBalanceActivated()
        val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
        val snapshot = account.snapshot(transactionDao.getAllForAccountOnce(accountId))
        val draft = DebtOperationFactory.cashReduction(
            operationId = operationId,
            account = snapshot,
            amount = amountDecimal,
            cashSource = cashSource,
            occurredAtEpochMillis = occurredAt
        )
        val debtTransaction = draft.toEntity(account.currencyCode)
        DebtCalculator.assertCanReduce(snapshot, DebtMoney.of(amountDecimal))
        transactionDao.upsert(debtTransaction)
        accountDao.upsert(account.copy(updatedAt = occurredAt))
        val balance = if (cashSource == DebtCashSource.MadarBalance) {
            writeBalanceLeg(draft, debtTransaction, account.currencyCode)
        } else {
            null
        }
        val links = balance?.let {
            listOf(writeLink(operationId, account.id, debtTransaction.id, "balance_transaction", it.id, "cash_leg", amountDecimal))
        }.orEmpty()
        publishAndReturn(DebtOperationRecords(account, debtTransaction, balanceTransaction = balance, links = links, impact = draft.impact))
    }

    suspend fun getAccountSnapshot(accountId: String): DebtAccountSnapshot {
        val account = accountDao.getById(accountId) ?: throw IllegalArgumentException("Debt account not found")
        return account.snapshot(transactionDao.getAllForAccountOnce(accountId))
    }

    suspend fun deleteAllLocalData() = db.withTransaction {
        linkDao.deleteAll()
        transactionDao.deleteAll()
        accountDao.deleteAll()
    }

    private suspend fun publishAndReturn(records: DebtOperationRecords): DebtOperationRecords {
        publishDebtChange(records)
        return records
    }

    private suspend fun publishDebtChange(records: DebtOperationRecords) {
        val transaction = records.debtTransaction
        changePublisher.publish(
            sourceType = "debts",
            sourceId = records.account.id,
            operationId = transaction.operationId,
            effectiveDate = dateFromMillis(transaction.occurredAt),
            changedFields = "account,principal,transaction,payment,balance,deletedAt",
            createdAt = transaction.updatedAt,
        )
    }

    private suspend fun existing(operationId: String): DebtOperationRecords? {
        val transactions = transactionDao.getByOperationId(operationId)
        if (transactions.isEmpty()) return null
        val tx = transactions.first()
        val account = accountDao.getById(tx.accountId) ?: return null
        val balance = balanceDao.getByOperationId(operationId).firstOrNull()
        val links = linkDao.getByOperationId(operationId)
        return DebtOperationRecords(
            account = account,
            debtTransaction = tx,
            balanceTransaction = balance,
            links = links,
            impact = DebtOperationFactory.opening(
                operationId = operationId,
                accountId = account.id,
                direction = DebtDirection.fromDb(account.direction),
                partyName = account.partyName,
                amount = tx.amountDecimal,
                occurredAtEpochMillis = tx.occurredAt
            ).impact
        )
    }

    private suspend fun requireBalanceActivated() {
        require(balanceDao.getActiveOpeningBalance() != null) {
            "Madar balance must be activated before selecting it for debt operations"
        }
    }

    private suspend fun writeBalanceLeg(
        draft: DebtOperationDraft,
        debtTransaction: DebtTransaction,
        currencyCode: String
    ): BalanceTransaction {
        val delta = draft.impact.balanceDeltaDecimal
        val kind = if (delta.startsWith("-")) BalanceTransactionKind.ManualWithdrawal else BalanceTransactionKind.ManualAdd
        val item = BalanceTransaction(
            operationId = draft.operationId,
            direction = if (delta.startsWith("-")) BalanceDirection.Outflow.dbValue else BalanceDirection.Inflow.dbValue,
            kind = kind.dbValue,
            amountDecimal = delta.removePrefix("-"),
            currencyCode = currencyCode,
            date = dateFromMillis(debtTransaction.occurredAt),
            note = "Debt principal ${debtTransaction.type}",
            sourceType = "debt_transaction",
            sourceId = debtTransaction.id,
            createdAt = debtTransaction.createdAt,
            updatedAt = debtTransaction.updatedAt
        )
        balanceDao.insert(item)
        return item
    }

    private suspend fun writeLink(
        operationId: String,
        accountId: String,
        debtTransactionId: String,
        targetType: String,
        targetId: String,
        role: String,
        amountDecimal: String
    ): DebtLink {
        val link = DebtLink(
            operationId = operationId,
            accountId = accountId,
            debtTransactionId = debtTransactionId,
            targetType = targetType,
            targetId = targetId,
            role = role,
            amountDecimal = amountDecimal
        )
        linkDao.upsert(link)
        return link
    }

    private fun DebtOperationDraft.toEntity(currencyCode: String): DebtTransaction =
        DebtTransaction(
            id = transaction.id,
            accountId = accountId,
            operationId = operationId,
            type = transaction.type.dbValue,
            amountDecimal = transaction.amount.decimalText,
            currencyCode = currencyCode,
            occurredAt = transaction.occurredAtEpochMillis,
            note = "",
            reason = transaction.reason,
            originalTransactionId = transaction.originalTransactionId,
            sourceType = "debt_operation",
            sourceId = operationId,
            createdAt = transaction.occurredAtEpochMillis,
            updatedAt = transaction.occurredAtEpochMillis
        )

    private fun DebtAccount.snapshot(transactions: List<DebtTransaction>): DebtAccountSnapshot =
        DebtAccountSnapshot(
            accountId = id,
            direction = DebtDirection.fromDb(direction),
            partyName = partyName,
            currencyCode = currencyCode,
            confirmed = confirmed,
            archived = archivedAt != null,
            transactions = transactions.map {
                DebtTransactionInput(
                    id = it.id,
                    accountId = it.accountId,
                    operationId = it.operationId,
                    type = DebtTransactionType.fromDb(it.type),
                    amount = DebtMoney.of(it.amountDecimal),
                    occurredAtEpochMillis = it.occurredAt,
                    reason = it.reason,
                    originalTransactionId = it.originalTransactionId,
                    isVoided = it.deletedAt != null
                )
            }
        )

    private fun dateFromMillis(millis: Long): String =
        Instant.ofEpochMilli(millis.absoluteValue).atZone(ZoneOffset.UTC).toLocalDate().toString()
}

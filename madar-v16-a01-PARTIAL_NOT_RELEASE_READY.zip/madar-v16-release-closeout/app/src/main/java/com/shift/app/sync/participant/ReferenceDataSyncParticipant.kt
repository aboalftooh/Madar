package com.shift.app.sync.participant

import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.dao.IncomeSourceDao
import com.shift.app.sync.remote.ReferenceDataRemoteSync
import com.shift.app.sync.SyncCheckpointKey
import com.shift.app.data.remote.shouldPushFinancialRecord
import com.shift.app.sync.SyncOperation
import com.shift.app.sync.SyncParticipant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReferenceDataSyncParticipant @Inject constructor(
    private val incomeSourceDao: IncomeSourceDao,
    private val expenseBeneficiaryDao: ExpenseBeneficiaryDao,
    private val remote: ReferenceDataRemoteSync,
) : SyncParticipant {
    override val key: String = "reference_data"
    override val order: Int = 10

    override suspend fun pullOperations(): List<SyncOperation> = listOf(
        SyncOperation("pull_income_sources", SyncCheckpointKey.IncomeSources) { remote.pullIncomeSources() },
        SyncOperation("pull_expense_beneficiaries", SyncCheckpointKey.ExpenseBeneficiaries) {
            remote.pullExpenseBeneficiaries()
        },
    )

    override suspend fun pushOperations(lastSuccessfulSync: Long): List<SyncOperation> = buildList {
        val incomeSources = incomeSourceDao.getAllOnce().filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        if (incomeSources.isNotEmpty()) {
            add(SyncOperation("push_income_sources") { remote.pushIncomeSources(incomeSources) })
        }

        val beneficiaries = expenseBeneficiaryDao.getAllOnce().filter {
            shouldPushFinancialRecord(it.updatedAt, it.syncState, lastSuccessfulSync)
        }
        if (beneficiaries.isNotEmpty()) {
            add(SyncOperation("push_expense_beneficiaries") {
                remote.pushExpenseBeneficiaries(beneficiaries)
            })
        }
    }
}

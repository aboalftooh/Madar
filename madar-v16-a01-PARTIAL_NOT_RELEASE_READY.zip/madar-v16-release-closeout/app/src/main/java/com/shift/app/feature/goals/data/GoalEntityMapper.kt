package com.shift.app.feature.goals.data

import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.data.local.entities.goals.GoalActivityEntity
import com.shift.app.data.local.entities.goals.GoalConditionEntity
import com.shift.app.data.local.entities.goals.GoalCostEstimateEntity
import com.shift.app.data.local.entities.goals.GoalEvaluationEntity
import com.shift.app.data.local.entities.goals.GoalFundingTransactionEntity
import com.shift.app.data.local.entities.goals.GoalMetricEntity
import com.shift.app.data.local.entities.goals.GoalScopeEntity
import com.shift.app.data.repository.FinancialGoalAggregate
import com.shift.app.feature.goals.domain.model.FinancialChangeEvent
import com.shift.app.feature.goals.domain.model.FinancialGoal
import com.shift.app.feature.goals.domain.model.GoalActivity
import com.shift.app.feature.goals.domain.model.GoalAggregate
import com.shift.app.feature.goals.domain.model.GoalCondition
import com.shift.app.feature.goals.domain.model.GoalCostEstimate
import com.shift.app.feature.goals.domain.model.GoalEvaluation
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.feature.goals.domain.model.GoalMetric
import com.shift.app.feature.goals.domain.model.GoalScope

internal fun FinancialGoalEntity.toDomain() = FinancialGoal(
    id, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId,
    targetDecimal, baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson,
    revision, readyAt, completedAt, cancelledAt, archivedAt, createdAt, updatedAt, deletedAt, syncState,
)

internal fun FinancialGoal.toEntity() = FinancialGoalEntity(
    id, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId,
    targetDecimal, baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson,
    revision, readyAt, completedAt, cancelledAt, archivedAt, createdAt, updatedAt, deletedAt, syncState,
)

internal fun GoalMetricEntity.toDomain() = GoalMetric(id, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalMetric.toEntity() = GoalMetricEntity(id, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalConditionEntity.toDomain() = GoalCondition(id, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalCondition.toEntity() = GoalConditionEntity(id, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalScopeEntity.toDomain() = GoalScope(id, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalScope.toEntity() = GoalScopeEntity(id, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalFundingTransactionEntity.toDomain() = GoalFundingTransaction(id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId, relatedFundingTransactionId, note, occurredAt, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalFundingTransaction.toEntity() = GoalFundingTransactionEntity(id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId, relatedFundingTransactionId, note, occurredAt, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalCostEstimateEntity.toDomain() = GoalCostEstimate(id, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note, effectiveAt, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalCostEstimate.toEntity() = GoalCostEstimateEntity(id, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note, effectiveAt, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalEvaluationEntity.toDomain() = GoalEvaluation(id, goalId, asOf, engineVersion, inputFingerprint, lifecycleStatus, healthStatus, measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt, updatedAt, deletedAt)
internal fun GoalEvaluation.toEntity() = GoalEvaluationEntity(id, goalId, asOf, engineVersion, inputFingerprint, lifecycleStatus, healthStatus, measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt, updatedAt, deletedAt)
internal fun GoalActivityEntity.toDomain() = GoalActivity(id, goalId, operationId, type, occurredAt, effectiveDate, detailsJson, createdAt, updatedAt, deletedAt, syncState)
internal fun GoalActivity.toEntity() = GoalActivityEntity(id, goalId, operationId, type, occurredAt, effectiveDate, detailsJson, createdAt, updatedAt, deletedAt, syncState)

internal fun FinancialGoalAggregate.toDomain() = GoalAggregate(
    goal.toDomain(), metrics.map { it.toDomain() }, conditions.map { it.toDomain() }, scopes.map { it.toDomain() },
    fundingTransactions.map { it.toDomain() }, costEstimates.map { it.toDomain() }, evaluations.map { it.toDomain() }, activities.map { it.toDomain() },
)

internal fun GoalAggregate.toEntityAggregate() = FinancialGoalAggregate(
    goal.toEntity(), metrics.map { it.toEntity() }, conditions.map { it.toEntity() }, scopes.map { it.toEntity() },
    fundingTransactions.map { it.toEntity() }, costEstimates.map { it.toEntity() }, evaluations.map { it.toEntity() }, activities.map { it.toEntity() },
)

internal fun FinancialChangeOutboxEntity.toDomain() = FinancialChangeEvent(eventId, sourceType, sourceId, operationId, effectiveDate, changedFields, createdAt, processedAt, attemptCount, lastError)
internal fun FinancialChangeEvent.toEntity() = FinancialChangeOutboxEntity(eventId, sourceType, sourceId, operationId, effectiveDate, changedFields, createdAt, processedAt, attemptCount, lastError)

package com.shift.app.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.ui.theme.*
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.viewmodel.PinViewModel
import kotlinx.coroutines.delay

@Composable
fun PinScreen(
    onAuthenticated: () -> Unit,
    vm: PinViewModel = hiltViewModel()
) {
    val correctPin  by vm.pin.collectAsState()
    val pinEnabled  by vm.pinEnabled.collectAsState()
    val secQuestion by vm.secQuestion.collectAsState()
    val lockedUntil by vm.lockedUntil.collectAsState()
    val context = LocalContext.current

    var input      by remember { mutableStateOf("") }
    var errorMsg   by remember { mutableStateOf("") }
    var successMsg by remember { mutableStateOf("") }
    var showForgot by remember { mutableStateOf(false) }
    var resetMode  by remember { mutableStateOf(false) }
    var newPin     by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var now        by remember { mutableLongStateOf(System.currentTimeMillis()) }

    BackHandler {
        (context as? Activity)?.finish()
    }

    LaunchedEffect(lockedUntil) {
        while (lockedUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(1_000L)
        }
        now = System.currentTimeMillis()
    }

    // null = لم يُحمَّل بعد → شاشة فارغة بدون أي قرار
    // false = PIN معطّل → ادخل مباشرة
    // true = PIN مفعّل → اعرض لوحة الأرقام
    if (pinEnabled == null) {
        Box(Modifier.fillMaxSize().background(BackgroundDark))
        return
    }
    // PIN معطّل أو لم يُضبط بعد (أول تشغيل) → ادخل مباشرة
    if (pinEnabled == false || correctPin.isEmpty()) {
        LaunchedEffect(Unit) { onAuthenticated() }
        return
    }

    val remainingLockMillis = (lockedUntil - now).coerceAtLeast(0L)
    val isLocked = remainingLockMillis > 0L

    if (showForgot) {
        ForgotPinDialog(
            question = secQuestion,
            onSubmit = { answer ->
                if (vm.verifySecAnswer(answer)) {
                    showForgot = false
                    input = ""
                    errorMsg = ""
                    successMsg = "تم التحقق. اضبط PIN جديداً للمتابعة."
                    resetMode = true
                } else {
                    successMsg = ""
                    errorMsg = "إجابة خاطئة!"
                }
            },
            onDismiss = { showForgot = false }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            // Logo
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AccentBlue, AccentCyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(36.dp))
            }

            Spacer(Modifier.height(24.dp))
            Text("madar", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                if (resetMode) "اضبط رمز PIN جديد" else "أدخل رمز PIN",
                color = TextSecondary,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(Modifier.height(32.dp))

            if (resetMode) {
                ResetPinForm(
                    newPin = newPin,
                    confirmPin = confirmPin,
                    onNewPinChange = { value -> newPin = value.filter { it.isDigit() }.take(4) },
                    onConfirmPinChange = { value -> confirmPin = value.filter { it.isDigit() }.take(4) },
                    onSave = {
                        when {
                            newPin.length != 4 -> {
                                successMsg = ""
                                errorMsg = "يجب أن يكون PIN من 4 أرقام"
                            }
                            newPin != confirmPin -> {
                                successMsg = ""
                                errorMsg = "رمزا PIN غير متطابقين"
                            }
                            else -> {
                                vm.setRecoveredPin(newPin) {
                                    onAuthenticated()
                                }
                            }
                        }
                    }
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    repeat(4) { i ->
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (i < input.length) AccentBlue else SurfaceVariant)
                        )
                    }
                }
            }

            if (successMsg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(successMsg, color = IncomeGreen, fontSize = 13.sp)
            }
            if (errorMsg.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(errorMsg, color = ExpenseRed, fontSize = 13.sp)
            }

            if (isLocked) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "محاولات كثيرة. حاول بعد ${NumberDisplayFormatter.format((remainingLockMillis + 999L) / 1000L)} ثانية.",
                    color = ExpenseRed,
                    fontSize = 13.sp
                )
            }

            if (!resetMode) {
                Spacer(Modifier.height(32.dp))

                val keys = listOf("1","2","3","4","5","6","7","8","9","","0","⌫")
                val grid = keys.chunked(3)
                grid.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        row.forEach { key ->
                            if (key.isEmpty()) {
                                Spacer(Modifier.size(72.dp))
                            } else {
                                NumKey(label = key, enabled = !isLocked) {
                                    when (key) {
                                        "⌫" -> if (input.isNotEmpty()) input = input.dropLast(1)
                                        else -> {
                                            if (input.length < 4) {
                                                input += key
                                                if (input.length == 4) {
                                                    if (vm.verifyPin(input)) {
                                                        vm.resetPinAttempts()
                                                        onAuthenticated()
                                                    } else {
                                                        input = ""
                                                        successMsg = ""
                                                        vm.recordFailedPinAttempt { attempts, lockedUntilMillis ->
                                                            val lockText = if (lockedUntilMillis > System.currentTimeMillis()) {
                                                                " تم القفل مؤقتاً."
                                                            } else {
                                                                ""
                                                            }
                                                            errorMsg = "PIN خاطئ! ($attempts/5)$lockText"
                                                            if (attempts >= 3) showForgot = true
                                                        }
                                                    }
                                                } else {
                                                    errorMsg = ""
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { showForgot = true }) {
                    Text("نسيت PIN؟", color = AccentCyan)
                }
            }
        }
    }
}

@Composable
private fun NumKey(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.size(72.dp),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
        contentPadding = PaddingValues(0.dp)
    ) {
        if (label == "⌫") {
            Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "حذف", tint = TextSecondary, modifier = Modifier.size(22.dp))
        } else {
            Text(label, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        }
    }
}

@Composable
private fun ResetPinForm(
    newPin: String,
    confirmPin: String,
    onNewPinChange: (String) -> Unit,
    onConfirmPinChange: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = newPin,
            onValueChange = onNewPinChange,
            label = { Text("PIN جديد", color = TextMuted) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = SurfaceVariant
            )
        )
        OutlinedTextField(
            value = confirmPin,
            onValueChange = onConfirmPinChange,
            label = { Text("تأكيد PIN", color = TextMuted) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = SurfaceVariant
            )
        )
        Button(
            onClick = onSave,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Text("حفظ PIN والمتابعة", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ForgotPinDialog(
    question: String,
    onSubmit: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var answer by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("استعادة PIN", color = AccentCyan, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(question, color = TextSecondary)
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    placeholder = { Text("إجابتك", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = SurfaceVariant
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(answer) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text("تأكيد") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", color = TextMuted) }
        }
    )
}

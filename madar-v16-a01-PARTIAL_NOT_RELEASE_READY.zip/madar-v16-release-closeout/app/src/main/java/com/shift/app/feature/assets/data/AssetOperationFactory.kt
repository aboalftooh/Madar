package com.shift.app.feature.assets.data

import com.shift.app.data.local.entities.Asset
import com.shift.app.data.local.entities.AssetTransaction
import com.shift.app.data.local.entities.AssetValuation
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.CurrencyAssetLot
import com.shift.app.data.local.entities.CurrencyAssetSaleAllocation
import com.shift.app.data.local.entities.Payment
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.BalanceDirection
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.CurrencySalePlan
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.feature.assets.domain.model.AddCurrencyLotRequest
import com.shift.app.feature.assets.domain.model.AssetPaymentRequest
import com.shift.app.feature.assets.domain.model.AssetSaleRequest
import com.shift.app.feature.assets.domain.model.AssetValuationRequest
import com.shift.app.feature.assets.domain.model.CurrencyAssetSaleRequest
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.feature.assets.domain.model.PreexistingAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.feature.assets.domain.model.PurchaseCurrencyAssetRequest
import java.math.RoundingMode
import java.time.LocalDate
import java.util.UUID

data class AssetOperationRecords(
    val assets: List<Asset> = emptyList(),
    val assetTransactions: List<AssetTransaction> = emptyList(),
    val assetValuations: List<AssetValuation> = emptyList(),
    val payments: List<Payment> = emptyList(),
    val balanceTransactions: List<BalanceTransaction> = emptyList(),
    val currencyLots: List<CurrencyAssetLot> = emptyList(),
    val currencySaleAllocations: List<CurrencyAssetSaleAllocation> = emptyList()
)

/**
 * Pure builders for the composite rows. Keeping this separate from Room makes the
 * financial effects executable in local unit tests.
 */
object AssetOperationFactory {
    fun preexisting(request: PreexistingAssetRequest, now: Long = System.currentTimeMillis()): AssetOperationRecords {
        val operationId = request.operationId.required("operationId")
        val name = request.name.trim().required("name")
        val type = request.type.trim().required("type")
        val date = request.date.isoDate()
        val acquisition = DecimalText.canonicalNonNegative(request.acquisitionAmountDecimal, DecimalTextScale.Money)
        val asset = Asset(
            operationId = operationId,
            type = type,
            name = name,
            acquisitionMode = "preexisting",
            acquisitionAmountDecimal = acquisition,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            operationId = operationId,
            assetId = asset.id,
            kind = AssetTransactionKind.PreexistingAdd.dbValue,
            amountDecimal = acquisition,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val valuation = AssetValuation(
            operationId = operationId,
            assetId = asset.id,
            valueDecimal = acquisition,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assets = listOf(asset),
            assetTransactions = listOf(event),
            assetValuations = listOf(valuation)
        )
    }

    fun purchase(request: PurchaseAssetRequest, now: Long = System.currentTimeMillis()): AssetOperationRecords {
        val operationId = request.operationId.required("operationId")
        val name = request.name.trim().required("name")
        val type = request.type.trim().required("type")
        val date = request.date.isoDate()
        val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
        val balanceId = UUID.randomUUID().toString()
        val paymentId = UUID.randomUUID().toString()
        val assetId = UUID.randomUUID().toString()
        val balance = BalanceTransaction(
            id = balanceId,
            operationId = operationId,
            direction = BalanceDirection.Outflow.dbValue,
            kind = BalanceTransactionKind.AssetPurchase.dbValue,
            amountDecimal = amount,
            date = date,
            note = request.note,
            sourceType = "payment",
            sourceId = paymentId,
            createdAt = now,
            updatedAt = now
        )
        val payment = Payment(
            id = paymentId,
            operationId = operationId,
            kind = PaymentKind.AssetPurchase.dbValue,
            amountDecimal = amount,
            date = date,
            purpose = "شراء أصل",
            purposeKey = "شراء أصل",
            assetId = assetId,
            assetNameSnapshot = name,
            balanceTransactionId = balanceId,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val asset = Asset(
            id = assetId,
            operationId = operationId,
            type = type,
            name = name,
            acquisitionMode = "purchased_in_app",
            acquisitionAmountDecimal = amount,
            purchasePaymentId = paymentId,
            purchaseBalanceTransactionId = balanceId,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            operationId = operationId,
            assetId = assetId,
            kind = AssetTransactionKind.Purchase.dbValue,
            amountDecimal = amount,
            paymentId = paymentId,
            balanceTransactionId = balanceId,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val valuation = AssetValuation(
            operationId = operationId,
            assetId = assetId,
            valueDecimal = amount,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assets = listOf(asset),
            assetTransactions = listOf(event),
            assetValuations = listOf(valuation),
            payments = listOf(payment),
            balanceTransactions = listOf(balance)
        )
    }

    fun purchaseCurrency(
        request: PurchaseCurrencyAssetRequest,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        val operationId = request.operationId.required("operationId")
        val name = request.name.trim().required("name")
        val code = request.foreignCurrencyCode.currencyCode()
        val quantity = DecimalText.canonicalPositive(request.quantityDecimal, DecimalTextScale.Quantity)
        val exchangeRate = DecimalText.canonicalPositive(request.exchangeRateDecimal, DecimalTextScale.ExchangeRate)
        val localCost = DecimalText.canonicalPositive(request.localCostDecimal, DecimalTextScale.Money)
        val date = request.date.isoDate()
        val balanceId = UUID.randomUUID().toString()
        val paymentId = UUID.randomUUID().toString()
        val assetId = UUID.randomUUID().toString()
        val eventId = UUID.randomUUID().toString()
        val balance = BalanceTransaction(
            id = balanceId,
            operationId = operationId,
            direction = BalanceDirection.Outflow.dbValue,
            kind = BalanceTransactionKind.AssetPurchase.dbValue,
            amountDecimal = localCost,
            currencyCode = "SDG",
            date = date,
            note = request.note,
            sourceType = "payment",
            sourceId = paymentId,
            createdAt = now,
            updatedAt = now
        )
        val payment = Payment(
            id = paymentId,
            operationId = operationId,
            kind = PaymentKind.AssetPurchase.dbValue,
            amountDecimal = localCost,
            currencyCode = "SDG",
            date = date,
            purpose = "شراء عملة $code",
            purposeKey = "شراء عملة ${code.lowercase()}",
            assetId = assetId,
            assetNameSnapshot = name,
            balanceTransactionId = balanceId,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val asset = Asset(
            id = assetId,
            operationId = operationId,
            type = FOREIGN_CURRENCY_ASSET_TYPE,
            name = name,
            acquisitionMode = "purchased_in_app",
            acquisitionAmountDecimal = localCost,
            currencyCode = code,
            purchasePaymentId = paymentId,
            purchaseBalanceTransactionId = balanceId,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            id = eventId,
            operationId = operationId,
            assetId = assetId,
            kind = AssetTransactionKind.Purchase.dbValue,
            amountDecimal = localCost,
            currencyQuantityDeltaDecimal = quantity,
            paymentId = paymentId,
            balanceTransactionId = balanceId,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val lot = CurrencyAssetLot(
            operationId = operationId,
            assetId = assetId,
            purchaseAssetTransactionId = eventId,
            foreignCurrencyCode = code,
            quantityPurchasedDecimal = quantity,
            purchaseExchangeRateDecimal = exchangeRate,
            localCostDecimal = localCost,
            purchaseDate = date,
            createdAt = now,
            updatedAt = now
        )
        val valuation = AssetValuation(
            operationId = operationId,
            assetId = assetId,
            valueDecimal = localCost,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assets = listOf(asset),
            assetTransactions = listOf(event),
            assetValuations = listOf(valuation),
            payments = listOf(payment),
            balanceTransactions = listOf(balance),
            currencyLots = listOf(lot)
        )
    }

    fun addCurrencyLot(
        asset: Asset,
        request: AddCurrencyLotRequest,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        require(request.assetId == asset.id) { "Currency lot assetId does not match the asset" }
        require(asset.type == FOREIGN_CURRENCY_ASSET_TYPE) { "Asset is not a foreign currency asset" }
        require(asset.status == AssetStatus.Active.dbValue) { "Only an active currency asset can be purchased" }
        val operationId = request.operationId.required("operationId")
        val quantity = DecimalText.canonicalPositive(request.quantityDecimal, DecimalTextScale.Quantity)
        val exchangeRate = DecimalText.canonicalPositive(request.exchangeRateDecimal, DecimalTextScale.ExchangeRate)
        val localCost = DecimalText.canonicalPositive(request.localCostDecimal, DecimalTextScale.Money)
        val date = request.date.isoDate()
        val code = asset.currencyCode.currencyCode()
        val balanceId = UUID.randomUUID().toString()
        val paymentId = UUID.randomUUID().toString()
        val eventId = UUID.randomUUID().toString()
        val balance = BalanceTransaction(
            id = balanceId,
            operationId = operationId,
            direction = BalanceDirection.Outflow.dbValue,
            kind = BalanceTransactionKind.AssetPurchase.dbValue,
            amountDecimal = localCost,
            currencyCode = "SDG",
            date = date,
            note = request.note,
            sourceType = "payment",
            sourceId = paymentId,
            createdAt = now,
            updatedAt = now
        )
        val payment = Payment(
            id = paymentId,
            operationId = operationId,
            kind = PaymentKind.AssetPurchase.dbValue,
            amountDecimal = localCost,
            currencyCode = "SDG",
            date = date,
            purpose = "شراء دفعة $code",
            purposeKey = "شراء دفعة ${code.lowercase()}",
            assetId = asset.id,
            assetNameSnapshot = asset.name,
            balanceTransactionId = balanceId,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            id = eventId,
            operationId = operationId,
            assetId = asset.id,
            kind = AssetTransactionKind.Purchase.dbValue,
            amountDecimal = localCost,
            currencyQuantityDeltaDecimal = quantity,
            paymentId = paymentId,
            balanceTransactionId = balanceId,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val lot = CurrencyAssetLot(
            operationId = operationId,
            assetId = asset.id,
            purchaseAssetTransactionId = eventId,
            foreignCurrencyCode = code,
            quantityPurchasedDecimal = quantity,
            purchaseExchangeRateDecimal = exchangeRate,
            localCostDecimal = localCost,
            purchaseDate = date,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assetTransactions = listOf(event),
            payments = listOf(payment),
            balanceTransactions = listOf(balance),
            currencyLots = listOf(lot)
        )
    }

    fun currencySale(
        asset: Asset,
        request: CurrencyAssetSaleRequest,
        plan: CurrencySalePlan,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        require(request.assetId == asset.id) { "Currency sale assetId does not match the asset" }
        require(asset.type == FOREIGN_CURRENCY_ASSET_TYPE) { "Asset is not a foreign currency asset" }
        require(asset.status == AssetStatus.Active.dbValue) { "Only an active currency asset can be sold" }
        val operationId = request.operationId.required("operationId")
        val requestedQuantity = DecimalText.canonicalPositive(request.quantityDecimal, DecimalTextScale.Quantity)
        require(requestedQuantity == plan.requestedQuantityDecimal) { "Currency sale plan quantity does not match request" }
        require(
            plan.allocations.fold(java.math.BigDecimal.ZERO) { total, allocation ->
                total + DecimalText.toBigDecimal(allocation.quantitySoldDecimal)
            }.setScale(DecimalTextScale.Quantity.places, RoundingMode.HALF_UP).toPlainString() == requestedQuantity
        ) { "Currency sale allocations do not add up to the requested quantity" }
        val proceeds = DecimalText.canonicalPositive(request.localProceedsDecimal, DecimalTextScale.Money)
        val date = request.date.isoDate()
        val balance = BalanceTransaction(
            operationId = operationId,
            direction = BalanceDirection.Inflow.dbValue,
            kind = BalanceTransactionKind.AssetSale.dbValue,
            amountDecimal = proceeds,
            currencyCode = "SDG",
            date = date,
            note = request.note,
            sourceType = "asset",
            sourceId = asset.id,
            createdAt = now,
            updatedAt = now
        )
        val fullSale = DecimalText.toBigDecimal(plan.availableAfterDecimal).signum() == 0
        val event = AssetTransaction(
            operationId = operationId,
            assetId = asset.id,
            kind = if (fullSale) AssetTransactionKind.SaleFull.dbValue else AssetTransactionKind.SalePartial.dbValue,
            amountDecimal = proceeds,
            currencyQuantityDeltaDecimal = DecimalText.toBigDecimal(plan.requestedQuantityDecimal)
                .negate()
                .setScale(DecimalTextScale.Quantity.places, RoundingMode.HALF_UP)
                .toPlainString(),
            balanceTransactionId = balance.id,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val allocations = plan.allocations.map { draft ->
            CurrencyAssetSaleAllocation(
                operationId = operationId,
                assetId = asset.id,
                saleAssetTransactionId = event.id,
                lotId = draft.lotId,
                quantitySoldDecimal = draft.quantitySoldDecimal,
                allocatedLocalCostDecimal = draft.allocatedLocalCostDecimal,
                createdAt = now,
                updatedAt = now
            )
        }
        return AssetOperationRecords(
            assets = listOf(asset.copy(
                status = if (fullSale) AssetStatus.Sold.dbValue else AssetStatus.Active.dbValue,
                updatedAt = now
            )),
            assetTransactions = listOf(event),
            balanceTransactions = listOf(balance),
            currencySaleAllocations = allocations
        )
    }

    fun paymentEvent(
        asset: Asset,
        request: AssetPaymentRequest,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        require(asset.deletedAt == null) { "Asset is deleted" }
        val operationId = request.operationId.required("operationId")
        val date = request.date.required("date")
        val purpose = request.purpose.trim().required("purpose")
        val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
        val isMaintenance = request.kind == PaymentKind.AssetMaintenance
        require(request.kind == PaymentKind.AssetImprovement || isMaintenance) {
            "Only improvement and maintenance are asset payment events"
        }
        val balanceKind = if (isMaintenance) {
            BalanceTransactionKind.AssetMaintenance
        } else {
            BalanceTransactionKind.AssetImprovement
        }
        val eventKind = if (isMaintenance) {
            AssetTransactionKind.Maintenance
        } else {
            AssetTransactionKind.Improvement
        }
        val balanceId = UUID.randomUUID().toString()
        val paymentId = UUID.randomUUID().toString()
        val balance = BalanceTransaction(
            id = balanceId,
            operationId = operationId,
            direction = BalanceDirection.Outflow.dbValue,
            kind = balanceKind.dbValue,
            amountDecimal = amount,
            date = date,
            note = request.note,
            sourceType = "payment",
            sourceId = paymentId,
            createdAt = now,
            updatedAt = now
        )
        val payment = Payment(
            id = paymentId,
            operationId = operationId,
            kind = request.kind.dbValue,
            amountDecimal = amount,
            date = date,
            purpose = purpose,
            purposeKey = purpose.lowercase(),
            beneficiaryId = asset.id.takeIf { isMaintenance },
            beneficiaryNameSnapshot = asset.name.takeIf { isMaintenance }.orEmpty(),
            assetId = asset.id,
            assetNameSnapshot = asset.name,
            balanceTransactionId = balanceId,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            operationId = operationId,
            assetId = asset.id,
            kind = eventKind.dbValue,
            amountDecimal = amount,
            paymentId = paymentId,
            balanceTransactionId = balanceId,
            date = date,
            note = request.note.ifBlank { purpose },
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assetTransactions = listOf(event),
            payments = listOf(payment),
            balanceTransactions = listOf(balance)
        )
    }

    fun valuation(
        asset: Asset,
        request: AssetValuationRequest,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        require(asset.deletedAt == null) { "Asset is deleted" }
        val valuation = AssetValuation(
            operationId = request.operationId.required("operationId"),
            assetId = asset.id,
            valueDecimal = DecimalText.canonicalNonNegative(request.valueDecimal, DecimalTextScale.Money),
            date = request.date.required("date"),
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(assetValuations = listOf(valuation))
    }

    fun sale(
        asset: Asset,
        request: AssetSaleRequest,
        now: Long = System.currentTimeMillis()
    ): AssetOperationRecords {
        require(asset.status == AssetStatus.Active.dbValue) { "Only an active asset can be sold" }
        val operationId = request.operationId.required("operationId")
        val date = request.date.required("date")
        val amount = DecimalText.canonicalPositive(request.amountDecimal, DecimalTextScale.Money)
        val balance = BalanceTransaction(
            operationId = operationId,
            direction = BalanceDirection.Inflow.dbValue,
            kind = BalanceTransactionKind.AssetSale.dbValue,
            amountDecimal = amount,
            date = date,
            note = request.note,
            sourceType = "asset",
            sourceId = asset.id,
            createdAt = now,
            updatedAt = now
        )
        val event = AssetTransaction(
            operationId = operationId,
            assetId = asset.id,
            kind = AssetTransactionKind.SaleFull.dbValue,
            amountDecimal = amount,
            balanceTransactionId = balance.id,
            date = date,
            note = request.note,
            createdAt = now,
            updatedAt = now
        )
        return AssetOperationRecords(
            assets = listOf(asset.copy(status = AssetStatus.Sold.dbValue, updatedAt = now)),
            assetTransactions = listOf(event),
            balanceTransactions = listOf(balance)
        )
    }

}


private fun String.currencyCode(): String {
    val code = trim().uppercase().required("foreignCurrencyCode")
    require(code.matches(Regex("[A-Z]{3}"))) { "Currency code must contain exactly three Latin letters" }
    require(code != "SDG") { "Foreign currency code cannot be the local SDG currency" }
    return code
}

private fun String.isoDate(): String = LocalDate.parse(trim().required("date")).toString()

private fun String.required(field: String): String {
    require(isNotBlank()) { "$field must not be blank" }
    return this
}

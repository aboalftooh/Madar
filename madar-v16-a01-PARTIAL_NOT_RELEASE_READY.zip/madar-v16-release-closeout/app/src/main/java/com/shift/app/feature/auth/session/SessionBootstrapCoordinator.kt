package com.shift.app.feature.auth.session

import com.shift.app.feature.auth.domain.SessionBootstrapper
import com.shift.app.feature.auth.domain.SessionWriter
import com.shift.app.sync.SyncQueueGateway
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionBootstrapCoordinator @Inject constructor(
    private val sessionWriter: SessionWriter,
    private val syncQueue: SyncQueueGateway,
) : SessionBootstrapper {
    override suspend fun onLogin(email: String, rememberMe: Boolean) {
        sessionWriter.rememberEmail(if (rememberMe) email else "")
        syncQueue.enqueueRecovery()
    }

    override suspend fun onRegistration(name: String, jobTitle: String) {
        sessionWriter.initializeRegisteredAccount(name, jobTitle)
        syncQueue.requestSync(
            reason = "registration-settings",
            operationId = "registration-settings",
        )
    }
}

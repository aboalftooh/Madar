package com.shift.app.sync.di

import com.shift.app.sync.PreferencesSyncCheckpointStore
import com.shift.app.data.remote.AssetRemoteSyncDataSource
import com.shift.app.data.remote.DebtRemoteSyncDataSource
import com.shift.app.data.remote.GoalRemoteSyncDataSource
import com.shift.app.data.remote.LedgerRemoteSyncDataSource
import com.shift.app.data.remote.ReferenceDataRemoteSyncDataSource
import com.shift.app.data.remote.RemoteSyncContext
import com.shift.app.data.remote.SettingsRemoteSyncDataSource
import com.shift.app.sync.remote.AssetRemoteSync
import com.shift.app.sync.remote.DebtRemoteSync
import com.shift.app.sync.remote.GoalRemoteSync
import com.shift.app.sync.remote.LedgerRemoteSync
import com.shift.app.sync.remote.ReferenceDataRemoteSync
import com.shift.app.sync.remote.SettingsRemoteSync
import com.shift.app.sync.remote.SyncSessionRemote
import com.shift.app.sync.SyncCheckpointStore
import com.shift.app.sync.SyncParticipant
import com.shift.app.sync.participant.AssetSyncParticipant
import com.shift.app.sync.participant.DebtSyncParticipant
import com.shift.app.sync.participant.GoalSyncParticipant
import com.shift.app.sync.participant.LedgerSyncParticipant
import com.shift.app.sync.participant.ReferenceDataSyncParticipant
import com.shift.app.sync.participant.SettingsSyncParticipant
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

@Module
@InstallIn(SingletonComponent::class)
abstract class SyncParticipantModule {
    @Binds abstract fun bindSyncSessionRemote(impl: RemoteSyncContext): SyncSessionRemote
    @Binds abstract fun bindReferenceRemote(impl: ReferenceDataRemoteSyncDataSource): ReferenceDataRemoteSync
    @Binds abstract fun bindLedgerRemote(impl: LedgerRemoteSyncDataSource): LedgerRemoteSync
    @Binds abstract fun bindAssetRemote(impl: AssetRemoteSyncDataSource): AssetRemoteSync
    @Binds abstract fun bindDebtRemote(impl: DebtRemoteSyncDataSource): DebtRemoteSync
    @Binds abstract fun bindGoalRemote(impl: GoalRemoteSyncDataSource): GoalRemoteSync
    @Binds abstract fun bindSettingsRemote(impl: SettingsRemoteSyncDataSource): SettingsRemoteSync
    @Binds abstract fun bindCheckpointStore(impl: PreferencesSyncCheckpointStore): SyncCheckpointStore
    @Binds @IntoSet abstract fun bindReferenceData(impl: ReferenceDataSyncParticipant): SyncParticipant
    @Binds @IntoSet abstract fun bindLedger(impl: LedgerSyncParticipant): SyncParticipant
    @Binds @IntoSet abstract fun bindAssets(impl: AssetSyncParticipant): SyncParticipant
    @Binds @IntoSet abstract fun bindDebts(impl: DebtSyncParticipant): SyncParticipant
    @Binds @IntoSet abstract fun bindGoals(impl: GoalSyncParticipant): SyncParticipant
    @Binds @IntoSet abstract fun bindSettings(impl: SettingsSyncParticipant): SyncParticipant
}

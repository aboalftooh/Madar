package com.shift.app.sync.di

import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.SyncOutboxDao
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.sync.outbox.SyncWorkScheduler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SyncInfrastructureModule {
    @Provides
    fun provideSyncOutboxDao(database: MadarDatabase): SyncOutboxDao = database.syncOutboxDao()

    @Provides
    @Singleton
    fun provideSyncQueueGateway(scheduler: SyncWorkScheduler): SyncQueueGateway = scheduler
}

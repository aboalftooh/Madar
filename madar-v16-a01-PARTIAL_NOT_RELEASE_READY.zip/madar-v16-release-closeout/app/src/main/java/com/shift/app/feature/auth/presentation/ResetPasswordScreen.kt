package com.shift.app.feature.auth.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.ui.theme.*

@Composable
fun ResetPasswordScreen(
    email: String,
    onResetSuccess: () -> Unit,
    vm: AuthViewModel = hiltViewModel()
) {
    var code by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf(false) }

    LaunchedEffect(success) {
        if (success) {
            kotlinx.coroutines.delay(1500)
            onResetSuccess()
        }
    }

    Box(
        Modifier.fillMaxSize().background(BackgroundDark),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("مدار", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                Spacer(Modifier.height(8.dp))
                Text("تعيين كلمة مرور جديدة", fontSize = 18.sp, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text("أدخل الرمز المرسل إلى $email", fontSize = 14.sp, color = TextMuted)
                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { input ->
                        val normalized = input.map { c -> if (c in '٠'..'٩') '0' + (c - '٠') else c }
                            .filter { it.isDigit() }.joinToString("").take(8)
                        code = normalized
                    },
                    label = { Text("رمز الاستعادة (8 أرقام)") },
                    leadingIcon = { Icon(Icons.Default.Lock, null, tint = GoldPrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = GoldPrimary,
                        cursorColor = GoldPrimary,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("كلمة المرور الجديدة") },
                    visualTransformation = PasswordVisualTransformation(),
                    leadingIcon = { Icon(Icons.Default.Lock, null, tint = GoldPrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = GoldPrimary,
                        cursorColor = GoldPrimary,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور") },
                    visualTransformation = PasswordVisualTransformation(),
                    leadingIcon = { Icon(Icons.Default.Lock, null, tint = GoldPrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = TextMuted,
                        focusedLabelColor = GoldPrimary,
                        cursorColor = GoldPrimary,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }

                if (success) {
                    Spacer(Modifier.height(8.dp))
                    Text("✅ تم تغيير كلمة المرور!", color = GoldPrimary, fontSize = 14.sp)
                }

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = {
                        val hasLetter = newPassword.any { it.isLetter() }
                        val hasDigit = newPassword.any { it.isDigit() }
                        if (code.length != 8) {
                            error = "أدخل رمز الاستعادة المكوّن من 8 أرقام"
                        } else if (newPassword.length < 8 || !hasLetter || !hasDigit) {
                            error = "كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي حرفاً ورقماً"
                        } else if (newPassword != confirmPassword) {
                            error = "كلمتا المرور غير متطابقتين"
                        } else {
                            loading = true; error = ""
                            vm.verifyRecoveryOtp(email, code) { ok, msg ->
                                if (!ok) { loading = false; error = msg ?: "رمز غير صحيح أو منتهي الصلاحية" }
                                else vm.updatePassword(newPassword) { ok2 ->
                                    loading = false
                                    if (ok2) success = true
                                    else error = "تعذر حفظ كلمة المرور، حاول مرة أخرى"
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) CircularProgressIndicator(color = BackgroundDark, modifier = Modifier.size(24.dp))
                    else Text("حفظ كلمة المرور", color = BackgroundDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

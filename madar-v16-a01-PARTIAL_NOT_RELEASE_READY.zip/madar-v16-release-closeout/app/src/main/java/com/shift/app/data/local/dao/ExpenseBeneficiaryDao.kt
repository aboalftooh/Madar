package com.shift.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.ExpenseBeneficiary
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseBeneficiaryDao {
    @Query("SELECT * FROM expense_beneficiaries WHERE deletedAt IS NULL ORDER BY name COLLATE NOCASE ASC")
    fun getAll(): Flow<List<ExpenseBeneficiary>>

    @Query("SELECT * FROM expense_beneficiaries")
    suspend fun getAllOnce(): List<ExpenseBeneficiary>

    @Query("SELECT * FROM expense_beneficiaries WHERE deletedAt IS NULL")
    suspend fun getActiveOnce(): List<ExpenseBeneficiary>

    @Query("SELECT * FROM expense_beneficiaries WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ExpenseBeneficiary?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(source: ExpenseBeneficiary)

    @Update
    suspend fun update(source: ExpenseBeneficiary)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ExpenseBeneficiary>)

    @Query("DELETE FROM expense_beneficiaries")
    suspend fun deleteAll()
}

package com.shift.app.ui.theme

import androidx.compose.ui.graphics.Color

// ── Backgrounds ──────────────────────────────────────────
val BackgroundDark   = Color(0xFF05080F)   // أعمق أسود
val SurfaceDark      = Color(0xFF0D1117)   // سطح الكاردات
val SurfaceVariant   = Color(0xFF161C27)   // كارد ثانوي
val SurfaceBright    = Color(0xFF1E2736)   // عناصر مرتفعة

// ── Text ─────────────────────────────────────────────────
val TextPrimary      = Color(0xFFFFFFFF)
val TextSecondary    = Color(0xFFCDD5E0)
val TextMuted        = Color(0xFF6B7A90)

// ── Gold Accent (الذهبي الفاخر) ───────────────────────────
val GoldPrimary      = Color(0xFFFFCC33)   // ذهبي أساسي
val GoldLight        = Color(0xFFFFE57A)   // ذهبي فاتح
val GoldDark         = Color(0xFFB8892A)   // ذهبي غامق
val GoldGlow         = Color(0x33FFD700)   // توهج ذهبي (شفاف)

// ── Accent Colors ─────────────────────────────────────────
val AccentBlue       = Color(0xFFFFCC33)   // استخدام الذهبي بدل الأزرق
val AccentCyan       = Color(0xFFFFE57A)
val IncomeGreen      = Color(0xFF00C896)   // أخضر مشرق
val ExpenseRed       = Color(0xFFFF4757)   // أحمر فاخر
val YellowAccent     = Color(0xFFFFCC33)
val PurpleAccent     = Color(0xFF9D7FEA)
val PinkAccent       = Color(0xFFFF6B9D)
val OrangeAccent     = Color(0xFFFF8C42)
val IndigoAccent     = Color(0xFF6C63FF)

// ── Card Gradients helpers ────────────────────────────────
val CardBorder       = Color(0x40FFD700)   // حدود ذهبية شفافة
val CardGlow         = Color(0x1AFFCC33)   // توهج الكارد

package com.shift.app.data.repository

import com.shift.app.data.local.dao.goals.FinancialChangeOutboxDao
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.domain.goals.evaluation.GoalInvalidationProcessor
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import dagger.Lazy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/** Writes one durable invalidation event for one logical financial operation. */
@Singleton
class FinancialChangePublisher @Inject constructor(
    private val outboxDao: FinancialChangeOutboxDao,
    private val processor: Lazy<GoalInvalidationProcessor>,
) {
    private val processingScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun publish(
        sourceType: String,
        sourceId: String,
        operationId: String,
        effectiveDate: String,
        changedFields: String,
        createdAt: Long = System.currentTimeMillis(),
    ): Boolean {
        val date = runCatching { LocalDate.parse(effectiveDate).toString() }
            .getOrElse { Instant.ofEpochMilli(createdAt).atZone(ZoneOffset.UTC).toLocalDate().toString() }
        val inserted = outboxDao.insert(
            FinancialChangeOutboxEntity(
                eventId = "$sourceType:$operationId",
                sourceType = sourceType,
                sourceId = sourceId,
                operationId = operationId,
                effectiveDate = date,
                changedFields = changedFields,
                createdAt = createdAt,
                processedAt = null,
                attemptCount = 0,
                lastError = null,
            ),
        ) != -1L
        if (inserted) {
            processingScope.launch { processor.get().processPending() }
        }
        return inserted
    }
}

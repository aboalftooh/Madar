package com.shift.app.feature.auth.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.feature.auth.domain.AuthGateway
import com.shift.app.feature.auth.domain.LogoutResult
import com.shift.app.feature.auth.domain.SessionBootstrapper
import com.shift.app.feature.auth.domain.SessionCleanup
import com.shift.app.feature.auth.domain.SessionReader
import com.shift.app.utils.ErrorMessages
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    data object Idle : AuthState()
    data object Loading : AuthState()
    data object Success : AuthState()
    data class Error(val message: String) : AuthState()
}

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authGateway: AuthGateway,
    private val sessionReader: SessionReader,
    private val sessionBootstrapper: SessionBootstrapper,
    private val sessionCleanup: SessionCleanup,
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState = _authState.asStateFlow()

    private val _forgotPasswordState = MutableStateFlow<AuthState>(AuthState.Idle)
    val forgotPasswordState = _forgotPasswordState.asStateFlow()

    val savedEmail = sessionReader.rememberedEmail

    fun login(email: String, password: String, rememberMe: Boolean = false) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                authGateway.signIn(email, password)
                sessionBootstrapper.onLogin(email, rememberMe)
                _authState.value = AuthState.Success
            } catch (error: Exception) {
                _authState.value = AuthState.Error(ErrorMessages.userMessage(error))
            }
        }
    }

    fun register(email: String, password: String, name: String = "", jobTitle: String = "") {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                authGateway.signUp(email, password)
                sessionBootstrapper.onRegistration(name, jobTitle)
                _authState.value = AuthState.Success
            } catch (error: Exception) {
                _authState.value = AuthState.Error(ErrorMessages.userMessage(error))
            }
        }
    }

    fun forgotPassword(email: String) {
        viewModelScope.launch {
            _forgotPasswordState.value = AuthState.Loading
            try {
                authGateway.requestPasswordReset(email)
                _forgotPasswordState.value = AuthState.Success
            } catch (error: Exception) {
                _forgotPasswordState.value = AuthState.Error(ErrorMessages.userMessage(error))
            }
        }
    }

    fun resetForgotPasswordState() {
        _forgotPasswordState.value = AuthState.Idle
    }

    fun updatePassword(newPassword: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            onResult(runCatching { authGateway.updatePassword(newPassword) }.isSuccess)
        }
    }

    fun verifyRecoveryOtp(email: String, code: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            runCatching { authGateway.verifyRecoveryOtp(email, code) }
                .onSuccess { onResult(true, null) }
                .onFailure { onResult(false, ErrorMessages.userMessage(it)) }
        }
    }

    fun logout(onSuccess: () -> Unit = {}, onBlocked: () -> Unit = {}) {
        viewModelScope.launch {
            when (sessionCleanup.logout(discardUnsyncedChanges = false)) {
                LogoutResult.Completed -> onSuccess()
                is LogoutResult.Blocked,
                is LogoutResult.Failed -> onBlocked()
            }
        }
    }

    fun forceLogoutDiscardLocal(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (sessionCleanup.logout(discardUnsyncedChanges = true) is LogoutResult.Completed) {
                onSuccess()
            }
        }
    }

    fun isLoggedIn(): Boolean = sessionReader.isLoggedIn()

    fun resetState() {
        _authState.value = AuthState.Idle
    }
}

package com.shift.app.data.local.dao

import androidx.room.*
import com.shift.app.data.local.entities.Debt
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Debt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(d: Debt)

    @Update
    suspend fun update(d: Debt)

    @Query("SELECT * FROM debts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Debt?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<Debt>)

    @Query("SELECT * FROM debts")
    suspend fun getAllOnce(): List<Debt>

    @Query("DELETE FROM debts")
    suspend fun deleteAll()
}

package com.shift.app.feature.debts.presentation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.debt.DebtDirection
import com.shift.app.domain.debt.DebtTransactionType
import com.shift.app.ui.theme.AccentBlue
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.IncomeGreen
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.SurfaceVariant
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.ui.theme.TextSecondary
import com.shift.app.utils.NumberDisplayFormatter
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID

private enum class DebtSheet {
    CreateOpening,
    CompositeOperation,
    CashIncrease,
    Reduction,
    Settlement,
    Correction,
    Organization,
    Migration
}

internal enum class CompositeMode(val label: String) {
    Cash("أصل نقدي"),
    DeferredExpense("مصروف آجل"),
    AccruedIncome("دخل مستحق"),
    FinancedAsset("أصل ممول"),
    CreditSale("بيع أصل بالأجل")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebtsScreen(
    state: DebtCenterState,
    openCreateSignal: Int = 0,
    onCreateConsumed: () -> Unit = {},
    onEvent: (DebtsUiEvent) -> Unit,
) {
    var activeSheet by remember { mutableStateOf<DebtSheet?>(null) }
    var selectedAccountId by remember { mutableStateOf<String?>(null) }
    val selectedAccount = state.accounts.firstOrNull { it.id == selectedAccountId }

    LaunchedEffect(openCreateSignal) {
        if (openCreateSignal > 0) {
            activeSheet = DebtSheet.CreateOpening
            onCreateConsumed()
        }
    }

    Box(Modifier.fillMaxSize().background(BackgroundDark)) {
        if (selectedAccount == null) {
            DebtCenterContent(
                state = state,
                onSelectAccount = { selectedAccountId = it.id },
                onCreateOpening = { activeSheet = DebtSheet.CreateOpening },
                onComposite = { activeSheet = DebtSheet.CompositeOperation },
                onMigration = { activeSheet = DebtSheet.Migration },
                onEvent = onEvent
            )
        } else {
            DebtDetailsContent(
                state = state,
                account = selectedAccount,
                onBack = { selectedAccountId = null },
                onIncrease = { activeSheet = DebtSheet.CashIncrease },
                onReduce = { activeSheet = DebtSheet.Reduction },
                onSettlement = { activeSheet = DebtSheet.Settlement },
                onCorrection = { activeSheet = DebtSheet.Correction },
                onOrganization = { activeSheet = DebtSheet.Organization }
            )
        }
    }

    when (activeSheet) {
        DebtSheet.CreateOpening -> CreateDebtAccountSheet(
            isSubmitting = state.isSubmitting,
            onDismiss = { activeSheet = null },
            onCreate = { direction, party, amount, dueDate, includeInActivePayoffGoal ->
                onEvent(DebtsUiEvent.CreateOpening(direction, party, amount, dueDate, includeInActivePayoffGoal))
                activeSheet = null
            }
        )
        DebtSheet.CompositeOperation -> CompositeOperationSheet(
            state = state,
            isSubmitting = state.isSubmitting,
            onDismiss = { activeSheet = null },
            onEvent = onEvent
        )
        DebtSheet.CashIncrease -> selectedAccount?.let { account ->
            CashPrincipalSheet(
                account = account,
                isSubmitting = state.isSubmitting,
                onDismiss = { activeSheet = null },
                onSubmit = { amount, source ->
                    onEvent(
                        DebtsUiEvent.RecordCashPrincipal(
                            accountId = account.id,
                            direction = DebtDirection.fromDb(account.directionLabel),
                            partyName = account.partyName,
                            amountDecimal = amount,
                            cashSource = source,
                        )
                    )
                    activeSheet = null
                }
            )
        }
        DebtSheet.Reduction -> selectedAccount?.let { account ->
            ReduceDebtSheet(
                account = account,
                isSubmitting = state.isSubmitting,
                onDismiss = { activeSheet = null },
                onSubmit = { amount, source ->
                    onEvent(DebtsUiEvent.Reduce(account.id, amount, source))
                    activeSheet = null
                }
            )
        }
        DebtSheet.Settlement -> selectedAccount?.let { account ->
            SettlementActionSheet(
                state = state,
                account = account,
                isSubmitting = state.isSubmitting,
                onDismiss = { activeSheet = null },
                onEvent = onEvent
            )
        }
        DebtSheet.Correction -> selectedAccount?.let { account ->
            CorrectionActionSheet(
                account = account,
                timeline = state.timelinesByAccount[account.id].orEmpty(),
                isSubmitting = state.isSubmitting,
                onDismiss = { activeSheet = null },
                onReverse = { originalId, reason ->
                    onEvent(DebtsUiEvent.ReverseTransaction(originalId, reason))
                    activeSheet = null
                }
            )
        }
        DebtSheet.Organization -> selectedAccount?.let { account ->
            OrganizationActionSheet(
                account = account,
                isSubmitting = state.isSubmitting,
                onDismiss = { activeSheet = null },
                onEvent = onEvent
            )
        }
        DebtSheet.Migration -> MigrationReviewSheet(
            state = state,
            onDismiss = { activeSheet = null }
        )
        null -> Unit
    }
}

@Composable
private fun DebtCenterContent(
    state: DebtCenterState,
    onSelectAccount: (DebtAccountUiModel) -> Unit,
    onCreateOpening: () -> Unit,
    onComposite: () -> Unit,
    onMigration: () -> Unit,
    onEvent: (DebtsUiEvent) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "الديون",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.statusBarsPadding()
            )
        }
        item {
            DebtSummaryCard(
                receivable = state.totalReceivableDecimal,
                payable = state.totalPayableDecimal,
                net = state.netDecimal
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onCreateOpening, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) {
                    Text("فتح دين")
                }
                Button(onClick = onComposite, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)) {
                    Text("عملية مركبة", color = BackgroundDark)
                }
            }
        }
        item {
            TextButton(onClick = onMigration) {
                Text("مراجعة ترحيل الديون القديمة (${state.pendingMigrationReviews})", color = GoldPrimary)
            }
        }
        item {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = { onEvent(DebtsUiEvent.SearchChanged(it)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                label = { Text("بحث", color = TextMuted) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DebtCenterTab.entries) { tab ->
                    FilterChip(
                        selected = state.selectedTab == tab,
                        onClick = { onEvent(DebtsUiEvent.TabSelected(tab)) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
        state.errorMessage?.let { message ->
            item { AlertCard(message = message, onDismiss = { onEvent(DebtsUiEvent.ErrorDismissed) }) }
        }
        if (state.visibleAccounts.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("لا توجد حسابات دين في هذا العرض", color = TextMuted)
                }
            }
        }
        items(state.visibleAccounts, key = { it.id }) { account ->
            Box(Modifier.clickable { onSelectAccount(account) }) {
                DebtAccountCard(model = account)
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun DebtDetailsContent(
    state: DebtCenterState,
    account: DebtAccountUiModel,
    onBack: () -> Unit,
    onIncrease: () -> Unit,
    onReduce: () -> Unit,
    onSettlement: () -> Unit,
    onCorrection: () -> Unit,
    onOrganization: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.statusBarsPadding()) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
                }
                Text(account.partyName, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            DebtDetailsScreen(
                account = account,
                timeline = state.timelinesByAccount[account.id].orEmpty(),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onIncrease, modifier = Modifier.weight(1f)) { Text("زيادة") }
                Button(
                    onClick = onReduce,
                    enabled = account.status != "settled" && account.remainingDecimal != "0.00",
                    modifier = Modifier.weight(1f)
                ) { Text(if (account.directionLabel == DebtDirection.Receivable.dbValue) "تحصيل" else "سداد") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSettlement, modifier = Modifier.weight(1f)) { Text("تسوية") }
                Button(onClick = onCorrection, modifier = Modifier.weight(1f)) { Text("عكس") }
                Button(onClick = onOrganization, modifier = Modifier.weight(1f)) { Text("تنظيم") }
            }
        }
    }
}

@Composable
private fun DebtSummaryCard(receivable: String, payable: String, net: String) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Row(
            Modifier.fillMaxWidth().padding(18.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            DebtSummaryItem("لي", receivable, IncomeGreen)
            SummaryDivider()
            DebtSummaryItem("علي", payable, ExpenseRed)
            SummaryDivider()
            DebtSummaryItem("الصافي", net, if (net.startsWith("-")) ExpenseRed else IncomeGreen)
        }
    }
}

@Composable
private fun SummaryDivider() {
    Box(Modifier.height(48.dp).width(1.dp).background(SurfaceVariant))
}

@Composable
private fun DebtSummaryItem(label: String, amount: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 12.sp)
        Text(
            NumberDisplayFormatter.formatDecimalText(amount, useGrouping = true),
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
private fun AlertCard(message: String, onDismiss: () -> Unit) {
    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = ExpenseRed.copy(alpha = 0.16f))) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(message, color = TextPrimary, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("إغلاق", color = TextMuted) }
        }
    }
}

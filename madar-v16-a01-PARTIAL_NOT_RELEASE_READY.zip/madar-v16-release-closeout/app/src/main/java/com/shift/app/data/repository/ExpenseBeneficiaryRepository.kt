package com.shift.app.data.repository

import com.shift.app.data.local.dao.ExpenseBeneficiaryDao
import com.shift.app.data.local.entities.ExpenseBeneficiary
import com.shift.app.domain.finance.SyncState
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ExpenseBeneficiaryRepository @Inject constructor(private val dao: ExpenseBeneficiaryDao) {
    fun getAll(): Flow<List<ExpenseBeneficiary>> = dao.getAll()
    suspend fun getAllOnce(): List<ExpenseBeneficiary> = dao.getAllOnce()
    suspend fun getActiveOnce(): List<ExpenseBeneficiary> = dao.getActiveOnce()
    suspend fun getById(id: String): ExpenseBeneficiary? = dao.getById(id)
    suspend fun insert(source: ExpenseBeneficiary) = dao.insert(source.copy(syncState = SyncState.Pending.dbValue))
    suspend fun update(source: ExpenseBeneficiary) = dao.update(source.copy(syncState = SyncState.Pending.dbValue))
    suspend fun upsertAll(items: List<ExpenseBeneficiary>) = dao.upsertAll(items.map { it.copy(syncState = SyncState.Pending.dbValue) })
    suspend fun deleteAll() = dao.deleteAll()
}

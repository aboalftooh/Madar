package com.shift.app.feature.backup.domain.model

/** Versioned envelope contract for complete application backups. */
data class BackupManifest(
    val applicationId: String,
    val formatVersion: Int,
    val minimumReaderVersion: Int,
    val maximumReaderVersion: Int,
    val databaseSchemaVersion: Int,
    val createdAt: Long,
) {
    init {
        require(applicationId.isNotBlank()) { "Backup application id is missing" }
        require(formatVersion > 0) { "Backup format version must be positive" }
        require(minimumReaderVersion > 0) { "Backup minimum reader version must be positive" }
        require(maximumReaderVersion >= minimumReaderVersion) { "Backup reader range is invalid" }
        require(databaseSchemaVersion > 0) { "Backup database schema version must be positive" }
        require(createdAt >= 0L) { "Backup creation timestamp is invalid" }
    }

    companion object {
        const val APPLICATION_ID = "madar"
        const val CURRENT_FORMAT_VERSION = 2
        const val MIN_SUPPORTED_FORMAT_VERSION = 1
        const val MAX_SUPPORTED_FORMAT_VERSION = 2
        const val CURRENT_DATABASE_SCHEMA_VERSION = 18

        fun current(createdAt: Long): BackupManifest = BackupManifest(
            applicationId = APPLICATION_ID,
            formatVersion = CURRENT_FORMAT_VERSION,
            minimumReaderVersion = CURRENT_FORMAT_VERSION,
            maximumReaderVersion = CURRENT_FORMAT_VERSION,
            databaseSchemaVersion = CURRENT_DATABASE_SCHEMA_VERSION,
            createdAt = createdAt,
        )

        fun legacy(): BackupManifest = BackupManifest(
            applicationId = APPLICATION_ID,
            formatVersion = 1,
            minimumReaderVersion = 1,
            maximumReaderVersion = CURRENT_FORMAT_VERSION,
            databaseSchemaVersion = 17,
            createdAt = 0L,
        )
    }
}

enum class BackupCompatibility {
    COMPATIBLE,
    WRONG_APPLICATION,
    FORMAT_TOO_OLD,
    FORMAT_TOO_NEW,
    READER_TOO_OLD,
    READER_TOO_NEW,
}

fun BackupManifest.compatibility(
    readerVersion: Int = BackupManifest.CURRENT_FORMAT_VERSION,
): BackupCompatibility = when {
    applicationId != BackupManifest.APPLICATION_ID -> BackupCompatibility.WRONG_APPLICATION
    formatVersion < BackupManifest.MIN_SUPPORTED_FORMAT_VERSION -> BackupCompatibility.FORMAT_TOO_OLD
    formatVersion > BackupManifest.MAX_SUPPORTED_FORMAT_VERSION -> BackupCompatibility.FORMAT_TOO_NEW
    readerVersion < minimumReaderVersion -> BackupCompatibility.READER_TOO_OLD
    readerVersion > maximumReaderVersion -> BackupCompatibility.READER_TOO_NEW
    else -> BackupCompatibility.COMPATIBLE
}

enum class BackupImportMode {
    MERGE,
    REPLACE,
}

data class BackupInspection(
    val fingerprint: String,
    val manifest: BackupManifest,
    val compatibility: BackupCompatibility,
    val sectionIds: List<String>,
    val importedRowCount: Int,
    val warnings: List<String> = emptyList(),
)

data class BackupPlanSummary(
    val fingerprint: String,
    val mode: BackupImportMode,
    val importedRowCount: Int,
    val affectedRowCount: Int,
    val deleteCount: Int,
    val sectionCounts: Map<String, Int>,
    val warnings: List<String> = emptyList(),
)

enum class RestoreFailureCode {
    CORRUPT_BACKUP,
    INCOMPATIBLE_BACKUP,
    STALE_INSPECTION,
    SESSION_EXPIRED,
    RESTORE_FAILED,
}

sealed interface RestoreReport {
    data class Success(
        val fingerprint: String,
        val affectedRowCount: Int,
        val sectionCount: Int,
        val syncScheduled: Boolean,
        val warnings: List<String> = emptyList(),
    ) : RestoreReport

    data class Failure(
        val code: RestoreFailureCode,
        val userMessage: String,
        val reference: String,
    ) : RestoreReport
}

open class BackupException(
    message: String,
    cause: Throwable? = null,
) : IllegalArgumentException(message, cause)

class CorruptBackupException(
    message: String = "Backup file is corrupt",
    cause: Throwable? = null,
) : BackupException(message, cause)

class IncompatibleBackupException(
    val manifest: BackupManifest,
    val reason: BackupCompatibility,
) : BackupException("Backup is incompatible: ${reason.name}")

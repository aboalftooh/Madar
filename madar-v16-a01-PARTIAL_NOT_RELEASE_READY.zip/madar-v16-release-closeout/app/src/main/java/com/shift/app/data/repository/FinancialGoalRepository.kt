package com.shift.app.data.repository

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.goals.FinancialChangeOutboxDao
import com.shift.app.data.local.dao.goals.FinancialGoalDao
import com.shift.app.data.local.dao.goals.GoalActivityDao
import com.shift.app.data.local.dao.goals.GoalConditionDao
import com.shift.app.data.local.dao.goals.GoalCostEstimateDao
import com.shift.app.data.local.dao.goals.GoalEvaluationDao
import com.shift.app.data.local.dao.goals.GoalFundingTransactionDao
import com.shift.app.data.local.dao.goals.GoalMetricDao
import com.shift.app.data.local.dao.goals.GoalScopeDao
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.data.local.entities.goals.GoalActivityEntity
import com.shift.app.data.local.entities.goals.GoalConditionEntity
import com.shift.app.data.local.entities.goals.GoalCostEstimateEntity
import com.shift.app.data.local.entities.goals.GoalEvaluationEntity
import com.shift.app.data.local.entities.goals.GoalFundingTransactionEntity
import com.shift.app.data.local.entities.goals.GoalMetricEntity
import com.shift.app.data.local.entities.goals.GoalScopeEntity
import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.domain.goals.funding.AvailableSpendingImpact
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.goals.model.ScopeDimension
import com.shift.app.domain.goals.usecase.GoalLifecycleStateMachine
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

data class FinancialGoalAggregate(
    val goal: FinancialGoalEntity,
    val metrics: List<GoalMetricEntity> = emptyList(),
    val conditions: List<GoalConditionEntity> = emptyList(),
    val scopes: List<GoalScopeEntity> = emptyList(),
    val fundingTransactions: List<GoalFundingTransactionEntity> = emptyList(),
    val costEstimates: List<GoalCostEstimateEntity> = emptyList(),
    val evaluations: List<GoalEvaluationEntity> = emptyList(),
    val activities: List<GoalActivityEntity> = emptyList(),
)

data class ActiveGoalAllocation(
    val fundingTransactionId: String,
    val goalId: String,
    val goalName: String,
    val availableDecimal: String,
)

class GoalRevisionConflictException(goalId: String, expected: Long, actual: Long) :
    IllegalStateException("Goal $goalId revision conflict: expected $expected, actual $actual")

@Singleton
class FinancialGoalRepository @Inject constructor(
    private val database: MadarDatabase,
    private val balanceTransactionDao: BalanceTransactionDao,
    private val goalDao: FinancialGoalDao,
    private val metricDao: GoalMetricDao,
    private val conditionDao: GoalConditionDao,
    private val scopeDao: GoalScopeDao,
    private val fundingDao: GoalFundingTransactionDao,
    private val costDao: GoalCostEstimateDao,
    private val evaluationDao: GoalEvaluationDao,
    private val activityDao: GoalActivityDao,
    private val outboxDao: FinancialChangeOutboxDao,
) : GoalInvalidationGateway {
    suspend fun getAggregate(goalId: String): FinancialGoalAggregate? {
        val goal = goalDao.getById(goalId) ?: return null
        return FinancialGoalAggregate(
            goal = goal,
            metrics = metricDao.getForGoal(goalId),
            conditions = conditionDao.getForGoal(goalId),
            scopes = scopeDao.getForGoal(goalId),
            fundingTransactions = fundingDao.getForGoal(goalId),
            costEstimates = costDao.getForGoal(goalId),
            evaluations = evaluationDao.getForGoal(goalId),
            activities = activityDao.observeForGoal(goalId).first(),
        )
    }

    override suspend fun getLiveAggregates(): List<FinancialGoalAggregate> =
        goalDao.observeActive().first().mapNotNull { getAggregate(it.id) }

    suspend fun createAggregate(
        aggregate: FinancialGoalAggregate,
        operationId: String = "goal-create:${aggregate.goal.id}",
    ) = database.withTransaction {
        require(aggregate.goal.revision == 0L) { "A new goal must start at revision 0" }
        validateOwnedChildren(aggregate)
        goalDao.insert(aggregate.goal)
        metricDao.insertAll(aggregate.metrics)
        conditionDao.insertAll(aggregate.conditions)
        scopeDao.insertAll(aggregate.scopes)
        aggregate.fundingTransactions.forEach { fundingDao.insert(it) }
        aggregate.costEstimates.forEach { costDao.insert(it) }
        aggregate.evaluations.forEach { evaluationDao.insert(it) }
        aggregate.activities.forEach { activityDao.insert(it) }
        insertGoalOutbox(aggregate.goal, operationId, "created")
    }

    /** Replaces the mutable definition while preserving append-only financial/history rows. */
    suspend fun updateAggregate(
        aggregate: FinancialGoalAggregate,
        expectedRevision: Long,
        now: Long,
        operationId: String = "goal-update:${aggregate.goal.id}:${expectedRevision + 1}",
    ): FinancialGoalAggregate = database.withTransaction {
        val current = requireGoalRevision(aggregate.goal.id, expectedRevision)
        require(current.deletedAt == null) { "Cannot update a deleted goal" }
        validateOwnedChildren(aggregate)
        val nextGoal = aggregate.goal.copy(
            revision = expectedRevision + 1,
            createdAt = current.createdAt,
            updatedAt = now,
        )
        goalDao.update(nextGoal)
        replaceMetrics(aggregate.goal.id, aggregate.metrics, now)
        replaceConditions(aggregate.goal.id, aggregate.conditions, now)
        replaceScopes(aggregate.goal.id, aggregate.scopes, now)
        insertGoalOutbox(nextGoal, operationId, "definition")
        aggregate.copy(goal = nextGoal)
    }

    suspend fun softDelete(
        goalId: String,
        expectedRevision: Long,
        now: Long,
        operationId: String = "goal-delete:$goalId:${expectedRevision + 1}",
    ) =
        database.withTransaction {
            val current = requireGoalRevision(goalId, expectedRevision)
            if (current.deletedAt == null) {
                val deleted = current.copy(
                        revision = expectedRevision + 1,
                        updatedAt = now,
                        deletedAt = now,
                        syncState = "PENDING",
                    )
                goalDao.update(deleted)
                insertGoalOutbox(deleted, operationId, "deletedAt")
            }
        }

    suspend fun transition(
        goalId: String,
        expectedRevision: Long,
        to: GoalLifecycleStatus,
        operationId: String,
        now: Long,
        activityType: String,
    ): FinancialGoalEntity = database.withTransaction {
        val current = requireGoalRevision(goalId, expectedRevision)
        GoalLifecycleStateMachine.requireAllowed(current.lifecycleStatus, to)
        val updated = current.copy(
            lifecycleStatus = to,
            revision = current.revision + 1,
            readyAt = if (to == GoalLifecycleStatus.READY) current.readyAt ?: now else current.readyAt,
            completedAt = if (to == GoalLifecycleStatus.COMPLETED) now else current.completedAt,
            cancelledAt = if (to == GoalLifecycleStatus.CANCELLED) now else current.cancelledAt,
            archivedAt = if (to == GoalLifecycleStatus.ARCHIVED) now else current.archivedAt,
            updatedAt = now,
            syncState = "PENDING",
        )
        goalDao.update(updated)
        activityDao.insert(
            GoalActivityEntity(
                id = "$goalId:$operationId:$activityType",
                goalId = goalId,
                operationId = operationId,
                type = activityType,
                occurredAt = now,
                effectiveDate = null,
                detailsJson = "{\"from\":\"${current.lifecycleStatus}\",\"to\":\"$to\"}",
                createdAt = now,
                updatedAt = now,
                deletedAt = null,
                syncState = "PENDING",
            ),
        )
        insertGoalOutbox(updated, operationId, "lifecycleStatus")
        updated
    }

    /** Evaluation, activity, and derived status are committed as one atomic unit. */
    override suspend fun saveEvaluation(
        evaluation: GoalEvaluationEntity,
        activity: GoalActivityEntity,
        expectedRevision: Long,
    ): Boolean = database.withTransaction {
        val current = requireGoalRevision(evaluation.goalId, expectedRevision)
        val inserted = evaluationDao.insert(evaluation) != -1L
        if (inserted) {
            goalDao.update(
                current.copy(
                    lifecycleStatus = evaluation.lifecycleStatus,
                    healthStatus = evaluation.healthStatus,
                    revision = current.revision + 1,
                    readyAt = if (evaluation.lifecycleStatus == GoalLifecycleStatus.READY) {
                        current.readyAt ?: evaluation.asOf
                    } else {
                        current.readyAt
                    },
                    updatedAt = evaluation.updatedAt,
                    syncState = "PENDING",
                ),
            )
            activityDao.insert(activity)
        }
        inserted
    }

    override suspend fun pendingOutbox(limit: Int): List<FinancialChangeOutboxEntity> =
        outboxDao.getPending(limit)

    suspend fun enqueueOutbox(event: FinancialChangeOutboxEntity): Boolean =
        outboxDao.insert(event) != -1L

    suspend fun enqueueFinancialChange(
        sourceType: String,
        sourceId: String,
        operationId: String,
        effectiveDate: String,
        changedFields: String,
        createdAt: Long,
    ): Boolean =
        outboxDao.insert(
            FinancialChangeOutboxEntity(
                eventId = "$sourceType:$operationId",
                sourceType = sourceType,
                sourceId = sourceId,
                operationId = operationId,
                effectiveDate = effectiveDate,
                changedFields = changedFields,
                createdAt = createdAt,
                processedAt = null,
                attemptCount = 0,
                lastError = null,
            ),
        ) != -1L

    suspend fun spendingImpact(expenseAmountDecimal: String): AvailableSpendingImpact =
        database.withTransaction {
            GoalFundingCalculator.spendingImpact(
                balanceTransactionDao.getAllOnce().map { it.toGoalBalanceRow() },
                fundingDao.getAllOnce().map { it.toGoalFundingTransaction() },
                expenseAmountDecimal,
            )
        }

    suspend fun activeAllocationChoices(): List<ActiveGoalAllocation> = database.withTransaction {
        val all = fundingDao.getAllOnce()
        val goalsById = goalDao.observeActive().first().associateBy { it.id }
        all.asSequence()
            .filter { it.deletedAt == null && it.kind == FundingKind.ALLOCATE }
            .mapNotNull { allocation ->
                val remaining = GoalFundingCalculator.remainingForAllocation(allocation.id, all.map { it.toGoalFundingTransaction() })
                if (remaining.signum() <= 0) return@mapNotNull null
                val goal = goalsById[allocation.goalId] ?: return@mapNotNull null
                ActiveGoalAllocation(
                    fundingTransactionId = allocation.id,
                    goalId = goal.id,
                    goalName = goal.name,
                    availableDecimal = remaining.setScale(DecimalTextScale.Money.places).toPlainString(),
                )
            }
            .toList()
    }

    suspend fun releaseAllocationsForOverspend(
        selectedFundingTransactionIds: List<String>,
        shortfallDecimal: String,
        operationId: String,
        balanceTransactionId: String?,
        now: Long,
    ): List<GoalFundingTransactionEntity> = database.withTransaction {
        val shortfall = DecimalText.toBigDecimal(
            DecimalText.canonicalPositive(shortfallDecimal, DecimalTextScale.Money),
        )
        require(selectedFundingTransactionIds.isNotEmpty()) {
            "يجب اختيار تخصيص واحد على الأقل قبل تسجيل مصروف يتجاوز الرصيد المتاح"
        }
        var remaining = shortfall
        val releases = mutableListOf<GoalFundingTransactionEntity>()
        selectedFundingTransactionIds.distinct().forEach { fundingId ->
            if (remaining.signum() <= 0) return@forEach
            val selected = requireNotNull(fundingDao.getById(fundingId)) {
                "Selected funding transaction not found"
            }
            require(selected.deletedAt == null && selected.kind == FundingKind.ALLOCATE) {
                "Selected funding transaction is not an active allocation"
            }
            val availableFromSelection = GoalFundingCalculator.remainingForAllocation(selected.id, fundingDao.getAllOnce().map { it.toGoalFundingTransaction() })
            val releaseAmount = availableFromSelection.min(remaining)
            if (releaseAmount.signum() > 0) {
                releases += recordFundingTransaction(
                    goalId = selected.goalId,
                    operationId = "expense-release:$operationId:${selected.id}",
                    kind = FundingKind.RELEASE,
                    amountDecimal = releaseAmount.setScale(DecimalTextScale.Money.places).toPlainString(),
                    currencyCode = selected.currencyCode,
                    note = "تحرير تخصيص لتسجيل مصروف فوق الرصيد المتاح",
                    now = now,
                    relatedFundingTransactionId = selected.id,
                    balanceTransactionId = balanceTransactionId,
                )
                remaining -= releaseAmount
            }
        }
        releases
    }

    suspend fun recordFundingTransaction(
        goalId: String,
        operationId: String,
        kind: FundingKind,
        amountDecimal: String,
        currencyCode: String,
        note: String,
        now: Long,
        relatedFundingTransactionId: String? = null,
        balanceTransactionId: String? = null,
    ): GoalFundingTransactionEntity = database.withTransaction {
        fundingDao.getByOperationId(operationId)?.let { return@withTransaction it }
        val goal = requireNotNull(goalDao.getById(goalId)) { "Goal $goalId does not exist" }
        require(goal.deletedAt == null) { "Cannot fund a deleted goal" }
        if (kind == FundingKind.RELEASE && goal.type == GoalType.EMERGENCY_FUND) {
            require(note.isNotBlank()) { "سحب صندوق الطوارئ يتطلب سبباً" }
        }
        val allFunding = fundingDao.getAllOnce()
        val goalFunding = allFunding.filter { it.goalId == goalId }
        val currentGoalAllocated = GoalFundingCalculator.allocatedForGoal(goalFunding.map { it.toGoalFundingTransaction() })
        val amount = com.shift.app.domain.finance.DecimalText.canonicalPositive(
            amountDecimal,
            com.shift.app.domain.finance.DecimalTextScale.Money,
        )
        val amountValue = com.shift.app.domain.finance.DecimalText.toBigDecimal(amount)
        when (kind) {
            FundingKind.ALLOCATE -> {
                val realBalance = balanceTransactionDao.getAllOnce()
                require(!GoalFundingCalculator.wouldOverAllocate(realBalance.map { it.toGoalBalanceRow() }, allFunding.map { it.toGoalFundingTransaction() }, amount)) {
                    "لا يمكن تخصيص مبلغ أكبر من الرصيد المتاح"
                }
            }
            FundingKind.RELEASE, FundingKind.CONSUME -> {
                require(currentGoalAllocated >= amountValue) { "لا يمكن سحب مبلغ أكبر من تخصيص الهدف" }
            }
            FundingKind.REVERSAL -> {
                val relatedId = requireNotNull(relatedFundingTransactionId) { "Reversal requires related funding transaction" }
                val related = requireNotNull(fundingDao.getById(relatedId)) { "Related funding transaction does not exist" }
                require(related.goalId == goalId) { "Related funding transaction belongs to another goal" }
                require(related.kind != FundingKind.REVERSAL) { "Cannot reverse a reversal" }
                require(related.amountDecimal == amount) { "Reversal amount must match the related transaction" }
                val alreadyReversed = allFunding.any {
                    it.deletedAt == null &&
                        it.kind == FundingKind.REVERSAL &&
                        it.relatedFundingTransactionId == relatedId
                }
                require(!alreadyReversed) { "Funding transaction has already been reversed" }
            }
        }
        val entity = GoalFundingTransactionEntity(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            operationId = operationId,
            kind = kind,
            amountDecimal = amount,
            currencyCode = currencyCode.ifBlank { goal.currencyCode },
            balanceTransactionId = balanceTransactionId,
            relatedFundingTransactionId = relatedFundingTransactionId,
            note = note,
            occurredAt = now,
            createdAt = now,
            updatedAt = now,
            deletedAt = null,
            syncState = "PENDING",
        )
        fundingDao.insert(entity)
        activityDao.insert(
            GoalActivityEntity(
                id = "$goalId:$operationId:FUNDING_${kind.name}",
                goalId = goalId,
                operationId = operationId,
                type = "FUNDING_${kind.name}",
                occurredAt = now,
                effectiveDate = utcDate(now),
                detailsJson = "{\"kind\":\"${kind.name}\",\"amountDecimal\":\"$amount\"}",
                createdAt = now,
                updatedAt = now,
                deletedAt = null,
                syncState = "PENDING",
            ),
        )
        insertAppendOnlyOutbox(
            sourceType = "goal_funding_transactions",
            sourceId = entity.id,
            operationId = operationId,
            effectiveDate = utcDate(now),
            changedFields = "funding",
            createdAt = now,
        )
        entity
    }

    suspend fun recordCostEstimate(
        goalId: String,
        operationId: String,
        expectedDecimal: String,
        safeDecimal: String,
        currencyCode: String,
        source: String,
        note: String,
        now: Long,
        minDecimal: String? = null,
    ): GoalCostEstimateEntity = database.withTransaction {
        costDao.getForGoal(goalId).firstOrNull { it.operationId == operationId }?.let { return@withTransaction it }
        val goal = requireNotNull(goalDao.getById(goalId)) { "Goal $goalId does not exist" }
        require(goal.deletedAt == null) { "Cannot update cost for a deleted goal" }
        val entity = GoalCostEstimateEntity(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            operationId = operationId,
            minDecimal = minDecimal?.let { DecimalText.canonicalNonNegative(it, DecimalTextScale.Money) },
            expectedDecimal = DecimalText.canonicalPositive(expectedDecimal, DecimalTextScale.Money),
            safeDecimal = DecimalText.canonicalPositive(safeDecimal, DecimalTextScale.Money),
            currencyCode = currencyCode.ifBlank { goal.currencyCode },
            source = source.ifBlank { "manual" },
            note = note,
            effectiveAt = now,
            createdAt = now,
            updatedAt = now,
            deletedAt = null,
            syncState = "PENDING",
        )
        costDao.insert(entity)
        activityDao.insert(
            GoalActivityEntity(
                id = "$goalId:$operationId:COST_ESTIMATE",
                goalId = goalId,
                operationId = operationId,
                type = "COST_ESTIMATE",
                occurredAt = now,
                effectiveDate = utcDate(now),
                detailsJson = "{\"expectedDecimal\":\"${entity.expectedDecimal}\",\"safeDecimal\":\"${entity.safeDecimal}\"}",
                createdAt = now,
                updatedAt = now,
                deletedAt = null,
                syncState = "PENDING",
            ),
        )
        insertAppendOnlyOutbox(
            sourceType = "goal_cost_estimates",
            sourceId = entity.id,
            operationId = operationId,
            effectiveDate = utcDate(now),
            changedFields = "cost",
            createdAt = now,
        )
        entity
    }

    suspend fun recordNewDebtPayoffDecision(
        debtAccountId: String,
        include: Boolean,
        operationId: String,
        now: Long,
    ): List<GoalScopeEntity> = database.withTransaction {
        require(debtAccountId.isNotBlank())
        val activeDebtGoals = goalDao.getAllOnce().filter {
            it.deletedAt == null &&
                it.type == GoalType.DEBT_PAYOFF &&
                it.lifecycleStatus == GoalLifecycleStatus.ACTIVE
        }
        activeDebtGoals.map { goal ->
            val mode = if (include) "INCLUDE" else "EXCLUDE"
            val scopeId = "${goal.id}:scope:debt:$debtAccountId"
            val scope = GoalScopeEntity(
                id = scopeId,
                goalId = goal.id,
                dimension = ScopeDimension.DEBT_ACCOUNT,
                referenceId = debtAccountId,
                mode = mode,
                reason = if (include) "دين جديد أضيف صراحة إلى هدف السداد" else "دين جديد استبعد صراحة من هدف السداد",
                effectiveFrom = utcDate(now),
                effectiveTo = null,
                createdAt = now,
                updatedAt = now,
                deletedAt = null,
                syncState = "PENDING",
            )
            if (!rowExists("goal_scopes", scopeId)) {
                scopeDao.insertAll(listOf(scope))
            } else {
                database.openHelper.writableDatabase.execSQL(
                    """UPDATE goal_scopes SET mode=?, reason=?, effectiveFrom=?, effectiveTo=NULL,
                        updatedAt=?, deletedAt=NULL, syncState='PENDING' WHERE id=? AND goalId=?""".trimIndent(),
                    arrayOf(mode, scope.reason, scope.effectiveFrom, now, scopeId, goal.id),
                )
            }
            val updatedGoal = goal.copy(
                revision = goal.revision + 1,
                updatedAt = now,
                syncState = "PENDING",
            )
            goalDao.update(updatedGoal)
            val goalOperationId = "$operationId:${goal.id}"
            activityDao.insert(
                GoalActivityEntity(
                    id = "${goal.id}:$goalOperationId:DEBT_SCOPE_DECISION",
                    goalId = goal.id,
                    operationId = goalOperationId,
                    type = "DEBT_SCOPE_DECISION",
                    occurredAt = now,
                    effectiveDate = utcDate(now),
                    detailsJson = "{\"debtAccountId\":\"$debtAccountId\",\"decision\":\"$mode\"}",
                    createdAt = now,
                    updatedAt = now,
                    deletedAt = null,
                    syncState = "PENDING",
                ),
            )
            insertGoalOutbox(updatedGoal, goalOperationId, "debtScopeDecision")
            scope
        }
    }

    override suspend fun markOutboxProcessed(eventId: String, processedAt: Long) =
        outboxDao.markProcessed(eventId, processedAt)

    override suspend fun markOutboxFailed(event: FinancialChangeOutboxEntity, error: String) {
        outboxDao.markFailed(event.eventId, error.take(1000))
    }

    private suspend fun requireGoalRevision(id: String, expected: Long): FinancialGoalEntity {
        val current = requireNotNull(goalDao.getById(id)) { "Goal $id does not exist" }
        if (current.revision != expected) {
            throw GoalRevisionConflictException(id, expected, current.revision)
        }
        return current
    }

    private fun validateOwnedChildren(aggregate: FinancialGoalAggregate) {
        val goalId = aggregate.goal.id
        require(aggregate.metrics.all { it.goalId == goalId })
        require(aggregate.conditions.all { it.goalId == goalId })
        require(aggregate.scopes.all { it.goalId == goalId })
        require(aggregate.fundingTransactions.all { it.goalId == goalId })
        require(aggregate.costEstimates.all { it.goalId == goalId })
        require(aggregate.evaluations.all { it.goalId == goalId })
        require(aggregate.activities.all { it.goalId == goalId })
        val metricIds = aggregate.metrics.map { it.id }.toSet()
        require(aggregate.conditions.all { it.metricId == null || it.metricId in metricIds })
    }

    private suspend fun replaceMetrics(goalId: String, incoming: List<GoalMetricEntity>, now: Long) {
        val current = metricDao.getForGoal(goalId).associateBy { it.id }
        markMissingDeleted("goal_metrics", current.keys - incoming.map { it.id }.toSet(), now)
        incoming.forEach { entity ->
            if (!rowExists("goal_metrics", entity.id)) metricDao.insertAll(listOf(entity))
            else database.openHelper.writableDatabase.execSQL(
                """UPDATE goal_metrics SET metricType=?, windowType=?, windowSize=?, baselineDecimal=?,
                    configJson=?, ordinal=?, updatedAt=?, deletedAt=?, syncState=? WHERE id=? AND goalId=?""".trimIndent(),
                arrayOf(entity.metricType.name, entity.windowType, entity.windowSize, entity.baselineDecimal,
                    entity.configJson, entity.ordinal, now, entity.deletedAt, entity.syncState, entity.id, goalId),
            )
        }
    }

    private suspend fun replaceConditions(goalId: String, incoming: List<GoalConditionEntity>, now: Long) {
        val current = conditionDao.getForGoal(goalId).associateBy { it.id }
        markMissingDeleted("goal_conditions", current.keys - incoming.map { it.id }.toSet(), now)
        incoming.forEach { entity ->
            if (!rowExists("goal_conditions", entity.id)) conditionDao.insertAll(listOf(entity))
            else database.openHelper.writableDatabase.execSQL(
                """UPDATE goal_conditions SET metricId=?, kind=?, operator=?, valueDecimal=?, required=?,
                    configJson=?, ordinal=?, updatedAt=?, deletedAt=?, syncState=? WHERE id=? AND goalId=?""".trimIndent(),
                arrayOf(entity.metricId, entity.kind.name, entity.operator, entity.valueDecimal,
                    if (entity.required) 1 else 0, entity.configJson, entity.ordinal, now, entity.deletedAt,
                    entity.syncState, entity.id, goalId),
            )
        }
    }

    private suspend fun replaceScopes(goalId: String, incoming: List<GoalScopeEntity>, now: Long) {
        val current = scopeDao.getForGoal(goalId).associateBy { it.id }
        markMissingDeleted("goal_scopes", current.keys - incoming.map { it.id }.toSet(), now)
        incoming.forEach { entity ->
            if (!rowExists("goal_scopes", entity.id)) scopeDao.insertAll(listOf(entity))
            else database.openHelper.writableDatabase.execSQL(
                """UPDATE goal_scopes SET dimension=?, referenceId=?, mode=?, reason=?, effectiveFrom=?,
                    effectiveTo=?, updatedAt=?, deletedAt=?, syncState=? WHERE id=? AND goalId=?""".trimIndent(),
                arrayOf(entity.dimension.name, entity.referenceId, entity.mode, entity.reason,
                    entity.effectiveFrom, entity.effectiveTo, now, entity.deletedAt, entity.syncState,
                    entity.id, goalId),
            )
        }
    }

    private fun markMissingDeleted(table: String, ids: Set<String>, now: Long) {
        require(table in setOf("goal_metrics", "goal_conditions", "goal_scopes"))
        ids.forEach { id ->
            database.openHelper.writableDatabase.execSQL(
                "UPDATE $table SET deletedAt=?, updatedAt=?, syncState='PENDING' WHERE id=?",
                arrayOf(now, now, id),
            )
        }
    }

    private fun rowExists(table: String, id: String): Boolean {
        require(table in setOf("goal_metrics", "goal_conditions", "goal_scopes"))
        return database.openHelper.readableDatabase.query(
            "SELECT 1 FROM $table WHERE id=? LIMIT 1",
            arrayOf(id),
        ).use { it.moveToFirst() }
    }

    private suspend fun insertGoalOutbox(
        goal: FinancialGoalEntity,
        operationId: String,
        changedFields: String,
    ) {
        require(operationId.isNotBlank())
        outboxDao.insert(
            FinancialChangeOutboxEntity(
                eventId = "goal-event:$operationId",
                sourceType = "financial_goals",
                sourceId = goal.id,
                operationId = operationId,
                effectiveDate = Instant.ofEpochMilli(goal.updatedAt).atZone(ZoneOffset.UTC).toLocalDate().toString(),
                changedFields = changedFields,
                createdAt = goal.updatedAt,
                processedAt = null,
                attemptCount = 0,
                lastError = null,
            ),
        )
    }

    private fun utcDate(epochMillis: Long): String =
        Instant.ofEpochMilli(epochMillis).atZone(ZoneOffset.UTC).toLocalDate().toString()

    private suspend fun insertAppendOnlyOutbox(
        sourceType: String,
        sourceId: String,
        operationId: String,
        effectiveDate: String,
        changedFields: String,
        createdAt: Long,
    ) {
        outboxDao.insert(
            FinancialChangeOutboxEntity(
                eventId = "$sourceType:$operationId",
                sourceType = sourceType,
                sourceId = sourceId,
                operationId = operationId,
                effectiveDate = effectiveDate,
                changedFields = changedFields,
                createdAt = createdAt,
                processedAt = null,
                attemptCount = 0,
                lastError = null,
            ),
        )
    }
}

private fun com.shift.app.data.local.entities.BalanceTransaction.toGoalBalanceRow() = GoalBalanceRow(
    id = id, direction = direction, amountDecimal = amountDecimal, deletedAt = deletedAt,
)

private fun GoalFundingTransactionEntity.toGoalFundingTransaction() = GoalFundingTransaction(
    id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId,
    relatedFundingTransactionId, note, occurredAt, createdAt, updatedAt, deletedAt, syncState,
)

interface GoalInvalidationGateway {
    suspend fun getLiveAggregates(): List<FinancialGoalAggregate>
    suspend fun pendingOutbox(limit: Int): List<FinancialChangeOutboxEntity>
    suspend fun saveEvaluation(
        evaluation: GoalEvaluationEntity,
        activity: GoalActivityEntity,
        expectedRevision: Long,
    ): Boolean
    suspend fun markOutboxProcessed(eventId: String, processedAt: Long)
    suspend fun markOutboxFailed(event: FinancialChangeOutboxEntity, error: String)
}

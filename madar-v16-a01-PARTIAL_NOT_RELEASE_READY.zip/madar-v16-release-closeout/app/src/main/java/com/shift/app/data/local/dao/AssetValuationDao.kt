package com.shift.app.data.local.dao

import androidx.room.*
import com.shift.app.data.local.entities.AssetValuation
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetValuationDao {
    @Query("SELECT * FROM asset_valuations WHERE deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getAll(): Flow<List<AssetValuation>>

    @Query("SELECT * FROM asset_valuations WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    fun getByAssetId(assetId: String): Flow<List<AssetValuation>>

    @Query("SELECT * FROM asset_valuations WHERE assetId = :assetId AND deletedAt IS NULL ORDER BY date DESC, createdAt DESC")
    suspend fun getActiveByAssetIdOnce(assetId: String): List<AssetValuation>

    @Query("SELECT * FROM asset_valuations")
    suspend fun getAllOnce(): List<AssetValuation>

    @Query("SELECT * FROM asset_valuations WHERE operationId = :operationId")
    suspend fun getByOperationId(operationId: String): List<AssetValuation>

    @Query("SELECT * FROM asset_valuations WHERE operationId = :operationId AND deletedAt IS NULL")
    suspend fun getActiveByOperationId(operationId: String): List<AssetValuation>

    @Query("SELECT * FROM asset_valuations WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AssetValuation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: AssetValuation)

    @Update
    suspend fun update(item: AssetValuation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AssetValuation>)

    @Query("DELETE FROM asset_valuations")
    suspend fun deleteAll()
}

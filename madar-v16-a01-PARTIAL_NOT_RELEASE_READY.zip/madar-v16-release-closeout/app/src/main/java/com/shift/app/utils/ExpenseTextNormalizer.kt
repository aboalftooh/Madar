package com.shift.app.utils

import java.util.Locale

object ExpenseTextNormalizer {
    private val whitespace = Regex("\\s+")

    fun displayText(raw: String): String =
        FinanceCalculations.normalizeDigits(raw)
            .trim()
            .replace(whitespace, " ")

    fun key(raw: String): String =
        displayText(raw)
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ى', 'ي')
            .lowercase(Locale.ROOT)
}

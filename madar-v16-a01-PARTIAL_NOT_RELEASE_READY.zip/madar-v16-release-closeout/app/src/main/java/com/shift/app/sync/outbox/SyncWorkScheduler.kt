package com.shift.app.sync.outbox

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.shift.app.data.local.dao.SyncOutboxDao
import com.shift.app.data.local.entities.SyncOutboxEntity
import com.shift.app.sync.SyncQueueGateway
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

@Singleton
class SyncWorkScheduler @Inject constructor(
    @ApplicationContext context: Context,
    private val outboxDao: SyncOutboxDao,
) : SyncQueueGateway {
    override val pendingCount = outboxDao.observePendingCount()
    override val failedCount = outboxDao.observeFailedCount()

    private val workManager = WorkManager.getInstance(context)
    private val networkConstraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    override suspend fun requestSync(
        reason: String,
        operationId: String,
        now: Long,
    ) {
        val safeReason = reason.ifBlank { "local-change" }
        val safeOperationId = operationId.ifBlank { safeReason }
        outboxDao.enqueue(
            SyncOutboxEntity(
                eventId = outboxEventId("manual", safeOperationId),
                entityType = "manual",
                entityId = safeReason,
                operationId = safeOperationId,
                createdAt = now,
                updatedAt = now,
            ),
        )
        enqueueRecovery()
    }

    fun startRecovery(scope: CoroutineScope) {
        enqueueRecovery()
        ensurePeriodicRecovery()
        scope.launch {
            pendingCount
                .distinctUntilChanged()
                .filter { it > 0 }
                .collect { enqueueRecovery() }
        }
    }

    override fun enqueueRecovery() {
        val request = OneTimeWorkRequestBuilder<SyncOutboxWorker>()
            .setConstraints(networkConstraints)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                OUTBOX_MIN_BACKOFF_MS,
                TimeUnit.MILLISECONDS,
            )
            .build()
        workManager.enqueueUniqueWork(
            UNIQUE_IMMEDIATE_WORK,
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            request,
        )
    }

    fun ensurePeriodicRecovery() {
        val request = PeriodicWorkRequestBuilder<SyncOutboxWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraints)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                OUTBOX_MIN_BACKOFF_MS,
                TimeUnit.MILLISECONDS,
            )
            .build()
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    companion object {
        const val UNIQUE_IMMEDIATE_WORK = "madar-sync-outbox-immediate"
        const val UNIQUE_PERIODIC_WORK = "madar-sync-outbox-periodic"
    }
}

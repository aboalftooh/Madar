package com.shift.app.feature.debts.presentation

enum class DebtCenterTab(val label: String) {
    Payables("علي (التزامات)"),
    Receivables("لي (مستحقات)"),
    DueToday("اليوم"),
    Overdue("متأخر"),
    Upcoming("قادم"),
    Settled("مكتمل"),
    NoDate("بلا تاريخ"),
    All("الكل")
}

data class DebtAccountUiModel(
    val id: String,
    val partyName: String,
    val directionLabel: String,
    val remainingDecimal: String,
    val dueDate: String?,
    val status: String,
    val syncState: String,
    val needsReview: Boolean
)

data class DebtTimelineItemUiModel(
    val id: String,
    val title: String,
    val amountDecimal: String,
    val occurredAt: Long,
    val operationId: String
)

data class DebtAssetOptionUiModel(
    val id: String,
    val name: String,
    val valueDecimal: String
)

package com.shift.app.feature.assets.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.shift.app.feature.assets.domain.model.Asset
import com.shift.app.feature.assets.domain.model.AssetTransaction
import com.shift.app.feature.assets.domain.model.AssetValuation
import com.shift.app.feature.assets.domain.model.FOREIGN_CURRENCY_ASSET_TYPE
import com.shift.app.domain.finance.AssetStatus
import com.shift.app.domain.finance.AssetTransactionKind
import com.shift.app.domain.finance.CurrencyAllocationSnapshot
import com.shift.app.domain.finance.CurrencyAssetCalculator
import com.shift.app.domain.finance.CurrencyLotSnapshot
import com.shift.app.ui.theme.BackgroundDark
import com.shift.app.ui.theme.CairoFamily
import com.shift.app.ui.theme.ExpenseRed
import com.shift.app.ui.theme.GoldPrimary
import com.shift.app.ui.theme.SurfaceDark
import com.shift.app.ui.theme.TextMuted
import com.shift.app.ui.theme.TextPrimary
import com.shift.app.utils.NumberDisplayFormatter
import com.shift.app.feature.assets.domain.model.AssetSummary
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun AssetsScreen(
    openEditorSignal: Int = 0,
    onEditorConsumed: () -> Unit = {},
    onBack: () -> Unit = {},
    vm: AssetsViewModel = hiltViewModel(),
    detailsVm: AssetDetailsViewModel = hiltViewModel()
) {
    val summaries by vm.summaries.collectAsState()
    val actionState by vm.actionState.collectAsState()
    val detailsActionState by detailsVm.actionState.collectAsState()
    val details by detailsVm.details.collectAsState()
    var selectedAssetId by remember { mutableStateOf<String?>(null) }
    var createMode by remember { mutableStateOf<AssetCreateMode?>(null) }
    var showCreateChoice by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(openEditorSignal) {
        if (openEditorSignal > 0) {
            showCreateChoice = true
            onEditorConsumed()
        }
    }
    LaunchedEffect(selectedAssetId) { detailsVm.selectAsset(selectedAssetId) }
    ActionSnackbar(actionState, snackbar) { vm.clearActionMessage() }
    ActionSnackbar(detailsActionState, snackbar) { detailsVm.clearActionMessage() }

    Box(Modifier.fillMaxSize().background(BackgroundDark)) {
        if (selectedAssetId == null) {
            AssetList(
                summaries = summaries.filter { it.asset.status in currentAssetStatuses },
                onBack = onBack,
                onAssetClick = { selectedAssetId = it.id },
            )
        } else {
            AssetDetails(
                state = details,
                busy = detailsActionState.busy,
                onBack = { selectedAssetId = null },
                vm = detailsVm
            )
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.TopCenter).padding(16.dp))
        if (actionState.busy || detailsActionState.busy) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = GoldPrimary)
        }
    }

    if (showCreateChoice) {
        AssetCreateChoiceDialog(
            onDismiss = { showCreateChoice = false },
            onPurchase = {
                showCreateChoice = false
                createMode = AssetCreateMode.PURCHASE
            },
            onAddPreexisting = {
                showCreateChoice = false
                createMode = AssetCreateMode.PREEXISTING
            }
        )
    }

    createMode?.let { mode ->
        AssetCreateDialog(
            mode = mode,
            onDismiss = { createMode = null },
            onSave = { name, type, amount, currentValue, date, note, currencyCode, quantity, exchangeRate ->
                if (mode == AssetCreateMode.PREEXISTING) {
                    vm.addPreexistingAsset(name, type, amount, currentValue, date, note)
                } else if (type == FOREIGN_CURRENCY_ASSET_TYPE) {
                    vm.purchaseCurrencyAsset(name, currencyCode, quantity, exchangeRate, amount, date, note)
                } else {
                    vm.purchaseAsset(name, type, amount, date, note)
                }
                createMode = null
            }
        )
    }
}

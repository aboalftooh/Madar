package com.shift.app.feature.debts.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DebtDetailsScreen(
    account: DebtAccountUiModel,
    timeline: List<DebtTimelineItemUiModel>,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(account.partyName)
        Text(account.remainingDecimal)
        timeline.forEach { item ->
            Text("${item.title}: ${item.amountDecimal}")
        }
    }
}

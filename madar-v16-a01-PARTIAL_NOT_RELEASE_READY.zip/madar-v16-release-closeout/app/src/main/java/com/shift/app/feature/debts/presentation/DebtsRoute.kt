package com.shift.app.feature.debts.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun DebtsRoute(
    openCreateSignal: Int = 0,
    onCreateConsumed: () -> Unit = {},
    viewModel: DebtsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    DebtsScreen(
        state = state,
        openCreateSignal = openCreateSignal,
        onCreateConsumed = onCreateConsumed,
        onEvent = viewModel::onEvent,
    )
}

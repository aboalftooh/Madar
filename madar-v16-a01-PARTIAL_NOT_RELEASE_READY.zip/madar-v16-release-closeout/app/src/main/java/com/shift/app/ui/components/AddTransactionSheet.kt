package com.shift.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.data.local.entities.IncomeSource
import com.shift.app.data.local.entities.Transaction
import com.shift.app.ui.theme.*
import com.shift.app.utils.ExpenseTextNormalizer
import com.shift.app.utils.FinancialInput
import com.shift.app.utils.FinanceCalculations
import com.shift.app.viewmodel.TransactionsViewModel
import java.time.LocalDate
import kotlinx.coroutines.launch


@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AddTransactionSheet(
    vm: TransactionsViewModel,
    editItem: Transaction? = null,
    initialType: String = editItem?.type ?: "expense",
    onDismiss: () -> Unit
) {
    val incomeSources by vm.incomeSources.collectAsState()
    val expenseBeneficiaries by vm.expenseBeneficiaries.collectAsState()
    val purposeSuggestions by vm.expensePurposeSuggestions.collectAsState()
    val allocationDecision by vm.expenseAllocationDecision.collectAsState()
    val focusManager  = LocalFocusManager.current
    val isEdit        = editItem != null
    val scope         = rememberCoroutineScope()
    val type          = remember(editItem, initialType) { editItem?.type ?: initialType }
    val dialogTitle   = when {
        isEdit && type == "income" -> "تعديل دخل"
        isEdit -> "تعديل مصروف"
        type == "income" -> "إضافة دخل"
        else -> "إضافة مصروف"
    }

    var amount   by remember { mutableStateOf(editItem?.amount?.toInt()?.toString() ?: "") }
    var date     by remember { mutableStateOf(editItem?.date     ?: LocalDate.now().toString()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    var note     by remember { mutableStateOf(editItem?.note     ?: "") }
    var amountError by remember { mutableStateOf("") }
    var sourceError by remember { mutableStateOf("") }
    var purposeError by remember { mutableStateOf("") }
    var selectedIncomeSourceId by remember(editItem) { mutableStateOf(editItem?.incomeSourceId) }
    var incomeSourceName by remember(editItem) {
        mutableStateOf(editItem?.incomeSourceNameSnapshot ?: editItem?.category ?: "")
    }
    var incomeSourceExpanded by remember { mutableStateOf(false) }
    var beneficiaryName by remember(editItem) {
        mutableStateOf(editItem?.expenseBeneficiaryNameSnapshot.orEmpty())
    }
    var selectedExpenseBeneficiaryId by remember(editItem) {
        mutableStateOf(editItem?.expenseBeneficiaryId)
    }
    var beneficiaryExpanded by remember { mutableStateOf(false) }
    var showAddBeneficiary by remember { mutableStateOf(false) }
    var newBeneficiaryInput by remember { mutableStateOf("") }
    var purpose by remember(editItem) {
        mutableStateOf(editItem?.purpose?.ifBlank { editItem.category }.orEmpty())
    }
    var purposeExpanded by remember { mutableStateOf(false) }
    var selectedAllocationIds by remember { mutableStateOf(emptySet<String>()) }
    LaunchedEffect(allocationDecision) {
        selectedAllocationIds = emptySet()
    }

    val categoryFocus = remember { FocusRequester() }
    val amountFocus   = remember { FocusRequester() }
    val noteFocus     = remember { FocusRequester() }

    val categoryBiv = remember { BringIntoViewRequester() }
    val amountBiv   = remember { BringIntoViewRequester() }
    val noteBiv     = remember { BringIntoViewRequester() }

    val selectedIncomeSource = remember(incomeSources, selectedIncomeSourceId) {
        incomeSources.firstOrNull { it.id == selectedIncomeSourceId }
    }
    val matchingIncomeSource = remember(incomeSources, incomeSourceName, selectedIncomeSourceId) {
        incomeSources.firstOrNull { it.id == selectedIncomeSourceId }
            ?.takeIf { normalizeIncomeSourceName(it.name).equals(normalizeIncomeSourceName(incomeSourceName), ignoreCase = true) }
            ?: incomeSources.firstOrNull {
                normalizeIncomeSourceName(it.name).equals(normalizeIncomeSourceName(incomeSourceName), ignoreCase = true)
            }
    }
    val selectedExpenseBeneficiary = remember(expenseBeneficiaries, selectedExpenseBeneficiaryId) {
        expenseBeneficiaries.firstOrNull { it.id == selectedExpenseBeneficiaryId }
    }
    val matchingExpenseBeneficiary = remember(
        expenseBeneficiaries,
        beneficiaryName,
        selectedExpenseBeneficiaryId
    ) {
        val beneficiaryKey = ExpenseTextNormalizer.key(beneficiaryName)
        expenseBeneficiaries.firstOrNull { it.id == selectedExpenseBeneficiaryId }
            ?.takeIf { ExpenseTextNormalizer.key(it.name) == beneficiaryKey }
            ?: expenseBeneficiaries.firstOrNull { ExpenseTextNormalizer.key(it.name) == beneficiaryKey }
    }
    val filteredPurposeSuggestions = remember(purposeSuggestions, purpose) {
        val queryKey = ExpenseTextNormalizer.key(purpose)
        purposeSuggestions
            .filter { suggestion ->
                val suggestionKey = ExpenseTextNormalizer.key(suggestion)
                queryKey.isBlank() || suggestionKey.contains(queryKey)
            }
            .distinctBy { ExpenseTextNormalizer.key(it) }
            .take(6)
    }

    val onSave = {
        val amt = FinanceCalculations.parseLocalizedDouble(amount)
        amountError = when {
            amt == null || amt <= 0 -> "أدخل مبلغاً صحيحاً"
            amt > 10_000_000 -> "الحد الأقصى للمبلغ هو 10,000,000"
            else -> ""
        }
        val normalizedSourceName = normalizeIncomeSourceName(incomeSourceName)
        sourceError = if (type == "income" && normalizedSourceName.isBlank()) "أدخل مصدر الدخل" else ""
        val normalizedPurpose = ExpenseTextNormalizer.displayText(purpose)
        purposeError = if (type == "expense" && normalizedPurpose.isBlank()) "أدخل الغرض" else ""
        if (amountError.isBlank() && sourceError.isBlank() && purposeError.isBlank()) {
            val tx = Transaction(
                id       = editItem?.id ?: java.util.UUID.randomUUID().toString(),
                type     = type,
                amount   = amt!!,
                category = if (type == "income") normalizedSourceName else normalizedPurpose,
                date     = date,
                note     = note,
                group    = "",
                incomeSourceId = if (type == "income") matchingIncomeSource?.id else null,
                incomeSourceNameSnapshot = if (type == "income") matchingIncomeSource?.name ?: normalizedSourceName else "",
                paymentMethodSnapshot = if (type == "income") matchingIncomeSource?.paymentMethod.orEmpty() else ""
            )
            if (type == "income" && !isEdit) {
                vm.addIncomeTransactionWithSource(tx, normalizedSourceName, onComplete = onDismiss)
            } else if (!isEdit) {
                vm.addExpenseTransactionWithBeneficiary(
                    tx,
                    beneficiaryName,
                    normalizedPurpose,
                    onComplete = onDismiss
                )
            } else {
                if (type == "income" && matchingIncomeSource == null) {
                    vm.addIncomeSourceIfMissing(normalizedSourceName) { source ->
                        vm.updateTransaction(tx.withIncomeSource(source))
                        onDismiss()
                    }
                } else {
                    val updatedTx = if (type == "expense") {
                        tx.copy(
                            type = "expense",
                            purpose = normalizedPurpose,
                            purposeKey = ExpenseTextNormalizer.key(normalizedPurpose),
                            category = normalizedPurpose,
                            group = "",
                            expenseBeneficiaryId = matchingExpenseBeneficiary?.id,
                            expenseBeneficiaryNameSnapshot = matchingExpenseBeneficiary?.name
                                ?: ExpenseTextNormalizer.displayText(beneficiaryName),
                            incomeSourceId = null,
                            incomeSourceNameSnapshot = "",
                            paymentMethodSnapshot = ""
                        )
                    } else {
                        tx
                    }
                    vm.updateTransaction(updatedTx)
                    onDismiss()
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceDark,
        shape            = RoundedCornerShape(24.dp),
        title = {
            Text(
                dialogTitle,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(top = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ── الفئة ───────────────────────────────────────────────────
            if (type == "income") {
                ExposedDropdownMenuBox(
                    expanded = incomeSourceExpanded,
                    onExpandedChange = { incomeSourceExpanded = it }
                ) {
                    OutlinedTextField(
                        value = incomeSourceName,
                        onValueChange = { value ->
                            incomeSourceName = value
                            sourceError = ""
                            val selected = selectedIncomeSource
                            if (
                                selected != null &&
                                !normalizeIncomeSourceName(selected.name).equals(
                                    normalizeIncomeSourceName(value),
                                    ignoreCase = true
                                )
                            ) {
                                selectedIncomeSourceId = null
                            }
                        },
                        label = { Text("مصدر الدخل", color = TextMuted) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(incomeSourceExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = transactionTextFieldColors(),
                        isError = sourceError.isNotBlank(),
                        supportingText = if (sourceError.isNotBlank()) {{ Text(sourceError) }} else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { amountFocus.requestFocus() })
                    )
                    ExposedDropdownMenu(
                        expanded = incomeSourceExpanded,
                        onDismissRequest = { incomeSourceExpanded = false }
                    ) {
                        incomeSources.forEach { source ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(source.name, color = TextPrimary)
                                        if (source.paymentMethod.isNotBlank()) {
                                            Text(source.paymentMethod, color = TextMuted, fontSize = 11.sp)
                                        }
                                    }
                                },
                                onClick = {
                                    selectedIncomeSourceId = source.id
                                    incomeSourceName = source.name
                                    sourceError = ""
                                    incomeSourceExpanded = false
                                }
                            )
                        }
                    }
                }
                matchingIncomeSource?.takeIf { it.paymentMethod.isNotBlank() }?.let { source ->
                    OutlinedTextField(
                        value = source.paymentMethod,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("طريقة الدفع", color = TextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = transactionTextFieldColors()
                    )
                }
            } else {
                ExposedDropdownMenuBox(
                    expanded = beneficiaryExpanded,
                    onExpandedChange = { beneficiaryExpanded = it }
                ) {
                    OutlinedTextField(
                        value = beneficiaryName,
                        onValueChange = { value ->
                            beneficiaryName = value
                            val selected = selectedExpenseBeneficiary
                            if (
                                selected != null &&
                                ExpenseTextNormalizer.key(selected.name) != ExpenseTextNormalizer.key(value)
                            ) {
                                selectedExpenseBeneficiaryId = null
                            }
                        },
                        label = { Text("المستفيد", color = TextMuted) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(beneficiaryExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .focusRequester(categoryFocus)
                            .bringIntoViewRequester(categoryBiv)
                            .onFocusChanged { if (it.isFocused) scope.launch { categoryBiv.bringIntoView() } },
                        colors = transactionTextFieldColors(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { amountFocus.requestFocus() })
                    )
                    ExposedDropdownMenu(
                        expanded = beneficiaryExpanded,
                        onDismissRequest = { beneficiaryExpanded = false }
                    ) {
                        expenseBeneficiaries.forEach { beneficiary ->
                            DropdownMenuItem(
                                text = { Text(beneficiary.name, color = TextPrimary) },
                                onClick = {
                                    selectedExpenseBeneficiaryId = beneficiary.id
                                    beneficiaryName = beneficiary.name
                                    beneficiaryExpanded = false
                                }
                            )
                        }
                        HorizontalDivider(color = SurfaceVariant)
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(16.dp))
                                    Text("إضافة مستفيد", color = AccentBlue)
                                }
                            },
                            onClick = { showAddBeneficiary = true; beneficiaryExpanded = false }
                        )
                    }
                }

                ExposedDropdownMenuBox(
                    expanded = purposeExpanded && filteredPurposeSuggestions.isNotEmpty(),
                    onExpandedChange = { purposeExpanded = it }
                ) {
                    OutlinedTextField(
                        value = purpose,
                        onValueChange = {
                            purpose = it
                            purposeError = ""
                            purposeExpanded = true
                        },
                        label = { Text("الغرض", color = TextMuted) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(purposeExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = transactionTextFieldColors(),
                        isError = purposeError.isNotBlank(),
                        supportingText = if (purposeError.isNotBlank()) {{ Text(purposeError) }} else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { amountFocus.requestFocus() })
                    )
                    ExposedDropdownMenu(
                        expanded = purposeExpanded && filteredPurposeSuggestions.isNotEmpty(),
                        onDismissRequest = { purposeExpanded = false }
                    ) {
                        filteredPurposeSuggestions.forEach { suggestion ->
                            DropdownMenuItem(
                                text = { Text(suggestion, color = TextPrimary) },
                                onClick = {
                                    purpose = suggestion
                                    purposeError = ""
                                    purposeExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // ── المبلغ ─────────────────────────────────────────────────────
            OutlinedTextField(
                value          = amount,
                onValueChange  = { amount = FinancialInput.englishDigitsOnly(it) },
                label          = { Text("المبلغ", color = TextMuted) },
                modifier       = Modifier
                    .fillMaxWidth()
                    .focusRequester(amountFocus)
                    .bringIntoViewRequester(amountBiv)
                    .onFocusChanged { if (it.isFocused) scope.launch { amountBiv.bringIntoView() } },
                colors          = transactionTextFieldColors(),
                isError = amountError.isNotBlank(),
                supportingText = if (amountError.isNotBlank()) {{ Text(amountError) }} else null,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction    = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(onNext = { noteFocus.requestFocus() })
            )

            // ── التاريخ ──────────────────────────────────────────────────
            OutlinedTextField(
                value          = date,
                onValueChange  = { },
                readOnly       = true,
                label          = { Text("التاريخ", color = TextMuted) },
                trailingIcon   = {
                    IconButton(onClick = { showDatePicker = true }) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Default.DateRange,
                            contentDescription = "اختر التاريخ",
                            tint = TextMuted
                        )
                    }
                    if (showDatePicker) {
                        DatePickerDialog(
                            onDismissRequest = { showDatePicker = false },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        datePickerState.selectedDateMillis?.let { millis ->
                                            val selectedDate = java.time.Instant.ofEpochMilli(millis)
                                                .atZone(java.time.ZoneId.of("UTC"))
                                                .toLocalDate()
                                            date = selectedDate.toString()
                                        }
                                        showDatePicker = false
                                    }
                                ) {
                                    Text("موافق", color = AccentBlue)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showDatePicker = false }) {
                                    Text("إلغاء", color = TextMuted)
                                }
                            },
                            colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
                        ) {
                            DatePicker(state = datePickerState)
                        }
                    }
                },
                modifier       = Modifier.fillMaxWidth(),
                colors         = transactionTextFieldColors()
            )

            // ── ملاحظة ───────────────────────────────────────────────────
            OutlinedTextField(
                value          = note,
                onValueChange  = { note = it },
                label          = { Text("ملاحظة (اختياري)", color = TextMuted) },
                modifier       = Modifier
                    .fillMaxWidth()
                    .focusRequester(noteFocus)
                    .bringIntoViewRequester(noteBiv)
                    .onFocusChanged { if (it.isFocused) scope.launch { noteBiv.bringIntoView() } },
                colors          = transactionTextFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); onSave() })
            )

            Button(
                onClick  = { onSave() },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) { Text(if (isEdit) "حفظ التعديل" else "إضافة", fontWeight = FontWeight.Bold) }
        }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextMuted)
            }
        }
    )

    if (showAddBeneficiary) {
        AlertDialog(
            onDismissRequest = { showAddBeneficiary = false; newBeneficiaryInput = "" },
            containerColor   = SurfaceDark,
            title = { Text("مستفيد جديد", color = AccentCyan, fontWeight = FontWeight.Bold) },
            text  = {
                OutlinedTextField(
                    value         = newBeneficiaryInput,
                    onValueChange = { newBeneficiaryInput = it },
                    label         = { Text("اسم المستفيد", color = TextMuted) },
                    colors        = transactionTextFieldColors()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newBeneficiaryInput.isNotBlank()) {
                            vm.addExpenseBeneficiaryIfMissing(newBeneficiaryInput) { beneficiary ->
                                selectedExpenseBeneficiaryId = beneficiary.id
                                beneficiaryName = beneficiary.name
                                newBeneficiaryInput = ""
                                showAddBeneficiary = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                ) { Text("حفظ") }
            },
            dismissButton = {
                TextButton(onClick = { showAddBeneficiary = false; newBeneficiaryInput = "" }) {
                    Text("إلغاء", color = TextMuted)
                }
            }
        )
    }

    allocationDecision?.let { decision ->
        AlertDialog(
            onDismissRequest = vm::cancelExpenseAllocationDecision,
            containerColor = SurfaceDark,
            title = { Text("المصروف يتجاوز الرصيد المتاح", color = ExpenseRed, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "المتاح حاليًا ${decision.availableBeforeDecimal}، والتجاوز ${decision.shortfallDecimal}. " +
                            "اختر التخصيصات التي تريد تحريرها، أو سجّل الواقع دون تحرير وسيصبح المتاح سالبًا.",
                        color = TextPrimary,
                    )
                    decision.allocations.forEach { allocation ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedAllocationIds = if (allocation.fundingTransactionId in selectedAllocationIds) {
                                        selectedAllocationIds - allocation.fundingTransactionId
                                    } else {
                                        selectedAllocationIds + allocation.fundingTransactionId
                                    }
                                },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = allocation.fundingTransactionId in selectedAllocationIds,
                                onCheckedChange = { checked ->
                                    selectedAllocationIds = if (checked) {
                                        selectedAllocationIds + allocation.fundingTransactionId
                                    } else {
                                        selectedAllocationIds - allocation.fundingTransactionId
                                    }
                                },
                            )
                            Column {
                                Text(allocation.goalName, color = TextPrimary)
                                Text("متاح للتحرير: ${allocation.availableDecimal}", color = TextMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { vm.confirmExpenseAllocationDecision(selectedAllocationIds) },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                ) {
                    Text(if (selectedAllocationIds.isEmpty()) "تسجيل دون تحرير" else "تحرير المحدد والتسجيل")
                }
            },
            dismissButton = {
                TextButton(onClick = vm::cancelExpenseAllocationDecision) {
                    Text("إلغاء العملية", color = TextMuted)
                }
            },
        )
    }

}

private fun Transaction.withIncomeSource(source: IncomeSource): Transaction = copy(
    type = "income",
    category = source.name,
    group = "",
    incomeSourceId = source.id,
    incomeSourceNameSnapshot = source.name,
    paymentMethodSnapshot = source.paymentMethod
)

private fun normalizeIncomeSourceName(name: String): String =
    name.trim().replace(Regex("\\s+"), " ")

@Composable
private fun transactionTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor     = TextPrimary,
    unfocusedTextColor   = TextPrimary,
    focusedBorderColor   = GoldPrimary,
    unfocusedBorderColor = GoldPrimary.copy(alpha = 0.45f),
    errorBorderColor     = ExpenseRed,
    disabledBorderColor  = SurfaceVariant,
    focusedLabelColor    = GoldLight,
    unfocusedLabelColor  = TextMuted,
    cursorColor          = GoldPrimary
)

@Composable
fun shiftTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor     = TextPrimary,
    unfocusedTextColor   = TextPrimary,
    focusedBorderColor   = AccentBlue,
    unfocusedBorderColor = SurfaceVariant,
    cursorColor          = AccentBlue
)

package com.shift.app.feature.backup.domain.repository

import com.shift.app.feature.backup.domain.model.BackupInspection
import com.shift.app.feature.backup.domain.model.BackupImportMode
import com.shift.app.feature.backup.domain.model.BackupPlanSummary
import com.shift.app.feature.backup.domain.model.RestoreReport

interface BackupGateway {
    suspend fun exportJson(): String
    suspend fun inspect(sourceJson: String): BackupInspection
    suspend fun plan(sourceJson: String, mode: BackupImportMode): BackupPlanSummary
    suspend fun restore(sourceJson: String, mode: BackupImportMode): RestoreReport
}

package com.shift.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.shift.app.navigation.MadarNavGraph
import com.shift.app.ui.theme.MadarTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private var lockNonce by mutableIntStateOf(0)
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()

        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> stoppedAt = System.currentTimeMillis()
                Lifecycle.Event.ON_START -> {
                    val awayFor = if (stoppedAt == 0L) 0L else System.currentTimeMillis() - stoppedAt
                    if (awayFor > 30_000L) lockNonce++
                    stoppedAt = 0L
                }
                else -> Unit
            }
        })

        setContent {
            MadarTheme {
                MadarNavGraph(lockNonce = lockNonce)
            }
        }
    }
}

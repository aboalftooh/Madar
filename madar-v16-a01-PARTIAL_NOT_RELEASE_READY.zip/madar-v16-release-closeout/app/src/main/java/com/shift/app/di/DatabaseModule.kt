package com.shift.app.di

import android.content.Context
import android.util.Base64
import androidx.room.Room
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.sync.SyncOutboxSchema
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.security.SecureRandom
import javax.inject.Singleton
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MadarDatabase {
        System.loadLibrary("sqlcipher")
        val factory = SupportOpenHelperFactory(databasePassphrase(context))
        return Room.databaseBuilder(context, MadarDatabase::class.java, "madar.db")
            .openHelperFactory(factory)
            .addMigrations(*MadarDatabase.ALL_MIGRATIONS)
            .addCallback(SyncOutboxSchema.callback)
            .build()
    }

    private fun databasePassphrase(context: Context): ByteArray {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        val preferences = EncryptedSharedPreferences.create(
            "shift_secure_prefs",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
        val key = "db_pass"
        val existing = preferences.getString(key, null)
        if (existing != null) return Base64.decode(existing, Base64.DEFAULT)

        val generated = ByteArray(32).also(SecureRandom()::nextBytes)
        preferences.edit()
            .putString(key, Base64.encodeToString(generated, Base64.DEFAULT))
            .apply()
        return generated
    }
}

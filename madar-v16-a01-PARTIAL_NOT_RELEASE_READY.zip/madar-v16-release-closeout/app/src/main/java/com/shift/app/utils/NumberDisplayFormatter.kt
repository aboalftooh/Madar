package com.shift.app.utils

import java.math.BigDecimal

/**
 * The single formatter for numbers shown to the user.
 *
 * It never changes the stored value or rounds it: it only removes trailing fractional zeroes
 * and optionally adds grouping separators to the integer part.
 */
object NumberDisplayFormatter {
    fun format(value: BigDecimal, useGrouping: Boolean = false): String {
        val normalized = if (value.compareTo(BigDecimal.ZERO) == 0) {
            BigDecimal.ZERO
        } else {
            value.stripTrailingZeros()
        }
        val plain = normalized.toPlainString()
        return if (useGrouping) groupIntegerPart(plain) else plain
    }

    fun format(value: Double, useGrouping: Boolean = false): String =
        format(BigDecimal.valueOf(value), useGrouping)

    fun format(value: Float, useGrouping: Boolean = false): String =
        format(BigDecimal(value.toString()), useGrouping)

    fun format(value: Int, useGrouping: Boolean = false): String =
        format(BigDecimal(value), useGrouping)

    fun format(value: Long, useGrouping: Boolean = false): String =
        format(BigDecimal(value), useGrouping)

    fun formatDecimalText(
        value: String,
        useGrouping: Boolean = false,
        absolute: Boolean = false
    ): String {
        val parsed = value.trim().toBigDecimalOrNull() ?: return value
        return format(if (absolute) parsed.abs() else parsed, useGrouping)
    }

    private fun groupIntegerPart(value: String): String {
        val sign = value.takeIf { it.startsWith('-') }?.let { "-" }.orEmpty()
        val unsigned = value.removePrefix("-")
        val integer = unsigned.substringBefore('.')
        val fraction = unsigned.substringAfter('.', missingDelimiterValue = "")
        val groupedInteger = integer
            .reversed()
            .chunked(3)
            .joinToString(",")
            .reversed()
        return buildString {
            append(sign)
            append(groupedInteger)
            if (fraction.isNotEmpty()) {
                append('.')
                append(fraction)
            }
        }
    }
}

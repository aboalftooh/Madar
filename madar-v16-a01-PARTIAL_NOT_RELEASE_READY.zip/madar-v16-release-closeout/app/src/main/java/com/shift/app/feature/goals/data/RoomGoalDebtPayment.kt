package com.shift.app.feature.goals.data

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.repository.DebtLedgerRepository
import com.shift.app.data.repository.FinancialGoalRepository
import com.shift.app.domain.debt.DebtCashSource
import com.shift.app.domain.goals.measurement.DebtPayoffMeasurementProvider
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.first
import com.shift.app.domain.goals.usecase.GoalDebtPaymentRequest
import com.shift.app.feature.goals.domain.model.GoalDebtAccountRow
import com.shift.app.feature.goals.domain.model.GoalDebtTransactionRow

internal class RoomGoalDebtPayment @Inject constructor(
    private val database: MadarDatabase,
    private val goalRepository: FinancialGoalRepository,
    private val debtLedgerRepository: DebtLedgerRepository,
) {
    suspend fun record(request: GoalDebtPaymentRequest) = database.withTransaction {
        val entityAggregate = requireNotNull(goalRepository.getAggregate(request.goalId)) { "Goal not found" }
        val aggregate = entityAggregate.toDomain()
        require(aggregate.goal.type == GoalType.DEBT_PAYOFF)
        require(aggregate.goal.lifecycleStatus in setOf(GoalLifecycleStatus.ACTIVE, GoalLifecycleStatus.READY))
        val records = debtLedgerRepository.recordReduction(
            operationId = request.operationId,
            accountId = request.accountId,
            amountDecimal = request.amountDecimal,
            cashSource = if (request.fromMadarBalance) DebtCashSource.MadarBalance else DebtCashSource.External,
            occurredAt = request.occurredAt,
        )
        if (request.completeGoalWhenPaidOff) {
            val measured = DebtPayoffMeasurementProvider.measureDebt(
                metric = aggregate.metrics.single { it.metricType == com.shift.app.domain.goals.model.MetricType.DEBT_BALANCE },
                aggregate = aggregate,
                accounts = database.debtAccountDao().getActiveAccounts().first().map { GoalDebtAccountRow(it.id, it.direction, it.confirmed, it.createdAt, it.deletedAt) },
                transactions = database.debtTransactionDao().getActiveTransactions().first().map { GoalDebtTransactionRow(it.accountId, it.type, it.amountDecimal, it.occurredAt, it.deletedAt) },
            )
            require(measured.measuredDecimal == "0.00") {
                "لا يمكن إكمال هدف سداد الدين قبل سداد جميع الديون الواقعة في نطاقه"
            }
            var current = requireNotNull(goalRepository.getAggregate(request.goalId)).goal
            if (current.lifecycleStatus == GoalLifecycleStatus.ACTIVE) {
                current = goalRepository.transition(
                    goalId = current.id,
                    expectedRevision = current.revision,
                    to = GoalLifecycleStatus.READY,
                    operationId = "${request.operationId}:ready",
                    now = request.occurredAt,
                    activityType = "DEBT_PAYOFF_READY",
                )
            }
            goalRepository.transition(
                goalId = current.id,
                expectedRevision = current.revision,
                to = GoalLifecycleStatus.COMPLETED,
                operationId = request.operationId,
                now = request.occurredAt,
                activityType = "DEBT_PAYOFF_COMPLETED",
            )
        }
        records
    }
}

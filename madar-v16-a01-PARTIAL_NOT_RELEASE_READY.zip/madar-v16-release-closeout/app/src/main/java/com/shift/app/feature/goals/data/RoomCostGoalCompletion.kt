package com.shift.app.feature.goals.data

import androidx.room.withTransaction
import com.shift.app.data.local.MadarDatabase
import com.shift.app.data.local.dao.BalanceTransactionDao
import com.shift.app.data.local.dao.PaymentDao
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.entities.Payment
import com.shift.app.data.repository.AssetRepository
import com.shift.app.data.repository.FinancialGoalRepository
import com.shift.app.feature.assets.domain.model.PurchaseAssetRequest
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import java.util.UUID
import javax.inject.Inject
import com.shift.app.domain.goals.usecase.CompleteCostGoalRequest
import com.shift.app.domain.goals.usecase.CostGoalCompletionMode

internal class RoomCostGoalCompletionRequest(
    val goalId: String,
    val amountDecimal: String,
    val date: String,
    val purpose: String,
    val note: String = "",
    val mode: CostGoalCompletionMode,
    val operationId: String = UUID.randomUUID().toString(),
    val now: Long = System.currentTimeMillis(),
)

class CompleteCostGoal @Inject constructor(
    private val database: MadarDatabase,
    private val goalRepository: FinancialGoalRepository,
    private val balanceTransactionDao: BalanceTransactionDao,
    private val paymentDao: PaymentDao,
    private val assetRepository: AssetRepository,
) {
    suspend fun complete(request: CompleteCostGoalRequest) = database.withTransaction {
        val aggregate = requireNotNull(goalRepository.getAggregate(request.goalId)) { "Goal not found" }
        require(aggregate.goal.type == GoalType.PROJECT_FUNDING || aggregate.goal.type == GoalType.TRIP_FUNDING)
        require(aggregate.goal.lifecycleStatus == GoalLifecycleStatus.READY) { "Cost goal must be READY" }
        when (request.mode) {
            CostGoalCompletionMode.KEEP_ALLOCATED -> Unit
            CostGoalCompletionMode.PROJECT_ASSET -> {
                require(aggregate.goal.type == GoalType.PROJECT_FUNDING) { "Only project goals can become assets" }
                val records = assetRepository.purchaseAsset(
                    PurchaseAssetRequest(
                        name = request.purpose,
                        type = "project",
                        amountDecimal = request.amountDecimal,
                        date = request.date,
                        note = request.note,
                        operationId = request.operationId,
                    ),
                )
                consume(request, aggregate.goal.currencyCode, records.balanceTransactions.single().id)
            }
            CostGoalCompletionMode.ORDINARY_EXPENSE -> {
                val balance = BalanceTransaction(
                    operationId = request.operationId,
                    kind = BalanceTransactionKind.ExpensePayment,
                    amountDecimal = request.amountDecimal,
                    currencyCode = aggregate.goal.currencyCode,
                    date = request.date,
                    note = request.note,
                    sourceType = "payment",
                )
                val payment = Payment(
                    operationId = request.operationId,
                    kind = PaymentKind.OrdinaryExpense,
                    amountDecimal = request.amountDecimal,
                    currencyCode = aggregate.goal.currencyCode,
                    date = request.date,
                    purpose = request.purpose,
                    purposeKey = request.purpose.trim().lowercase(),
                    balanceTransactionId = balance.id,
                    note = request.note,
                )
                balanceTransactionDao.insert(balance.copy(sourceId = payment.id))
                paymentDao.insert(payment)
                consume(request, aggregate.goal.currencyCode, balance.id)
            }
        }
        goalRepository.transition(
            goalId = request.goalId,
            expectedRevision = aggregate.goal.revision,
            to = GoalLifecycleStatus.COMPLETED,
            operationId = request.operationId,
            now = request.now,
            activityType = "COST_GOAL_COMPLETED",
        )
    }

    private suspend fun consume(request: CompleteCostGoalRequest, currencyCode: String, balanceTransactionId: String) {
        goalRepository.recordFundingTransaction(
            goalId = request.goalId,
            operationId = "${request.operationId}:consume",
            kind = FundingKind.CONSUME,
            amountDecimal = request.amountDecimal,
            currencyCode = currencyCode,
            note = request.note,
            now = request.now,
            balanceTransactionId = balanceTransactionId,
        )
    }
}

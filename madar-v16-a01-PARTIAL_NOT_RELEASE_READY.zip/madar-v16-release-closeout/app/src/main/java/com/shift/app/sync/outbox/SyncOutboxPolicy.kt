package com.shift.app.sync.outbox

import com.shift.app.data.local.entities.SyncOutboxEntity
import com.shift.app.data.local.entities.SyncOutboxState
import com.shift.app.sync.SyncRunResult
import kotlin.math.min

internal const val OUTBOX_MIN_BACKOFF_MS = 10_000L
internal const val OUTBOX_MAX_BACKOFF_MS = 6 * 60 * 60 * 1_000L

object SyncOutboxBackoff {
    fun delayMillis(attemptCount: Int): Long {
        val safeAttempt = attemptCount.coerceIn(0, 20)
        var delay = OUTBOX_MIN_BACKOFF_MS
        repeat(safeAttempt) { delay = min(delay * 2, OUTBOX_MAX_BACKOFF_MS) }
        return delay
    }

    fun nextAttemptAt(now: Long, attemptCount: Int): Long = now + delayMillis(attemptCount)
}

sealed interface SyncOutboxRunDecision {
    data object Complete : SyncOutboxRunDecision
    data class Retry(val failedSteps: List<String>) : SyncOutboxRunDecision
    data object WaitForAuthentication : SyncOutboxRunDecision
}

fun decideOutboxRun(result: SyncRunResult): SyncOutboxRunDecision = when (result) {
    is SyncRunResult.Success -> SyncOutboxRunDecision.Complete
    is SyncRunResult.PartialFailure -> SyncOutboxRunDecision.Retry(result.failedSteps)
    SyncRunResult.AuthenticationRequired -> SyncOutboxRunDecision.WaitForAuthentication
}

fun outboxEventId(entityType: String, operationId: String): String =
    "$entityType:$operationId"

fun retryOutboxEvent(
    event: SyncOutboxEntity,
    now: Long,
    failedSteps: List<String>,
): SyncOutboxEntity = event.copy(
    state = SyncOutboxState.Failed.dbValue,
    attemptCount = event.attemptCount + 1,
    nextAttemptAt = SyncOutboxBackoff.nextAttemptAt(now, event.attemptCount),
    lastError = failedSteps.joinToString(",").take(500),
    updatedAt = now,
)

package com.shift.app.data.local.entities.goals

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalDecimalContract
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension

private const val NO_ACTION = ForeignKey.NO_ACTION

@Entity(
    tableName = "financial_goals",
    indices = [Index(value = ["lifecycleStatus", "deletedAt"])],
)
data class FinancialGoalEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: GoalType,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val currencyCode: String,
    val startDate: String,
    val deadline: String,
    val timezoneId: String,
    val targetDecimal: String,
    val baselineDecimal: String?,
    val targetPercentDecimal: String?,
    val confirmationPeriods: Int,
    val costThreshold: CostThreshold?,
    val configJson: String,
    val revision: Long,
    val readyAt: Long?,
    val completedAt: Long?,
    val cancelledAt: Long?,
    val archivedAt: Long?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && name.isNotBlank() && currencyCode.isNotBlank())
        require(startDate.isNotBlank() && deadline.isNotBlank() && timezoneId.isNotBlank())
        require(configJson.startsWith("{\"version\":1,")) { "configJson must start with version 1" }
        require(confirmationPeriods > 0 && revision >= 0)
        GoalDecimalContract.requireCanonicalNonNegative(targetDecimal)
        GoalDecimalContract.requireCanonicalNullable(baselineDecimal)
        GoalDecimalContract.requireCanonicalNullable(targetPercentDecimal)
    }
}

@Entity(
    tableName = "goal_metrics",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [Index(value = ["goalId", "updatedAt"])],
)
data class GoalMetricEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val metricType: MetricType,
    val windowType: String,
    val windowSize: Int,
    val baselineDecimal: String?,
    val configJson: String,
    val ordinal: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && windowType.isNotBlank())
        require(windowSize > 0 && ordinal >= 0)
        require(configJson.startsWith("{\"version\":1,"))
        GoalDecimalContract.requireCanonicalNullable(baselineDecimal)
    }
}

@Entity(
    tableName = "goal_conditions",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
        ForeignKey(
            entity = GoalMetricEntity::class,
            parentColumns = ["id"],
            childColumns = ["metricId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [Index(value = ["goalId", "updatedAt"]), Index(value = ["metricId"])],
)
data class GoalConditionEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val metricId: String?,
    val kind: ConditionKind,
    val operator: String,
    val valueDecimal: String?,
    val required: Boolean,
    val configJson: String,
    val ordinal: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && operator.isNotBlank())
        require(ordinal >= 0 && configJson.startsWith("{\"version\":1,"))
        GoalDecimalContract.requireCanonicalNullable(valueDecimal)
    }
}

@Entity(
    tableName = "goal_scopes",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [
        Index(value = ["goalId", "updatedAt"]),
        Index(value = ["dimension", "referenceId"]),
        Index(value = ["goalId", "dimension", "referenceId", "effectiveFrom"], unique = true),
    ],
)
data class GoalScopeEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val dimension: ScopeDimension,
    val referenceId: String,
    val mode: String,
    val reason: String,
    val effectiveFrom: String,
    val effectiveTo: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && referenceId.isNotBlank())
        require(mode.isNotBlank() && effectiveFrom.isNotBlank())
    }
}

@Entity(
    tableName = "goal_funding_transactions",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
        ForeignKey(
            entity = BalanceTransaction::class,
            parentColumns = ["id"],
            childColumns = ["balanceTransactionId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
        ForeignKey(
            entity = GoalFundingTransactionEntity::class,
            parentColumns = ["id"],
            childColumns = ["relatedFundingTransactionId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [
        Index(value = ["goalId", "updatedAt"]),
        Index(value = ["operationId"], unique = true),
        Index(value = ["balanceTransactionId"]),
        Index(value = ["relatedFundingTransactionId"]),
    ],
)
data class GoalFundingTransactionEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val operationId: String,
    val kind: FundingKind,
    val amountDecimal: String,
    val currencyCode: String,
    val balanceTransactionId: String?,
    val relatedFundingTransactionId: String?,
    val note: String,
    val occurredAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && operationId.isNotBlank())
        require(currencyCode.isNotBlank())
        GoalDecimalContract.requireCanonicalPositive(amountDecimal)
    }
}

@Entity(
    tableName = "goal_cost_estimates",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [Index(value = ["goalId", "updatedAt"]), Index(value = ["operationId"], unique = true)],
)
data class GoalCostEstimateEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val operationId: String,
    val minDecimal: String?,
    val expectedDecimal: String,
    val safeDecimal: String,
    val currencyCode: String,
    val source: String,
    val note: String,
    val effectiveAt: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && operationId.isNotBlank())
        require(currencyCode.isNotBlank() && source.isNotBlank())
        GoalDecimalContract.requireCanonicalNullable(minDecimal)
        GoalDecimalContract.requireCanonicalPositive(expectedDecimal)
        GoalDecimalContract.requireCanonicalPositive(safeDecimal)
    }
}

@Entity(
    tableName = "goal_evaluations",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
        ForeignKey(
            entity = GoalEvaluationEntity::class,
            parentColumns = ["id"],
            childColumns = ["correctionOfId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [
        Index(value = ["goalId", "updatedAt"]),
        Index(value = ["goalId", "asOf"]),
        Index(value = ["goalId", "inputFingerprint", "engineVersion"], unique = true),
        Index(value = ["correctionOfId"]),
    ],
)
data class GoalEvaluationEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val asOf: Long,
    val engineVersion: String,
    val inputFingerprint: String,
    val lifecycleStatus: GoalLifecycleStatus,
    val healthStatus: GoalHealthStatus,
    val measuredDecimal: String?,
    val targetDecimal: String?,
    val progressDecimal: String?,
    val resultJson: String,
    val correctionOfId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank())
        require(engineVersion.isNotBlank() && inputFingerprint.isNotBlank() && resultJson.isNotBlank())
        GoalDecimalContract.requireCanonicalNullable(measuredDecimal)
        GoalDecimalContract.requireCanonicalNullable(targetDecimal)
        GoalDecimalContract.requireCanonicalNullable(progressDecimal)
    }
}

@Entity(
    tableName = "goal_activities",
    foreignKeys = [
        ForeignKey(
            entity = FinancialGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = NO_ACTION,
            onUpdate = NO_ACTION,
        ),
    ],
    indices = [
        Index(value = ["goalId", "updatedAt"]),
        Index(value = ["goalId", "operationId", "type"], unique = true),
    ],
)
data class GoalActivityEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val operationId: String,
    val type: String,
    val occurredAt: Long,
    val effectiveDate: String?,
    val detailsJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long?,
    val syncState: String,
) {
    init {
        require(id.isNotBlank() && goalId.isNotBlank() && operationId.isNotBlank() && type.isNotBlank())
        require(detailsJson.isNotBlank())
    }
}

@Entity(
    tableName = "financial_change_outbox",
    indices = [Index(value = ["processedAt", "createdAt"])],
)
data class FinancialChangeOutboxEntity(
    @PrimaryKey val eventId: String,
    val sourceType: String,
    val sourceId: String,
    val operationId: String,
    val effectiveDate: String,
    val changedFields: String,
    val createdAt: Long,
    val processedAt: Long?,
    val attemptCount: Int,
    val lastError: String?,
) {
    init {
        require(eventId.isNotBlank() && sourceType.isNotBlank() && sourceId.isNotBlank())
        require(operationId.isNotBlank() && effectiveDate.isNotBlank() && changedFields.isNotBlank())
        require(attemptCount >= 0)
    }
}

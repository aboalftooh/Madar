package com.shift.app.sync.outbox

import com.shift.app.data.local.dao.SyncOutboxDao
import com.shift.app.data.remote.SyncManager
import javax.inject.Inject
import javax.inject.Singleton

sealed interface SyncOutboxProcessResult {
    data object NoWork : SyncOutboxProcessResult
    data class Completed(val processedCount: Int) : SyncOutboxProcessResult
    data class Retry(val failedSteps: List<String>) : SyncOutboxProcessResult
    data object AuthenticationRequired : SyncOutboxProcessResult
}

@Singleton
class SyncOutboxProcessor @Inject constructor(
    private val outboxDao: SyncOutboxDao,
    private val syncManager: SyncManager,
) {
    suspend fun processReady(
        now: Long = System.currentTimeMillis(),
        limit: Int = 100,
    ): SyncOutboxProcessResult {
        val snapshot = outboxDao.getReady(now, limit)
        if (snapshot.isEmpty()) return SyncOutboxProcessResult.NoWork

        return when (val decision = decideOutboxRun(syncManager.syncAll())) {
            SyncOutboxRunDecision.Complete -> {
                // Revision-checked deletion preserves a newer write for the same operation.
                var deletedCount = 0
                snapshot.forEach { event ->
                    deletedCount += outboxDao.deleteIfUnchanged(event.eventId, event.revision)
                }
                SyncOutboxProcessResult.Completed(deletedCount)
            }

            is SyncOutboxRunDecision.Retry -> {
                snapshot.forEach { event ->
                    val failed = retryOutboxEvent(event, now, decision.failedSteps)
                    outboxDao.markFailedIfUnchanged(
                        eventId = failed.eventId,
                        expectedRevision = event.revision,
                        attemptCount = failed.attemptCount,
                        nextAttemptAt = failed.nextAttemptAt,
                        lastError = requireNotNull(failed.lastError),
                        updatedAt = failed.updatedAt,
                    )
                }
                SyncOutboxProcessResult.Retry(decision.failedSteps)
            }

            SyncOutboxRunDecision.WaitForAuthentication ->
                SyncOutboxProcessResult.AuthenticationRequired
        }
    }
}

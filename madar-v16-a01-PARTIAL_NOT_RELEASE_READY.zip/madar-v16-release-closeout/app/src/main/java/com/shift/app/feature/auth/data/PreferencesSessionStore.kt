package com.shift.app.feature.auth.data

import com.shift.app.feature.auth.domain.SessionReader
import com.shift.app.feature.auth.domain.SessionWriter
import com.shift.app.utils.PreferencesManager
import io.github.jan.supabase.gotrue.Auth
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow

@Singleton
class PreferencesSessionStore @Inject constructor(
    private val auth: Auth,
    private val preferences: PreferencesManager,
) : SessionReader, SessionWriter {
    override val rememberedEmail: Flow<String> = preferences.rememberedEmail

    override fun isLoggedIn(): Boolean = auth.currentUserOrNull() != null

    override suspend fun rememberEmail(email: String) {
        preferences.setRememberedEmail(email)
    }

    override suspend fun initializeRegisteredAccount(name: String, jobTitle: String) {
        if (name.isNotBlank()) preferences.setUserName(name)
        if (jobTitle.isNotBlank()) preferences.setWorkType(jobTitle)
        preferences.setSetupDone(true)
    }

    override suspend fun clearAccountScopedState() {
        preferences.clearAccountScopedState()
    }
}

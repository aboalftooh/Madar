package com.shift.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteDebtSchedule(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("operation_id") val operationId: String,
    @SerialName("account_id") val accountId: String,
    @SerialName("installment_no") val installmentNo: Int,
    @SerialName("due_date") val dueDate: String,
    @SerialName("amount_decimal") val amountDecimal: String,
    @SerialName("currency_code") val currencyCode: String,
    val status: String,
    @SerialName("reminder_before_due") val reminderBeforeDue: Boolean,
    @SerialName("reminder_on_due") val reminderOnDue: Boolean,
    @SerialName("sync_state") val syncState: String,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null
)

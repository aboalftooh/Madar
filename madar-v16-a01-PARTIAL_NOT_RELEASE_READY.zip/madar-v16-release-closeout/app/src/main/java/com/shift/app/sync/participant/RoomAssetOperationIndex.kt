package com.shift.app.sync.participant

import com.shift.app.data.local.dao.AssetDao
import com.shift.app.data.local.dao.AssetTransactionDao
import com.shift.app.data.local.dao.AssetValuationDao
import com.shift.app.data.local.dao.CurrencyAssetLotDao
import com.shift.app.data.local.dao.CurrencyAssetSaleAllocationDao
import com.shift.app.data.local.dao.PaymentDao
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RoomAssetOperationIndex @Inject constructor(
    private val assetDao: AssetDao,
    private val transactionDao: AssetTransactionDao,
    private val valuationDao: AssetValuationDao,
    private val lotDao: CurrencyAssetLotDao,
    private val allocationDao: CurrencyAssetSaleAllocationDao,
    private val paymentDao: PaymentDao,
) {
    suspend fun readOperationIds(): Set<String> = buildSet {
        addAll(assetDao.getAllOnce().mapNotNull { it.operationId })
        addAll(transactionDao.getAllOnce().map { it.operationId })
        addAll(valuationDao.getAllOnce().map { it.operationId })
        addAll(lotDao.getAllOnce().map { it.operationId })
        addAll(allocationDao.getAllOnce().map { it.operationId })
        addAll(paymentDao.getAllOnce().filter { it.assetId != null }.map { it.operationId })
    }
}

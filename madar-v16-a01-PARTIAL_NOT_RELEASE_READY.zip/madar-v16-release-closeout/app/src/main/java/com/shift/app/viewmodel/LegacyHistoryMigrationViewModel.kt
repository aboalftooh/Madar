package com.shift.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.data.local.entities.LedgerHistoryMigration
import com.shift.app.data.migration.LegacyFinancialCutoverCoordinator
import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.requireSuccess
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.LegacyHistoryMigrationRepository
import com.shift.app.domain.finance.BalanceCalculator
import com.shift.app.domain.finance.LegacyHistoryMigrationPreview
import com.shift.app.utils.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LegacyHistoryMigrationUiState(
    val activated: Boolean = false,
    val marker: LedgerHistoryMigration? = null,
    val preview: LegacyHistoryMigrationPreview? = null,
    val debtCandidateCount: Int = 0,
    val debtReviewCount: Int = 0,
    val cutoverFingerprint: String? = null,
    val targetBalanceInput: String = "",
    val recordsCompleteConfirmed: Boolean = false,
    val adjustmentConfirmed: Boolean = false,
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

@HiltViewModel
class LegacyHistoryMigrationViewModel @Inject constructor(
    private val prefs: PreferencesManager,
    private val ledgerRepository: FinancialLedgerRepository,
    private val migrationRepository: LegacyHistoryMigrationRepository,
    private val cutoverCoordinator: LegacyFinancialCutoverCoordinator,
    private val sync: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : ViewModel() {
    private data class CutoverPreviewState(
        val history: LegacyHistoryMigrationPreview? = null,
        val fingerprint: String? = null,
        val debtCandidateCount: Int = 0,
        val debtReviewCount: Int = 0,
    )

    private val cutoverPreview = MutableStateFlow(CutoverPreviewState())
    private val targetBalanceInput = MutableStateFlow("")
    private val recordsConfirmed = MutableStateFlow(false)
    private val adjustmentConfirmed = MutableStateFlow(false)
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val error = MutableStateFlow<String?>(null)
    private var previewJob: Job? = null

    private data class Core(
        val activated: Boolean,
        val marker: LedgerHistoryMigration?,
        val cutoverPreview: CutoverPreviewState,
        val target: String,
        val recordsConfirmed: Boolean
    )

    private val core = combine(
        prefs.balanceActivated,
        migrationRepository.marker(),
        cutoverPreview,
        targetBalanceInput,
        recordsConfirmed
    ) { activated, marker, currentPreview, target, confirmed ->
        Core(activated, marker, currentPreview, target, confirmed)
    }

    private data class Secondary(
        val adjustmentConfirmed: Boolean,
        val busy: Boolean,
        val message: String?,
        val error: String?
    )

    private val secondary = combine(
        adjustmentConfirmed,
        busy,
        message,
        error
    ) { confirmed, isBusy, currentMessage, currentError ->
        Secondary(confirmed, isBusy, currentMessage, currentError)
    }

    val state: StateFlow<LegacyHistoryMigrationUiState> = combine(core, secondary) { first, second ->
        LegacyHistoryMigrationUiState(
            activated = first.activated,
            marker = first.marker,
            preview = first.cutoverPreview.history,
            debtCandidateCount = first.cutoverPreview.debtCandidateCount,
            debtReviewCount = first.cutoverPreview.debtReviewCount,
            cutoverFingerprint = first.cutoverPreview.fingerprint,
            targetBalanceInput = first.target,
            recordsCompleteConfirmed = first.recordsConfirmed,
            adjustmentConfirmed = second.adjustmentConfirmed,
            busy = second.busy,
            message = second.message,
            error = second.error
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LegacyHistoryMigrationUiState())

    fun setRecordsCompleteConfirmed(value: Boolean) {
        recordsConfirmed.value = value
        if (!value) adjustmentConfirmed.value = false
    }

    fun setAdjustmentConfirmed(value: Boolean) {
        adjustmentConfirmed.value = value
    }

    fun startPreview() {
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            error.value = null
            message.value = null
            runCatching {
                sync.syncAll().requireSuccess()
                require(prefs.balanceActivated.first()) { "فعّل الرصيد أولًا" }
                require(migrationRepository.getMarker() == null) { "تم ترحيل التاريخ الكامل مسبقًا" }
                val current = BalanceCalculator.currentBalance(
                    ledgerRepository.getBalanceTransactionsOnce()
                ).toPlainString()
                targetBalanceInput.value = current
                val cutover = cutoverCoordinator.preview(
                    localCurrencyCode = prefs.localCurrencyCode.first(),
                    targetBalanceInput = current,
                )
                cutoverPreview.value = CutoverPreviewState(
                    history = requireNotNull(cutover.history),
                    fingerprint = cutover.plan.fingerprint,
                    debtCandidateCount = cutover.plan.debtCandidateCount,
                    debtReviewCount = cutover.plan.debtReviewCount,
                )
                adjustmentConfirmed.value = false
            }.onFailure { error.value = it.message ?: "تعذر إعداد معاينة الترحيل" }
        }
    }

    fun setTargetBalance(value: String) {
        targetBalanceInput.value = value
        adjustmentConfirmed.value = false
    }

    fun refreshAdjustmentPreview() {
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            error.value = null
            runCatching {
                val cutover = cutoverCoordinator.preview(
                    localCurrencyCode = prefs.localCurrencyCode.first(),
                    targetBalanceInput = targetBalanceInput.value,
                )
                cutoverPreview.value = CutoverPreviewState(
                    history = requireNotNull(cutover.history),
                    fingerprint = cutover.plan.fingerprint,
                    debtCandidateCount = cutover.plan.debtCandidateCount,
                    debtReviewCount = cutover.plan.debtReviewCount,
                )
            }.onFailure { error.value = it.message ?: "تعذر حساب التسوية" }
        }
    }

    fun execute() = viewModelScope.launch {
        if (busy.value) return@launch
        val expected = cutoverPreview.value
        val expectedFingerprint = expected.fingerprint ?: return@launch
        if (expected.history == null || !recordsConfirmed.value || !adjustmentConfirmed.value) return@launch
        busy.value = true
        error.value = null
        message.value = null
        try {
            sync.syncAll().requireSuccess()
            val result = sync.executeSessionOperation {
                val cutover = cutoverCoordinator.commit(
                    expectedCutoverFingerprint = expectedFingerprint,
                    localCurrencyCode = prefs.localCurrencyCode.first(),
                    targetBalanceInput = targetBalanceInput.value,
                )
                val changed = cutover.historyApplied ||
                    cutover.debtResult.migratedAccounts > 0 ||
                    cutover.debtResult.reviews > 0
                if (changed) {
                    syncQueue.requestSync(
                        reason = "legacy-financial-cutover",
                        operationId = cutover.fingerprint,
                    )
                }
                cutover
            } ?: error("انتهت جلسة الحساب")
            val changed = result.historyApplied ||
                result.debtResult.migratedAccounts > 0 ||
                result.debtResult.reviews > 0
            message.value = if (changed) {
                "اكتمل التحويل المالي إلى الدفتر والديون الجديدة"
            } else {
                "تم التحويل مسبقًا دون تكرار"
            }
        } catch (failure: Throwable) {
            error.value = failure.message ?: "تعذر تنفيذ ترحيل التاريخ"
        } finally {
            busy.value = false
        }
    }

    fun clearMessages() {
        message.value = null
        error.value = null
    }
}

package com.shift.app.domain.finance

import com.shift.app.data.local.entities.BalanceTransaction
import java.math.BigDecimal

object BalanceCalculator {
    fun currentBalance(items: List<BalanceTransaction>): BigDecimal =
        items
            .asSequence()
            .filter { it.deletedAt == null }
            .fold(BigDecimal.ZERO) { total, item ->
                val amount = DecimalText.toBigDecimal(item.amountDecimal)
                when (item.direction) {
                    BalanceDirection.Inflow.dbValue -> total + amount
                    BalanceDirection.Outflow.dbValue -> total - amount
                    else -> total
                }
            }
}

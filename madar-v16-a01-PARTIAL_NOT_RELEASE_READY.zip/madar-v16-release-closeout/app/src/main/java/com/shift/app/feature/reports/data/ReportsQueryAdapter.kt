package com.shift.app.feature.reports.data

import com.shift.app.data.local.dao.DebtAccountDao
import com.shift.app.data.local.dao.DebtTransactionDao
import com.shift.app.data.repository.AssetRepository
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.TransactionRepository
import com.shift.app.feature.reports.domain.model.ReportAssetRow
import com.shift.app.feature.reports.domain.model.ReportAssetValuationRow
import com.shift.app.feature.reports.domain.model.ReportBalanceRow
import com.shift.app.feature.reports.domain.model.ReportDebtAccountRow
import com.shift.app.feature.reports.domain.model.ReportDebtTransactionRow
import com.shift.app.feature.reports.domain.model.ReportPaymentRow
import com.shift.app.feature.reports.domain.model.ReportTransactionRow
import com.shift.app.feature.reports.domain.model.ReportsDataset
import com.shift.app.feature.reports.domain.repository.ReportsQuery
import java.math.BigDecimal
import java.math.RoundingMode
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

@Singleton
class ReportsQueryAdapter @Inject constructor(
    transactionRepository: TransactionRepository,
    financialLedgerRepository: FinancialLedgerRepository,
    assetRepository: AssetRepository,
    debtAccountDao: DebtAccountDao,
    debtTransactionDao: DebtTransactionDao,
) : ReportsQuery {
    private val finance = combine(
        transactionRepository.getAll(),
        financialLedgerRepository.balanceTransactions(),
        financialLedgerRepository.payments(),
        financialLedgerRepository.migratedLegacyTransactionIds(),
    ) { transactions, balances, payments, migratedIds ->
        FinanceRows(
            transactions = transactions.map { row ->
                ReportTransactionRow(
                    id = row.id,
                    type = row.type,
                    amountDecimal = BigDecimal.valueOf(row.amount).setScale(2, RoundingMode.HALF_UP).toPlainString(),
                    category = row.category,
                    date = row.date,
                    incomeSourceName = row.incomeSourceNameSnapshot,
                    purpose = row.purpose,
                    beneficiaryName = row.expenseBeneficiaryNameSnapshot,
                    deleted = row.deletedAt != null,
                )
            },
            balances = balances.map { row ->
                ReportBalanceRow(
                    id = row.id,
                    direction = row.direction,
                    kind = row.kind,
                    amountDecimal = row.amountDecimal,
                    date = row.date,
                    sourceType = row.sourceType,
                    sourceId = row.sourceId,
                    legacyTransactionId = row.legacyTransactionId,
                    createdAt = row.createdAt,
                    updatedAt = row.updatedAt,
                    deleted = row.deletedAt != null,
                )
            },
            payments = payments.map { row ->
                ReportPaymentRow(
                    id = row.id,
                    operationId = row.operationId,
                    kind = row.kind,
                    amountDecimal = row.amountDecimal,
                    date = row.date,
                    purpose = row.purpose,
                    beneficiaryName = row.beneficiaryNameSnapshot,
                    assetName = row.assetNameSnapshot,
                    legacyTransactionId = row.legacyTransactionId,
                    createdAt = row.createdAt,
                    updatedAt = row.updatedAt,
                    deleted = row.deletedAt != null,
                )
            },
            migratedIds = migratedIds.toSet(),
        )
    }

    private val assets = combine(
        assetRepository.assets(),
        assetRepository.assetValuations(),
    ) { assets, valuations ->
        AssetRows(
            assets = assets.map { row -> ReportAssetRow(row.id, row.status, row.deletedAt != null) },
            valuations = valuations.map { row ->
                ReportAssetValuationRow(
                    id = row.id,
                    assetId = row.assetId,
                    valueDecimal = row.valueDecimal,
                    date = row.date,
                    createdAt = row.createdAt,
                    deleted = row.deletedAt != null,
                )
            },
        )
    }

    private val debts = combine(
        debtAccountDao.getActiveAccounts(),
        debtTransactionDao.getActiveTransactions(),
    ) { accounts, transactions ->
        DebtRows(
            accounts = accounts.map { row ->
                ReportDebtAccountRow(row.id, row.direction, row.confirmed, row.deletedAt != null)
            },
            transactions = transactions.map { row ->
                ReportDebtTransactionRow(row.id, row.accountId, row.type, row.amountDecimal, row.deletedAt != null)
            },
        )
    }

    override fun observeDataset(): Flow<ReportsDataset> = combine(finance, assets, debts) { finance, assets, debts ->
        ReportsDataset(
            transactions = finance.transactions,
            balances = finance.balances,
            payments = finance.payments,
            migratedLegacyExpenseIds = finance.migratedIds,
            assets = assets.assets,
            assetValuations = assets.valuations,
            debtAccounts = debts.accounts,
            debtTransactions = debts.transactions,
        )
    }

    private data class FinanceRows(
        val transactions: List<ReportTransactionRow>,
        val balances: List<ReportBalanceRow>,
        val payments: List<ReportPaymentRow>,
        val migratedIds: Set<String>,
    )

    private data class AssetRows(
        val assets: List<ReportAssetRow>,
        val valuations: List<ReportAssetValuationRow>,
    )

    private data class DebtRows(
        val accounts: List<ReportDebtAccountRow>,
        val transactions: List<ReportDebtTransactionRow>,
    )
}

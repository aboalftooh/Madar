package com.shift.app.feature.reports.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shift.app.feature.reports.domain.model.ReportCategoryReadModel
import com.shift.app.ui.components.DonutChart
import com.shift.app.ui.components.DonutSlice
import com.shift.app.ui.components.MonthlyPoint
import com.shift.app.ui.components.ShiftLineChart
import com.shift.app.ui.theme.*
import com.shift.app.utils.NumberDisplayFormatter
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

// ── ألوان الفئات ───────────────────────────────────────────────────────────
private val SliceColors = listOf(
    Color(0xFF38BDF8), // أزرق
    Color(0xFF22C55E), // أخضر
    Color(0xFFC9A84C), // ذهبي
    Color(0xFFEF4444), // أحمر
    Color(0xFFA78BFA), // بنفسجي
    Color(0xFF06B6D4), // سماوي
    Color(0xFFF97316), // برتقالي
    Color(0xFFEC4899), // وردي
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    state: ReportsUiState,
    onEvent: (ReportsUiEvent) -> Unit,
) {
    val readModel = state.readModel
    val dateFrom = readModel.range.from
    val dateTo = readModel.range.to
    val report = readModel.period
    val wealth = readModel.wealth
    val chartData = readModel.monthlyTrend.map { point ->
        MonthlyPoint(point.label, point.income, point.expense)
    }
    val byPurpose = readModel.expensesByPurpose
    val byBeneficiary = readModel.expensesByBeneficiary
    val incomeBySource = readModel.incomeBySource
    val dateRangeError = readModel.invalidRange

    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }
    val fromPickerState = rememberDatePickerState(
        initialSelectedDateMillis = dateFrom.atStartOfDay(ZoneId.of("UTC")).toInstant().toEpochMilli()
    )
    val toPickerState = rememberDatePickerState(
        initialSelectedDateMillis = dateTo.atStartOfDay(ZoneId.of("UTC")).toInstant().toEpochMilli()
    )
    var activeTab by remember { mutableStateOf(0) }

    // ── الواجهة ───────────────────────────────────────────────────────────
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .imePadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // ── العنوان ───────────────────────────────────────────────────────
        Row(
            Modifier.fillMaxWidth().statusBarsPadding(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Text("التقارير", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Icon(Icons.Default.BarChart, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(28.dp))
        }

        // ── فلتر التاريخ بالتقويم ─────────────────────────────────────────
        Card(
            shape  = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                DateButton(label = "من", date = dateFrom) { showFromPicker = true }
                Text("←", color = TextMuted, fontSize = 16.sp)
                DateButton(label = "إلى", date = dateTo) { showToPicker = true }
            }
        }
        if (dateRangeError) {
            Text("يجب أن يكون تاريخ البداية قبل تاريخ النهاية أو مساوياً له", color = ExpenseRed, fontSize = 12.sp)
        }

        // ── KPIs ─────────────────────────────────────────────────────────
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiCard("الدخل", report.income, IncomeGreen, Icons.Default.TrendingUp, Modifier.weight(1f))
            KpiCard("المصروفات الفعلية", report.actualExpenses, ExpenseRed, Icons.Default.TrendingDown, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NetCard(net = report.net, modifier = Modifier.weight(1f))
            SavingCard(rate = report.savingRatePercent, modifier = Modifier.weight(1f))
        }

        ReportSection(title = "صافي الثروة الحالي") {
            WealthRow("الرصيد المتاح", wealth.balance, Icons.Default.AccountBalanceWallet, GoldPrimary)
            WealthRow("قيمة الأصول", wealth.assetsValue, Icons.Default.Inventory2, AccentCyan)
            WealthRow("ديون لك", wealth.receivables, Icons.Default.CallReceived, IncomeGreen)
            WealthRow("ديون عليك", wealth.payables, Icons.Default.CallMade, ExpenseRed)
            HorizontalDivider(color = SurfaceVariant)
            WealthRow(
                "صافي الثروة",
                wealth.netWorth,
                Icons.Default.AutoGraph,
                if (wealth.netWorth.signum() >= 0) IncomeGreen else ExpenseRed
            )
            Text("الرصيد الحالي + أحدث تقييم صالح للأصول الحالية + ديون لك - ديون عليك", color = TextMuted, fontSize = 11.sp)
        }

        // ── الرسم الخطي 6 أشهر ────────────────────────────────────────────
        ReportSection(title = "الدخل والمصروفات الفعلية — آخر 6 أشهر") {
            // Legend ملونة
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LegendDot(color = IncomeGreen, label = "دخل")
                LegendDot(color = ExpenseRed,  label = "مصروفات فعلية")
            }
            if (chartData.any { it.income > 0f || it.expense > 0f }) {
                ShiftLineChart(
                    data     = chartData,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
            } else {
                EmptyHint("لا توجد بيانات كافية بعد")
            }
        }

        ReportSection(title = "الدخل حسب المصدر") {
            if (incomeBySource.isEmpty()) {
                EmptyHint("لا توجد إيرادات في هذه الفترة")
            } else {
                                incomeBySource.forEach { item ->
                    val source = item.name
                    val amount = item.amount
                    val pct = item.shareFraction
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(IncomeGreen)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(source, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(
                            formatMoney(amount),
                            color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "${NumberDisplayFormatter.format(pct * 100)}%",
                            color = TextMuted, fontSize = 11.sp, modifier = Modifier.width(36.dp)
                        )
                    }
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(SurfaceVariant)) {
                        Box(
                            Modifier.fillMaxWidth(pct).fillMaxHeight()
                                .clip(RoundedCornerShape(2.dp))
                                .background(IncomeGreen)
                        )
                    }
                }
            }
        }

        // ── تبويبان ───────────────────────────────────────────────────────
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("حسب الغرض", "حسب المستفيد").forEachIndexed { i, title ->
                val selected = activeTab == i
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) GoldGlow else SurfaceDark)
                        .then(Modifier.padding(vertical = 10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    TextButton(
                        onClick = { activeTab = i },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            title,
                            color      = if (selected) GoldLight else TextMuted,
                            fontSize   = 13.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // ── محتوى التبويب ─────────────────────────────────────────────────
        val activeData: List<ReportCategoryReadModel> = if (activeTab == 0) byPurpose else byBeneficiary
        val activeLabel  = if (activeTab == 0) "الغرض" else "المستفيد"

        // دونات + تفاصيل
        ReportSection(title = "توزيع المصروفات $activeLabel") {
            if (activeData.isEmpty()) {
                EmptyHint("لا توجد مصروفات في هذه الفترة")
            } else {
                val slices = activeData.mapIndexed { i, item ->
                    DonutSlice(item.name, item.amount.toFloat(), SliceColors[i % SliceColors.size])
                }
                DonutChart(
                    slices   = slices,
                    modifier = Modifier.size(150.dp).align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(8.dp))
                // Legend + bars
                slices.zip(activeData).forEach { (slice, item) ->
                    val name = item.name
                    val amount = item.amount
                    val pct = item.shareFraction
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // مربع اللون
                        Box(
                            Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(slice.color)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(name, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(
                            formatMoney(amount),
                            color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "${NumberDisplayFormatter.format(pct * 100)}%",
                            color = TextMuted, fontSize = 11.sp, modifier = Modifier.width(36.dp)
                        )
                    }
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(SurfaceVariant)) {
                        Box(
                            Modifier.fillMaxWidth(pct).fillMaxHeight()
                                .clip(RoundedCornerShape(2.dp))
                                .background(slice.color)
                        )
                    }
                }
            }
        }


        Spacer(Modifier.height(16.dp))
    }

    // ── DatePicker dialogs ────────────────────────────────────────────────
    if (showFromPicker) {
        DatePickerDialog(
            onDismissRequest = { showFromPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    fromPickerState.selectedDateMillis?.let {
                        onEvent(ReportsUiEvent.DateFromChanged(Instant.ofEpochMilli(it).atZone(ZoneId.of("UTC")).toLocalDate()))
                    }
                    showFromPicker = false
                }) { Text("موافق", color = AccentBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showFromPicker = false }) { Text("إلغاء", color = TextMuted) }
            },
            colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
        ) { DatePicker(state = fromPickerState) }
    }

    if (showToPicker) {
        DatePickerDialog(
            onDismissRequest = { showToPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    toPickerState.selectedDateMillis?.let {
                        onEvent(ReportsUiEvent.DateToChanged(Instant.ofEpochMilli(it).atZone(ZoneId.of("UTC")).toLocalDate()))
                    }
                    showToPicker = false
                }) { Text("موافق", color = AccentBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showToPicker = false }) { Text("إلغاء", color = TextMuted) }
            },
            colors = DatePickerDefaults.colors(containerColor = SurfaceDark)
        ) { DatePicker(state = toPickerState) }
    }
}

// ── مكونات مساعدة ─────────────────────────────────────────────────────────

@Composable
private fun RowScope.DateButton(label: String, date: LocalDate, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.weight(1f),
        shape  = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceVariant)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = TextMuted, fontSize = 10.sp)
            Text(date.toString(), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Text(label, color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun ReportSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape  = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            content()
        }
    }
}

@Composable
private fun KpiCard(
    label: String, amount: BigDecimal, color: Color,
    icon: ImageVector, modifier: Modifier = Modifier
) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(15.dp))
                Text(label, color = TextMuted, fontSize = 12.sp)
            }
            Text(
                formatMoney(amount),
                color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun NetCard(net: BigDecimal, modifier: Modifier = Modifier) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("صافي الفترة", color = TextMuted, fontSize = 12.sp)
            Text(
                formatMoney(net),
                color = if (net.signum() >= 0) IncomeGreen else ExpenseRed,
                fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun WealthRow(label: String, amount: BigDecimal, icon: ImageVector, color: Color) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Text(label, color = TextSecondary, fontSize = 13.sp)
        }
        Text(formatMoney(amount), color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun SavingCard(rate: Int, modifier: Modifier = Modifier) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("معدل الادخار", color = TextMuted, fontSize = 12.sp)
            Text("${NumberDisplayFormatter.format(rate)}%", color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(SurfaceVariant)) {
                Box(
                    Modifier.fillMaxWidth(rate.coerceIn(0, 100) / 100f).fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(Brush.linearGradient(listOf(GoldDark, GoldLight)))
                )
            }
        }
    }
}

@Composable
private fun EmptyHint(msg: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
        Text(msg, color = TextMuted, fontSize = 13.sp)
    }
}

private fun formatMoney(amount: BigDecimal): String =
    NumberDisplayFormatter.format(amount, useGrouping = true)

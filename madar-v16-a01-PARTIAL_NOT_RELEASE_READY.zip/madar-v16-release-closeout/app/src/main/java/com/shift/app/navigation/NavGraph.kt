package com.shift.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.shift.app.feature.auth.presentation.AuthViewModel
import com.shift.app.feature.auth.presentation.LoginScreen
import com.shift.app.feature.auth.presentation.RegisterScreen
import com.shift.app.feature.auth.presentation.ResetPasswordScreen
import com.shift.app.ui.screens.MainScreen
import com.shift.app.ui.screens.PinScreen

sealed class Screen(val route: String) {
    object Login         : Screen("login")
    object Register      : Screen("register")
    object Pin           : Screen("pin")
    object Main          : Screen("main")
    object ResetPassword : Screen("reset-password/{email}") {
        fun withEmail(email: String) =
            "reset-password/" + java.net.URLEncoder.encode(email, "UTF-8")
    }
}

@Composable
fun MadarNavGraph(lockNonce: Int = 0) {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = hiltViewModel()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    val startDestination = remember {
        when {
            authViewModel.isLoggedIn() -> Screen.Pin.route
            else                   -> Screen.Login.route
        }
    }

    LaunchedEffect(lockNonce) {
        if (lockNonce > 0 && authViewModel.isLoggedIn() && currentRoute == Screen.Main.route) {
            navController.navigate(Screen.Pin.route) {
                popUpTo(Screen.Main.route) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    NavHost(navController = navController, startDestination = startDestination) {

        // — Login
        composable(Screen.Login.route) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Screen.Pin.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onOtpSent = { email ->
                    navController.navigate(Screen.ResetPassword.withEmail(email))
                },
                onNavigateToRegister = {
                    navController.navigate(Screen.Register.route)
                }
            )
        }

        // — Register
        composable(Screen.Register.route) {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate(Screen.Pin.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.popBackStack()
                }
            )
        }

        // — PIN
        composable(Screen.Pin.route) {
            PinScreen(
                onAuthenticated = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Pin.route) { inclusive = true }
                    }
                }
            )
        }

        // — Main
        composable(Screen.Main.route) {
            MainScreen(
                onLogout = { onBlocked ->
                    authViewModel.logout(
                        onSuccess = {
                            navController.navigate(Screen.Login.route) {
                                popUpTo(Screen.Main.route) { inclusive = true }
                            }
                        },
                        onBlocked = onBlocked
                    )
                },
                onForceLogout = {
                    authViewModel.forceLogoutDiscardLocal {
                        navController.navigate(Screen.Login.route) {
                            popUpTo(Screen.Main.route) { inclusive = true }
                        }
                    }
                }
            )
        }

        // — Reset Password
        composable(Screen.ResetPassword.route) { backStackEntry ->
            val email = java.net.URLDecoder.decode(
                backStackEntry.arguments?.getString("email") ?: "", "UTF-8"
            )
            ResetPasswordScreen(
                email = email,
                onResetSuccess = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}

package com.shift.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shift.app.data.local.entities.BalanceTransaction
import com.shift.app.data.local.dao.goals.GoalFundingTransactionDao
import com.shift.app.data.remote.SyncManager
import com.shift.app.sync.SyncQueueGateway
import com.shift.app.data.repository.BalanceTransactionRequest
import com.shift.app.data.repository.FinancialLedgerRepository
import com.shift.app.data.repository.PaymentRequest
import com.shift.app.domain.finance.BalanceTransactionKind
import com.shift.app.domain.finance.DecimalText
import com.shift.app.domain.finance.DecimalTextScale
import com.shift.app.domain.finance.PaymentKind
import com.shift.app.domain.goals.funding.GoalFundingCalculator
import com.shift.app.feature.goals.domain.model.GoalBalanceRow
import com.shift.app.feature.goals.domain.model.GoalFundingTransaction
import com.shift.app.utils.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class BalanceUiState(
    val activated: Boolean = false,
    val activatedAt: Long = 0L,
    val currencyCode: String = "SDG",
    val currentBalanceDecimal: String = "0.00",
    val allocatedBalanceDecimal: String = "0.00",
    val availableBalanceDecimal: String = "0.00",
    val transactions: List<BalanceTransaction> = emptyList(),
    val busy: Boolean = false,
    val error: String? = null,
    val message: String? = null
)

@HiltViewModel
class BalanceViewModel @Inject constructor(
    private val prefs: PreferencesManager,
    private val ledgerRepo: FinancialLedgerRepository,
    private val goalFundingDao: GoalFundingTransactionDao,
    private val sync: SyncManager,
    private val syncQueue: SyncQueueGateway,
) : ViewModel() {
    private val error = MutableStateFlow<String?>(null)
    private val message = MutableStateFlow<String?>(null)
    private val busy = MutableStateFlow(false)
    private val activationMutex = Mutex()
    private val manualOperationMutex = Mutex()

    private val feedback = combine(error, message) { currentError, currentMessage ->
        currentError to currentMessage
    }

    private val balanceSnapshot = combine(
        ledgerRepo.balanceTransactions(),
        goalFundingDao.observeActive(),
    ) { transactions, fundingTransactions ->
        transactions to GoalFundingCalculator.totals(
            transactions.map { GoalBalanceRow(it.id, it.direction, it.amountDecimal, it.date, it.deletedAt) },
            fundingTransactions.map { GoalFundingTransaction(it.id, it.goalId, it.operationId, it.kind, it.amountDecimal, it.currencyCode, it.balanceTransactionId, it.relatedFundingTransactionId, it.note, it.occurredAt, it.createdAt, it.updatedAt, it.deletedAt, it.syncState) },
        )
    }

    private val coreState = combine(
        prefs.balanceActivated,
        prefs.balanceActivatedAt,
        prefs.localCurrencyCode,
        balanceSnapshot,
        feedback
    ) { activated, activatedAt, currencyCode, snapshot, currentFeedback ->
        val (transactions, fundingTotals) = snapshot
        BalanceUiState(
            activated = activated,
            activatedAt = activatedAt,
            currencyCode = currencyCode,
            currentBalanceDecimal = fundingTotals.realBalanceDecimal,
            allocatedBalanceDecimal = fundingTotals.allocatedDecimal,
            availableBalanceDecimal = fundingTotals.availableDecimal,
            transactions = transactions,
            error = currentFeedback.first,
            message = currentFeedback.second
        )
    }

    val state: StateFlow<BalanceUiState> = combine(coreState, busy) { current, isBusy ->
        current.copy(busy = isBusy)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BalanceUiState())

    fun activate(openingBalanceInput: String) = viewModelScope.launch {
        if (busy.value) return@launch
        busy.value = true
        error.value = null
        message.value = null
        try {
            val executed = sync.executeSessionOperation {
                activationMutex.withLock {
                    if (prefs.balanceActivated.first()) return@withLock
                    runCatching {
                        val amount = DecimalText.canonical(openingBalanceInput.ifBlank { "0" }, DecimalTextScale.Money)
                        val activatedAt = System.currentTimeMillis()
                        val operationId = UUID.randomUUID().toString()
                        ledgerRepo.recordOpeningBalance(
                            operationId = operationId,
                            amountDecimal = amount,
                            currencyCode = "SDG",
                            date = LocalDate.now().toString(),
                            note = ""
                        )
                        prefs.activateBalance(localCurrencyCode = "SDG", activatedAt = activatedAt)
                        syncQueue.requestSync("balance-activation", operationId)
                    }.onFailure {
                        error.value = it.message ?: "تعذر تفعيل الرصيد"
                    }
                }
            }
            if (executed == null) error.value = "انتهت جلسة الحساب"
        } finally {
            busy.value = false
        }
    }

    fun saveManualBalance(
        isAddition: Boolean,
        amountInput: String,
        date: String,
        note: String
    ) = viewModelScope.launch {
        if (busy.value) return@launch
        busy.value = true
        error.value = null
        message.value = null
        try {
            val executed = sync.executeSessionOperation {
                manualOperationMutex.withLock {
                    if (!prefs.balanceActivated.first()) {
                        error.value = "فعّل الرصيد أولاً"
                        return@withLock
                    }
                    runCatching {
                        val operationId = UUID.randomUUID().toString()
                        val amount = DecimalText.canonicalPositive(amountInput, DecimalTextScale.Money)
                        val currency = prefs.localCurrencyCode.first()
                        if (isAddition) {
                            ledgerRepo.recordBalanceTransaction(
                                BalanceTransactionRequest(
                                    operationId = operationId,
                                    kind = BalanceTransactionKind.ManualAdd,
                                    amountDecimal = amount,
                                    currencyCode = currency,
                                    date = date,
                                    note = note,
                                    sourceType = "manual_balance"
                                )
                            )
                            syncQueue.requestSync("manual-balance-add", operationId)
                            message.value = "تمت إضافة الرصيد بنجاح"
                        } else {
                            ledgerRepo.recordPayment(
                                PaymentRequest(
                                    operationId = operationId,
                                    kind = PaymentKind.BalanceWithdrawal,
                                    amountDecimal = amount,
                                    currencyCode = currency,
                                    date = date,
                                    purpose = "سحب رصيد يدوي",
                                    note = note
                                )
                            )
                            syncQueue.requestSync("manual-balance-withdrawal", operationId)
                            message.value = "تم سحب الرصيد بنجاح"
                        }
                    }.onFailure {
                        error.value = it.message ?: if (isAddition) {
                            "تعذر إضافة الرصيد"
                        } else {
                            "تعذر سحب الرصيد"
                        }
                    }
                }
            }
            if (executed == null) error.value = "انتهت جلسة الحساب"
        } finally {
            busy.value = false
        }
    }

    fun addManualBalance(amountInput: String) = saveManualBalance(
        isAddition = true,
        amountInput = amountInput,
        date = LocalDate.now().toString(),
        note = "إضافة رصيد يدوية"
    )

    fun clearFeedback() {
        error.value = null
        message.value = null
    }

    fun clearError() {
        error.value = null
    }
}

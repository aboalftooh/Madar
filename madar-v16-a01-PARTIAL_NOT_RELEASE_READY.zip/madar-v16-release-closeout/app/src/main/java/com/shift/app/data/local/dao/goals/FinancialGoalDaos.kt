package com.shift.app.data.local.dao.goals

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.shift.app.data.local.entities.goals.FinancialChangeOutboxEntity
import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.data.local.entities.goals.GoalActivityEntity
import com.shift.app.data.local.entities.goals.GoalConditionEntity
import com.shift.app.data.local.entities.goals.GoalCostEstimateEntity
import com.shift.app.data.local.entities.goals.GoalEvaluationEntity
import com.shift.app.data.local.entities.goals.GoalFundingTransactionEntity
import com.shift.app.data.local.entities.goals.GoalMetricEntity
import com.shift.app.data.local.entities.goals.GoalScopeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialGoalDao {
    @Query("SELECT * FROM financial_goals WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun observeActive(): Flow<List<FinancialGoalEntity>>

    @Query("SELECT * FROM financial_goals ORDER BY updatedAt DESC")
    suspend fun getAllOnce(): List<FinancialGoalEntity>

    @Query("SELECT * FROM financial_goals WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): FinancialGoalEntity?

    @Query("SELECT * FROM financial_goals WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<FinancialGoalEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: FinancialGoalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<FinancialGoalEntity>)

    @Update
    suspend fun update(entity: FinancialGoalEntity)

    @Query("DELETE FROM financial_goals")
    suspend fun deleteAll()
}

@Dao
interface GoalMetricDao {
    @Query("SELECT * FROM goal_metrics WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY ordinal")
    suspend fun getForGoal(goalId: String): List<GoalMetricEntity>

    @Query("SELECT * FROM goal_metrics ORDER BY goalId, ordinal")
    suspend fun getAllOnce(): List<GoalMetricEntity>

    @Query("SELECT * FROM goal_metrics WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalMetricEntity?

    @Query("SELECT * FROM goal_metrics WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalMetricEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(entities: List<GoalMetricEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalMetricEntity>)

    @Query("DELETE FROM goal_metrics")
    suspend fun deleteAll()
}

@Dao
interface GoalConditionDao {
    @Query("SELECT * FROM goal_conditions WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY ordinal")
    suspend fun getForGoal(goalId: String): List<GoalConditionEntity>

    @Query("SELECT * FROM goal_conditions ORDER BY goalId, ordinal")
    suspend fun getAllOnce(): List<GoalConditionEntity>

    @Query("SELECT * FROM goal_conditions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalConditionEntity?

    @Query("SELECT * FROM goal_conditions WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalConditionEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(entities: List<GoalConditionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalConditionEntity>)

    @Query("DELETE FROM goal_conditions")
    suspend fun deleteAll()
}

@Dao
interface GoalScopeDao {
    @Query("SELECT * FROM goal_scopes WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY effectiveFrom")
    suspend fun getForGoal(goalId: String): List<GoalScopeEntity>

    @Query("SELECT * FROM goal_scopes ORDER BY goalId, effectiveFrom")
    suspend fun getAllOnce(): List<GoalScopeEntity>

    @Query("SELECT * FROM goal_scopes WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalScopeEntity?

    @Query("SELECT * FROM goal_scopes WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalScopeEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(entities: List<GoalScopeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalScopeEntity>)

    @Query("DELETE FROM goal_scopes")
    suspend fun deleteAll()
}

@Dao
interface GoalFundingTransactionDao {
    @Query("SELECT * FROM goal_funding_transactions WHERE deletedAt IS NULL ORDER BY occurredAt")
    fun observeActive(): Flow<List<GoalFundingTransactionEntity>>

    @Query("SELECT * FROM goal_funding_transactions WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY occurredAt")
    suspend fun getForGoal(goalId: String): List<GoalFundingTransactionEntity>

    @Query("SELECT * FROM goal_funding_transactions ORDER BY goalId, occurredAt")
    suspend fun getAllOnce(): List<GoalFundingTransactionEntity>

    @Query("SELECT * FROM goal_funding_transactions WHERE operationId = :operationId LIMIT 1")
    suspend fun getByOperationId(operationId: String): GoalFundingTransactionEntity?

    @Query("SELECT * FROM goal_funding_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalFundingTransactionEntity?

    @Query("SELECT * FROM goal_funding_transactions WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalFundingTransactionEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: GoalFundingTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalFundingTransactionEntity>)

    @Query("DELETE FROM goal_funding_transactions")
    suspend fun deleteAll()
}

@Dao
interface GoalCostEstimateDao {
    @Query("SELECT * FROM goal_cost_estimates WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY effectiveAt")
    suspend fun getForGoal(goalId: String): List<GoalCostEstimateEntity>

    @Query("SELECT * FROM goal_cost_estimates ORDER BY goalId, effectiveAt")
    suspend fun getAllOnce(): List<GoalCostEstimateEntity>

    @Query("SELECT * FROM goal_cost_estimates WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalCostEstimateEntity?

    @Query("SELECT * FROM goal_cost_estimates WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalCostEstimateEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: GoalCostEstimateEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalCostEstimateEntity>)

    @Query("DELETE FROM goal_cost_estimates")
    suspend fun deleteAll()
}

@Dao
interface GoalEvaluationDao {
    @Query("SELECT * FROM goal_evaluations WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY asOf DESC")
    suspend fun getForGoal(goalId: String): List<GoalEvaluationEntity>

    @Query("SELECT * FROM goal_evaluations ORDER BY goalId, asOf")
    suspend fun getAllOnce(): List<GoalEvaluationEntity>

    @Query("SELECT * FROM goal_evaluations WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalEvaluationEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: GoalEvaluationEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalEvaluationEntity>)

    @Query("DELETE FROM goal_evaluations")
    suspend fun deleteAll()
}

@Dao
interface GoalActivityDao {
    @Query("SELECT * FROM goal_activities WHERE goalId = :goalId AND deletedAt IS NULL ORDER BY occurredAt DESC")
    fun observeForGoal(goalId: String): Flow<List<GoalActivityEntity>>

    @Query("SELECT * FROM goal_activities ORDER BY goalId, occurredAt")
    suspend fun getAllOnce(): List<GoalActivityEntity>

    @Query("SELECT * FROM goal_activities WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): GoalActivityEntity?

    @Query("SELECT * FROM goal_activities WHERE syncState IN ('pending','failed','conflict','incomplete_remote') ORDER BY updatedAt ASC")
    suspend fun getPendingSync(): List<GoalActivityEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: GoalActivityEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<GoalActivityEntity>)

    @Query("DELETE FROM goal_activities")
    suspend fun deleteAll()
}

@Dao
interface FinancialChangeOutboxDao {
    @Query("SELECT * FROM financial_change_outbox WHERE processedAt IS NULL ORDER BY createdAt LIMIT :limit")
    suspend fun getPending(limit: Int): List<FinancialChangeOutboxEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: FinancialChangeOutboxEntity): Long

    @Query("UPDATE financial_change_outbox SET processedAt = :processedAt WHERE eventId = :eventId")
    suspend fun markProcessed(eventId: String, processedAt: Long)

    @Query("UPDATE financial_change_outbox SET attemptCount = attemptCount + 1, lastError = :error WHERE eventId = :eventId")
    suspend fun markFailed(eventId: String, error: String)

    @Query("DELETE FROM financial_change_outbox")
    suspend fun deleteAll()
}

package com.shift.app.data.backup

import com.shift.app.data.local.entities.goals.FinancialGoalEntity
import com.shift.app.data.local.entities.goals.GoalActivityEntity
import com.shift.app.data.local.entities.goals.GoalConditionEntity
import com.shift.app.data.local.entities.goals.GoalCostEstimateEntity
import com.shift.app.data.local.entities.goals.GoalEvaluationEntity
import com.shift.app.data.local.entities.goals.GoalFundingTransactionEntity
import com.shift.app.data.local.entities.goals.GoalMetricEntity
import com.shift.app.data.local.entities.goals.GoalScopeEntity
import com.shift.app.domain.goals.model.ConditionKind
import com.shift.app.domain.goals.model.CostThreshold
import com.shift.app.domain.goals.model.FundingKind
import com.shift.app.domain.goals.model.GoalHealthStatus
import com.shift.app.domain.goals.model.GoalLifecycleStatus
import com.shift.app.domain.goals.model.GoalType
import com.shift.app.domain.goals.model.MetricType
import com.shift.app.domain.goals.model.ScopeDimension
import kotlinx.serialization.Serializable

@Serializable
data class GoalBackupPayload(
    val schemaVersion: Int = 17,
    val goals: List<GoalBackup> = emptyList(),
    val metrics: List<GoalMetricBackup> = emptyList(),
    val conditions: List<GoalConditionBackup> = emptyList(),
    val scopes: List<GoalScopeBackup> = emptyList(),
    val fundingTransactions: List<GoalFundingTransactionBackup> = emptyList(),
    val costEstimates: List<GoalCostEstimateBackup> = emptyList(),
    val evaluations: List<GoalEvaluationBackup> = emptyList(),
    val activities: List<GoalActivityBackup> = emptyList()
) {
    fun validateForRestore() {
        val goalIds = goals.map { it.id }.toSet()
        val metricIds = metrics.map { it.id }.toSet()
        val fundingIds = fundingTransactions.map { it.id }.toSet()
        val evaluationIds = evaluations.map { it.id }.toSet()

        require(goals.map { it.id }.distinct().size == goals.size) { "Duplicate financial goal id" }
        require(metrics.map { it.id }.distinct().size == metrics.size) { "Duplicate goal metric id" }
        require(conditions.map { it.id }.distinct().size == conditions.size) { "Duplicate goal condition id" }
        require(scopes.map { it.id }.distinct().size == scopes.size) { "Duplicate goal scope id" }
        require(fundingTransactions.map { it.id }.distinct().size == fundingTransactions.size) {
            "Duplicate goal funding transaction id"
        }
        require(fundingTransactions.map { it.operationId }.distinct().size == fundingTransactions.size) {
            "Duplicate goal funding operation id"
        }
        require(costEstimates.map { it.id }.distinct().size == costEstimates.size) { "Duplicate goal cost id" }
        require(costEstimates.map { it.operationId }.distinct().size == costEstimates.size) {
            "Duplicate goal cost operation id"
        }
        require(evaluations.map { it.id }.distinct().size == evaluations.size) { "Duplicate goal evaluation id" }
        require(activities.map { it.id }.distinct().size == activities.size) { "Duplicate goal activity id" }

        require(metrics.all { it.goalId in goalIds }) { "Goal backup has orphan metrics" }
        require(conditions.all { it.goalId in goalIds && (it.metricId == null || it.metricId in metricIds) }) {
            "Goal backup has orphan conditions"
        }
        require(scopes.all { it.goalId in goalIds }) { "Goal backup has orphan scopes" }
        require(fundingTransactions.all {
            it.goalId in goalIds && (it.relatedFundingTransactionId == null || it.relatedFundingTransactionId in fundingIds)
        }) { "Goal backup has orphan funding transactions" }
        require(costEstimates.all { it.goalId in goalIds }) { "Goal backup has orphan cost estimates" }
        require(evaluations.all { it.goalId in goalIds && (it.correctionOfId == null || it.correctionOfId in evaluationIds) }) {
            "Goal backup has orphan evaluations"
        }
        require(activities.all { it.goalId in goalIds }) { "Goal backup has orphan activities" }
    }
}

@Serializable data class GoalBackup(val id: String, val name: String, val type: GoalType, val lifecycleStatus: GoalLifecycleStatus, val healthStatus: GoalHealthStatus, val currencyCode: String, val startDate: String, val deadline: String, val timezoneId: String, val targetDecimal: String, val baselineDecimal: String? = null, val targetPercentDecimal: String? = null, val confirmationPeriods: Int, val costThreshold: CostThreshold? = null, val configJson: String, val revision: Long, val readyAt: Long? = null, val completedAt: Long? = null, val cancelledAt: Long? = null, val archivedAt: Long? = null, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalMetricBackup(val id: String, val goalId: String, val metricType: MetricType, val windowType: String, val windowSize: Int, val baselineDecimal: String? = null, val configJson: String, val ordinal: Int, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalConditionBackup(val id: String, val goalId: String, val metricId: String? = null, val kind: ConditionKind, val operator: String, val valueDecimal: String? = null, val required: Boolean, val configJson: String, val ordinal: Int, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalScopeBackup(val id: String, val goalId: String, val dimension: ScopeDimension, val referenceId: String, val mode: String, val reason: String, val effectiveFrom: String, val effectiveTo: String? = null, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalFundingTransactionBackup(val id: String, val goalId: String, val operationId: String, val kind: FundingKind, val amountDecimal: String, val currencyCode: String, val balanceTransactionId: String? = null, val relatedFundingTransactionId: String? = null, val note: String, val occurredAt: Long, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalCostEstimateBackup(val id: String, val goalId: String, val operationId: String, val minDecimal: String? = null, val expectedDecimal: String, val safeDecimal: String, val currencyCode: String, val source: String, val note: String, val effectiveAt: Long, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalEvaluationBackup(val id: String, val goalId: String, val asOf: Long, val engineVersion: String, val inputFingerprint: String, val lifecycleStatus: GoalLifecycleStatus, val healthStatus: GoalHealthStatus, val measuredDecimal: String? = null, val targetDecimal: String? = null, val progressDecimal: String? = null, val resultJson: String, val correctionOfId: String? = null, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)
@Serializable data class GoalActivityBackup(val id: String, val goalId: String, val operationId: String, val type: String, val occurredAt: Long, val effectiveDate: String? = null, val detailsJson: String, val syncState: String, val createdAt: Long, val updatedAt: Long, val deletedAt: Long? = null)

object GoalBackupMapper {
    val restoreOrder: List<String> = listOf(
        "financial_goals",
        "goal_metrics",
        "goal_conditions",
        "goal_scopes",
        "goal_funding_transactions",
        "goal_cost_estimates",
        "goal_evaluations",
        "goal_activities"
    )

    fun fromEntities(
        goals: List<FinancialGoalEntity>,
        metrics: List<GoalMetricEntity>,
        conditions: List<GoalConditionEntity>,
        scopes: List<GoalScopeEntity>,
        fundingTransactions: List<GoalFundingTransactionEntity>,
        costEstimates: List<GoalCostEstimateEntity>,
        evaluations: List<GoalEvaluationEntity>,
        activities: List<GoalActivityEntity>
    ): GoalBackupPayload = GoalBackupPayload(
        goals = goals.map { it.toBackup() },
        metrics = metrics.map { it.toBackup() },
        conditions = conditions.map { it.toBackup() },
        scopes = scopes.map { it.toBackup() },
        fundingTransactions = fundingTransactions.map { it.toBackup() },
        costEstimates = costEstimates.map { it.toBackup() },
        evaluations = evaluations.map { it.toBackup() },
        activities = activities.map { it.toBackup() }
    )
}

private fun FinancialGoalEntity.toBackup() = GoalBackup(id, name, type, lifecycleStatus, healthStatus, currencyCode, startDate, deadline, timezoneId, targetDecimal, baselineDecimal, targetPercentDecimal, confirmationPeriods, costThreshold, configJson, revision, readyAt, completedAt, cancelledAt, archivedAt, syncState, createdAt, updatedAt, deletedAt)
private fun GoalMetricEntity.toBackup() = GoalMetricBackup(id, goalId, metricType, windowType, windowSize, baselineDecimal, configJson, ordinal, syncState, createdAt, updatedAt, deletedAt)
private fun GoalConditionEntity.toBackup() = GoalConditionBackup(id, goalId, metricId, kind, operator, valueDecimal, required, configJson, ordinal, syncState, createdAt, updatedAt, deletedAt)
private fun GoalScopeEntity.toBackup() = GoalScopeBackup(id, goalId, dimension, referenceId, mode, reason, effectiveFrom, effectiveTo, syncState, createdAt, updatedAt, deletedAt)
private fun GoalFundingTransactionEntity.toBackup() = GoalFundingTransactionBackup(id, goalId, operationId, kind, amountDecimal, currencyCode, balanceTransactionId, relatedFundingTransactionId, note, occurredAt, syncState, createdAt, updatedAt, deletedAt)
private fun GoalCostEstimateEntity.toBackup() = GoalCostEstimateBackup(id, goalId, operationId, minDecimal, expectedDecimal, safeDecimal, currencyCode, source, note, effectiveAt, syncState, createdAt, updatedAt, deletedAt)
private fun GoalEvaluationEntity.toBackup() = GoalEvaluationBackup(id, goalId, asOf, engineVersion, inputFingerprint, lifecycleStatus, healthStatus, measuredDecimal, targetDecimal, progressDecimal, resultJson, correctionOfId, createdAt, updatedAt, deletedAt)
private fun GoalActivityEntity.toBackup() = GoalActivityBackup(id, goalId, operationId, type, occurredAt, effectiveDate, detailsJson, syncState, createdAt, updatedAt, deletedAt)

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ShiftApp"
include(":app")
include(":core:model")
include(":core:sync")
include(":feature:ledger")
include(":feature:auth")
include(":feature:assets")
include(":feature:debts")
include(":feature:goals")
include(":feature:reports")
